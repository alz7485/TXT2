from pathlib import Path
s=Path(__file__).with_name('main.py').read_text(encoding='utf-8')
for marker in ('def show_diagnostics(self):', "('読み込み失敗','failures')", "('読み込み注意','warnings')", 'if self.sender() is not self.worker:', 'if self.worker is not None and self.worker.isInterruptionRequested():'):
    assert marker in s,marker
print('trial22 static checks OK')
