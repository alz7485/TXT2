import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import tempfile,copy,json,unittest
from pathlib import Path
from unittest.mock import patch
from outlook_mail import DEFAULT_MAIL_SETTINGS,validate_mail_settings,addresses,build_mail_plans
from microsoft_mail import process_graph_plans
from engine import save_json,DEFAULT
from PySide6.QtWidgets import QApplication
import runtime_paths
IMPORT=tempfile.TemporaryDirectory()
with patch.object(runtime_paths,'get_data_dir',return_value=Path(IMPORT.name)):import main
APP=QApplication.instance() or QApplication([])
APP.setQuitOnLastWindowClosed(False)
class Mail(unittest.TestCase):
 def settings(self,auto=False):return {**DEFAULT_MAIL_SETTINGS,'auto_send':auto,'account':'operator@example.com','always_to':'担当者 <fixed@example.com>','always_cc':'cc@example.com; CC@example.com','sender_name':'担当者','signature':'部署名'}
 def plans(self):
  rows=[dict(employee='E1',staff='S1',name='社員一',date='2026-10-01',field='始業',xlsx='9:00',csv='9:05',status='不一致'),dict(employee='E1',staff='S1',name='社員一',date='2026-10-02',field='終業',xlsx='',csv='18:00',status='不一致'),dict(employee='E2',staff='S2',name='社員二',date='2026-10-01',field='始業',xlsx='8:00',csv='8:10',status='不一致'),dict(employee='E2',staff='S2',name='社員二',date='2026-10-02',field='始業',xlsx='8:00',csv='8:00',status='一致')]
  contacts={'contacts':[{'employee':'E1','staff':'S1','name':'社員一','email':'one@example.com'},{'employee':'E2','staff':'S2','name':'社員二','email':'two@example.com'}]}
  return build_mail_plans(rows,contacts,{'E1':'S1','E2':'S2'},self.settings(),{'year':2026,'month':10})
 def test_separate_employee_bodies_to_and_cc(self):
  plans=self.plans();self.assertEqual(len(plans),2);self.assertEqual(plans[0]['count'],2);self.assertEqual(plans[1]['count'],1)
  self.assertIn('one@example.com',plans[0]['to']);self.assertIn('fixed@example.com',plans[0]['to']);
  from microsoft_mail import graph_payload
  self.assertEqual(graph_payload(plans[0])['toRecipients'][1]['emailAddress']['name'],'担当者');self.assertEqual(plans[0]['cc'],['cc@example.com'])
  self.assertIn('社員一殿',plans[0]['body']);self.assertIn('社員一殿',plans[0]['subject']);self.assertIn('派遣元：',plans[0]['body']);self.assertIn('派遣先：',plans[0]['body']);self.assertNotIn('XLSX',plans[0]['body']);self.assertNotIn('CSV',plans[0]['body']);self.assertIn('（空欄）',plans[0]['body']);self.assertNotIn('社員二',plans[0]['body']);self.assertNotIn('2026-10-02',plans[1]['body'])
 def test_missing_employee_email_never_sends_only_to_fixed(self):
  plan=build_mail_plans([dict(employee='E1',staff='S1',name='名前',status='不一致')],{'contacts':[]},{'E1':'S1'},self.settings(),{'year':2026,'month':10})[0]
  self.assertTrue(plan['problem'])
  with tempfile.TemporaryDirectory() as t:
   calls=[]
   with self.assertRaises(ValueError):process_graph_plans([plan],self.settings(True),t,lambda *args:calls.append(args))
   self.assertFalse(calls)
 def test_template_validation(self):
  for update in [{'body':'確認してください'},{'body':'{differences} {unknown}'},{'subject':'x\nBcc:y'},{'auto_send':'true'},{'always_to':'invalid'}]:
   with self.assertRaises(ValueError):validate_mail_settings({**DEFAULT_MAIL_SETTINGS,**update})
  from microsoft_mail import _validate_graph_settings
  with self.assertRaises(ValueError):_validate_graph_settings({**DEFAULT_MAIL_SETTINGS,'client_id':'not-uuid'})
  self.assertFalse(DEFAULT_MAIL_SETTINGS['auto_send']);self.assertEqual(addresses('人名 <a@example.com>; b@example.com'),['a@example.com','b@example.com'])
 def test_default_drafts_do_not_call_send(self):
  with tempfile.TemporaryDirectory() as t:
   calls=[]
   def transport(method,path,payload):calls.append((method,path,payload));return {'id':'draft'+str(len(calls)),'_http_status':201}
   results=process_graph_plans(self.plans(),self.settings(),t,transport)
   self.assertTrue(all(r['status']=='下書き保存済み' for r in results));self.assertEqual(len(calls),2);self.assertTrue(all(c[1]=='/me/messages' for c in calls))
   results=process_graph_plans(self.plans(),self.settings(),t,transport);self.assertEqual(len(calls),2)
 def test_auto_send_and_duplicate_prevention(self):
  with tempfile.TemporaryDirectory() as t:
   calls=[]
   def transport(method,path,payload):calls.append((method,path,payload));return {'_http_status':202} if path.endswith('/send') else {'id':'draft/id'}
   results=process_graph_plans(self.plans(),self.settings(True),t,transport)
   self.assertEqual(len(calls),4);self.assertTrue(all(r['status']=='送信受付済み' for r in results));self.assertIn('draft%2Fid/send',calls[1][1])
   process_graph_plans(self.plans(),self.settings(True),t,transport);self.assertEqual(len(calls),4)
 def test_ambiguous_send_failure_not_retried_and_rest_not_sent(self):
  with tempfile.TemporaryDirectory() as t:
   calls=[]
   def transport(method,path,payload):
    calls.append(path)
    if path.endswith('/send'):raise TimeoutError('synthetic timeout')
    return {'id':'draft1'}
   result=process_graph_plans(self.plans(),self.settings(True),t,transport)
   self.assertEqual(len(calls),2);self.assertEqual(result[1]['status'],'未処理')
   ledger=json.loads((Path(t)/'mail_processing_history.json').read_text());self.assertEqual(next(iter(ledger.values()))['status'],'sending')
   process_graph_plans([self.plans()[0]],self.settings(True),t,transport);self.assertEqual(len(calls),2)
 def test_history_save_failure_prevents_network(self):
  with tempfile.TemporaryDirectory() as t:
   calls=[]
   with patch('microsoft_mail.save_json',side_effect=PermissionError('denied')):result=process_graph_plans(self.plans(),self.settings(True),t,lambda *args:calls.append(args))
   self.assertFalse(calls);self.assertTrue(result[0].get('error'))
 def test_setting_roundtrip_and_json_auto_send(self):
  window=main.Window();dialog=main.SettingsDialog(window,copy.deepcopy(DEFAULT));self.assertEqual(dialog.mail_controls['name_suffix'].text(),'殿');dialog.mail_controls['name_suffix'].setText('様');dialog.mail_controls['auto_send'].setChecked(True);dialog.mail_controls['always_cc'].setText('cc@example.com');dialog.mail_controls['sender_name'].setText('確認担当');dialog.accept()
  self.assertEqual(dialog.result(),main.QDialog.Accepted);self.assertTrue(dialog.value['mail_settings']['auto_send']);self.assertEqual(dialog.value['mail_settings']['sender_name'],'確認担当')
  reopened=main.SettingsDialog(window,dialog.value);self.assertTrue(reopened.mail_controls['auto_send'].isChecked());self.assertEqual(reopened.mail_controls['name_suffix'].text(),'様');reopened.close();dialog.close();window.close()
 def test_button_left_of_print_and_visible_scope(self):
  window=main.Window();window.show();APP.processEvents();self.assertLess(window.mail_button.x(),window.print_button.x());self.assertFalse(window.mail_button.isEnabled())
  window.results=[dict(employee='E1',staff='S1',name='社員一',date='2026-10-01',field='始業',xlsx='9:00',csv='9:05',status='不一致')];window.show_results();self.assertTrue(window.mail_button.isEnabled())
  window.select_filter('一致のみ');self.assertFalse(window.mail_button.isEnabled());window.close()
 def test_authentication_scopes_and_expected_account(self):
  import sys
  from unittest.mock import Mock
  from microsoft_mail import authenticate
  settings={**self.settings(),'client_id':'11111111-1111-1111-1111-111111111111'}
  for auto in (False,True):
   settings['auto_send']=auto;cache=Mock();application=Mock();application.get_accounts.return_value=[{'username':'operator@example.com'}];application.acquire_token_silent.return_value={'access_token':'synthetic-token'}
   fake=Mock();fake.SerializableTokenCache.return_value=cache;fake.PublicClientApplication.return_value=application
   with tempfile.TemporaryDirectory() as t,patch.dict(sys.modules,{'msal':fake}),patch('sys.platform','linux'),patch('microsoft_mail.graph_request',return_value={'mail':'operator@example.com'}):
    self.assertEqual(authenticate(settings,t),'synthetic-token')
   scopes=application.acquire_token_silent.call_args.args[0];self.assertEqual('Mail.Send' in scopes,auto)
 def test_authentication_wrong_account_rejected(self):
  import sys
  from unittest.mock import Mock
  from microsoft_mail import authenticate
  settings={**self.settings(),'client_id':'11111111-1111-1111-1111-111111111111'};fake=Mock();application=fake.PublicClientApplication.return_value;application.get_accounts.return_value=[{}];application.acquire_token_silent.return_value={'access_token':'synthetic-token'}
  with tempfile.TemporaryDirectory() as t,patch.dict(sys.modules,{'msal':fake}),patch('sys.platform','linux'),patch('microsoft_mail.graph_request',return_value={'mail':'wrong@example.com'}):
   with self.assertRaises(RuntimeError):authenticate(settings,t)
 def test_parallel_mail_processing_is_blocked(self):
  from microsoft_mail import mail_lock
  with tempfile.TemporaryDirectory() as t,mail_lock(t):
   calls=[]
   with self.assertRaises(RuntimeError):process_graph_plans(self.plans(),self.settings(True),t,lambda *args:calls.append(args))
   self.assertFalse(calls)
 def test_actual_dialog_auto_send_mode_uses_classic_worker(self):
  from outlook_mail import show_mail_dialog
  from PySide6.QtCore import QTimer
  from PySide6.QtWidgets import QPushButton,QTableWidget
  window=main.Window();errors=[];calls=[];attempts=[0]
  def process(plans,settings,data_dir):
   calls.append((plans,settings['auto_send']));return [{'employee':p['employee'],'status':'送信要求済み'} for p in plans]
  def finish():
   attempts[0]+=1;dialog=APP.activeModalWidget()
   if dialog is None:return
   table=dialog.findChild(QTableWidget)
   if table.item(0,3).text()=='送信要求済み':dialog.reject();return
   if attempts[0]>100:errors.append('worker timeout');dialog.reject();return
   QTimer.singleShot(20,finish)
  def start():
   dialog=APP.activeModalWidget();next(b for b in dialog.findChildren(QPushButton) if b.text()=='選択したメールを送信').click();QTimer.singleShot(20,finish)
  with tempfile.TemporaryDirectory() as t,patch('classic_outlook.process_classic_plans',side_effect=process),patch('PySide6.QtWidgets.QMessageBox.information'),patch('PySide6.QtWidgets.QMessageBox.warning'):
   QTimer.singleShot(0,start);show_mail_dialog(window,[self.plans()[0]],self.settings(True),t)
  self.assertFalse(errors,errors);self.assertEqual(len(calls),1);self.assertTrue(calls[0][1]);window.close()
if __name__=='__main__':unittest.main(verbosity=2)
