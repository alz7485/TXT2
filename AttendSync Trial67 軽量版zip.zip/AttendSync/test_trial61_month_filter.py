"""Missing-month view filtering with real attendance data and Qt interactions."""
import copy
import unittest
from pathlib import Path
from unittest.mock import patch
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
import test_trial38_audit as fixture
import main
from result_filters import csv_month_coverage, missing_csv_months, is_missing_month_csv_gap


class MonthFilter61(unittest.TestCase):
    setUpClass = classmethod(fixture.Audit38.setUpClass.__func__)
    setUp = fixture.Audit38.setUp

    def load_only(self, month):
        data = [row for row in self.cdata if row['date'].startswith(month)]
        self.w.read_done(copy.deepcopy(self.xdata), copy.deepcopy(data), [],
                         dict(elapsed=.1, cache_hits=0, parsed=5, files_found=5, files_completed=5))

    def test_current_csv_only_hides_previous_month_by_default_and_off_restores(self):
        self.load_only('2026-10')
        checkbox = self.w.hide_missing_csv_months
        self.assertTrue(checkbox.isChecked())
        self.assertEqual(checkbox.text(), 'CSVが無い月度分は非表示')
        hidden = [r for r in self.w.results if r['field'] == 'CSV記録なし' and r['date'].startswith('2026-09')]
        self.assertTrue(hidden)
        self.assertEqual(self.w.hidden_csv_month_rows_count, len(hidden))
        self.assertFalse(any(r['field'] == 'CSV記録なし' for r in self.w.visible))
        self.assertTrue(any(r['status'] == '不一致' for r in self.w.visible))
        self.assertIn('2026/09', self.w.count_label.text())
        raw = copy.deepcopy(self.w.results); summary = copy.deepcopy(self.w.comparison_summary)
        with patch.object(self.w, 'run_read') as reader, patch.object(main, 'save_json') as writer:
            checkbox.setChecked(False)
            self.assertTrue(any(r in self.w.visible for r in hidden))
            checkbox.setChecked(True)
            reader.assert_not_called(); writer.assert_not_called()
        self.assertEqual(self.w.results, raw)
        self.assertEqual(self.w.comparison_summary, summary)

    def test_previous_csv_only_hides_current_month(self):
        self.load_only('2026-09')
        self.assertTrue(self.w.hidden_csv_month_rows_count)
        self.assertIn('2026/10', self.w.count_label.text())
        self.assertFalse(any(r['field'] == 'CSV記録なし' and r['date'].startswith('2026-10') for r in self.w.visible))

    def test_one_file_with_both_months_does_not_hide_employee_missing_days(self):
        data = [r for r in self.cdata if not (r['staff'] == 'S001' and r['date'] == '2026-09-16')]
        for row in data: row['file'] = 'combined.csv'
        self.w.read_done(self.xdata, data, [], dict(elapsed=.1, cache_hits=0, parsed=5, files_found=5, files_completed=5))
        self.assertEqual(self.w.hidden_csv_month_rows_count, 0)
        self.assertTrue(any(r['employee'] == '10001' and r['date'] == '2026-09-16'
                            and r['field'] == 'CSV記録なし' for r in self.w.visible))

    def test_employee_absent_for_whole_month_is_not_global_month_absence(self):
        data = [r for r in self.cdata if not (r['staff'] == 'S001' and r['date'].startswith('2026-09'))]
        self.w.read_done(self.xdata, data, [], dict(elapsed=.1, cache_hits=0, parsed=6, files_found=6, files_completed=6))
        self.assertEqual(self.w.hidden_csv_month_rows_count, 0)
        self.assertTrue(any(r['employee'] == '10001' and r['field'] == 'CSV記録なし' for r in self.w.visible))

    def test_filters_search_print_and_all_mode_use_same_visible_rows(self):
        self.load_only('2026-10')
        hidden_count = self.w.hidden_csv_month_rows_count
        self.w.select_filter('すべて')
        self.assertEqual(len(self.w.visible), len(self.w.results) - hidden_count)
        self.w.search.setText('10001')
        self.assertTrue(self.w.visible)
        self.assertTrue(all(r['employee'] == '10001' for r in self.w.visible))
        self.assertFalse(any(r['field'] == 'CSV記録なし' for r in self.w.visible))
        with patch.object(main, 'print_html') as printer: self.w.print_list(preview=True)
        html = printer.call_args.args[1]
        self.assertNotIn('CSV記録なし', html)
        self.w.hide_missing_csv_months.setChecked(False)
        self.assertTrue(any(r['field'] == 'CSV記録なし' for r in self.w.visible))

    def test_pending_month_setting_does_not_change_completed_result_filter(self):
        self.load_only('2026-10')
        before = list(self.w.visible)
        self.w.cfg['year'] = 2027; self.w.cfg['month'] = 1
        self.w.year.setValue(2027); self.w.month.setValue(1)
        self.w.show_results()
        self.assertEqual(self.w.visible, before)

    def test_year_boundary_and_corrupt_dates(self):
        cfg = dict(year=2027, month=1)
        months = csv_month_coverage([{'date':'2027-01-05'}, {'date':'not-a-date'}, {'date':'2027-02-30'}])
        absent = missing_csv_months(months, cfg)
        self.assertEqual(absent, {'2026-12'})
        base = dict(status='要確認', field='CSV記録なし', crecord=None)
        self.assertTrue(is_missing_month_csv_gap({**base, 'date':'2026-12-16'}, absent, cfg))
        self.assertFalse(is_missing_month_csv_gap({**base, 'date':'2026-12-15'}, absent, cfg))
        self.assertFalse(is_missing_month_csv_gap({**base, 'date':'bad'}, absent, cfg))

    def test_empty_wrong_month_and_failed_csv_do_not_hide_review(self):
        cfg = dict(year=2026, month=10)
        for months in [None, frozenset(), {'2026-11'}]:
            self.assertFalse(missing_csv_months(months, cfg))
        current = [{'date':'2026-10-01'}]
        self.assertIsNone(csv_month_coverage(current, [{'file':'September.CSV','reason':'read failed'}]))
        self.assertIsNone(csv_month_coverage(current, warnings=[{'file':'September.csv','reason':'日付不正'}]))
        self.assertIsNone(csv_month_coverage(current, warnings=[{'file':'September.csv','reason':'IDまたは日付が空欄'}]))
        # A bad time still identifies the month and must remain a visible input issue.
        self.assertEqual(csv_month_coverage(current, warnings=[{'file':'October.csv','reason':'時刻の値が不正'}]), {'2026-10'})

    def test_unrelated_review_and_corrupt_xlsx_rows_remain_visible(self):
        cfg = dict(year=2026, month=10); absent = {'2026-09'}
        base = dict(status='要確認', date='2026-09-20', crecord=None)
        for field in ['CSV入力異常：始業時刻', 'スタッフID未紐付け', 'XLSX同日重複（2行）',
                      'ファイル読み込み失敗', '期間整合性：XLSX記録なし']:
            self.assertFalse(is_missing_month_csv_gap({**base, 'field':field}, absent, cfg))
        self.assertFalse(is_missing_month_csv_gap({**base, 'field':'CSV記録なし',
                         'xrecord':{'invalid_fields':['start']}}, absent, cfg))
        self.assertTrue(is_missing_month_csv_gap({**base, 'field':'期間整合性：CSV記録なし'}, absent, cfg))

    def test_failed_or_cancelled_read_keeps_previous_month_filter(self):
        self.load_only('2026-10'); before = list(self.w.visible)
        for stats in [dict(cancelled=True), dict(fatal_error='failed', file_errors=[{'file':'bad.csv','reason':'failed'}])]:
            self.w.read_done({}, [], [], stats)
            self.assertEqual(self.w.visible, before)

    def test_hidden_only_results_do_not_claim_everything_matched(self):
        self.w.results_cfg = dict(year=2026, month=10)
        self.w.result_csv_months = {'2026-10'}
        self.w.results = [dict(status='要確認', date='2026-09-20', employee='E1', staff='S1',
                              name='確認社員', field='CSV記録なし', xlsx='—', csv='—', crecord=None)]
        self.w.show_results()
        self.assertFalse(self.w.visible)
        self.assertIn('表示対象', self.w.empty_state.title.text())
        self.assertIn('チェックを外す', self.w.empty_state.caption.text())


if __name__ == '__main__': unittest.main(verbosity=2)
