"""Route a single local CSV drop across one dialog and its child controls."""
from pathlib import Path
from PySide6.QtCore import QObject, QEvent, Qt, Signal
from PySide6.QtWidgets import QWidget


class CsvDropHandler(QObject):
    ready = Signal(str)

    def __init__(self, dialog, callback):
        super().__init__(dialog)
        self.dialog = dialog
        self.callback = callback
        self.pending = False
        self.ready.connect(self.deliver, Qt.QueuedConnection)
        self.attach(dialog)

    def attach(self, widget):
        if widget.window() is not self.dialog:
            return
        widget.setAcceptDrops(True)
        widget.installEventFilter(self)
        for child in widget.findChildren(QWidget):
            if child.window() is self.dialog:
                child.setAcceptDrops(True)
                child.installEventFilter(self)

    @staticmethod
    def csv_path(event):
        mime = event.mimeData()
        if not mime.hasUrls():
            return ''
        urls = mime.urls()
        if len(urls) != 1 or not urls[0].isLocalFile():
            return ''
        path = Path(urls[0].toLocalFile())
        try:
            return str(path) if path.suffix.casefold() == '.csv' and path.is_file() else ''
        except OSError:
            return ''

    def deliver(self, path):
        try:
            if self.dialog.isVisible() and self.dialog.isEnabled():
                self.callback(path)
        finally:
            self.pending = False

    def eventFilter(self, watched, event):
        if not isinstance(watched, QWidget) or watched.window() is not self.dialog:
            return super().eventFilter(watched, event)
        if event.type() == QEvent.ChildPolished:
            child = event.child()
            if isinstance(child, QWidget):
                self.attach(child)
        if event.type() in (QEvent.DragEnter, QEvent.DragMove, QEvent.Drop):
            path = self.csv_path(event)
            if (path and not self.pending and self.dialog.isEnabled()
                    and event.possibleActions() & Qt.CopyAction):
                event.setDropAction(Qt.CopyAction)
                event.accept()
                if event.type() == QEvent.Drop:
                    self.pending = True
                    self.ready.emit(path)
            else:
                event.ignore()
            return True
        return super().eventFilter(watched, event)
