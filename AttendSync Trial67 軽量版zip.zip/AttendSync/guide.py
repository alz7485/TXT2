"""On-screen guide (coach marks) for the main window.

A translucent overlay draws a red frame around the widget(s) the user
should touch next, while a panel in the centre of the window explains
what to do.  The overlay never intercepts mouse events (only the panel
does), so the highlighted control stays clickable while its guide is up.

The manager is event driven: real work events advance the tour
(employee registration saved, folder chosen, read finished, ...), and
each panel also offers a manual "next" button for steps that are already
done.  Display preferences are shared with 設定 → ガイド through
``guide_config`` and persisted to the main settings JSON as soon as a
checkbox is toggled.
"""
from __future__ import annotations

import copy

from PySide6.QtCore import QEvent, QObject, QPoint, QRect, Qt, QTimer
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QCheckBox, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from guide_config import (
    GUIDE_STEPS, STEP_IDS, normalize_guide_settings, step_visible,
    visible_step_ids, with_all_off, with_step_hidden,
)
from ui_theme import button, theme_colors

HIGHLIGHT_COLOR = '#e5322d'
PANEL_WIDTH = 470


class HighlightOverlay(QWidget):
    """Full-window translucent layer that frames the current targets."""

    def __init__(self, parent):
        super().__init__(parent)
        self._targets = []
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.hide()

    def set_targets(self, widgets):
        self._targets = [widget for widget in widgets if widget is not None]
        self.update()

    def _target_rects(self):
        rects = []
        origin = self.parentWidget()
        for widget in self._targets:
            try:
                if not widget.isVisible():
                    continue
                top_left = widget.mapTo(origin, QPoint(0, 0))
            except RuntimeError:
                continue
            rects.append(QRect(top_left, widget.size()).adjusted(-6, -6, 6, 6))
        return rects

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        rects = self._target_rects()
        shade = QPainterPath()
        shade.addRect(self.rect())
        for rect in rects:
            hole = QPainterPath()
            hole.addRoundedRect(rect, 10, 10)
            shade = shade.subtracted(hole)
        painter.fillPath(shade, QColor(13, 22, 40, 96))
        pen = QPen(QColor(HIGHLIGHT_COLOR), 3)
        painter.setPen(pen)
        painter.setBrush(Qt.NoBrush)
        for rect in rects:
            painter.drawRoundedRect(rect, 10, 10)
        painter.end()


class GuidePanel(QWidget):
    """Centre panel: step title, explanation, hide checkboxes, actions."""

    def __init__(self, parent, manager):
        super().__init__(parent)
        self._manager = manager
        self.setObjectName('guidePanel')
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setFixedWidth(PANEL_WIDTH)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(9)

        top = QHBoxLayout()
        self.step_label = QLabel('')
        self.step_label.setObjectName('guideStep')
        top.addWidget(self.step_label)
        top.addStretch()
        self.close_button = QPushButton('×')
        self.close_button.setObjectName('guideClose')
        self.close_button.setFixedSize(26, 26)
        self.close_button.setToolTip('ガイドを閉じる（今回だけ）')
        self.close_button.clicked.connect(manager.dismiss)
        top.addWidget(self.close_button)
        layout.addLayout(top)

        self.title_label = QLabel('')
        self.title_label.setObjectName('guideTitle')
        self.title_label.setWordWrap(True)
        layout.addWidget(self.title_label)

        self.body_label = QLabel('')
        self.body_label.setObjectName('guideBody')
        self.body_label.setWordWrap(True)
        layout.addWidget(self.body_label)

        self.check_all = QCheckBox('次回から全てのガイドを表示しない')
        self.check_all.setObjectName('guideCheckAll')
        self.check_all.toggled.connect(lambda checked: manager.on_hide_choice('all', checked))
        layout.addWidget(self.check_all)
        self.check_step = QCheckBox('次回からこのガイドを表示しない')
        self.check_step.setObjectName('guideCheckStep')
        self.check_step.toggled.connect(lambda checked: manager.on_hide_choice('step', checked))
        layout.addWidget(self.check_step)

        self.notice_label = QLabel('この設定は「設定 → ガイド」からいつでも変更できます。')
        self.notice_label.setObjectName('guideNotice')
        self.notice_label.setWordWrap(True)
        self.notice_label.hide()
        layout.addWidget(self.notice_label)

        actions = QHBoxLayout()
        actions.setSpacing(8)
        self.next_button = button('次へ', 'arrow-right', 'quiet')
        self.next_button.setObjectName('guideNext')
        self.next_button.clicked.connect(manager.advance)
        actions.addWidget(self.next_button)
        actions.addStretch()
        self.action_button = button('', 'play', 'primary')
        self.action_button.setObjectName('guideAction')
        self.action_button.clicked.connect(manager.run_action)
        actions.addWidget(self.action_button)
        layout.addLayout(actions)
        self.hide()

    def present(self, index, step):
        self.step_label.setText(f'ガイド {index + 1} / {len(GUIDE_STEPS)}：使い方の手順')
        self.title_label.setText(step['title'])
        self.body_label.setText(step['body'])
        # A wrapped label's first size hint can understate its height before
        # the panel has been shown once; pin both text labels to their real
        # height-for-width so the text can never overlap the rows below.
        text_width = PANEL_WIDTH - 40
        for lbl in (self.title_label, self.body_label):
            lbl.setFixedHeight(lbl.heightForWidth(text_width))
        self.action_button.setText(step['action'])
        self.action_button.setVisible(bool(step.get('action')))
        self.next_button.setText('ガイドを終わる' if step['id'] == GUIDE_STEPS[-1]['id'] else '次へ')
        settings = self._manager.settings
        self.check_all.blockSignals(True)
        self.check_step.blockSignals(True)
        self.check_all.setChecked(bool(settings['all_off']))
        self.check_step.setChecked(step['id'] in settings['hidden'])
        self.check_all.blockSignals(False)
        self.check_step.blockSignals(False)
        self.notice_label.setVisible(self.check_all.isChecked() or self.check_step.isChecked())
        self.layout().activate()
        self.adjustSize()

    def refresh_style(self, dark):
        c = theme_colors(dark)
        self.setStyleSheet(
            f"QWidget#guidePanel {{ background: {c['panel']}; border: 1.5px solid {HIGHLIGHT_COLOR}; border-radius: 12px; }}"
            f"QLabel#guideStep {{ color: {c['muted']}; font-size: 9pt; }}"
            f"QLabel#guideTitle {{ color: {c['text']}; font-size: 13pt; font-weight: 700; }}"
            f"QLabel#guideBody {{ color: {c['text']}; font-size: 10pt; }}"
            f"QLabel#guideNotice {{ color: {c['warning']}; font-size: 9.5pt; }}"
            f"QPushButton#guideClose {{ background: transparent; border: none; color: {c['muted']}; font-size: 11pt; }}"
        )


class GuideManager(QObject):
    """Owns the overlay + panel and the tour's position for this session."""

    def __init__(self, window, persist=None):
        super().__init__(window)
        self.window = window
        self._persist_callback = persist
        self.settings = normalize_guide_settings(window.cfg.get('guides'))
        self.active = False
        self.finished = False
        self.current_id = None
        self._awaiting_read = False
        self.overlay = HighlightOverlay(window)
        self.panel = GuidePanel(window, self)
        self.panel.refresh_style(window.is_dark)
        window.installEventFilter(self)

    # -- settings -----------------------------------------------------
    def _persist(self):
        """Save guide preferences immediately, preserving all other settings."""
        if self._persist_callback is None:
            return False
        try:
            return bool(self._persist_callback(copy.deepcopy(self.settings)))
        except Exception:
            return False

    def on_hide_choice(self, kind, checked):
        """A panel checkbox was toggled: advise, then persist at once.

        The panel stays up for this run; the choice takes effect from the
        next launch (or the next time the tour reaches that step), exactly
        as the checkbox wording promises.
        """
        if kind == 'all':
            self.settings = with_all_off(self.settings, checked)
        elif self.current_id:
            self.settings = with_step_hidden(self.settings, self.current_id, checked)
        self.panel.notice_label.setVisible(
            self.panel.check_all.isChecked() or self.panel.check_step.isChecked())
        self._persist()

    def apply_settings(self, restart=False):
        """Re-read preferences after 設定 was saved."""
        self.settings = normalize_guide_settings(self.window.cfg.get('guides'))
        if restart:
            self.finished = False
            self.start(force=True)
            return
        if not self.active:
            return
        if self.current_id and not step_visible(self.settings, self.current_id):
            self._show_next_after(self.current_id)
        else:
            self._present_current()

    # -- lifecycle ------------------------------------------------------
    def start(self, force=False):
        if self.active or (self.finished and not force):
            return
        visible = visible_step_ids(self.settings)
        if not visible:
            return
        self.active = True
        self._show(visible[0])

    def dismiss(self):
        """Close the panel for this session only (nothing is persisted)."""
        self.active = False
        self._awaiting_read = False
        self._hide_widgets()

    def finish(self):
        self.active = False
        self.finished = True
        self._awaiting_read = False
        self.current_id = None
        self._hide_widgets()

    def refresh_theme(self):
        self.panel.refresh_style(self.window.is_dark)
        self.overlay.update()

    # -- flow -----------------------------------------------------------
    def _targets_for(self, step_id):
        w = self.window
        if step_id == 'employee':
            return [w.btn_map]
        if step_id == 'period_folder':
            return [w.year, w.month, w.path, w.btn_browse]
        if step_id == 'csv_load':
            return [w.path, w.run_button]
        if step_id == 'results':
            return [getattr(w, 'result_card', None) or w.table]
        if step_id == 'mail':
            return [w.mail_button]
        return []

    def _has_problems(self):
        return any(row.get('status') in ('不一致', '要確認') for row in self.window.results)

    def _has_mismatches(self):
        """Mail can only be created for mismatches — the same condition
        that enables the メールを作成 button.  要確認 alone (missing or
        unlinked data) has nothing to mail, so it must not open the
        mail guide with its button disabled."""
        return any(row.get('status') == '不一致' for row in self.window.results)

    def _show(self, step_id):
        if step_id is None or not step_visible(self.settings, step_id):
            self._show_next_after(step_id)
            return
        # The mail guide only makes sense when the read found mismatches.
        if step_id == 'mail' and not self._has_mismatches():
            self.finish()
            return
        self.current_id = step_id
        self._present_current()

    def _present_current(self):
        step = next(s for s in GUIDE_STEPS if s['id'] == self.current_id)
        self.overlay.set_targets(self._targets_for(self.current_id))
        self.panel.present(STEP_IDS.index(self.current_id), step)
        self._layout_widgets()
        self.overlay.show()
        self.panel.show()
        self.panel.raise_()

    def _show_next_after(self, step_id):
        from guide_config import next_visible_step
        following = next_visible_step(self.settings, step_id)
        if following is None:
            self.finish()
        else:
            self._show(following)

    def advance(self):
        """Manual "next" (also used for steps that are already done)."""
        if not self.active or not self.current_id:
            return
        if self.current_id == 'results' and not self._has_mismatches():
            self.finish()
            return
        self._show_next_after(self.current_id)

    def run_action(self):
        """The panel's primary button performs the step's real action."""
        w = self.window
        step_id = self.current_id
        if step_id == 'employee':
            w.edit_map()
        elif step_id == 'period_folder':
            w.browse()
        elif step_id == 'csv_load':
            w.run_read()
        elif step_id == 'results':
            self.advance()
        elif step_id == 'mail':
            w.compose_mail()

    def notify(self, event):
        """Advance or pause the tour in response to real work events."""
        if event == 'read_started':
            if self.active and self.current_id in ('period_folder', 'csv_load'):
                self._awaiting_read = True
                self._hide_widgets()
            return
        if event == 'read_failed':
            if self._awaiting_read:
                self._awaiting_read = False
                self.active = True
                self._show('csv_load')
            return
        if not self.active:
            return
        if event == 'employee_registered' and self.current_id == 'employee':
            self._show_next_after('employee')
        elif event == 'folder_selected' and self.current_id == 'period_folder':
            # Give the user a moment to see the chosen folder before moving on.
            QTimer.singleShot(500, lambda: self.current_id == 'period_folder' and self._show_next_after('period_folder'))
        elif event == 'read_succeeded' and (self._awaiting_read or self.current_id in ('period_folder', 'csv_load')):
            self._awaiting_read = False
            self._show('results')
        elif event == 'mail_done' and self.current_id == 'mail':
            self.finish()

    # -- geometry -------------------------------------------------------
    def _hide_widgets(self):
        self.overlay.hide()
        self.panel.hide()

    def _layout_widgets(self):
        rect = self.window.rect()
        self.overlay.setGeometry(rect)
        x = max(8, (rect.width() - self.panel.width()) // 2)
        y = max(8, (rect.height() - self.panel.height()) // 2)
        self.panel.move(x, y)

    def eventFilter(self, watched, event):
        if watched is self.window and event.type() in (QEvent.Resize, QEvent.Show):
            if self.panel.isVisible():
                self._layout_widgets()
                self.overlay.update()
        return False
