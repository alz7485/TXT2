from pathlib import Path
import ast
p=Path(__file__).with_name('main.py')
s=p.read_text(encoding='utf-8')
ast.parse(s)
assert "prefix = '要確認・読み込み未完了' if incomplete else '読込完了'" in s
assert "completed < found" in s
assert "self.status.setToolTip" in s
print('Trial29 completion guard static OK')
