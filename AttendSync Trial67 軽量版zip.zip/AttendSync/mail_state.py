"""Shared local mail locking and canonical payload, independent of authentication."""
from pathlib import Path

def mail_identity(plan):
    """Delivery identity is independent of captions, list order and address case."""
    return {'subject':plan['subject'],'body':plan['body'],
            'to':sorted({address.casefold() for address in plan['to']}),
            'cc':sorted({address.casefold() for address in plan['cc']})}

def mail_payload(plan):
    def recipients(addresses):
        names=plan.get('recipient_names',{})
        return [{'emailAddress':dict(address=address,**({'name':names[address]} if names.get(address) else {}))} for address in addresses]
    return {'subject':plan['subject'],'body':{'contentType':'Text','content':plan['body']},
            'toRecipients':recipients(plan['to']),'ccRecipients':recipients(plan['cc'])}


from contextlib import contextmanager
@contextmanager
def mail_lock(data_dir):
    path=Path(data_dir)/'mail_processing.lock';path.parent.mkdir(parents=True,exist_ok=True)
    stream=path.open('a+b');locked=False
    try:
        if path.stat().st_size==0:stream.write(b'0');stream.flush()
        stream.seek(0)
        import sys
        try:
            if sys.platform=='win32':
                import msvcrt
                msvcrt.locking(stream.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
            locked=True
        except OSError as exc:raise RuntimeError('別のメール処理が実行中です。完了後に実行してください。') from exc
        yield
    finally:
        if locked:
            stream.seek(0)
            if sys.platform=='win32':msvcrt.locking(stream.fileno(),msvcrt.LK_UNLCK,1)
            else:fcntl.flock(stream.fileno(),fcntl.LOCK_UN)
        stream.close()

