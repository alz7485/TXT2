"""Completion-audit regressions. Synthetic files and mock Outlook only."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import copy,csv,hashlib,json,sqlite3,tempfile,threading,time,unittest
from pathlib import Path
from unittest.mock import patch
from datetime import date,timedelta
from PySide6.QtWidgets import QApplication,QPushButton,QTableWidget
from PySide6.QtCore import QTimer,Qt
from openpyxl import Workbook
import runtime_paths
IMPORT=tempfile.TemporaryDirectory()
with patch.object(runtime_paths,'get_data_dir',return_value=Path(IMPORT.name)):
    import main
from engine import DEFAULT,Cache,reconcile,save_json,xlsx_read,csv_read
from stable_read import file_signature,parse_stable_file
from classic_outlook import process_classic_plans
from outlook_mail import DEFAULT_MAIL_SETTINGS
from mail_state import mail_payload
from settings_dialog import SettingsDialog,SettingsError
from employee_information import plan_employee_import
from test_trial64_classic_mail import Outlook
APP=QApplication.instance() or QApplication([])
APP.setQuitOnLastWindowClosed(False)

class Completion66(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.state=self.root/'state';self.state.mkdir()
        self.paths=patch.multiple(main,CONFIG=self.state/'settings.json',MAP=self.state/'staff_mapping.json',DB=self.state/'attendance_cache.sqlite3')
        self.paths.start();self.addCleanup(self.paths.stop)
        self.cfg=copy.deepcopy(DEFAULT);self.cfg.update(year=2026,month=10,data_last_row=38)
        self.folder=self.root/'inputs';self.folder.mkdir()
        workbook=Workbook();sheet=workbook.active;sheet.title='10月'
        sheet['A1']='2026年10月度';sheet['N1']='E1';sheet['U1']='Synthetic'
        for i in range(30):
            day=date(2026,9,16)+timedelta(days=i);row=i+9
            for col,value in [('A',day.month),('B',day.day),('G','09:00'),('H','18:00'),('T','08:00')]:sheet[f'{col}{row}']=value
        workbook.save(self.folder/'employee.xlsx');workbook.close()
        self.csv=self.folder/'attendance.csv'
        with self.csv.open('w',newline='') as stream:
            writer=csv.writer(stream);writer.writerow(['header']*14)
            for i in range(30):
                day=date(2026,9,16)+timedelta(days=i);row=['']*14
                row[0]=day.strftime('%Y%m%d');row[3]='S1';row[4]='Synthetic';row[10:14]=['09:00','18:00','08:00','01:00'];writer.writerow(row)
        save_json(main.MAP,{'E1':'S1'})
        save_json(main.MAP.with_name('employee_contacts.json'),{'version':1,'contacts':[dict(employee='E1',staff='S1',name='Synthetic',email='employee@example.invalid')],'employee_information_registered':True})
        with patch.object(main,'current_attendance_month',return_value=(2026,10)):self.window=main.Window()
        self.window.cfg=copy.deepcopy(self.cfg);self.window.mapping={'E1':'S1'}
        self.addCleanup(self.close_window)
    def close_window(self):
        worker=self.window.worker
        if worker is not None and worker.isRunning():worker.cancel();worker.wait(5000)
        self.window.worker=None;self.window.close();APP.processEvents()
    def read(self,full=False,ui=False):
        worker=main.ReadWorker(self.folder,self.cfg,full);out=[]
        worker.result.connect(lambda *args:out.append(args))
        if ui:self.window.worker=worker;worker.result.connect(self.window.read_done)
        worker.run();self.assertEqual(len(out),1);self.assertNotIn('fatal_error',out[0][3]);return out[0]
    def tally(self,result):
        from collections import Counter
        return Counter(r['status'] for r in reconcile(result[0],result[1],{'E1':'S1'},self.cfg)[0])
    def test_content_replacement_with_preserved_metadata_reparses(self):
        self.assertEqual(self.tally(self.read()),{'一致':90})
        self.assertEqual(self.read()[3]['cache_hits'],2)
        st=self.csv.stat();self.csv.write_bytes(self.csv.read_bytes().replace(b'09:00',b'10:00'));os.utime(self.csv,ns=(st.st_atime_ns,st.st_mtime_ns))
        result=self.read();self.assertEqual(result[3]['parsed'],1)
        self.assertEqual(self.tally(result),{'一致':60,'不一致':30})
        self.assertEqual(self.tally(self.read(True)),self.tally(result))
    def test_stable_read_and_public_cache_detect_same_stat_changes(self):
        path=self.root/'data.txt';path.write_text('old')
        cache=Cache(self.root/'standalone.sqlite3');self.addCleanup(cache.close)
        parser=lambda p:{'value':p.read_text()}
        self.assertFalse(cache.parse(path,'tag',parser)[1]);self.assertTrue(cache.parse(path,'tag',parser)[1])
        before=path.stat();path.write_text('new');os.utime(path,ns=(before.st_atime_ns,before.st_mtime_ns))
        packet,hit=cache.parse(path,'tag',parser);self.assertFalse(hit);self.assertEqual(packet['value'],'new')
        def changing(p,cfg):
            before=p.stat();p.write_text('bad');os.utime(p,ns=(before.st_atime_ns,before.st_mtime_ns));return {'records':[]}
        self.assertIn('更新',parse_stable_file(changing,path,{})['error'])
    def test_corrupt_database_is_quarantined_and_read_recovers(self):
        for full in (False,True):
            with self.subTest(full=full):
                self.read();main.DB.write_bytes(b'synthetic invalid sqlite')
                result=self.read(full);self.assertEqual(result[3]['parsed'],2)
                self.assertEqual(self.tally(result),{'一致':90})
                backups=list(self.state.glob('attendance_cache.sqlite3.corrupt-*'));self.assertTrue(backups)
                self.assertTrue(all(p.read_bytes()==b'synthetic invalid sqlite' for p in backups))
                self.assertTrue(any('再作成' in w['reason'] for w in result[3]['read_warnings']))
                self.assertEqual(self.read()[3]['cache_hits'],2)
    def test_incomplete_cache_rejected_and_source_reparsed(self):
        first=self.read()
        for is_xlsx,packet in ((True,first[0]['E1']),(False,{'records':first[1]})):
            self.assertTrue(main.ReadWorker._valid_cached_packet(packet,is_xlsx,self.cfg))
            for key in ('file','row','invalid_fields',*(['sheet'] if is_xlsx else ['missing_fields'])):
                broken=copy.deepcopy(packet);del broken['records'][0][key]
                self.assertFalse(main.ReadWorker._valid_cached_packet(broken,is_xlsx,self.cfg),key)
        with sqlite3.connect(main.DB) as db:
            name=str(self.csv);packet=json.loads(db.execute('SELECT data FROM cache WHERE path=?',(name,)).fetchone()[0])
            for record in packet['records']:del record['missing_fields']
            db.execute('UPDATE cache SET data=? WHERE path=?',(json.dumps(packet),name))
        recovered=self.read();self.assertEqual(recovered[3]['parsed'],1);self.assertEqual(self.tally(recovered),{'一致':90})
    def test_readable_schema_with_corrupt_btree_recovers_persistently(self):
        for full in (False,True):
            with self.subTest(full=full):
                self.read()
                with sqlite3.connect(main.DB) as db:
                    page_size=db.execute('PRAGMA page_size').fetchone()[0]
                    page=db.execute("SELECT rootpage FROM sqlite_master WHERE name='cache'").fetchone()[0]
                raw=bytearray(main.DB.read_bytes());raw[(page-1)*page_size]=0
                main.DB.write_bytes(raw);result=self.read(full)
                self.assertEqual(result[3]['parsed'],2);self.assertEqual(self.tally(result),{'一致':90})
                self.assertTrue(any(p.read_bytes()==raw for p in self.state.glob('*.corrupt-*')))
                self.assertEqual(self.read()[3]['cache_hits'],2)
    def save_employee_dialog(self,new_staff=None):
        errors=[]
        def action():
            dialog=APP.activeModalWidget()
            try:
                if new_staff:dialog.findChild(QTableWidget,'employeeIdTable').cellWidget(0,2).setEditText(new_staff)
                next(b for b in dialog.findChildren(QPushButton) if b.text()=='社員情報を登録').click()
            except Exception as exc:errors.append(repr(exc));dialog.reject()
        QTimer.singleShot(0,action);self.window.edit_map();self.assertFalse(errors,errors)
    def test_employee_save_resets_all_summary_and_result_state(self):
        self.read(ui=True);self.assertIn('全数一致',self.window.total_check.text())
        self.save_employee_dialog()
        self.assertFalse(self.window.results);self.assertIsNone(self.window.comparison_summary)
        self.assertNotIn('全数一致',self.window.total_check.text())
        self.assertTrue(all(w.text()=='0' for w in self.window.metric_values.values()))
        self.assertFalse(self.window.mail_button.isEnabled());self.assertFalse(self.window.print_button.isEnabled())
        self.read(ui=True);self.assertIn('全数一致',self.window.total_check.text())
    def test_employee_save_invalidates_inflight_worker(self):
        entered=threading.Event();release=threading.Event();real=main.xlsx_read
        def held(*args):entered.set();release.wait(5);return real(*args)
        errors=[]
        with patch.object(main,'xlsx_read',held):
            worker=main.ReadWorker(self.folder,self.cfg,True);self.window.worker=worker;worker.result.connect(self.window.read_done);worker.start()
            try:
                limit=time.monotonic()+5
                while not entered.is_set() and time.monotonic()<limit:APP.processEvents();time.sleep(.005)
                self.assertTrue(entered.is_set());self.save_employee_dialog('S2')
                self.assertTrue(worker.isInterruptionRequested())
            finally:
                release.set();worker.wait(5000);APP.processEvents()
        self.assertEqual(self.window.mapping,{'E1':'S2'});self.assertFalse(self.window.results)
        self.assertNotIn('全数一致',self.window.total_check.text());self.assertTrue(worker.results_invalidated)
        result=self.read(ui=True);self.assertTrue(self.window.results)
    def test_queued_progress_cannot_overwrite_employee_save_state(self):
        worker=main.ReadWorker(self.folder,self.cfg);self.window.worker=worker
        worker.progress.connect(self.window.on_progress,Qt.QueuedConnection)
        worker.progress.emit(2,2,'old completion')
        self.window.invalidate_results();APP.processEvents()
        self.assertEqual(self.window.progress.value(),0)
        self.assertIn('社員情報を保存',self.window.status.text())
    def mail(self):
        path=self.root/'mail';path.mkdir(exist_ok=True)
        return path,Outlook(path),dict(employee='E1',staff='S1',to=['employee@example.com','fixed@example.com'],cc=['a@example.com','b@example.com'],subject='Subject',body='Body',problem='')
    def test_equivalent_recipient_order_case_and_caption_cannot_repeat(self):
        for auto in (False,True):
            with self.subTest(auto=auto),tempfile.TemporaryDirectory() as temp:
                path=Path(temp);outlook=Outlook(path);plan=self.mail()[2]
                settings={**DEFAULT_MAIL_SETTINGS,'account':'operator@example.com','auto_send':auto}
                process_classic_plans([plan],settings,path,outlook)
                equivalent={**plan,'to':[x.upper() for x in reversed(plan['to'])],'cc':list(reversed(plan['cc'])),'recipient_names':{'a@example.com':'Caption'}}
                process_classic_plans([equivalent],settings,path,outlook);self.assertEqual(len(outlook.messages),1)
                process_classic_plans([{**plan,'body':'New month'}],settings,path,outlook);self.assertEqual(len(outlook.messages),2)
                process_classic_plans([{**plan,'to':plan['cc'],'cc':plan['to']}],settings,path,outlook);self.assertEqual(len(outlook.messages),3)
    def test_previous_v2_history_is_aliased_without_creating_mail(self):
        path,outlook,plan=self.mail();settings={**DEFAULT_MAIL_SETTINGS,'account':'operator@example.com'}
        payload=mail_payload({**plan,'recipient_names':{}})
        key=hashlib.sha256(json.dumps([settings['account'],'classic_outlook_v2',False,'E1','S1',payload],ensure_ascii=False,sort_keys=True).encode()).hexdigest()
        save_json(path/'mail_processing_history.json',{key:{'employee':'E1','status':'draft','backend':'classic_outlook'}})
        process_classic_plans([plan],settings,path,outlook)
        process_classic_plans([{**plan,'cc':list(reversed(plan['cc']))}],settings,path,outlook)
        self.assertFalse(outlook.messages)
    def test_registered_employee_editor_candidate_count_is_linear(self):
        n=600;mapping={f'E{i}':f'S{i}' for i in range(n)}
        contacts={'version':1,'contacts':[dict(employee=e,staff=s,name=e,email=f'{e}@example.invalid') for e,s in mapping.items()],'employee_information_registered':True}
        self.window.mapping=mapping;save_json(main.MAP,mapping);save_json(main.MAP.with_name('employee_contacts.json'),contacts)
        found={};errors=[]
        def inspect():
            dialog=APP.activeModalWidget()
            try:
                table=dialog.findChild(QTableWidget,'employeeIdTable')
                found['candidates']=sum(table.cellWidget(i,j).count() for i in range(n) for j in (2,3))
                self.assertEqual(table.rowCount(),n)
            except Exception as exc:errors.append(repr(exc))
            finally:dialog.reject()
        QTimer.singleShot(0,inspect);start=time.perf_counter();self.window.edit_map();elapsed=time.perf_counter()-start
        self.assertFalse(errors,errors);self.assertEqual(found['candidates'],4*n)
        print('EDITOR600',json.dumps(dict(found,seconds=elapsed)))
    def test_employee_plan_six_thousand_and_conflict_policy(self):
        n=6000;rows=[dict(employee=f'E{i}',staff=f'S{i}',name=f'User{i}',email=f'u{i}@example.invalid') for i in range(n)]
        start=time.perf_counter();mapping,data,results=plan_employee_import(rows,'linking',{},dict(contacts=[],unlinked_contacts=[]))
        elapsed=time.perf_counter()-start;self.assertEqual(len(mapping),n);self.assertTrue(all(r['matched'] for r in results))
        conflicts=rows[:1]+[{**rows[0],'employee':'Other'}]
        blocked,_,results=plan_employee_import(conflicts,'linking',{},dict(contacts=[],unlinked_contacts=[]))
        self.assertFalse(blocked);self.assertTrue(all(not r['id_matched'] for r in results))
        print('IMPORT6000',json.dumps(dict(seconds=elapsed,rows=n)))
    def test_settings_errors_identify_actual_control(self):
        for key,value in [('account','bad'),('always_to','bad'),('always_cc','bad'),('subject',''),('subject','{unknown}'),('body','no differences'),('name_suffix','a\nb')]:
            with self.subTest(key=key,value=value):
                dialog=SettingsDialog(self.window,self.cfg)
                try:
                    control=dialog.mail_controls[key]
                    control.setPlainText(value) if hasattr(control,'setPlainText') else control.setText(value)
                    with self.assertRaises(SettingsError) as caught:dialog._collect_config()
                    self.assertIs(caught.exception.control,control)
                finally:dialog.reject();dialog.deleteLater()

if __name__=='__main__':unittest.main(verbosity=2)
