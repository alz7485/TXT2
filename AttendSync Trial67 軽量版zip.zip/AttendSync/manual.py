"""Open the bundled offline illustrated manual only when requested."""
from PySide6.QtCore import QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QMessageBox
from runtime_paths import application_dir


def open_manual(parent):
    path=application_dir()/'Manual'/'index.html'
    try:
        if not path.is_file():
            QMessageBox.warning(parent,'操作マニュアルが見つかりません',
                'Manualフォルダを含む配布フォルダ全体を展開してください。\n'
                'マニュアルは実行ファイルと同じフォルダのManualにあります。')
            return False
        if not QDesktopServices.openUrl(QUrl.fromLocalFile(str(path.resolve()))):
            QMessageBox.warning(parent,'操作マニュアルを開けません',
                '既定のブラウザを確認してください。\n'
                'Manualフォルダのindex.htmlを直接開くこともできます。')
            return False
    except Exception as exc:
        QMessageBox.warning(parent,'操作マニュアルを開けません',str(exc))
        return False
    return True
