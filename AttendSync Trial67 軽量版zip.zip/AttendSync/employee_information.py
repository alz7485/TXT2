"""Employee CSV registration, ID/email plans, and recoverable save."""
import csv,io,copy,os,json,base64,tempfile
from pathlib import Path
from collections import defaultdict
from openpyxl.utils.cell import column_index_from_string
from engine import save_json,load_json
from employee_contacts import validate_contacts,load_contacts,valid_email,merged_contacts
from mail_state import mail_lock

def source_key(path):return os.path.normcase(str(Path(path).expanduser().resolve()))

def load_information(path):
    return validate_information(load_contacts(path))

def validate_information(data):
    names=data.get('employee_names',{})
    if not isinstance(names,dict) or not all(isinstance(k,str) and isinstance(v,str) for k,v in names.items()):raise ValueError('社員名の保存形式が不正です。')
    candidates=data.get('staff_candidates',[])
    if not isinstance(candidates,list) or not all(isinstance(r,dict) and all(isinstance(r.get(k),str) for k in ('employee','staff','name')) for r in candidates):raise ValueError('スタッフID候補の保存形式が不正です。')
    sources=data.get('csv_sources',{})
    if not isinstance(sources,dict) or not all(isinstance(k,str) and v in ('linking','attendance') for k,v in sources.items()):raise ValueError('CSV用途の保存形式が不正です。')
    imports=data.get('employee_import_settings',{})
    if not isinstance(imports,dict):raise ValueError('社員情報CSVの読込設定が不正です。')
    if 'linking' in imports:
        profile=imports['linking']
        if not isinstance(profile,dict):raise ValueError('社員情報CSVの読込設定が不正です。')
        columns=profile.get('columns',{})
        if not isinstance(columns,dict) or not all(isinstance(columns.get(k,''),str) for k in ('staff','employee','name','email')):raise ValueError('社員情報CSVの列設定が不正です。')
        first=profile.get('first_row',2)
        if isinstance(first,bool) or not isinstance(first,int) or not 1<=first<=1048576:raise ValueError('社員情報CSVの開始行が不正です。')
        if profile.get('encoding','auto') not in ('auto','utf-8-sig','cp932'):raise ValueError('社員情報CSVの文字コード設定が不正です。')
    if not isinstance(data.get('employee_information_registered',False),bool):raise ValueError('社員情報の登録状態が不正です。')
    return data

def registration_is_ready(data,mapping):
    registered=data.get('employee_information_registered',any(role=='linking' for role in data.get('csv_sources',{}).values()))
    return bool(registered and any(str(sid).strip() for sid in mapping.values()))

def excluded_link_csv_paths(contacts_path):
    data=load_information(contacts_path)
    sources=data.get('csv_sources',{})
    if not isinstance(sources,dict):raise ValueError('CSV用途設定が不正です。社員情報を確認してください。')
    return {source_key(path) for path,role in sources.items() if role=='linking'}

def _restore(path,raw):
    if raw is None:
        if path.exists():path.unlink()
        return
    if path.exists() and path.read_bytes()==raw:return
    temporary=None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent,delete=False) as stream:
            temporary=Path(stream.name);stream.write(raw);stream.flush();os.fsync(stream.fileno())
        temporary.replace(path)
    finally:
        if temporary and temporary.exists():temporary.unlink()

def _recover(mapping_path,contacts_path):
    journal=Path(mapping_path).with_name('employee_save_transaction.json')
    if not journal.exists():return
    snapshots=load_json(journal,{})
    if not isinstance(snapshots,dict) or set(snapshots)!={'mapping','contacts'}:raise ValueError('社員情報の保存回復データが不正です。')
    # Validate every snapshot before restoring or deleting either live file.
    decoded={}
    try:
        for key,value in snapshots.items():
            if value is not None and not isinstance(value,str):raise ValueError('snapshot type')
            decoded[key]=None if value is None else base64.b64decode(value,validate=True)
            if decoded[key] is not None:
                data=json.loads(decoded[key].decode('utf-8-sig'))
                if key=='mapping':
                    if not isinstance(data,dict) or not all(isinstance(k,str) and k.strip() and isinstance(v,str) for k,v in data.items()):raise ValueError('mapping snapshot')
                else:validate_information(validate_contacts(data))
    except (ValueError,TypeError,UnicodeError) as exc:
        raise ValueError('社員情報の保存回復データが不正です。') from exc
    for key,path in [('contacts',Path(contacts_path)),('mapping',Path(mapping_path))]:_restore(path,decoded[key])
    journal.unlink()

def recover_employee_save(mapping_path,contacts_path):
    if Path(mapping_path).with_name('employee_save_transaction.json').exists():
        with mail_lock(Path(mapping_path).parent):_recover(mapping_path,contacts_path)

def commit_employee_information(mapping_path,contacts_path,mapping,contacts,writer=save_json):
    mapping_path=Path(mapping_path);contacts_path=Path(contacts_path);journal=mapping_path.with_name('employee_save_transaction.json')
    with mail_lock(mapping_path.parent):
        _recover(mapping_path,contacts_path)
        snapshots={key:base64.b64encode(path.read_bytes()).decode('ascii') if path.exists() else None for key,path in [('mapping',mapping_path),('contacts',contacts_path)]}
        save_json(journal,snapshots)
        try:
            writer(contacts_path,contacts);writer(mapping_path,mapping);journal.unlink()
        except Exception:
            _recover(mapping_path,contacts_path)
            raise

def read_information_csv(path,role,columns,first_row=2,encoding='auto'):
    if role!='linking':raise ValueError('IDとメールは社員情報CSVから登録してください。')
    required=('employee','staff','name','email')
    indices={}
    for key in ('employee','staff','name','email'):
        value=str(columns.get(key,'')).strip().upper()
        if not value:
            if key in required:raise ValueError(f'{key}の列を指定してください。')
            continue
        index=column_index_from_string(value)-1
        if not 0<=index<16384:raise ValueError('列はA～XFDで指定してください。')
        indices[key]=index
    if len(indices)!=len(set(indices.values())):raise ValueError('項目ごとに異なる列を指定してください。')
    if isinstance(first_row,bool) or not isinstance(first_row,int) or first_row<1:raise ValueError('開始行は1以上で指定してください。')
    raw=Path(path).read_bytes()
    if encoding=='auto':
        for enc in ('utf-8-sig','cp932'):
            try:text=raw.decode(enc);break
            except UnicodeDecodeError:continue
        else:raise ValueError('CSVはUTF-8またはCP932で保存してください。')
    else:text=raw.decode(encoding)
    rows=[]
    for line,record in enumerate(csv.reader(io.StringIO(text,newline='')),1):
        if line<first_row or not any(value.strip() for value in record):continue
        item={key:record[indices[key]].strip() if key in indices and indices[key]<len(record) else '' for key in ('employee','staff','name','email')}
        item['line']=line;rows.append(item)
    return rows

def plan_employee_import(rows,role,mapping,contacts):
    if role!='linking':raise ValueError('勤怠データからのID紐付けは行いません。')
    new_mapping=copy.deepcopy(mapping);data=copy.deepcopy(contacts);pairs=defaultdict(set);owners=defaultdict(set);emails=defaultdict(set)
    unique=[];seen=set();pair_names=defaultdict(set);assigned_owners=defaultdict(set)
    for employee,staff in new_mapping.items():
        if str(staff).strip():assigned_owners[str(staff).strip()].add(employee)
    for row in rows:
        signature=tuple(row.get(key,'') for key in ('employee','staff','name','email'))
        if signature in seen:continue
        seen.add(signature);unique.append(row)
        eid,sid=row['employee'],row['staff']
        if eid and sid:pairs[eid].add(sid);owners[sid].add(eid)
        if eid and sid and row['email']:emails[eid,sid].add(row['email'])
        if row['name']:pair_names[eid,sid].add(row['name'])
    results=[];names=data.setdefault('employee_names',{});candidates={r['staff']:dict(r) for r in data.get('staff_candidates',[]) if r.get('staff')}
    for row in unique:
        item=dict(row);eid,sid=row['employee'],row['staff'];status='';linked=False
        if sid:candidates[sid]={key:row[key] for key in ('employee','staff','name')}
        if not sid:status='スタッフID空欄'
        elif not eid:status='社員ID空欄・候補として保持'
        elif len(pairs[eid])>1 or len(owners[sid])>1:status='CSV内のID重複・競合'
        elif eid in new_mapping and str(new_mapping[eid]).strip() and str(new_mapping[eid]).strip()!=sid:status='既存スタッフIDと不一致'
        elif assigned_owners[sid]-{eid}:status='スタッフIDが別社員へ割当済み'
        else:
            new_mapping[eid]=sid;assigned_owners[sid].add(eid);linked=True;status='ID一致' if mapping.get(eid)==sid else 'IDを紐付け'
        if eid and row['name']:
            if linked and len(pair_names[eid,sid])==1:names[eid]=row['name']
            else:names.setdefault(eid,row['name'])
        item['employee']=eid;item['matched']=False
        if linked:
            if len(emails[eid,sid])>1:status+='・メール競合'
            elif valid_email(row['email']):item['matched']=True;status+='・メール一致'
            else:status+='・メール空欄/不正'
        item['status']=status;item['id_matched']=linked;results.append(item)
    data=merged_contacts(data,results,data.get('import_settings',{}))
    data['employee_names']=names;data['staff_candidates']=list(candidates.values())
    if any(r['id_matched'] for r in results):data['employee_information_registered']=True
    return new_mapping,data,results

def show_employee_import_dialog(parent,mapping,contacts,cfg,initial_path=None):
    from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QGroupBox,QLabel,
        QLineEdit,QSpinBox,QComboBox,QTableWidget,QTableWidgetItem,QHeaderView,QAbstractItemView,
        QFileDialog,QMessageBox,QWidget,QSizePolicy)
    from PySide6.QtCore import QTimer
    from ui_theme import button,refresh_button_icons
    from csv_drop import CsvDropHandler
    dlg=QDialog(parent);dlg.setWindowTitle('社員情報を読み込む');dlg.resize(1000,700);dlg.setMinimumSize(940,620)
    root=QVBoxLayout(dlg);root.setContentsMargins(20,18,20,16);root.setSpacing(12)
    heading=QHBoxLayout();title=QLabel('社員情報を読み込む');title.setObjectName('pageTitle');heading.addWidget(title);heading.addStretch()
    hint=QLabel('CSVをドロップして読み込み');hint.setObjectName('muted');heading.addWidget(hint);root.addLayout(heading)
    file_box=QGroupBox('CSVファイル');file_row=QHBoxLayout(file_box)
    filename=QLineEdit();filename.setObjectName('informationCsvPath');filename.setPlaceholderText('CSVをこの画面にドロップ、または右のボタンから選択')
    choose=button('CSVを選択','folder');file_row.addWidget(filename,1);file_row.addWidget(choose);root.addWidget(file_box)
    def browse():
        value,_=QFileDialog.getOpenFileName(dlg,'社員情報のCSVを選択','','CSV (*.csv)')
        if value:filename.setText(value)
    choose.clicked.connect(browse)
    box=QGroupBox('読み込み設定');content=QHBoxLayout(box);content.setSpacing(14);root.addWidget(box)
    fields={}
    def setting(title,control):
        item=QWidget();item.setSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed)
        group=QHBoxLayout(item);group.setContentsMargins(0,0,0,0);group.setSpacing(6);group.addWidget(QLabel(title));group.addWidget(control);content.addWidget(item)
    for key,title in [('staff','スタッフID'),('employee','社員ID'),('name','氏名'),('email','メール')]:
        edit=QLineEdit();edit.setObjectName('informationColumn_'+key);edit.setAccessibleName(title+'列');edit.setFixedWidth(54);fields[key]=edit;setting(title,edit)
    first=QSpinBox();first.setRange(1,1048576);first.setFixedWidth(90);first.setObjectName('informationFirstRow');setting('開始行',first)
    encoding=QComboBox();encoding.setObjectName('informationEncoding');encoding.addItems(['auto','utf-8-sig','cp932']);encoding.setFixedWidth(112);setting('文字コード',encoding)
    content.addStretch()
    results_heading=QHBoxLayout();results_heading.addWidget(QLabel('社員情報'));results_heading.addStretch()
    summary=QLabel('CSVを選択またはドロップしてください。');summary.setObjectName('muted');results_heading.addWidget(summary);root.addLayout(results_heading)
    problems=QLabel();problems.setWordWrap(True);problems.setObjectName('informationProblems');problems.hide();root.addWidget(problems)
    display_keys=['staff','employee','name','email']
    table=QTableWidget(0,4);table.setObjectName('informationPreview');table.setHorizontalHeaderLabels(['スタッフID','社員ID','氏名','メールアドレス'])
    table.setEditTriggers(QAbstractItemView.NoEditTriggers);table.setSelectionBehavior(QAbstractItemView.SelectRows);table.setSelectionMode(QAbstractItemView.SingleSelection)
    table.verticalHeader().hide();table.setAlternatingRowColors(True);table.verticalHeader().setDefaultSectionSize(38)
    table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
    for col,width in [(0,150),(1,180),(2,220)]:table.setColumnWidth(col,width)
    table.horizontalHeader().setSectionResizeMode(3,QHeaderView.Stretch);table.setToolTip('行をダブルクリックすると、元CSVの対応するセルをExcelで開きます。');root.addWidget(table,1)
    source_hint=QLabel('行をダブルクリックすると、元CSVの対応するセルをExcelで開きます。');source_hint.setObjectName('muted');root.addWidget(source_hint)
    buttons=QHBoxLayout();buttons.addStretch();cancel=button('キャンセル','x');apply=button('一覧に反映','check','primary');apply.setEnabled(False);buttons.addWidget(cancel);buttons.addWidget(apply);root.addLayout(buttons)
    state={};result=None
    refresh=QTimer(dlg);refresh.setSingleShot(True);refresh.setInterval(250)
    def invalidate(*args):
        refresh.stop();state.clear();apply.setEnabled(False);table.setRowCount(0);problems.hide()
        summary.setText('CSVを選択またはドロップしてください。')
    def schedule(*args):
        invalidate()
        if filename.text().strip():refresh.start()
    saved=contacts.get('employee_import_settings',{}).get('linking',{})
    defaults={'employee':'B','staff':'A','name':'C','email':'J'}
    for key,edit in fields.items():edit.setText(saved.get('columns',defaults).get(key,''))
    first.setValue(saved.get('first_row',2));encoding.setCurrentText(saved.get('encoding','auto'))
    for edit in [filename,*fields.values()]:edit.textChanged.connect(schedule)
    first.valueChanged.connect(schedule);encoding.currentTextChanged.connect(schedule)
    def preview():
        invalidate()
        try:
            config={'columns':{k:e.text().strip().upper() for k,e in fields.items()},'first_row':first.value(),'encoding':encoding.currentText()};purpose='linking'
            path=Path(filename.text()).expanduser().resolve();before=path.stat()
            rows=read_information_csv(path,purpose,**config);after=path.stat()
            if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):raise RuntimeError('CSVが読み込み中に更新されました。もう一度読み込んでください。')
            new_mapping,data,results=plan_employee_import(rows,purpose,mapping,contacts)
            data.setdefault('csv_sources',{})[source_key(path)]=purpose;data.setdefault('employee_import_settings',{})[purpose]=config
            state.update(mapping=new_mapping,contacts=data,results=results,config=config,source={'file':str(path),'file_size':after.st_size,'file_mtime_ns':after.st_mtime_ns})
            table.setRowCount(len(results))
            for i,item in enumerate(results):
                for col,key in enumerate(display_keys):table.setItem(i,col,QTableWidgetItem(str(item[key])))
            summary.setText(f'{len(results)}件');apply.setEnabled(bool(results))
            notes=[f'{r["employee"] or r["staff"] or "ID未入力"}: {r["status"]}' for r in results if not r['id_matched'] or (r['email'] and not r['matched'])]
            if notes:problems.setText('登録内容を確認してください：'+ ' / '.join(notes[:3]));problems.show()
        except Exception as exc:
            problems.setText('社員情報を読み込めません：'+str(exc));problems.show();summary.setText('読込エラー')
    def open_csv(row,col):
        if not state or not 0<=row<len(state['results']):return
        key=display_keys[col] if 0<=col<len(display_keys) else 'staff'
        column=state['config']['columns'].get(key) or state['config']['columns']['staff']
        record={**state['source'],'row':state['results'][row]['line']}
        try:
            from excel_jump import open_csv_cell
            open_csv_cell(record,column)
        except Exception as exc:QMessageBox.warning(dlg,'CSVを開けません',str(exc))
    table.cellDoubleClicked.connect(open_csv)
    def accept():
        nonlocal result
        if state:result={k:state[k] for k in ('mapping','contacts','results')};dlg.accept()
    refresh.timeout.connect(preview);apply.clicked.connect(accept);cancel.clicked.connect(dlg.reject);refresh_button_icons(dlg,getattr(parent,'is_dark',False))
    def read_dropped_csv(path):filename.setText(path);preview()
    drop_handler=CsvDropHandler(dlg,read_dropped_csv)
    if initial_path:QTimer.singleShot(0,dlg,lambda:read_dropped_csv(initial_path))
    try:dlg.exec();return result
    finally:dlg.deleteLater()

def validate_information_rows(selections):
    result={};seen=set()
    for i,(eid,sid,name,email) in enumerate(selections):
        if not eid and not sid and not email:continue
        if not eid:raise ValueError(f'{i+1}行目の社員IDが空欄です。')
        if eid in seen:raise ValueError('社員IDの重複：'+eid)
        seen.add(eid)
        if email and not sid:raise ValueError('メールを紐付けるスタッフIDを指定してください：'+eid)
        if sid:result[eid]=sid
    ids=list(result.values())
    if len(ids)!=len(set(ids)):raise ValueError('同じスタッフIDが複数の社員に割り当てられています。')
    return result

def contacts_for_mapping(contacts,mapping):
    data=copy.deepcopy(contacts);active=[];candidates={r['email']:dict(r) for r in data.get('unlinked_contacts',[])}
    for row in data['contacts']:
        if mapping.get(row['employee'])==row['staff']:active.append(row)
        elif valid_email(row['email']):candidates[row['email']]=row
    used={r['email'] for r in active};data['contacts']=active;data['unlinked_contacts']=[r for email,r in candidates.items() if email not in used]
    return data
