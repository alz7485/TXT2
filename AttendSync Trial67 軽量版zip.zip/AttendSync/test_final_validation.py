from copy import deepcopy
from engine import DEFAULT, validate_config
assert validate_config(deepcopy(DEFAULT))==[]
for part,value in [('xlsx_columns','1'),('csv_columns','AAAA')]:
    cfg=deepcopy(DEFAULT);cfg[part]['start']=value
    assert validate_config(cfg), part
cfg=deepcopy(DEFAULT);cfg['data_first_row']=101;cfg['data_last_row']=100
assert validate_config(cfg)
cfg=deepcopy(DEFAULT);cfg['sheet_names']['10']=''
assert validate_config(cfg)
print('PASS: config validation checks')
