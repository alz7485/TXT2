import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import tempfile,unittest,copy,json
from pathlib import Path
from unittest.mock import patch
from employee_contacts import read_contact_csv,match_contacts,merged_contacts,load_contacts,email_for,import_contacts_dialog,DEFAULT_COLUMNS,selected_email,save_manual_contacts
from engine import save_json
from PySide6.QtWidgets import QApplication,QLineEdit,QPushButton,QTableWidget,QTabWidget,QCheckBox
from PySide6.QtCore import QTimer
import runtime_paths
TMP=tempfile.TemporaryDirectory()
with patch.object(runtime_paths,'get_data_dir',return_value=Path(TMP.name)):import main
APP=QApplication.instance() or QApplication([]);APP.setQuitOnLastWindowClosed(False)
class Contacts(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.folder=Path(self.tmp.name)
 def csv(self,encoding='utf-8-sig'):
  p=self.folder/'連絡先.csv';p.write_text('メール,名前,スタッフ,社員\nfirst@example.com,同じ名前,0007,0001\nsecond@example.com,同じ名前,0008,0002\n',encoding=encoding);return p
 def rows(self,encoding='utf-8-sig'):
  return read_contact_csv(self.csv(encoding),{'employee':'D','staff':'C','name':'B','email':'A'})
 def test_columns_encodings_and_leading_zeros(self):
  for encoding in ['utf-8-sig','cp932']:
   rows=self.rows(encoding);self.assertEqual(rows[0]['employee'],'0001');self.assertEqual(rows[0]['staff'],'0007');self.assertEqual(rows[0]['name'],'同じ名前')
 def test_both_ids_required_no_name_fallback(self):
  rows=self.rows();r=match_contacts(rows,{'0001':'0007','0002':'9999'})
  self.assertTrue(r[0]['matched']);self.assertFalse(r[1]['matched'])
  self.assertFalse(match_contacts(rows,{'9':'0007'})[0]['matched'])
 def test_duplicate_ids_and_saved_staff_rejected(self):
  rows=self.rows();self.assertFalse(any(r['matched'] for r in match_contacts(rows+[rows[0]],{'0001':'0007','0002':'0008'}) if r['employee']=='0001'))
  self.assertFalse(match_contacts(rows,{'0001':'0007','other':'0007'})[0]['matched'])
 def test_empty_ids_bad_email_and_short_row(self):
  rows=self.rows()
  for key,value in [('employee',''),('staff',''),('email',''),('email','bad'),('email','a@b.com\nBCC:other@example.com')]:
   changed=copy.deepcopy(rows);changed[0][key]=value;self.assertFalse(match_contacts(changed,{'0001':'0007'})[0]['matched'])
 def test_merge_preserves_unmatched_and_unknown_data(self):
  old={'version':1,'contacts':[{'employee':'old','staff':'old','name':'old','email':'old@example.com'}],'extra':{'keep':1}}
  updated=merged_contacts(old,match_contacts(self.rows(),{'0001':'0007'}),{'columns':DEFAULT_COLUMNS})
  self.assertEqual(len(updated['contacts']),2);self.assertEqual(old['contacts'][0]['email'],'old@example.com');self.assertEqual(updated['extra'],{'keep':1})
  p=self.folder/'contacts.json';save_json(p,updated);self.assertEqual(load_contacts(p),updated);self.assertEqual(email_for(updated,'0001','0007'),'first@example.com');self.assertEqual(email_for(updated,'0001','wrong'),'')
 def test_column_validation(self):
  for columns in [dict(DEFAULT_COLUMNS,email='A'),dict(DEFAULT_COLUMNS,email='XFE'),dict(DEFAULT_COLUMNS,email='1')]:
   with self.assertRaises((ValueError,KeyError)):read_contact_csv(self.csv(),columns)
 def wizard(self,fail=False):
  path=self.folder/'contacts.json';old={'version':1,'contacts':[],'import_settings':{'columns':{'employee':'D','staff':'C','name':'B','email':'A'}}};save_json(path,old)
  window=main.Window();errors=[]
  def operate():
   try:
    dlg=APP.activeModalWidget();dlg.findChildren(QLineEdit)[0].setText(str(self.csv()))
    buttons={b.text():b for b in dlg.findChildren(QPushButton)};buttons['照合して確認'].click()
    self.assertEqual(dlg.findChild(QTableWidget).rowCount(),2);self.assertTrue(buttons['取込結果を保存'].isEnabled())
    buttons['取込結果を保存'].click()
    if fail:dlg.reject()
   except Exception as exc:errors.append(exc);APP.activeModalWidget().reject()
  QTimer.singleShot(0,operate)
  if fail:
   with patch('employee_contacts.save_json',side_effect=PermissionError('denied')),patch('PySide6.QtWidgets.QMessageBox.warning'):
    result=import_contacts_dialog(window,{'0001':'0007'},path)
   self.assertIsNone(result);self.assertEqual(load_contacts(path),old)
  else:
   result=import_contacts_dialog(window,{'0001':'0007'},path);self.assertEqual(email_for(result,'0001','0007'),'first@example.com');self.assertEqual(len(result['contacts']),1)
  window.close();self.assertFalse(errors,errors)
 def test_actual_import_dialog_saves_only_matched(self):self.wizard()
 def test_dialog_save_failure_preserves_file(self):self.wizard(True)
 def test_management_displays_persisted_email_and_clears_on_id_change(self):
  with patch.multiple(main,CONFIG=self.folder/'settings.json',MAP=self.folder/'staff_mapping.json',DB=self.folder/'cache.db'):
   save_json(main.MAP,{'0001':'0007'});save_json(main.MAP.with_name('employee_contacts.json'),{'version':1,'contacts':[{'employee':'0001','staff':'0007','name':'名前','email':'first@example.com'}]})
   window=main.Window();errors=[]
   def inspect():
    try:
     dlg=APP.activeModalWidget();table=dlg.findChild(QTableWidget,'employeeIdTable');self.assertEqual(selected_email(table.cellWidget(0,3)),'first@example.com');dlg.findChild(QTableWidget,'employeeIdTable').cellWidget(0,2).setEditText('different');self.assertEqual(selected_email(table.cellWidget(0,3)),'')
     next(b for b in dlg.findChildren(QPushButton) if b.text()=='社員番号を追加').click();dlg.findChild(QTableWidget,'employeeIdTable').item(1,0).setText('new')
    except Exception as exc:errors.append(exc)
    finally:
     if APP.activeModalWidget():APP.activeModalWidget().reject()
   QTimer.singleShot(0,inspect);window.edit_map();window.close();self.assertFalse(errors,errors)
 def test_unmatched_valid_email_retained_for_manual_choice(self):
  old={'version':1,'contacts':[]};rows=self.rows();new=merged_contacts(old,match_contacts(rows,{}),{})
  self.assertEqual(len(new['unlinked_contacts']),2)
  linked=save_manual_contacts(new,{'0001':'0007'},[('0001','0007','name','second@example.com')])
  self.assertEqual(email_for(linked,'0001','0007'),'second@example.com');self.assertEqual(len(linked['unlinked_contacts']),1)
  with self.assertRaises(ValueError):save_manual_contacts(new,{},[('0001','0007','name','direct@example.com')])
 def manual_dialog(self,direct):
  with patch.multiple(main,CONFIG=self.folder/'settings.json',MAP=self.folder/'staff_mapping.json',DB=self.folder/'cache.db'):
   save_json(main.MAP,{'0001':'0007'});path=main.MAP.with_name('employee_contacts.json')
   save_json(path,{'version':1,'contacts':[],'unlinked_contacts':[{'employee':'0002','staff':'0008','name':'確認名','email':'candidate@example.com'}]})
   window=main.Window();errors=[]
   def operate():
    try:
     dlg=APP.activeModalWidget();table=dlg.findChild(QTableWidget,'employeeIdTable');combo=table.cellWidget(0,3)
     self.assertGreaterEqual(combo.count(),2)
     search=next(e for e in dlg.findChildren(QLineEdit) if e.placeholderText()=='社員ID・氏名・メールで検索')
     search.setText('missing-person');self.assertTrue(table.isRowHidden(0));search.clear();self.assertFalse(table.isRowHidden(0))
     if direct:combo.setEditText('direct@example.com')
     else:combo.setCurrentIndex(1)
     toggle=dlg.findChild(main.QComboBox,'employeeFilter');toggle.setCurrentIndex(2);self.assertTrue(table.isRowHidden(0));toggle.setCurrentIndex(0)
     next(b for b in dlg.findChildren(QPushButton) if b.text()=='社員情報を登録').click()
    except Exception as exc:errors.append(exc)
    finally:
     if APP.activeModalWidget():APP.activeModalWidget().reject()
   with patch.object(main.QMessageBox,'question',return_value=main.QMessageBox.Yes) as question,patch.object(main.QMessageBox,'information'),patch.object(window,'run_read'):
    QTimer.singleShot(0,operate);window.edit_map();APP.processEvents()
    if not direct:question.assert_called_once()
   data=load_contacts(path);self.assertEqual(email_for(data,'0001','0007'),'direct@example.com' if direct else 'candidate@example.com');window.close();self.assertFalse(errors,errors)
 def test_manual_dropdown_and_mismatched_ids_confirmation(self):self.manual_dialog(False)
 def test_manual_direct_input(self):self.manual_dialog(True)
if __name__=='__main__':unittest.main(verbosity=2)
