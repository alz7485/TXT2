"""Compare source startup in alternating fresh processes on the same machine."""
import argparse,json,statistics,subprocess,sys,time
from pathlib import Path

def compare(baseline,current,runs):
    records={'baseline':[],'current':[]};ordered=[]
    probe=Path(__file__).with_name('benchmark_startup.py')
    for cycle in range(runs):
        # Reverse each pair to reduce bias from CPU load and warmed file caches.
        order=('baseline','current') if cycle%2==0 else ('current','baseline')
        for key in order:
            source=baseline if key=='baseline' else current
            started=time.perf_counter()
            child=subprocess.run([sys.executable,str(probe),'--probe',str(source)],capture_output=True,text=True,timeout=30)
            if child.returncode:raise RuntimeError(child.stderr or child.stdout)
            record=json.loads(child.stdout);record['process_total_seconds']=round(time.perf_counter()-started,4)
            records[key].append(record);ordered.append({'source':key,'pair':cycle+1,**record})
    result={'method':'Alternating fresh source-mode processes, order reversed each pair; default temporary userdata; no parallel tests; OS disk cache not cleared.','baseline_source':str(baseline),'current_source':str(current),'ordered_runs':ordered}
    for key,values in records.items():
        result[key]={'runs':values,'median_first_paint_seconds':round(statistics.median(value['first_paint_seconds'] for value in values),4),'max_first_paint_seconds':max(value['first_paint_seconds'] for value in values)}
    return result

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--baseline',type=Path,required=True);parser.add_argument('--current',type=Path,default=Path(__file__).resolve().parent);parser.add_argument('--runs',type=int,default=6);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    if not 1<=args.runs<=30:parser.error('runs must be between 1 and 30')
    for source in (args.baseline,args.current):
        if not (source/'main.py').is_file():parser.error('Each source directory must contain main.py')
    result=compare(args.baseline.resolve(),args.current.resolve(),args.runs);args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({key:result[key]['median_first_paint_seconds'] for key in ('baseline','current')}))

if __name__=='__main__':main()
