"""Regressions from six independent Trial65 audits. Synthetic data only."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import sys,copy,json,tempfile,base64,hashlib,unittest
from pathlib import Path
from unittest.mock import patch
from engine import DEFAULT,read_config,xlsx_read,reconcile,save_json,display_time
from cache_tags import parser_tag
from employee_information import recover_employee_save
from outlook_mail import DEFAULT_MAIL_SETTINGS,addresses,build_mail_plans,show_mail_dialog
from classic_outlook import process_classic_plans
from mail_state import mail_payload
from openpyxl import Workbook
from PySide6.QtCore import QTimer,Qt
from PySide6.QtWidgets import QApplication,QWidget,QPushButton,QTableWidget
import runtime_paths
IMPORT=tempfile.TemporaryDirectory()
with patch.object(runtime_paths,'get_data_dir',return_value=Path(IMPORT.name)):import main
APP=QApplication.instance() or QApplication([]);APP.setQuitOnLastWindowClosed(False)

class Audit65(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
 def book(self,period):
  path=self.root/'attendance.xlsx';wb=Workbook();ws=wb.active;ws.title='10月';ws['A1']=period;ws['N1']='E1';ws['U1']='Name';ws['A9']=10;ws['B9']=1;wb.save(path);wb.close();return path
 def test_semantically_corrupt_snapshot_cannot_modify_either_file(self):
  mp=self.root/'staff_mapping.json';cp=self.root/'employee_contacts.json';mp.write_text('{"E1":"S1"}');cp.write_text('{"version":1,"contacts":[]}');before=(mp.read_bytes(),cp.read_bytes())
  for bad in (b'',b'not JSON',b'[]',b'null',b'{"E1":2}'):
   journal=self.root/'employee_save_transaction.json';save_json(journal,{'mapping':base64.b64encode(bad).decode(),'contacts':None})
   with self.assertRaises(ValueError):recover_employee_save(mp,cp)
   self.assertEqual((mp.read_bytes(),cp.read_bytes()),before);self.assertTrue(journal.exists())
 def test_missing_read_options_share_defaults_without_mutating_input(self):
  for key in ('year','month','data_first_row','data_last_row','csv_first_row','csv_encoding'):
   cfg=copy.deepcopy(DEFAULT);del cfg[key];before=copy.deepcopy(cfg)
   self.assertEqual(read_config(cfg),DEFAULT);self.assertEqual(parser_tag(cfg,'xlsx'),parser_tag(DEFAULT,'xlsx'));self.assertEqual(parser_tag(cfg,'csv'),parser_tag(DEFAULT,'csv'));self.assertEqual(cfg,before)
 def test_clock_field_identity_changes_cache_but_enabled_flag_does_not(self):
  cfg=copy.deepcopy(DEFAULT);before=parser_tag(cfg,'xlsx');cfg['comparisons'][3]['type']='clock'
  self.assertNotEqual(parser_tag(cfg,'xlsx'),before);changed=parser_tag(cfg,'xlsx');cfg['comparisons'][3]['enabled']=True;self.assertEqual(parser_tag(cfg,'xlsx'),changed)
 def test_cache_value_keys_and_types_are_validated(self):
  packet={'records':[{'date':'2026-10-01','staff':'S1','name':'Name','file':'synthetic.csv','row':2,'invalid_fields':[],'missing_fields':[],'values':{key:None for key in DEFAULT['csv_columns']}}]}
  self.assertTrue(main.ReadWorker._valid_cached_packet(packet,False))
  for key in DEFAULT['csv_columns']:
   broken=copy.deepcopy(packet);del broken['records'][0]['values'][key];self.assertFalse(main.ReadWorker._valid_cached_packet(broken,False))
  for bad in ({},[],{'nested':1}):
   broken=copy.deepcopy(packet);broken['records'][0]['values']['start']=bad;self.assertFalse(main.ReadWorker._valid_cached_packet(broken,False))
 def test_nonzero_seconds_remain_distinguishable(self):
  self.assertEqual(display_time('9:00','clock'),'9:00');self.assertEqual(display_time('9:00:01','clock'),'9:00:01');self.assertEqual(display_time('9:00:02','clock'),'9:00:02');self.assertEqual(display_time('25:00:01','duration'),'25:00:01');self.assertEqual(display_time('25:00:01','clock'),'1:00:01')
 def test_unknown_period_never_reports_ordinary_matches(self):
  for period in ('',None,'not a period'):
   packet=xlsx_read(self.book(period),copy.deepcopy(DEFAULT));self.assertTrue(packet['period_unverified']);self.assertTrue(packet['warnings']);self.assertEqual(len(packet['records']),1)
   rows,_=reconcile({'E1':packet},[{'date':'2026-10-01','staff':'S1','name':'Name','values':{}}],{'E1':'S1'},copy.deepcopy(DEFAULT));self.assertEqual([r['status'] for r in rows],['要確認']);self.assertIn('対象年月',rows[0]['field'])
 def test_known_period_formats_check_year(self):
  for period in ('2025年10月','2025 年 10 月度','2025/10','2025-10'):
   self.assertIn('対象年月の不一致',xlsx_read(self.book(period),copy.deepcopy(DEFAULT))['error'])
  for period in ('2026年10月','2026 年 10 月度','2026/10','2026-10'):
   self.assertFalse(xlsx_read(self.book(period),copy.deepcopy(DEFAULT))['period_unverified'])
 def test_default_optional_to_keeps_employee_and_seconds_in_body(self):
  rows=[dict(employee='E1',staff='S1',name='Name',date='2026-10-01',field='Start',xlsx='9:00:01',csv='9:00:02',status='不一致')]
  contacts={'contacts':[dict(employee='E1',staff='S1',name='Name',email='employee@example.com')]}
  plan=build_mail_plans(rows,contacts,{'E1':'S1'},copy.deepcopy(DEFAULT_MAIL_SETTINGS),{'year':2026,'month':10})[0]
  self.assertEqual(plan['to'],['employee@example.com']);self.assertFalse(plan['problem']);self.assertIn('9:00:01',plan['body']);self.assertIn('9:00:02',plan['body'])
 def test_trailing_delimiters_do_not_silently_discard_addresses(self):
  for text in ('a@example.com;','a@example.com,',' ; a@example.com ; ', '"Last, First" <a@example.com>;'):
   self.assertEqual(addresses(text),['a@example.com'])
  for bad in ('<broken','(','a@example.com <'):
   with self.assertRaises(ValueError):addresses(bad)
 def fixture(self):
  from test_trial64_classic_mail import Outlook
  return Outlook(self.root),{'employee':'E1','staff':'S1','name':'Name','to':['employee@example.com'],'cc':['cc@example.com'],'subject':'Subject','body':'Body','problem':'','recipient_names':{'cc@example.com':'Old CC'}}
 def test_com_name_only_change_cannot_repeat_real_content(self):
  outlook,plan=self.fixture();settings={**DEFAULT_MAIL_SETTINGS,'account':'operator@example.com','auto_send':True}
  process_classic_plans([plan],settings,self.root,outlook);plan['recipient_names']['cc@example.com']='New CC';process_classic_plans([plan],settings,self.root,outlook);self.assertEqual(outlook.events.count('Send'),1)
 def test_old_com_history_alias_prevents_later_name_change_repeat(self):
  outlook,plan=self.fixture();settings={**DEFAULT_MAIL_SETTINGS,'account':'operator@example.com'}
  key=hashlib.sha256(json.dumps([settings['account'],'classic_outlook',False,'E1','S1',mail_payload(plan)],ensure_ascii=False,sort_keys=True).encode()).hexdigest()
  save_json(self.root/'mail_processing_history.json',{key:{'employee':'E1','status':'draft','backend':'classic_outlook'}})
  process_classic_plans([plan],settings,self.root,outlook);plan['recipient_names']['cc@example.com']='New CC';process_classic_plans([plan],settings,self.root,outlook);self.assertFalse(outlook.messages)
 def test_mail_dialog_can_process_remaining_employee_after_first_batch(self):
  from test_trial54_mail import Mail
  fixture=Mail();parent=QWidget();parent.is_dark=False;calls=[];errors=[];attempt=[0]
  def button(dialog):return next(b for b in dialog.findChildren(QPushButton) if b.text()=='Outlookの下書きを作成')
  def process(plans,settings,data_dir):calls.append([p['employee'] for p in plans]);return [{'employee':p['employee'],'status':'下書き保存済み'} for p in plans]
  def poll():
   attempt[0]+=1;dialog=APP.activeModalWidget();table=dialog.findChild(QTableWidget)
   if attempt[0]>200:errors.append('worker timeout');dialog.reject();return
   if len(calls)==1 and table.item(0,3).text()=='下書き保存済み' and button(dialog).isEnabled():
    table.item(1,0).setCheckState(Qt.Checked);button(dialog).click()
   if len(calls)==2 and table.isEnabled() and not button(dialog).isEnabled():dialog.reject();return
   QTimer.singleShot(10,poll)
  def start():
   dialog=APP.activeModalWidget();dialog.findChild(QTableWidget).item(1,0).setCheckState(Qt.Unchecked);button(dialog).click();QTimer.singleShot(10,poll)
  try:
   with patch('classic_outlook.process_classic_plans',side_effect=process),patch('PySide6.QtWidgets.QMessageBox.information'),patch('PySide6.QtWidgets.QMessageBox.warning'):
    QTimer.singleShot(0,start);show_mail_dialog(parent,fixture.plans(),fixture.settings(),self.root)
   self.assertFalse(errors);self.assertEqual(calls,[['E1'],['E2']])
  finally:parent.close();APP.processEvents()

if __name__=='__main__':unittest.main(verbosity=2)
