"""Initial attendance month from the device's local calendar date."""
from datetime import date


def current_attendance_month(today=None):
    today=date.today() if today is None else today
    return today.year,today.month
