"""Guide (onboarding tour) definitions and display settings — no Qt imports.

The tour walks a first-time user through the real workflow in order:

1. ``employee``       register employee information (ID / name / e-mail)
2. ``period_folder``  check the target month and choose the attendance folder
3. ``csv_load``       confirm the client CSV is in the same folder and run the read
4. ``results``        review the comparison results
5. ``mail``           create mail for employees with mismatches (only when needed)

Display preferences live in the main settings JSON under ``guides``::

    {"all_off": false, "hidden": ["results", "mail"]}

``all_off`` hides every guide; ``hidden`` hides individual guides.  Both are
editable from the guide panel itself and from 設定 → ガイド, and the two stay
in sync because they read and write the same structure.
"""
from __future__ import annotations

import copy

GUIDE_STEPS = [
    {
        'id': 'employee',
        'title': 'まず、社員情報を読み込みます',
        'body': (
            '勤怠チェックの前に、社員情報CSVを読み込んで社員情報を登録します。\n'
            '右上の「社員情報」を押して、画面の「社員情報を読み込む」からCSVを選び、'
            'ID・氏名・メールアドレスを確認して「社員情報を登録」を押してください。\n'
            '登録が終わると、次のガイドが自動で表示されます。'
        ),
        'action': '社員情報を開く',
    },
    {
        'id': 'period_folder',
        'title': '月度を確認し、勤怠ファイルのフォルダを選びます',
        'body': (
            '対象月度は起動日の年・月が自動で入っています。別の月度を調べるときだけ変更してください。\n'
            '次に、派遣元の勤怠ファイル（社員別XLSX）が入ったフォルダを「フォルダ選択」から選ぶか、'
            'メイン画面へフォルダをドロップします。フォルダを選ぶと次のガイドへ進みます。'
        ),
        'action': 'フォルダを選ぶ',
    },
    {
        'id': 'csv_load',
        'title': '派遣先CSVも同じフォルダに入れて、読み込みます',
        'body': (
            '派遣先の月別CSVは、XLSXと同じフォルダに入れてください。'
            '「読み込み・照合」を押すと、XLSXとCSVをまとめて読み込んで照合します。\n'
            'CSVが入っていないフォルダでは読み込みを始められません。'
        ),
        'action': '読み込み・照合を実行',
    },
    {
        'id': 'results',
        'title': '照合結果を確認します',
        'body': (
            '読み込みが終わると、上の数字と一覧に結果が出ます。\n'
            '「不一致のみ」で差異のある行だけを確認できます。行をダブルクリックすると詳細の対比表、'
            '右クリックで元のExcelの該当セルを開けます。\n'
            '問題（不一致・要確認）がなければ、これで完了です。'
        ),
        'action': '確認しました',
    },
    {
        'id': 'mail',
        'title': '問題があれば、メールを作成します',
        'body': (
            '不一致がある社員には、照合結果の「メールを作成」から連絡メールを作れます。\n'
            '宛先は社員情報に登録したメールアドレスです。設定により、Outlookの下書き保存か、'
            'そのまま送信かが変わります（設定 → メール）。\n'
            'メール画面を閉じるとガイドは終了です。'
        ),
        'action': 'メールを作成',
    },
]

STEP_IDS = [step['id'] for step in GUIDE_STEPS]
STEP_TITLES = {step['id']: step['title'] for step in GUIDE_STEPS}

DEFAULT_GUIDE_SETTINGS = {'all_off': False, 'hidden': []}


def normalize_guide_settings(raw):
    """Return a clean ``{'all_off': bool, 'hidden': [step_id, ...]}`` dict.

    Unknown step ids and malformed values are dropped rather than raising,
    so a hand-edited or older settings file can never break startup.
    Use ``validate_guide_settings`` where a strict check is required
    (the settings dialog's JSON validation).
    """
    if not isinstance(raw, dict):
        return copy.deepcopy(DEFAULT_GUIDE_SETTINGS)
    hidden = raw.get('hidden')
    if not isinstance(hidden, list):
        hidden = []
    cleaned = []
    for step_id in hidden:
        if step_id in STEP_IDS and step_id not in cleaned:
            cleaned.append(step_id)
    return {'all_off': bool(raw.get('all_off', False)), 'hidden': cleaned}


def validate_guide_settings(raw):
    """Raise ValueError with a Japanese message if ``raw`` is malformed."""
    if raw is None:
        return
    if not isinstance(raw, dict):
        raise ValueError('JSONのガイド設定はオブジェクト形式で入力してください。')
    if 'all_off' in raw and not isinstance(raw['all_off'], bool):
        raise ValueError('JSONのガイド設定「all_off」はtrueまたはfalseで入力してください。')
    hidden = raw.get('hidden')
    if hidden is not None:
        if not isinstance(hidden, list) or not all(isinstance(v, str) for v in hidden):
            raise ValueError('JSONのガイド設定「hidden」はガイドIDのリストで入力してください。')
        unknown = [v for v in hidden if v not in STEP_IDS]
        if unknown:
            raise ValueError('JSONのガイド設定「hidden」に不明なガイドIDがあります：' + ', '.join(unknown))


def step_visible(settings, step_id):
    """True when the guide for ``step_id`` should be shown under ``settings``."""
    cleaned = normalize_guide_settings(settings)
    return not cleaned['all_off'] and step_id not in cleaned['hidden']


def visible_step_ids(settings):
    cleaned = normalize_guide_settings(settings)
    if cleaned['all_off']:
        return []
    return [step_id for step_id in STEP_IDS if step_id not in cleaned['hidden']]


def next_visible_step(settings, after_id=None):
    """First visible step id after ``after_id`` (from the start when None)."""
    visible = visible_step_ids(settings)
    if after_id is None:
        return visible[0] if visible else None
    if after_id in STEP_IDS:
        later = STEP_IDS[STEP_IDS.index(after_id) + 1:]
        return next((step_id for step_id in later if step_id in visible), None)
    return visible[0] if visible else None


def with_step_hidden(settings, step_id, hidden=True):
    """Copy of ``settings`` with one step hidden (or shown again)."""
    cleaned = normalize_guide_settings(settings)
    if step_id in STEP_IDS:
        if hidden and step_id not in cleaned['hidden']:
            cleaned['hidden'].append(step_id)
        if not hidden and step_id in cleaned['hidden']:
            cleaned['hidden'].remove(step_id)
    return cleaned


def with_all_off(settings, off=True):
    """Copy of ``settings`` with the master hide switch set."""
    cleaned = normalize_guide_settings(settings)
    cleaned['all_off'] = bool(off)
    return cleaned
