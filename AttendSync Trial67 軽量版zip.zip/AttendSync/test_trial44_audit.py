"""Audit regressions for ID management edge cases discovered after Trial43."""
import os,sys
if os.environ.get('ATTENDSYNC_AUDIT_BASELINE'):sys.path.insert(0,os.environ['ATTENDSYNC_AUDIT_BASELINE'])
import copy,unittest
from unittest.mock import patch
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QTableWidget,QPushButton,QComboBox
import test_trial38_audit as fixture
import main

class Audit44(unittest.TestCase):
 setUpClass=classmethod(fixture.Audit38.setUpClass.__func__)
 setUp=fixture.Audit38.setUp
 def inspect(self,callback):
  errors=[];before=copy.deepcopy(self.w.mapping)
  def examine():
   dialog=self.app.activeModalWidget()
   try:
    dialog.findChild(QComboBox,'employeeFilter').setCurrentIndex(1)
    callback(dialog,dialog.findChild(QTableWidget,'employeeIdTable'))
   except Exception as exc:errors.append(exc)
   finally:dialog.reject()
  QTimer.singleShot(0,examine);fixture.register_roster(self.w);self.w.edit_map()
  self.assertFalse(errors,errors);self.assertEqual(self.w.mapping,before)
 def test_whitespace_saved_staff_is_visible_as_unlinked(self):
  self.w.loaded_xdata={'A':{'name':'社員A'},'B':{'name':'社員B'}};self.w.mapping={'A':'  ','B':'S2'}
  def inspect(dialog,table):
   self.assertFalse(table.isRowHidden(0));self.assertTrue(table.isRowHidden(1))
  self.inspect(inspect)
 def test_added_employee_filter_updates_when_staff_is_entered(self):
  self.w.loaded_xdata={'A':{'name':'社員A'}};self.w.mapping={}
  def inspect(dialog,table):
   next(b for b in dialog.findChildren(QPushButton) if b.text()=='社員番号を追加').click()
   combo=table.cellWidget(1,2);combo.setEditText('S2');combo.lineEdit().editingFinished.emit()
   self.assertTrue(table.isRowHidden(1))
  self.inspect(inspect)
 def test_added_employee_filter_updates_when_candidate_is_selected(self):
  self.w.loaded_xdata={'A':{'name':'社員A'}};self.w.loaded_cdata=[{'staff':'S2','name':'社員B'}];self.w.mapping={}
  def inspect(dialog,table):
   next(b for b in dialog.findChildren(QPushButton) if b.text()=='社員番号を追加').click()
   combo=table.cellWidget(1,2);combo.setCurrentIndex(1);combo.activated.emit(1)
   self.assertTrue(table.isRowHidden(1))
  self.inspect(inspect)
 def test_normalized_existing_staff_id_is_not_offered_to_another_employee(self):
  self.w.loaded_xdata={'A':{'name':'社員A'},'B':{'name':'社員B'}};self.w.loaded_cdata=[{'staff':'S1','name':'社員A'},{'staff':'S2','name':'社員B'}];self.w.mapping={'A':' S1 '}
  def inspect(dialog,table):
   combo=table.cellWidget(1,2);ids=[combo.itemData(i) for i in range(combo.count())]
   self.assertNotIn('S1',ids);self.assertIn('S2',ids)
  self.inspect(inspect)
 def test_saved_mapping_without_csv_names_can_be_saved_without_changing_ids(self):
  self.w.loaded_xdata={};self.w.loaded_cdata=[];self.w.mapping={'A':'S1','B':'S2'}
  errors=[]
  def save():
   dialog=self.app.activeModalWidget()
   try:next(b for b in dialog.findChildren(QPushButton) if b.text()=='社員情報を登録').click()
   except Exception as exc:errors.append(exc);dialog.reject()
  with patch.object(main,'save_json') as writer,patch.object(self.w,'run_read'):
   QTimer.singleShot(0,save);fixture.register_roster(self.w);self.w.edit_map();self.app.processEvents()
  self.assertFalse(errors,errors)
  self.assertEqual(self.w.mapping,{'A':'S1','B':'S2'})
  self.assertEqual(writer.call_args.args[1],{'A':'S1','B':'S2'})
 def test_blank_or_trailing_csv_name_does_not_enter_saved_id(self):
  for name in ('','社員A   '):
   self.w.loaded_xdata={'A':{'name':'社員A'}};self.w.loaded_cdata=[{'staff':'S1','name':name}];self.w.mapping={'A':'S1'}
   def save():
    dialog=self.app.activeModalWidget()
    next(b for b in dialog.findChildren(QPushButton) if b.text()=='社員情報を登録').click()
    if dialog.isVisible():dialog.reject()
   with patch.object(main,'save_json') as writer,patch.object(self.w,'run_read'),patch.object(main.QMessageBox,'question') as question:
    QTimer.singleShot(0,save);fixture.register_roster(self.w);self.w.edit_map();self.app.processEvents()
   question.assert_not_called();self.assertEqual(writer.call_args.args[1],{'A':'S1'})
 def test_new_employee_save_uses_typed_id_and_omits_unlinked_employee(self):
  self.w.loaded_xdata={'A':{'name':'社員A'}};self.w.mapping={};errors=[]
  def save():
   dialog=self.app.activeModalWidget()
   try:
    table=dialog.findChild(QTableWidget,'employeeIdTable')
    next(b for b in dialog.findChildren(QPushButton) if b.text()=='社員番号を追加').click()
    table.item(1,0).setText('B');combo=table.cellWidget(1,2);combo.setEditText(' S2 ');combo.lineEdit().editingFinished.emit()
    next(b for b in dialog.findChildren(QPushButton) if b.text()=='社員情報を登録').click()
   except Exception as exc:errors.append(exc);dialog.reject()
  with patch.object(main,'save_json') as writer,patch.object(self.w,'run_read'):
   QTimer.singleShot(0,save);fixture.register_roster(self.w);self.w.edit_map();self.app.processEvents()
  self.assertFalse(errors,errors);self.assertEqual(writer.call_args.args[1],{'B':'S2'})
 def test_normalized_duplicate_staff_id_is_rejected(self):
  self.w.loaded_xdata={'A':{'name':'社員A'},'B':{'name':'社員B'}};self.w.mapping={'B':' S2 '}
  def inspect(dialog,table):
   table.cellWidget(0,2).setEditText('S2')
   with patch.object(main.QMessageBox,'warning') as warning,patch.object(main,'save_json') as writer:
    next(b for b in dialog.findChildren(QPushButton) if b.text()=='社員情報を登録').click()
   warning.assert_called_once();writer.assert_not_called();self.assertTrue(dialog.isVisible())
  self.inspect(inspect)

if __name__=='__main__':unittest.main(verbosity=2)
