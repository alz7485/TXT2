from __future__ import annotations

def file_signature(path, tag=''):
    """Fingerprint content as well as metadata; restored timestamps are not identity."""
    import hashlib
    before=path.stat();digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            digest.update(block)
    after=path.stat()
    if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):
        raise RuntimeError('内容確認中に元ファイルが更新されました。再読み込みしてください。')
    return f'{after.st_size}:{after.st_mtime_ns}:{digest.hexdigest()}:{tag}'

def parse_stable_file(parser, path, cfg):
    """Reject any source modified while it was being parsed.

    Content and metadata must remain unchanged across the parse.
    """
    before = file_signature(path)
    result = parser(path, cfg)
    after = file_signature(path)
    if before != after:
        return {'error': '解析中に元ファイルが更新されました。保存完了後に再読み込みしてください。'}
    return result


