"""Real QThread cancellation/restart and mapping dialog button/edit transitions."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import copy,json,tempfile,time,threading
from pathlib import Path
from unittest.mock import patch
from PySide6.QtWidgets import QApplication,QDialog,QPushButton,QTableWidget,QMessageBox,QComboBox
from PySide6.QtCore import QTimer, QObject, Signal
from PySide6.QtTest import QTest
import main
from engine import DEFAULT
from test_trial38_audit import register_roster
app=QApplication.instance() or QApplication([])
def until(predicate,seconds=60):
    deadline=time.monotonic()+seconds
    while not predicate():
        assert time.monotonic()<deadline,'Qt wait timeout'
        app.processEvents();QTest.qWait(5)
    app.processEvents()
with tempfile.TemporaryDirectory() as tmp:
    base=Path(tmp)
    main.CONFIG=base/'settings.json';main.MAP=base/'map.json';main.DB=base/'cache.sqlite'
    w=main.Window();w.cfg=copy.deepcopy(DEFAULT)
    folder=Path(__file__).parent/'SampleData_120'
    w.path.setText(str(folder));w.year.setValue(2026);w.month.setValue(10)
    w.mapping=json.loads((folder/'期待結果.json').read_text())['id_mapping']
    main.save_json(main.MAP.with_name('employee_contacts.json'),{'version':1,'contacts':[],'employee_information_registered':True})
    real_parse=main.parse_stable_file
    # Stop while parsers are running, hold them until stop has been requested.
    for cycle in range(2):
        entered=threading.Event();release=threading.Event()
        def delayed(*args):
            entered.set();assert release.wait(10);return real_parse(*args)
        with patch.object(main,'parse_stable_file',side_effect=delayed):
            w.run_read(full=True)
            until(entered.is_set)
            old=w.worker;w.stop_read()
            assert not w.stop_button.isEnabled() and not w.run_button.isEnabled()
            w.run_read();assert w.worker is old
            release.set();until(lambda:not old.isRunning())
            until(w.run_button.isEnabled)
            assert '中止' in w.status.text()
    w.run_read();until(lambda:not w.worker.isRunning());until(w.run_button.isEnabled)
    from collections import Counter
    assert Counter(r['status'] for r in w.results)=={'一致':10797,'不一致':3}
    # Queued stale signals are ignored even after a new worker replaces the old one.
    class Stale(QObject):
        progress=Signal(int,int,str)
        result=Signal(object,object,object,object)
    stale=Stale();stale.progress.connect(w.on_progress);stale.result.connect(w.read_done)
    before=(w.status.text(),list(w.results),w.progress.value())
    stale.progress.emit(0,122,'stale');stale.result.emit({},[],[],{'cancelled':True})
    assert (w.status.text(),w.results,w.progress.value())==before
    w.loaded_xdata={'A':{'name':'一致 氏名'},'B':{'name':'別人'}}
    w.loaded_cdata=[{'staff':'A','name':'他人'},{'staff':'Z','name':'一致氏名'},{'staff':'C','name':'別人'}]
    w.mapping={'B':'C'}
    failures=[]
    def inspect():
        dialog=app.activeModalWidget()
        try:
            table=dialog.findChild(QTableWidget,'employeeIdTable')
            toggle=dialog.findChild(QComboBox,'employeeFilter');toggle.setCurrentIndex(1)
            assert not table.isRowHidden(0) and table.isRowHidden(1)
            assert table.cellWidget(0,2).itemData(1)=='Z' # matching name first
            toggle.setCurrentIndex(0);assert toggle.currentData()=='all' and not table.isRowHidden(1)
            toggle.setCurrentIndex(1);assert toggle.currentData()=='id'
            combo=table.cellWidget(0,2);combo.setEditText('Z');combo.lineEdit().editingFinished.emit()
            assert table.isRowHidden(0) # unsaved edit follows the filter
            toggle.setCurrentIndex(0)
            # Assign the same ID to both people: save must fail and retain dialog.
            table.cellWidget(1,2).setEditText('Z')
            save=next(b for b in dialog.findChildren(QPushButton) if b.text()=='社員情報を登録')
            with patch.object(QMessageBox,'warning') as message:
                save.click();assert message.called and w.mapping=={'B':'C'}
        except Exception as exc:failures.append(exc)
        finally:dialog.reject()
    register_roster(w);QTimer.singleShot(0,inspect);w.edit_map();assert not failures,failures
    w.close()
print('PASS: real QThread repeated stop/restart, 10800 rows, stale signals ignored; mapping labels, unsaved edits, name priority, duplicate rejection')
