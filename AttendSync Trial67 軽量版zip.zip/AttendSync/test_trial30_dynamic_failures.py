"""GUIライブラリなしで実 ReadWorker.run を駆動し、破損ファイルと解析失敗を実証。"""
from __future__ import annotations
import ast, sys, tempfile, shutil, json, time, traceback
from pathlib import Path
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED

BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE))
from engine import Cache,DEFAULT,xlsx_read,csv_read,read_config
from cache_tags import parser_tag
from stable_read import parse_stable_file

class SignalCollector:
    def __init__(self,*_):self.events=[]
    def emit(self,*args):self.events.append(args)
class SignalDescriptor:
    def __init__(self,*_):self.slot_name=None
    def __set_name__(self,owner,name):self.slot_name="_signal_"+name
    def __get__(self,obj,owner):
        if obj is None:return self
        if self.slot_name not in obj.__dict__:obj.__dict__[self.slot_name]=SignalCollector()
        return obj.__dict__[self.slot_name]
class FakeThread:
    def __init__(self):self.interrupted=False
    def requestInterruption(self):self.interrupted=True
    def isInterruptionRequested(self):return self.interrupted

source=ast.parse((BASE/'main.py').read_text(encoding='utf-8'))
cls=next(node for node in source.body if isinstance(node,ast.ClassDef) and node.name=='ReadWorker')
ns=dict(read_config=read_config,QThread=FakeThread,Signal=SignalDescriptor,Path=Path,json=json,Cache=Cache,DEFAULT=DEFAULT,xlsx_read=xlsx_read,csv_read=csv_read,
        parser_tag=parser_tag,parse_stable_file=parse_stable_file,ThreadPoolExecutor=ThreadPoolExecutor,wait=wait,FIRST_COMPLETED=FIRST_COMPLETED,
        time=time,traceback=traceback)
exec(compile(ast.fix_missing_locations(ast.Module(body=[cls],type_ignores=[])),str(BASE/'main.py'),'exec'),ns)
ReadWorker=ns['ReadWorker']

samples=BASE/'SampleData_120'
xlsx=next(samples.glob('*.xlsx'))
csv=next(samples.glob('*.csv'))
with tempfile.TemporaryDirectory(prefix='attendsync_trial30_') as t:
    folder=Path(t)/'source';folder.mkdir()
    shutil.copy2(xlsx,folder/xlsx.name)
    shutil.copy2(csv,folder/csv.name)
    (folder/'BROKEN.xlsx').write_bytes(b'not a zip file')
    ns['DB']=Path(t)/'cache.sqlite'
    def run(full=False, injected=False):
        w=ReadWorker(folder,DEFAULT,full)
        w.run()
        assert len(w.result.events)==1
        xd,cd,issues,stats=w.result.events[0]
        assert not stats['cancelled'],stats
        assert stats['files_found']==3,stats
        assert stats['files_completed']==3,stats
        assert stats['files_failed']==(2 if injected else 1),stats
        assert any('BROKEN.xlsx' in e['file'] for e in stats['file_errors']),stats
        assert len(xd)==(0 if injected else 1) and len(cd)>0,(len(xd),len(cd))
        return stats
    first=run(); cached=run()
    assert cached['cache_hits']>=2,cached
    # Fault injection: simulate stat failure on one real input, verify accounting.
    original_stat=Path.stat
    seen=[0]
    def forbidden_stat(self,*args,**kwargs):
        if self.name==xlsx.name and self.parent==folder:
            seen[0]+=1
            if seen[0]>=2:raise OSError('injected stat failure')
        return original_stat(self,*args,**kwargs)
    Path.stat=forbidden_stat
    try:
        stats=run(injected=True)
        assert stats['files_failed']==2,stats
        assert stats['files_completed']==stats['files_found'],stats
    finally:Path.stat=original_stat
    print('PASS Trial30: corrupted XLSX, cache reuse, injected stat error, consistent file counts')
