"""Fault-injection tests of classic Outlook draft/send. No real COM/network."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import copy,json,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch
from classic_outlook import process_classic_plans
from mail_state import mail_lock
from engine import save_json
from outlook_mail import DEFAULT_MAIL_SETTINGS

class Collection:
 def __init__(self,items):self.items=items;self.Count=len(items)
 def Item(self,index):return self.items[index-1]

class Recipients:
 def __init__(self,app):self.app=app;self.items=[]
 def Add(self,address):
  recipient=NS(address=address,Type=0);self.items.append(recipient);return recipient
 def ResolveAll(self):return not self.app.resolve_failure

class Message:
 def __init__(self,app,account):
  self.app=app;self.account=account;self.Recipients=Recipients(app);self._sender=None;self.EntryID='';self.Subject='';self.Body=''
 @property
 def SendUsingAccount(self):return self._sender
 @SendUsingAccount.setter
 def SendUsingAccount(self,value):self._sender=self.app.accounts[0] if self.app.ignore_sender else value
 def Save(self):
  self.app.events.append('Save')
  self.app.assert_ledger('creating')
  if self.app.save_failure:raise OSError('synthetic Save failure')
  self.EntryID='id-'+str(len(self.app.messages))
  if self.app.change_sender_on_save:self._sender=self.app.accounts[0]
 def Send(self):
  self.app.events.append('Send');self.app.assert_ledger('sending')
  if self.app.send_failure:raise TimeoutError('synthetic ambiguous Send failure')

class Items:
 def __init__(self,app,account):self.app=app;self.account=account
 def Add(self,message_class):
  assert message_class=='IPM.Note';self.app.assert_ledger('creating')
  self.app.events.append('Add');message=Message(self.app,self.account);self.app.messages.append(message);return message

class Store:
 def __init__(self,app,account):self.app=app;self.account=account
 def GetDefaultFolder(self,kind):
  assert kind==16;self.app.folder_accounts.append(self.account.SmtpAddress);return NS(Items=Items(self.app,self.account))

class Outlook:
 def __init__(self,path):
  self.path=path;self.events=[];self.messages=[];self.folder_accounts=[]
  self.ignore_sender=False;self.change_sender_on_save=False;self.resolve_failure=False;self.save_failure=False;self.send_failure=False
  self.accounts=[NS(SmtpAddress='other@example.com',DisplayName='Other'),NS(SmtpAddress='operator@example.com',DisplayName='Operator')]
  for account in self.accounts:account.DeliveryStore=Store(self,account)
  self.Session=NS(Accounts=Collection(self.accounts))
 def assert_ledger(self,status):
  ledger=json.loads((self.path/'mail_processing_history.json').read_text());assert any(r.get('status')==status for r in ledger.values() if isinstance(r,dict)),(status,ledger)
 def CreateItem(self,*args):raise AssertionError('Must use selected account Drafts, not the default account')

class ClassicMail64(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.path=Path(self.tmp.name);self.outlook=Outlook(self.path)
  self.settings={**DEFAULT_MAIL_SETTINGS,'account':'operator@example.com'}
  self.plans=[{'employee':f'E{i}','staff':f'S{i}','name':f'User {i}','to':[f'user{i}@example.com','fixed@example.com'],'cc':['cc@example.com'],'subject':f'Subject {i}','body':f'User {i}殿\n派遣元：9:00\n派遣先：9:05','problem':''} for i in (1,2)]
 def run_mail(self,plans=None,settings=None):return process_classic_plans(self.plans if plans is None else plans,settings or self.settings,self.path,self.outlook)
 def test_draft_mode_needs_no_app_id_and_uses_selected_account_folder(self):
  results=self.run_mail();self.assertTrue(all(r['status']=='下書き保存済み' for r in results));self.assertNotIn('Send',self.outlook.events)
  self.assertEqual(self.outlook.folder_accounts,['operator@example.com']*2)
  for plan,message in zip(self.plans,self.outlook.messages):
   self.assertIs(message.SendUsingAccount,self.outlook.accounts[1]);self.assertEqual(message.Subject,plan['subject']);self.assertEqual(message.Body,plan['body'])
   self.assertEqual([(r.address,r.Type) for r in message.Recipients.items],[(a,1) for a in plan['to']]+[(a,2) for a in plan['cc']])
 def test_send_saves_first_then_requests_send_and_blocks_repeat(self):
  self.settings['auto_send']=True;result=self.run_mail();self.assertTrue(all(r['status']=='送信要求済み' for r in result));self.assertEqual(self.outlook.events,['Add','Save','Send','Add','Save','Send'])
  before=list(self.outlook.events);self.run_mail();self.assertEqual(self.outlook.events,before)
 def test_drafts_block_repeat_even_if_unused_legacy_app_id_changes(self):
  self.run_mail();self.settings['client_id']='unused-value';self.settings['tenant_id']='also-unused';result=self.run_mail()
  self.assertEqual(len(self.outlook.messages),2);self.assertTrue(all(r['status']=='同内容の下書き保存済み' for r in result))
 def test_unknown_or_duplicate_sender_never_creates_mail(self):
  for duplicate in (False,True):
   if duplicate:self.outlook.accounts.append(self.outlook.accounts[1]);self.outlook.Session.Accounts=Collection(self.outlook.accounts)
   else:self.settings['account']='missing@example.com'
   if duplicate:self.settings['account']='operator@example.com'
   with self.assertRaises(ValueError):self.run_mail()
   self.assertFalse(self.outlook.messages)
 def test_missing_sender_and_bad_second_plan_fail_before_any_creation(self):
  for settings,plans in (({**self.settings,'account':''},self.plans),(self.settings,[self.plans[0],{**self.plans[1],'to':['invalid']}]),(self.settings,[{**self.plans[0],'problem':'未登録'}]),(self.settings,[{**self.plans[0],'subject':'subject\nBcc: bad'}])):
   with self.assertRaises(ValueError):self.run_mail(plans,settings)
   self.assertFalse(self.outlook.messages)
 def test_sender_assignment_failure_does_not_save_or_send(self):
  self.outlook.ignore_sender=True;self.settings['auto_send']=True;result=self.run_mail()
  self.assertTrue(result[0].get('error'));self.assertEqual(result[1]['status'],'未処理');self.assertEqual(self.outlook.events,['Add'])
 def test_sender_change_during_save_never_sends(self):
  self.outlook.change_sender_on_save=True;self.settings['auto_send']=True;result=self.run_mail()
  self.assertTrue(result[0].get('error'));self.assertEqual(self.outlook.events,['Add','Save'])
 def test_unresolved_recipient_never_saves_or_sends(self):
  self.outlook.resolve_failure=True;result=self.run_mail();self.assertIn('宛先',result[0]['error']);self.assertEqual(self.outlook.events,['Add']);self.assertEqual(result[1]['status'],'未処理')
 def test_failed_save_stops_batch_and_does_not_send(self):
  self.outlook.save_failure=True;self.settings['auto_send']=True;result=self.run_mail();self.assertTrue(result[0].get('error'));self.assertEqual(result[1]['status'],'未処理');self.assertNotIn('Send',self.outlook.events)
 def test_ambiguous_send_retains_sending_and_does_not_retry(self):
  self.outlook.send_failure=True;self.settings['auto_send']=True;result=self.run_mail();self.assertTrue(result[0].get('error'));self.assertEqual(result[1]['status'],'未処理')
  ledger=json.loads((self.path/'mail_processing_history.json').read_text());self.assertEqual(next(iter(ledger.values()))['status'],'sending')
  events=list(self.outlook.events);result=self.run_mail(self.plans[:1]);self.assertEqual(self.outlook.events,events);self.assertIn('再実行を停止',result[0]['status'])
 def test_failed_history_write_prevents_outlook_creation(self):
  with patch('engine.save_json',side_effect=PermissionError('denied')):result=self.run_mail()
  self.assertTrue(result[0].get('error'));self.assertFalse(self.outlook.messages)
 def test_failed_history_write_after_send_cannot_resend(self):
  self.settings['auto_send']=True
  def writer(path,value):
   if any(isinstance(r,dict) and r.get('status')=='sent' for r in value.values()):raise OSError('disk failure after send')
   save_json(path,value)
  with patch('engine.save_json',side_effect=writer):result=self.run_mail(self.plans[:1])
  self.assertTrue(result[0].get('error'));self.assertEqual(self.outlook.events.count('Send'),1);self.run_mail(self.plans[:1]);self.assertEqual(self.outlook.events.count('Send'),1)
 def test_falsey_history_values_block_repeat(self):
  self.run_mail(self.plans[:1]);path=self.path/'mail_processing_history.json';ledger=json.loads(path.read_text());key=next(iter(ledger))
  for value in ({},None,'',False,[]):
   ledger[key]=value;save_json(path,ledger);result=self.run_mail(self.plans[:1]);self.assertIn('再実行を停止',result[0]['status']);self.assertEqual(len(self.outlook.messages),1)
 def test_corrupt_history_root_blocks_before_creation(self):
  save_json(self.path/'mail_processing_history.json',[])
  with self.assertRaises(ValueError):self.run_mail()
  self.assertFalse(self.outlook.messages)
 def test_existing_graph_history_blocks_migration_duplicate(self):
  from microsoft_mail import process_graph_plans
  for auto in (False,True):
   with self.subTest(auto=auto),tempfile.TemporaryDirectory() as t:
    settings={**self.settings,'auto_send':auto};outlook=Outlook(Path(t))
    process_graph_plans(self.plans,settings,t,lambda *args:{'id':'old-graph-id','_http_status':202})
    result=process_classic_plans(self.plans,settings,t,outlook)
    self.assertFalse(outlook.messages);self.assertTrue(all('同内容' in r['status'] for r in result))
 def test_mail_lock_blocks_parallel_batch(self):
  with mail_lock(self.path),self.assertRaises(RuntimeError):self.run_mail()
  self.assertFalse(self.outlook.messages)
 def test_com_settings_hide_app_id_and_keep_legacy_values(self):
  from PySide6.QtWidgets import QApplication,QWidget,QDialog
  from settings_dialog import SettingsDialog
  from engine import DEFAULT
  app=QApplication.instance() or QApplication([]);parent=QWidget();parent.is_dark=False
  cfg=copy.deepcopy(DEFAULT);cfg['mail_settings']={**self.settings,'client_id':'old-unused-value','tenant_id':'old-unused-tenant','extension':{'keep':1}}
  dialog=SettingsDialog(parent,cfg)
  try:
   self.assertNotIn('client_id',dialog.mail_controls);self.assertNotIn('tenant_id',dialog.mail_controls)
   dialog.accept();self.assertEqual(dialog.result(),QDialog.Accepted,dialog.error_label.text());self.assertEqual(dialog.value['mail_settings'],cfg['mail_settings'])
  finally:dialog.close();parent.close();app.processEvents()

if __name__=='__main__':unittest.main(verbosity=2)
