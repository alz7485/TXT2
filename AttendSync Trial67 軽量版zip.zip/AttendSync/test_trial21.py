from pathlib import Path
from tempfile import TemporaryDirectory
import csv
from engine import DEFAULT,csv_read
with TemporaryDirectory() as tmp:
    p=Path(tmp)/'sample.csv'
    rows=[]
    for date, start, end, work, rest in [
        ('20261001','8:30:00','17:30:00','8:00','1:00'),
        ('20261002','bad','17:30:00','8:00','1:00'),
        ('20261003','8:30:00','17:30:00','8:00','oops'),
    ]:
        row=['']*14;row[0]=date;row[3]='S1';row[10:14]=[start,end,work,rest];rows.append(row)
    with p.open('w',newline='',encoding='cp932') as f:
        wr=csv.writer(f);wr.writerow(['header']*14);wr.writerows(rows)
    data=csv_read(p,DEFAULT)
    assert len(data['records'])==3, data
    assert len(data['warnings'])==2,data['warnings']
print('PASS Trial21 CSV all-time-field validation')
