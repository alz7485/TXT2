"""エンジンの軽量回帰テスト: python test_engine.py"""
from datetime import date
from tempfile import TemporaryDirectory
from pathlib import Path
from openpyxl import Workbook
from engine import DEFAULT, xlsx_read, csv_read, reconcile, compare_time
import csv

assert compare_time('25:00','1:00:00','clock') == '一致'
assert compare_time('8:30','8:30:00','clock') == '一致'
assert compare_time('8:00','7:30','duration') == '不一致'
assert compare_time('8:60','9:00','clock') == '要確認'
with TemporaryDirectory() as d:
    root=Path(d)
    book=Workbook(); sheet=book.active;sheet.title='10月'
    sheet['N1']='00123';sheet['U1']='山田　太郎';sheet['A1']='2026年10月度'
    sheet['A9']=9;sheet['B9']=16;sheet['F9']=1;sheet['G9']='8:30';sheet['H9']='17:30';sheet['T9']='8:00'
    book.save(root/'a.xlsx')
    source=xlsx_read(root/'a.xlsx',DEFAULT)
    assert source['info']['employee']=='00123'
    assert source['records'][0]['date']=='2026-09-16'
    with (root/'a.csv').open('w',encoding='utf-8-sig',newline='') as fp:
        w=csv.writer(fp);w.writerow(['header']*14)
        r=['']*14;r[0]='20260916';r[3]='A045';r[4]='山田　太郎';r[10]='8:30:00';r[11]='17:30:00';r[12]='8:00';w.writerow(r)
    target=csv_read(root/'a.csv',DEFAULT)['records']
    rows,issues=reconcile({'00123':source},target,{'00123':'A045'},DEFAULT)
    assert len(rows)==3 and all(row['status']=='一致' for row in rows), rows
    rows,issues=reconcile({'00123':source},[],{'00123':'A045'},DEFAULT)
    assert len(rows)==1 and rows[0]['status']=='要確認' and rows[0]['field']=='CSV記録なし'
print('PASS: 時刻正規化、XLSXの日付、CSV照合、欠落データの4系列')

# 同じ社員の同日XLSX重複と、XLSXに存在しないCSV側の日付を検証
with TemporaryDirectory() as d:
    root=Path(d)
    wb=Workbook();ws=wb.active;ws.title='10月';ws['A1']='2026年10月度';ws['N1']='00123';ws['U1']='山田　太郎'
    for rr,dd in [(9,16),(10,16)]:
        ws[f'A{rr}']=9;ws[f'B{rr}']=dd;ws[f'G{rr}']='8:30';ws[f'H{rr}']='17:30';ws[f'T{rr}']='8:00'
    wb.save(root/'dup.xlsx')
    packet=xlsx_read(root/'dup.xlsx',DEFAULT)
    csvrows=[{'staff':'A045','date':'2026-09-16','name':'山田　太郎','values':{'start':'8:30:00','end':'17:30:00','work':'8:00'}},
             {'staff':'A045','date':'2026-09-17','name':'山田　太郎','values':{'start':'8:30:00','end':'17:30:00','work':'8:00'}},
             {'staff':'Z999','date':'2026-09-17','name':'他人','values':{}}]
    rows,issues=reconcile({'00123':packet},csvrows,{'00123':'A045'},DEFAULT)
    assert len(rows)==2,rows
    assert {r['field'].split('（')[0] for r in rows}=={'XLSX同日重複','XLSX記録なし'},rows
    assert all(r['staff']=='A045' for r in rows)
    print('PASS: XLSX同日重複、XLSX日付欠落、他社員CSV無視')
