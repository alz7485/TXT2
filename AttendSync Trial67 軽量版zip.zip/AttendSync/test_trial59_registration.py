"""Register employees first; attendance reads never infer or save employee IDs."""
import copy
import unittest
from unittest.mock import patch
from pathlib import Path
from PySide6.QtCore import QTimer
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QTableWidget, QLineEdit, QPushButton
import test_trial58_csv_drop as fixture
from employee_information import show_employee_import_dialog
from employee_contacts import load_contacts
from engine import save_json, DEFAULT, xlsx_read, csv_read
import main

APP = fixture.APP

class Registration59(unittest.TestCase):
    setUp = fixture.CsvDrop58.setUp
    button = fixture.CsvDrop58.button

    def test_missing_registration_shows_exact_message_before_editor_without_read(self):
        events = []
        with patch.object(main.QMessageBox, 'information', side_effect=lambda *a: events.append(a[2])), \
             patch.object(self.window, 'edit_map', side_effect=lambda: events.append('editor')), \
             patch.object(main, 'ReadWorker') as worker, patch.object(Path, 'iterdir') as scan, \
             patch.object(main, 'save_json') as writer:
            self.window.run_read(full=True)
        self.assertEqual(events, ['勤怠チェックを行う前に社員情報を登録してください', 'editor'])
        worker.assert_not_called(); scan.assert_not_called(); writer.assert_not_called()

    def test_old_attendance_mapping_alone_does_not_bypass_registration(self):
        self.window.mapping = {'0001': 'S01'}
        save_json(main.MAP, self.window.mapping)
        with patch.object(main.QMessageBox, 'information') as message, \
             patch.object(self.window, 'edit_map') as editor, patch.object(main, 'ReadWorker') as worker:
            self.window.run_read()
        message.assert_called_once(); editor.assert_called_once(); worker.assert_not_called()

    def test_real_editor_opens_and_cancel_never_starts_attendance(self):
        errors = []
        def cancel():
            dialog = APP.activeModalWidget()
            try:
                self.assertIn('社員情報', dialog.windowTitle())
                self.assertIsNotNone(dialog.findChild(QTableWidget, 'employeeIdTable'))
            except Exception as exc: errors.append(exc)
            finally: dialog.reject()
        with patch.object(main.QMessageBox, 'information') as message, patch.object(main, 'ReadWorker') as worker:
            QTimer.singleShot(0, cancel); self.window.run_read(); APP.processEvents()
        self.assertFalse(errors, errors); message.assert_called_once(); worker.assert_not_called()
        self.assertFalse(main.MAP.with_name('employee_contacts.json').exists())

    def test_registered_employees_can_start_attendance_worker(self):
        self.window.mapping = {'0001': 'S01'}
        save_json(main.MAP.with_name('employee_contacts.json'), {**fixture.EMPTY, 'employee_information_registered': True})
        (self.folder/'source.xlsx').write_bytes(b'fixture')
        self.window.path.setText(str(self.folder))
        with patch.object(main, 'ReadWorker') as worker, patch.object(main.QMessageBox, 'information') as message:
            worker.return_value.isRunning.return_value = False
            self.window.run_read()
            worker.return_value.start.assert_called_once(); message.assert_not_called()
        self.window.worker = None

    def test_employee_csv_file_selection_reads_automatically(self):
        errors = []
        def operate():
            dialog = APP.activeModalWidget()
            try:
                with patch('PySide6.QtWidgets.QFileDialog.getOpenFileName', return_value=(str(self.csv), 'CSV')):
                    self.button(dialog, 'CSVを選択').click()
                QTest.qWait(350)
                table = dialog.findChild(QTableWidget, 'informationPreview')
                self.assertEqual(table.columnCount(), 4); self.assertEqual(table.rowCount(), 1)
                self.assertEqual(table.item(0, 1).text(), '0001')
                self.button(dialog, '一覧に反映').click()
            except Exception as exc: errors.append(exc); dialog.reject()
        QTimer.singleShot(0, operate)
        result = show_employee_import_dialog(self.window, {}, copy.deepcopy(fixture.EMPTY), DEFAULT)
        self.assertFalse(errors, errors); self.assertTrue(result['contacts']['employee_information_registered'])
        self.assertFalse(main.MAP.with_name('employee_contacts.json').exists())

    def test_register_button_saves_employee_information_without_reading_attendance(self):
        errors = []
        def operate():
            dialog = APP.activeModalWidget()
            try:
                self.button(dialog, '社員番号を追加').click()
                table = dialog.findChild(QTableWidget, 'employeeIdTable')
                table.item(0, 0).setText('0001'); table.cellWidget(0, 2).setEditText('S01')
                self.button(dialog, '社員情報を登録').click()
            except Exception as exc: errors.append(exc); dialog.reject()
        with patch.object(self.window, 'run_read') as read:
            QTimer.singleShot(0, operate); self.window.edit_map(); APP.processEvents(); read.assert_not_called()
        self.assertFalse(errors, errors)
        self.assertTrue(load_contacts(main.MAP.with_name('employee_contacts.json'))['employee_information_registered'])

    def test_attendance_names_never_become_employee_editor_candidates(self):
        self.window.loaded_xdata = {'E99': {'info': {'name': '勤怠だけの社員'}}}
        self.window.loaded_cdata = [{'staff': 'S99', 'name': '勤怠だけの社員'}]
        errors = []
        def operate():
            dialog = APP.activeModalWidget()
            try:
                table = dialog.findChild(QTableWidget, 'employeeIdTable')
                self.assertEqual(table.rowCount(), 0)
                self.button(dialog, '社員番号を追加').click()
                self.assertEqual(table.cellWidget(0, 2).count(), 1)
            except Exception as exc: errors.append(exc)
            finally: dialog.reject()
        QTimer.singleShot(0, operate); self.window.edit_map(); self.assertFalse(errors, errors)

    def test_matching_attendance_names_never_infer_or_save_employee_ids(self):
        folder = Path(__file__).parent/'SampleData'
        xdata = {}
        for path in folder.glob('*.xlsx'):
            packet = xlsx_read(path, DEFAULT); xdata[packet['info']['employee']] = packet
        cdata = []
        for path in folder.glob('*.csv'): cdata.extend(csv_read(path, DEFAULT)['records'])
        self.window.cfg = copy.deepcopy(DEFAULT); self.window.mapping = {}
        with patch.object(main, 'candidates') as automatic, patch.object(main, 'MappingDialog') as dialog, \
             patch.object(main, 'save_json') as writer:
            self.window.read_done(xdata, cdata, [], dict(elapsed=.1, cache_hits=0, parsed=6, files_found=6, files_completed=6))
        automatic.assert_not_called(); dialog.assert_not_called(); writer.assert_not_called()
        self.assertEqual(self.window.mapping, {})
        self.assertTrue(any('未登録' in text for text in self.window.issues))
        self.assertTrue(self.window.results)

if __name__ == '__main__': unittest.main(verbosity=2)
