"""Independent final-audit regressions: calendar integrity and XLSX formula caches.

All workbooks and cache databases are generated in TemporaryDirectory. No external
fixture paths, user data, Excel installation or company attendance data are needed.
Run next to the application sources: python test_trial46_engine.py
"""
import copy
from datetime import date, timedelta
import hashlib
import json
from pathlib import Path
import unittest
from xml.etree import ElementTree as ET
from zipfile import ZipFile, ZIP_DEFLATED

from openpyxl import Workbook
from engine import DEFAULT, Cache, xlsx_read, reconcile
from cache_tags import parser_tag, XLSX_KEYS
import test_trial38_audit as fixture

NS={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
XML='{'+NS['s']+'}'


class FinalEngine46(unittest.TestCase):
    setUpClass=classmethod(fixture.Audit38.setUpClass.__func__)

    def setUp(self):
        fixture.Audit38.setUp(self)
        self.root=Path(self.tmp.name)
        self.w.mapping={'E1':'S1'}
        self.base=self.root/'base.xlsx'
        book=Workbook();sheet=book.active;sheet.title='10月'
        sheet['A1']='2026年10月度';sheet['N1']='E1';sheet['U1']='監査用社員'
        self.targets=[]
        for i in range(30):
            day=date(2026,9,16)+timedelta(days=i);row=i+9
            for column,value in ((1,day.month),(2,day.day),(7,'8:30'),(8,'17:30'),(20,'8:00')):
                sheet.cell(row,column,value)
            self.targets.append(dict(staff='S1',name='監査用社員',date=day.isoformat(),row=i+2,
                                     file='audit.csv',values=dict(start='8:30',end='17:30',work='8:00'),invalid_fields=[]))
        sheet['V9']='=8/24'
        book.save(self.base);book.close()

    def workbook(self,name,change):
        path=self.root/(name+'.xlsx')
        with ZipFile(self.base) as source,ZipFile(path,'w',ZIP_DEFLATED) as destination:
            worksheet=ET.fromstring(source.read('xl/worksheets/sheet1.xml'))
            change(worksheet)
            for entry in source.infolist():
                destination.writestr(entry,ET.tostring(worksheet,encoding='utf-8')
                                     if entry.filename=='xl/worksheets/sheet1.xml' else source.read(entry.filename))
        return path

    @staticmethod
    def cell(worksheet,address):
        return next(c for c in worksheet.findall('.//s:c',NS) if c.get('r')==address)

    @classmethod
    def formula(cls,worksheet,address='T9',value=None,cell_type=None,missing_v=False,
                formula_text='8/24',attributes=None):
        cell=cls.cell(worksheet,address)
        for child in list(cell):cell.remove(child)
        cell.attrib.pop('t',None)
        if cell_type is not None:cell.set('t',cell_type)
        ET.SubElement(cell,XML+'f',attributes or {}).text=formula_text
        if not missing_v:ET.SubElement(cell,XML+'v').text=value

    def complete(self,packet,targets):
        warnings=packet.get('warnings',[])
        stats=dict(elapsed=.1,cache_hits=0,parsed=2,files_found=2,files_completed=2,
                   read_warnings=[dict(file='audit.xlsx',reason=warning) for warning in warnings])
        self.w.read_done({'E1':packet},targets,warnings,stats)
        return self.w.total_check.text().endswith('全数一致')

    def test_formula_cache_values_and_completed_summary(self):
        variants=[('uncalculated',None,None,False,True,''),
                  ('missing_v',None,None,True,True,''),
                  ('cached_number',repr(8/24),None,False,False,'8:00'),
                  ('cached_zero','0',None,False,False,'0:00'),
                  ('cached_empty',None,'str',False,False,'')]
        for name,value,cell_type,missing_v,invalid,csv_work in variants:
            with self.subTest(name=name):
                path=self.workbook(name,lambda ws:self.formula(ws,value=value,cell_type=cell_type,missing_v=missing_v))
                packet=xlsx_read(path,DEFAULT)
                self.assertEqual('work' in packet['records'][0]['invalid_fields'],invalid)
                targets=copy.deepcopy(self.targets);targets[0]['values']['work']=csv_work
                self.assertEqual(self.complete(packet,targets),not invalid)
                self.assertEqual(self.w.comparison_summary['review'],int(invalid))
                self.assertEqual(self.w.comparison_summary['expected'],90)

    def test_shared_formula_empty_element_is_checked(self):
        def change(ws):
            self.formula(ws,value=repr(8/24),attributes=dict(t='shared',si='0',ref='T9:T10'))
            self.formula(ws,address='T10',formula_text=None,attributes=dict(t='shared',si='0'))
        packet=xlsx_read(self.workbook('shared',change),DEFAULT)
        self.assertNotIn('work',packet['records'][0]['invalid_fields'])
        self.assertIn('work',packet['records'][1]['invalid_fields'])
        targets=copy.deepcopy(self.targets);targets[1]['values']['work']=''
        self.assertFalse(self.complete(packet,targets))
        self.assertEqual(self.w.comparison_summary['review'],1)

    def test_cached_formula_error_cannot_match_equal_text(self):
        cfg=copy.deepcopy(DEFAULT);cfg['comparisons'][2]['type']='text';self.w.cfg=cfg
        path=self.workbook('error',lambda ws:self.formula(ws,value='#DIV/0!',cell_type='e'))
        packet=xlsx_read(path,cfg);targets=copy.deepcopy(self.targets);targets[0]['values']['work']='#DIV/0!'
        self.assertIn('work',packet['records'][0]['invalid_fields'])
        self.assertFalse(self.complete(packet,targets))
        rows=[r for r in self.w.results if r.get('xlsx_key')=='work' and r['date']=='2026-09-16']
        self.assertEqual(rows[0]['status'],'要確認')

    def test_off_to_on_retains_formula_integrity_through_cache(self):
        cfg=copy.deepcopy(DEFAULT);cfg['comparisons'][2]['enabled']=False
        path=self.workbook('cached_off',lambda ws:self.formula(ws))
        cache=Cache(self.root/'parser.sqlite3')
        try:
            packet,hit=cache.parse(path,parser_tag(cfg,'xlsx'),lambda p:xlsx_read(p,cfg))
            self.assertFalse(hit);self.assertIn('work',packet['records'][0]['invalid_fields'])
            rows,_=reconcile({'E1':packet},self.targets,{'E1':'S1'},cfg)
            self.assertFalse(any(r['status']=='要確認' for r in rows))
            cfg['comparisons'][2]['enabled']=True
            packet,hit=cache.parse(path,parser_tag(cfg,'xlsx'),lambda p:xlsx_read(p,cfg))
            self.assertTrue(hit)
            targets=copy.deepcopy(self.targets);targets[0]['values']['work']=''
            rows,_=reconcile({'E1':packet},targets,{'E1':'S1'},cfg)
            self.assertTrue(any(r.get('xlsx_key')=='work' and r['status']=='要確認' for r in rows))
        finally:cache.close()

    def test_added_field_keeps_integrity_when_enabled_after_cache_read(self):
        cfg=copy.deepcopy(DEFAULT);cfg['xlsx_columns']['future']='V';cfg['csv_columns']['future']='O'
        cfg['comparisons'].append(dict(name='追加項目',xlsx='future',csv='future',type='text',enabled=False))
        targets=copy.deepcopy(self.targets)
        for row in targets:row['values']['future']=''
        cache=Cache(self.root/'future.sqlite3')
        try:
            packet,hit=cache.parse(self.base,parser_tag(cfg,'xlsx'),lambda p:xlsx_read(p,cfg))
            self.assertFalse(hit);self.assertIn('future',packet['records'][0]['invalid_fields'])
            rows,_=reconcile({'E1':packet},targets,{'E1':'S1'},cfg)
            self.assertFalse(any(r['status']=='要確認' for r in rows))
            cfg['comparisons'][-1]['enabled']=True
            packet,hit=cache.parse(self.base,parser_tag(cfg,'xlsx'),lambda p:xlsx_read(p,cfg))
            self.assertTrue(hit)
            rows,_=reconcile({'E1':packet},targets,{'E1':'S1'},cfg)
            self.assertTrue(any(r.get('xlsx_key')=='future' and r['status']=='要確認' for r in rows))
        finally:cache.close()

    def test_previous_parser_cache_is_invalidated(self):
        cfg=copy.deepcopy(DEFAULT);path=self.workbook('old_cache',lambda ws:self.formula(ws))
        old={'parser_version':'trial41-calendar-time-validation-v3','filetype':'xlsx',
             'settings':{key:cfg[key] for key in XLSX_KEYS}}
        old_tag=hashlib.sha256(json.dumps(old,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        stat=path.stat();cache=Cache(self.root/'old.sqlite3')
        try:
            cache.db.execute('INSERT INTO cache VALUES(?,?,?)',(str(path),f'{stat.st_size}:{stat.st_mtime_ns}:{old_tag}',json.dumps({'records':[]})))
            cache.db.commit()
            packet,hit=cache.parse(path,parser_tag(cfg,'xlsx'),lambda p:xlsx_read(p,cfg))
            self.assertFalse(hit);self.assertEqual(len(packet['records']),30)
            self.assertIn('work',packet['records'][0]['invalid_fields'])
        finally:cache.close()

    def test_invalid_calendar_rows_block_completion_but_valid_outside_does_not(self):
        variants=[('bad_day',10,'不正な日',True),('bad_month','不正な月',15,True),
                  ('month_13',13,15,True),('day_32',10,32,True),('impossible',9,31,True),
                  ('outside',9,15,False),('formula_day',10,'formula',True)]
        for name,month,day,blocked in variants:
            with self.subTest(name=name):
                def change(ws):
                    row=ET.SubElement(ws.find('s:sheetData',NS),XML+'row',{'r':'39'})
                    for address,value in [('A39',month),('B39',day)]:
                        cell=ET.SubElement(row,XML+'c',{'r':address})
                        if value=='formula':ET.SubElement(cell,XML+'f').text='15';ET.SubElement(cell,XML+'v')
                        elif isinstance(value,int):ET.SubElement(cell,XML+'v').text=str(value)
                        else:cell.set('t','inlineStr');ET.SubElement(ET.SubElement(cell,XML+'is'),XML+'t').text=value
                packet=xlsx_read(self.workbook(name,change),DEFAULT)
                self.assertEqual(len(packet['records']),30);self.assertTrue(packet['warnings'])
                self.assertEqual(self.complete(packet,self.targets),not blocked)
                self.assertEqual(self.w.comparison_summary['expected'],90)
                self.assertEqual(self.w.comparison_summary['additional_review'],int(blocked))

    def header_workbook(self,name,address,value,cell_type='str',formula_text='"2026年10月度"'):
        def change(ws):
            existing=[c for c in ws.findall('.//s:c',NS) if c.get('r')==address]
            if not existing:
                row_number=''.join(ch for ch in address if ch.isdigit())
                rows=[r for r in ws.findall('.//s:row',NS) if r.get('r')==row_number]
                row=rows[0] if rows else ET.SubElement(ws.find('s:sheetData',NS),XML+'row',{'r':row_number})
                ET.SubElement(row,XML+'c',{'r':address})
                ws.find('s:dimension',NS).set('ref','A1:V120')
            self.formula(ws,address=address,value=value,cell_type=cell_type,formula_text=formula_text)
        return self.workbook(name,change)

    def test_uncalculated_period_header_before_and_after_data_range_blocks_completion(self):
        for address in ('A1','A120'):
            with self.subTest(address=address):
                cfg=copy.deepcopy(DEFAULT);cfg['info_cells']['period']=address;self.w.cfg=cfg
                path=self.header_workbook('missing_period_'+address,address,None,cell_type=None,
                                          formula_text='"2026年9月度"')
                packet=xlsx_read(path,cfg)
                self.assertEqual(packet['info']['period'],'');self.assertEqual(len(packet['records']),30)
                self.assertTrue(any(address in w and '(period)' in w for w in packet['warnings']))
                self.assertFalse(self.complete(packet,self.targets))
                self.assertGreaterEqual(self.w.comparison_summary['additional_review'],1)

    def test_cached_period_headers_are_checked_without_false_formula_warnings(self):
        for address in ('A1','A120'):
            with self.subTest(address=address):
                cfg=copy.deepcopy(DEFAULT);cfg['info_cells']['period']=address;self.w.cfg=cfg
                path=self.header_workbook('cached_period_'+address,address,'2026年10月度')
                packet=xlsx_read(path,cfg)
                self.assertEqual(packet['info']['period'],'2026年10月度');self.assertEqual(packet['warnings'],[])
                self.assertTrue(self.complete(packet,self.targets))
                wrong=self.header_workbook('wrong_period_'+address,address,'2026年9月度')
                packet=xlsx_read(wrong,cfg)
                self.assertIn('対象年月の不一致',packet['error'])

    def test_optional_header_formula_missing_and_cached_empty_are_distinguished(self):
        for key,address in [('name','U1'),('organization','P1')]:
            with self.subTest(header=key):
                cfg=copy.deepcopy(DEFAULT);self.w.cfg=cfg
                missing=self.header_workbook('missing_'+key,address,None,cell_type=None,formula_text='"監査"')
                packet=xlsx_read(missing,cfg)
                self.assertTrue(any('('+key+')' in w for w in packet['warnings']))
                self.assertFalse(self.complete(packet,self.targets))
                cached=self.header_workbook('empty_'+key,address,None,cell_type='str',formula_text='IF(1=1,"","監査")')
                packet=xlsx_read(cached,cfg)
                self.assertEqual(packet['warnings'],[])
                self.assertTrue(self.complete(packet,self.targets))


if __name__=='__main__':unittest.main(verbosity=2)
