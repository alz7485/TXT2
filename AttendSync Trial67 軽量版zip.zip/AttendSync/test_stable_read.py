from pathlib import Path
from tempfile import TemporaryDirectory
from stable_read import parse_stable_file
with TemporaryDirectory() as d:
    p=Path(d)/'data.csv';p.write_text('test')
    assert parse_stable_file(lambda path,cfg:{'records':[1]},p,{}) == {'records':[1]}
    def altering(path,cfg):
        path.write_text('changed-file')
        return {'records':[1]}
    assert '更新' in parse_stable_file(altering,p,{})['error']
print('PASS: stable file accepted; modified file rejected')
