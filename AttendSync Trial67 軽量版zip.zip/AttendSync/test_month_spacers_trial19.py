from pathlib import Path
from tempfile import TemporaryDirectory
import engine
from openpyxl import load_workbook

cfg=engine.DEFAULT.copy()
cfg['year']=2026;cfg['month']=10
p=Path(__file__).parent/'SampleData'/"社員_10001.xlsx"
packet=engine.xlsx_read(p,cfg)
assert 'error' not in packet,packet
records=packet['records']
assert len(records)==30, len(records)
assert len(set(r['date'] for r in records))==30
assert any(r['date']=='2026-09-30' for r in records)
one=next(r for r in records if r['date']=='2026-10-01')
wb=load_workbook(p,read_only=True,data_only=True)
assert wb[one['sheet']].cell(one['row'],2).value==1
assert wb[one['sheet']].cell(one['row']-1,2).value is None
wb.close()
print('PASS: 3 blank month-border rows skipped; 30 days intact; Excel source row preserved')
