"""Measure first main-window paint in fresh processes without touching userdata.

python benchmark_startup.py --runs 6 --output STARTUP_RESULTS.json
The source-mode result is not a Windows EXE or network-startup guarantee.
"""
from pathlib import Path
import argparse,json,os,statistics,subprocess,sys,tempfile,time


def probe(source):
    started=time.perf_counter()
    sys.path.insert(0,str(source))
    import runtime_paths
    with tempfile.TemporaryDirectory(prefix='attendsync-startup-') as tmp:
        runtime_paths.get_data_dir=lambda:Path(tmp)
        import main
        imported=time.perf_counter()
        from PySide6.QtCore import QObject,QEvent,QTimer
        from PySide6.QtWidgets import QApplication
        app=QApplication([])
        class FirstPaint(QObject):
            def eventFilter(self,obj,event):
                if event.type()==QEvent.Paint and not getattr(self,'done',False):
                    self.done=True
                    print(json.dumps(dict(import_seconds=round(imported-started,4),
                        window_construct_seconds=round(constructed-imported,4),
                        first_paint_seconds=round(time.perf_counter()-started,4))),flush=True)
                    QTimer.singleShot(0,app.quit)
                return False
        observer=FirstPaint()
        window=main.Window();constructed=time.perf_counter()
        window.centralWidget().installEventFilter(observer);window.show()
        QTimer.singleShot(15000,app.quit);app.exec();window.close()
        if not getattr(observer,'done',False):raise RuntimeError('No first paint within 15 seconds')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runs',type=int,default=6)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--probe',type=Path,help=argparse.SUPPRESS)
    args=parser.parse_args()
    if args.probe is not None:probe(args.probe);return
    if not 1<=args.runs<=30:parser.error('--runs must be between 1 and 30')
    records=[];source=Path(__file__).resolve().parent
    for _ in range(args.runs):
        started=time.perf_counter()
        result=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--probe',str(source)],
                              capture_output=True,text=True,timeout=20)
        if result.returncode:raise RuntimeError(result.stderr or result.stdout)
        record=json.loads(result.stdout);record['process_total_seconds']=round(time.perf_counter()-started,4);records.append(record)
    report=dict(version='Trial41',method='Fresh source-mode Python processes; first central-widget paint; temporary default userdata; OS disk cache not cleared.',
        qt_platform=os.environ.get('QT_QPA_PLATFORM','system default'),runs=records,
        median_first_paint_seconds=round(statistics.median(r['first_paint_seconds'] for r in records),4),
        max_first_paint_seconds=max(r['first_paint_seconds'] for r in records),
        median_process_total_seconds=round(statistics.median(r['process_total_seconds'] for r in records),4))
    formatted=json.dumps(report,ensure_ascii=False,indent=2)
    if args.output:args.output.write_text(formatted,encoding='utf-8')
    print(formatted)


if __name__=='__main__':main()
