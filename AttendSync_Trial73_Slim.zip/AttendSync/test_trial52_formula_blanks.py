"""Saved Excel formula results, hidden zeros, real midnight and duration zeros."""
import tempfile,copy,unittest
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from xml.etree import ElementTree as ET
from openpyxl import Workbook
from engine import DEFAULT,xlsx_read,compare_time,zero_is_hidden
from cache_tags import parser_tag
NS='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
class FormulaBlanks(unittest.TestCase):
 def read(self,value='0',fmt='h:mm;;',formula=True,show_zeros=True,ctype='n',column='G',extra=None):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'input.xlsx';wb=Workbook();ws=wb.active;ws.title='10月'
   for cell,val in [('A1','2026年10月度'),('N1','E1'),('U1','確認社員'),('A9',10),('B9',1),('F9',5),(column+'9','=0' if formula else 0)]:ws[cell]=val
   for cell,val in (extra or {}).items():ws[cell]=val
   ws[column+'9'].number_format=fmt;ws.sheet_view.showZeros=show_zeros;wb.save(p);wb.close()
   with ZipFile(p) as z:parts={n:z.read(n) for n in z.namelist()}
   sheet=ET.fromstring(parts['xl/worksheets/sheet1.xml']);cell=next(c for c in sheet.iter(NS+'c') if c.get('r')==column+'9');cell.set('t',ctype);cell.find(NS+'v').text=value
   parts['xl/worksheets/sheet1.xml']=ET.tostring(sheet)
   with ZipFile(p,'w',ZIP_DEFLATED) as z:
    for n,data in parts.items():z.writestr(n,data)
   return xlsx_read(p,DEFAULT)['records'][0]
 def test_hidden_formula_zero_matches_blank_for_start_and_end(self):
  for col,key in [('G','start'),('H','end')]:
   r=self.read(column=col);self.assertIsNone(r['values'][key]);self.assertEqual(compare_time(r['values'][key],'','clock'),'一致')
 def test_sheet_zero_display_disabled(self):
  self.assertIsNone(self.read(fmt='h:mm',show_zeros=False)['values']['start'])
 def test_visible_midnight_is_not_blank(self):
  r=self.read(fmt='h:mm');self.assertEqual(compare_time(r['values']['start'],'','clock'),'不一致');self.assertEqual(compare_time(r['values']['start'],'0:00','clock'),'一致')
 def test_literal_midnight_not_erased(self):
  self.assertEqual(compare_time(self.read(formula=False)['values']['start'],'0:00','clock'),'一致')
 def test_nonzero_formula_not_erased(self):
  self.assertEqual(compare_time(self.read(value='0.375')['values']['start'],'9:00','clock'),'一致')
 def test_duration_zero_retained(self):
  # Trial72 refinement: on a WORKED day (start and end present) a hidden
  # formula zero for 実働時間 stays a real 0:00.  The Trial72 day-off case
  # (no start, no end) is covered by test_trial72_hidden_zero_duration.py.
  r=self.read(column='T',extra={'G9':'9:00','H9':'18:00'});self.assertEqual(compare_time(r['values']['work'],'0:00','duration'),'一致');self.assertEqual(compare_time(r['values']['work'],'','duration'),'不一致')
 def test_cached_empty_and_missing_cache(self):
  self.assertIsNone(self.read(value=None,ctype='str')['values']['start'])
  self.assertIn('start',self.read(value=None)['invalid_fields'])
 def test_format_quoted_semicolon_and_zero_section(self):
  for f in ['h:mm;;','h:mm;h:mm;""',';;;','h:mm;h:mm;[Red]','[=0]\"\";h:mm','[<>0]h:mm;\"\"']:
   self.assertTrue(zero_is_hidden(f),f)
  for f in ['h:mm','h:mm;h:mm;";"','h:mm;h:mm;0','[>0]h:mm;h:mm','[>=0]h:mm;\"\"']:
   self.assertFalse(zero_is_hidden(f),f)
if __name__=='__main__':unittest.main(verbosity=2)
