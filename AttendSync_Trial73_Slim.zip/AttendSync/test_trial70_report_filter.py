"""Trial70: 日報報告 name filter for the Excel side.

The real workbooks are named 日報報告… (the name also carries the employee
number and the employee name, but the 日報報告 mark alone is the filter).
When a folder contains at least one 日報報告 workbook, only those are
read and any other Excel file is ignored.  When none carries the mark
(legacy or sample folders), all workbooks remain candidates.
"""
from __future__ import annotations

import os
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

from employee_information import is_daily_report_workbook, select_daily_report_workbooks

try:
    from PySide6.QtWidgets import QApplication
except ModuleNotFoundError as exc:
    if exc.name != 'PySide6':
        raise
    QT_AVAILABLE = False
else:
    QT_AVAILABLE = True
    import runtime_paths
    _import_directory = tempfile.TemporaryDirectory(prefix='attendsync-trial70-import-')
    with patch.object(runtime_paths, 'get_data_dir', return_value=Path(_import_directory.name)):
        import main
    from engine import DEFAULT

SAMPLES = Path(__file__).parent / 'SampleData'


class DailyReportNameLogic(unittest.TestCase):
    def test_mark_matching(self):
        self.assertTrue(is_daily_report_workbook('日報報告_10001_佐藤花子.xlsx'))
        self.assertTrue(is_daily_report_workbook('日報報告.xlsx'))
        self.assertTrue(is_daily_report_workbook('202610日報報告_10001.xlsx'))
        self.assertFalse(is_daily_report_workbook('社員_10001.xlsx'))
        self.assertFalse(is_daily_report_workbook('集計.xlsx'))

    def test_selection_prefers_marked_and_falls_back(self):
        marked = Path('日報報告_10001.xlsx')
        other = Path('集計.xlsx')
        self.assertEqual(select_daily_report_workbooks([other, marked]), [marked])
        self.assertEqual(select_daily_report_workbooks([other]), [other])
        self.assertEqual(select_daily_report_workbooks([]), [])


@unittest.skipUnless(QT_AVAILABLE, 'PySide6 is required for real Qt checks')
class DailyReportWorkerFlow(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
        cls.app.setQuitOnLastWindowClosed(False)

    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(prefix='attendsync-trial70-test-')
        self.addCleanup(self.directory.cleanup)
        self.data_dir = Path(self.directory.name)
        self.paths_patch = patch.multiple(
            main, DATA_DIR=self.data_dir, CONFIG=self.data_dir / 'settings.json',
            MAP=self.data_dir / 'staff_mapping.json', DB=self.data_dir / 'attendance_cache.sqlite3',
        )
        self.paths_patch.start()
        self.addCleanup(self.paths_patch.stop)
        self.folder = self.data_dir / 'input'
        self.folder.mkdir()
        shutil.copy(SAMPLES / '派遣先_202610.csv', self.folder / '日別勤務情報20261019.csv')

    def run_worker(self):
        results = []
        worker = main.ReadWorker(self.folder, DEFAULT)
        worker.result.connect(lambda *args: results.append(args))
        worker.run()
        self.assertEqual(len(results), 1)
        return results[0]

    def test_mixed_folder_reads_only_daily_reports(self):
        shutil.copy(SAMPLES / '社員_10001.xlsx', self.folder / '日報報告_10001_確認社員.xlsx')
        shutil.copy(SAMPLES / '社員_10002.xlsx', self.folder / '集計_10002.xlsx')
        xdata, cdata, issues, stats = self.run_worker()
        self.assertEqual(stats['files_found'], 2)  # 日報報告 XLSX + 日別勤務情報 CSV only
        self.assertEqual(set(xdata), {'10001'})

    def test_legacy_folder_without_the_mark_reads_everything(self):
        shutil.copy(SAMPLES / '社員_10002.xlsx', self.folder / '社員_10002.xlsx')
        xdata, cdata, issues, stats = self.run_worker()
        self.assertEqual(stats['files_found'], 2)
        self.assertEqual(set(xdata), {'10002'})


if __name__ == '__main__':
    unittest.main(verbosity=2)
