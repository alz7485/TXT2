# AttendSync Trial45 配布・起動・Windows連携 独立最終レビュー

実施日: 2026-10-10。対象: `/workspace/attendsync-trial45/AttendSync` と `AttendSync_Trial45_Bordered_UI_Complete.zip`。本体ソースは編集していない。検証は Python 3.12 / PySide6 / Linux offscreen。Windows実機は接続されていない。

## 判定

onedir用の構成・依存指定・画像マニュアルの同梱は妥当。ソースZIPのCRC・全ファイルSHA256・manifest網羅性は合格。Windowsの実際のビルド・EXE起動・Excel・プリンターは未検証であり、ここで「会社PCで動作確認済み」とは判定しない。

起動時の保存先エラーについて P2 の修正推奨1件、最新資料案内について P3 の修正推奨1件を確認した。修正と独立再検証の完了前に、この報告を修正版の無条件合格証明として扱わない。

## 指摘

### P2: 保存先の初期化失敗が起動エラーダイアログを迂回する

- 場所: `AttendSync/main.py:20`、`AttendSync/runtime_paths.py:22`、`AttendSync/main.py:1472`。
- 条件: EXE隣の `userdata` が書込み不可、かつ `%LOCALAPPDATA%\\AttendSync` が作成できない／同名の通常ファイルが存在する。
- 結果: モジュール読込時の `DATA_DIR=get_data_dir()` が例外終了する。`QApplication` 作成と `main()` の `try: Window()` より前なので、「AttendSyncを起動できません」のダイアログに到達しない。`--windowed` 配布の利用者にはアプリ内の復旧案内が出ない。データ消失は確認していない。
- 再現証拠: `/tmp/final_distribution_review/check_distribution.py` が `get_data_dir()` を `PermissionError` にして `runpy.run_path(main.py)` を実行、例外が未捕捉で外へ出ることを確認した。結果 `/tmp/final_distribution_review/results.json` の `double_denied_import`。さらに `reproduce_double_denied.py` は実ファイルシステム上で userdata と LOCALAPPDATA/AttendSync に通常ファイルを配置し、実際の fallback.mkdir の FileExistsError が外へ出ることを確認した。ログ `/tmp/final_distribution_review/double_denied.log`。
- 最小修正案: モジュール初期化で `OSError` を保持しておき、`Window.__init__` 冒頭で保存先と原因を含む例外を発生させる。既存の `main()` の QApplication→Window→critical→終了コード1の処理へ渡す。失敗時の CONFIG/MAP/DB は書込みに使用しない。通常起動時のパスと既存テストのパス差替えは維持する。
- 追加確認: `get_data_dir()` の代替先も一時ファイルの write/flush で確認すれば、既に存在するが書けない代替フォルダも起動時に判定できる。例外には実際の代替先を含める。

### P3: 起動案内が Trial44 の変更・検証資料を指す

- 場所: `AttendSync/START_HERE.txt:4`、同5。
- 内容: 見出しはTrial45だが、変更点は `CHANGES_TRIAL44.md`、検証は `VALIDATION_TRIAL44.md`。ファイルは存在するためリンク切れではないが、採用された枠線UIの変更とTrial45確認結果へ直接到達できない。
- 修正案: 最新Trial45（今回の修正版を出す場合はその版）の変更・検証資料へ更新する。過去資料へのリンクは履歴として残せる。

## 独立実測

`/tmp/final_distribution_review/check_distribution.py` は以下をすべて検証した。

| 対象 | 結果・根拠 |
| --- | --- |
| ソースZIP CRC | `ZipFile.testzip()` が None |
| manifest SHA256 | 358項目すべて一致 |
| manifest 網羅性 | manifestを除く実ファイル集合と記載集合が完全一致 |
| ZIP内容 | 359ファイル、10,813,091 bytes |
| ZIP SHA256 | `7e9557625cf2b9d0656dc2706bd180136dcb3e43d0a7d84e9c6bf7dfeb7a9309` |
| 個人設定・ビルド環境 | userdata、__pycache__、.venv、dist、build がZIPに含まれない |
| frozenパス | sys.frozen=True / 日本語・空白を含む sys.executable からEXEの親を取得 |
| userdata 初期化 | 上記のEXE隣にuserdataを作成 |
| read-only配布先 | portableのwriteをPermissionErrorにするとLOCALAPPDATA/AttendSyncへ正常退避 |
| ビルド構成 | PyInstaller実行を成功モックし、--onedir / --windowed / QtSvg hidden import / check=True を確認 |
| 配布資材 | 上記モック後、Manual/index.html・画像・ICO・SampleData・userdataが出力に実際にコピーされることを確認 |

PyInstallerの成功モックは実ビルドの代替証明にはならない。実際の `_internal` 内DLL、Qtプラグイン、pywin32バイナリのWindowsロードはこの実測範囲に含まない。

## 実装確認

既存5本は独立プロセスで合格。`test_trial39_manual.py` は10件（75.433秒）、`test_trial41_runtime.py` は14件、`test_trial31_excel_mock.py`・`test_excel_jump.py`・`test_trial32_gui_print.py` は終了コード0。F1、画像・リンク、ブラウザエラー、onedirマニュアル実コピー、起動時に帳票走査しないこと、JSON追加項目の保存、破損JSONの保全、並行保存・起動、Excelのセル位置と既存ブック保全、Qtの印刷/PDF処理を確認した。実userdataの代わりに一時ディレクトリを指定した。

最初の隔離ハーネスは `get_data_dir` の差替えを試験本体に持ち込んだためruntime41の並行起動1件を、cwdを `/workspace` にしたためSampleData相対パスを参照するexcel_jumpを失敗させた。原因を確認してハーネスを修正し、2本を再実行して合格した。本体の不具合として扱わない。ログは `/tmp/final_distribution_review/` の対応 `.log` と `.corrected.log` に保持している。

- `build_onedir.py:29` の `--onedir` と `--windowed`、34のQtSvg hidden import、39–45のマニュアル・画像・ICO・サンプルコピーは整合する。
- `requirements-build.txt` はPySide6、openpyxl、PyInstaller、Windows限定pywin32を指定する。ソース単独用 requirements.txt にpywin32は含まれないため、WindowsでExcel連携を使う場合もビルド用requirementsを入れるというREADMEの案内が必要。
- `runtime_paths.py:9` は frozen 時に sys.executable の親を返し、PyInstaller 6の `_internal` を資材の基準にしていない。ManualとICOはEXE隣へのコピーと整合する。
- `ui_theme.py:11` はQtSvg importを行うため、QtSvgは遅延importではない。ただし隠しimport指定があり、利用不可の場合の描画フォールバックもある。Windows COMは `excel_jump.py:28` 以降でクリック時だけimportする。起動時にExcelを立ち上げない。
- `manual.py` はローカルHTMLを既定ブラウザで開く。不足・ブラウザ拒否・例外を警告にする。元資材のコピーはネット接続を要しない。
- `engine.py:79` のJSON保存は同じ親ディレクトリの固有一時ファイル→flush/fsync→replace、失敗時一時ファイル削除。既存ファイルを先に切り詰めない。
- `excel_jump.py` は読込後のサイズ・mtime変更、シート欠落、行範囲、Windows限定、pywin32欠落を検査。新規に開いたExcelのみ失敗時に閉じ、既存ユーザーのブックは閉じない。元ブックはReadOnlyで開く。
- `printing.py` はプリンター不在を案内、キャンセルを受理、QPrinter Error/Abortedと描画例外を警告する。実プリンタのドライバー・Windows用紙設定は未検証。
- README・マニュアルは「dist/AttendSync フォルダ全体」と「ソースZIPでありビルド済みEXEを含まない」と案内し、Windows未検証の制限も明記する。更新時userdataのバックアップとLOCALAPPDATA使用時の別保存先も案内している。

## 会社配布時に残る実機確認

Windowsで `requirements-build.txt` → `build_onedir.py` を実行し、Python未導入の会社対象PCへdist/AttendSync全体をコピーしてEXEを起動する。合成サンプルで月度設定・ID登録・保存後再起動・F1マニュアル・Excelの指定セルジャンプ・印刷プレビュー／実印刷を確認する。検証時にWindows/Excelの実際のバージョンと確認日を記録する。

会社の未開示列や実際の勤怠書式の受入確認は合成データのテストでは置き換えられない。このレビューでは実データと実userdataを使用していない。

## Trial46 保存先修正の独立再監査（2026-10-10 追記）

対象 `/workspace/attendsync-trial46/AttendSync`。本体は編集せず、修正された `runtime_paths.py` と `main.py` を別モジュールとして各ケースで新しく読み込み、実際に QApplication / Window / main() の処理を検証した。

`/tmp/final_distribution_review/test_trial46_startup.py` の6件が合格（1.187秒、終了コード0）。テストを main.py 隣へ置けばソース相対で実行できる。外部からは `ATTENDSYNC_AUDIT_ROOT` で対象ソースフォルダを指定する。ログ `/tmp/final_distribution_review/test_trial46_startup.log`。

| 修正後検証 | 結果 |
| --- | --- |
| 実ファイル衝突でportable/LOCALAPPDATAとも保存不可 | モジュール読込は成功、criticalダイアログ1回、終了コード1、配布先と代替先と権限案内を含む。元ファイル2件のbytes不変 |
| 既存代替フォルダのprobe.write拒否 | 起動前に書込み不能を検出、critical1回、終了コード1 |
| 既存代替フォルダのprobe.flush拒否 | 同上。mkdir成功だけで書込み可能とは扱わない |
| 正常portable | EXE隣相当userdata使用、Window正常起動、LOCALAPPDATA未作成、起動だけで設定/ID/キャッシュを保存しない |
| portableファイル衝突／正常代替先 | LOCALAPPDATA/AttendSync使用、Window正常起動、衝突元のファイルbytes不変 |
| frozen / 日本語・空白のEXEパス | 実runtime_pathsのapplication_dirがsys.executableの親を返し、その隣のuserdata使用 |

独立の補助実測 `/tmp/final_distribution_review/check_trial46.py` も同じ6条件で合格した。結果 `/tmp/final_distribution_review/trial46_results.json`。

**P2の起動時保存先エラー指摘は修正・独立再検証済み。** P3最新資料案内は親担当が更新中であり、この追記時点では確認前。Trial46配布ZIPはまだ検査していないため、上のCRC・manifest・SHA256はTrial45 ZIPの結果である。Windowsの実ビルド・会社PCでのEXE起動・実Excel・実プリンターの未検証という制限は継続する。
