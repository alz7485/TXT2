# AttendSync Trial45 最終独立レビュー：設定・社員ID・永続保存

対象：`/workspace/attendsync-trial45/AttendSync`。レビュー専任として本体コードを変更せず実施。

## 判定

設定・社員IDの保存内容や拡張性について重大なデータ破損は再現されていません。ただし、設定ダイアログを閉じても子ウィジェットが残留する中程度の問題を追加再現しました。繰り返し利用時のメモリ・テーマ処理増加を防ぐ修正を推奨します。既存の監査報告を根拠にせず、コードと新規の実Qt異常系テストを突き合わせました。

## 所見 P2：閉じた設定ダイアログの残留

位置：`main.py:953` (`Window.edit_settings`)。親付きSettingsDialogを生成してexecするが、キャンセル・保存後に破棄していません。

再現：Window生成 → 設定を開く → キャンセルを3回実施 → 各回でprocessEventsとDeferredDeleteを明示処理。

| 設定を開いた回数 | Window内に残るSettingsDialog | Window配下QWidget数 |
|---|---:|---:|
| 0 | 0 | 83 |
| 1 | 1 | 529 |
| 2 | 2 | 975 |
| 3 | 3 | 1421 |

閉じるたび446個のウィジェットが残留します。設定を何度も開くとメモリ増加とアプリ全体のスタイル更新処理増加につながる構造です。現在の3回で定量的な体感遅延を断定するものではありません。

推奨：保存値を読んだ後、キャンセル・保存失敗を含む全経路のfinallyでdeleteLaterする。WA_DeleteOnCloseはexec直後のdlg.value参照が破棄済みになる危険があるので、戻り値を利用するダイアログでは明示的な寿命管理を推奨。同じ親付きmodalの社員ID管理・詳細・ログ・診断画面も同様に確認。

社員ID管理も同型再現済み：`main.py:968`。キャンセル3回で残留QDialogが0→3、QWidgetが83→110→137→164（毎回27個増）。

専用再現：`/tmp/final_settings_review/lifetime_probe.py` と `mapping_lifetime_probe.py`、証拠：同フォルダの `lifetime.log` と `mapping-lifetime.log`。レビュー担当は本体変更していません。

## 独立テスト結果

専用テスト `/tmp/final_settings_review/review.py`：**8ケース合格**。Linux、Python 3.12、PySide6、Qt offscreen。再実行でも8ケース合格（28.508秒）。本番のuserdataを使用せず、実行ごとに一時ディレクトリを作成。

| 確認 | 証拠・結果 | 実装位置 |
|---|---|---|
| 設定のatomic replace失敗 | `Path.replace`をPermissionErrorにし、元の設定ファイルがバイト単位で不変、tmpファイルが残らないことを確認 | `engine.py:79` |
| JSONシリアライズ失敗 | object値を保存しTypeError発生後も元ファイル不変、tmp除去 | `engine.py:79` |
| 設定画面の保存失敗 | 実SettingsDialogで読み込み速度を変更して確定、保存をPermissionErrorにし、警告表示・設定メモリ不変・元ファイル不変を確認 | `main.py:953` |
| 社員ID画面の保存失敗 | 実ダイアログでS1をS2に変更して保存、保存をPermissionErrorにし、ダイアログ継続・警告・IDメモリ不変・元ファイル不変・再読み込み未発火を確認 | `main.py:1047` |
| 保存JSON破損・異常型 | settingsの不正JSONと配列、mappingの不正JSONと数値IDで起動がValueErrorを返し、元ファイルを上書きしない | `main.py:613` |
| 拡張項目の往復 | 未知の入れ子JSON、未知の照合属性を含む設定でXLSX/CSV列追加・改名・照合追加・ON/OFF・保存・Window再起動。値、内部ID、未知属性、表示名が維持され、入力元dictが不変 | `settings_dialog.py:432`, `settings_dialog.py:596` |
| 不正JSON反映の原子性 | workers上限外、開始終了逆転、XFE列、不明なON照合元を順に入力。「反映」で拒否し、元設定と全列入力欄が不変 | `settings_dialog.py:502`, `settings_dialog.py:557` |
| 候補外IDの取消し | CSVにないIDを入力して保存し確認でNoを選択。保存しない・元ID維持・ダイアログ継続 | `main.py:1060` |

新規テストは既存テストの実装をコピーせず作成。画面操作にはQTimerと実ダイアログを使用し、保存失敗だけを注入しました。`save_json`のファイル置換・JSON書き込みの異常は別途実処理で検証。

証拠ログ：`/tmp/final_settings_review/results.log`。

再現コマンド：

```sh
QT_QPA_PLATFORM=offscreen XDG_CACHE_HOME=/tmp/attendsync-test-cache /workspace/attendsync-venv/bin/python /tmp/final_settings_review/review.py
```

## コード確認

- `settings_dialog.py:432`：deepcopyから保存値を生成し、未知のトップレベル・照合項目属性を残す。表示名変更と内部ID変更を分離。
- `settings_dialog.py:596`：追加項目IDは既存列だけでなく将来の表示名・照合元・詳細表示指定を避けて採番。後から追加する列・照合項目の予約情報が壊れない。
- `settings_dialog.py:627`：必須列と照合で参照中の列の削除を止める。
- `main.py:30`、`main.py:1047`：候補の表示文字と保存IDを分離し、IDの外側の空白を除去。重複スタッフIDを保存前に拒否。
- `main.py:1024`：社員ID管理の初期表示は未紐づけがあるとき未紐づけのみ、ないとき全員。追加行にもフィルター更新を接続。
- `startup_period.py:5`、`main.py:626`：PCローカル日付の暦年・暦月を起動時だけ採用。10月16日も10月度。手動変更はセッション内で維持し、起動処理自体は設定JSONを保存しない。
- `engine.py:79`：同一フォルダにtmpを生成してflush/fsync後に置換するため、保存途中に既存JSONを空にする経路を避ける。

## 既存関連テストの再実行

実行対象：`test_trial34_settings` 27ケース、`test_trial41_settings` 8ケース、`test_trial43_startup_period` 6ケース、`test_trial43_mapping_default` 7ケース、`test_trial44_audit` 8ケース。合計**56ケースすべて合格**（226.267秒）。新規独立8ケースを合わせて計64ケースを再確認。

証拠ログ：`/tmp/final_settings_review/existing-results.log`。

## 限界

Windows実機、NTFSでの権限・共有フォルダ競合、実Excel/COM、会社の未開示データでは未実施。ファイルロック等はPermissionErrorを注入してアプリの失敗時挙動を確認したもので、Windows実機で同じ操作をした結果ではありません。未対応の新しい比較型は未知属性として保持できても、実際の比較方式の追加には実装が必要です。JSONに列を追加するだけで任意の新しい比較アルゴリズムが実行されるという保証はありません。

## Trial46 修正後の独立再監査

対象を `/workspace/attendsync-trial46/AttendSync` に変更し、本体を編集せず確認。親担当の修正は各exec処理をtry/finallyで囲み、戻り値・保存値を使用した後にdeleteLaterする方式です。

配布可能な回帰テスト：`/tmp/final_settings_review/test_trial46_dialog_lifecycle.py`。本体フォルダへコピーした場合はソース相対importで実行可能。別ソースの監査時は `ATTENDSYNC_SOURCE_ROOT` 環境変数で対象を指定できます。userdataは実行時のTemporaryDirectoryのみ。

**実Qt再監査10ケース全合格（3.369秒）。** 各画面を3回ずつ開閉し、DeferredDeleteを処理した後のQDialog数・QWidget数が開始時と同じであること、閉じたダイアログ/メニューがshiboken6.isValidでFalseになることを確認。

| 経路 | 再監査結果 |
|---|---|
| 設定：キャンセル | 3回とも残留なし |
| 社員ID管理：キャンセル | 3回とも残留なし |
| 診断：キャンセル | 3回とも残留なし |
| ログ：キャンセル | 3回とも残留なし |
| 全項目対比表：キャンセル | 3回とも残留なし |
| 詳細表示項目：保存 | 3回とも子ダイアログ残留なし。表示項目の保存結果と詳細設定の一致、OFF項目の除外を確認 |
| 読み込み後の未解決IDダイアログ：キャンセル | 3回とも残留なし |
| 読み込み後の未解決IDダイアログ：保存 | 3回とも残留なし。ID保存後にメモリとJSONが一致し、正しく1社員を保存 |
| 設定：保存成功／保存失敗 | それぞれ3回とも残留なし。成功では速度5→6→7の保存結果を確認。PermissionError時は警告3回、元メモリ・元JSONバイトが不変 |
| 右クリックメニュー：取消し | 3回ともメニュー残留なし |

以上により、Trial45で再現したP2の設定・社員IDダイアログ残留は、Trial46で解消されたと判定します。保存値を読み出す前にオブジェクトが削除される問題も、実保存経路で再現していません。

証拠ログ：`/tmp/final_settings_review/recheck46.log`。

Qt offscreenのraise/grabbing keyboard/propagateSizeHints未対応メッセージは出ていますが、実際のQtダイアログ/メニュー処理とテストは正常終了。Windows実機での描画や入力の確認を代替するものではありません。

初回独立テスト8ケースもTrial46で再実行し、**全合格（11.557秒）**。JSON/設定/ID保存の失敗時不変、拡張項目の保存再起動、破損JSON拒否は修正後も維持されています。証拠：`/tmp/final_settings_review/review46.py`、`independent46.log`。Trial46再監査は新規寿命10ケース＋独立異常系8ケース＝18ケース全合格です。
