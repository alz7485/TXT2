# AttendSync Trial45 最終 UI／操作マニュアル独立レビュー

対象: `/workspace/attendsync-trial45/AttendSync`。Python 3.12／PySide6、Qt offscreen（Linux）。本体ソースは変更していない。すべてのUI実行で一時設定・一時社員ID・一時キャッシュを使用した。

## 結論

枠線付きUIのライト／ダーク、対応最小サイズ、検索・フィルタ、マニュアルの同梱／F1経路に、致命的な操作不能や現行仕様との矛盾は検出していない。最終版として修正を推奨する中程度のキーボード操作の欠落を1件確認した。

## 指摘

### 中: 結果行をReturnで確定しても詳細対比表を開けない

- 箇所: `main.py:831`（`self.table.doubleClicked.connect(self.open_detail)`）、`main.py:1326`。
- 再現: 一時設定で起動、照合結果を1行表示、結果表の1行目を選択してフォーカス、Qt QTestでReturnを入力。
- 証拠: `QTableView.activated` が `[0]` を通知する一方、`DetailDialog.exec` の呼び出しは0回。詳細への経路がマウスのダブルクリックと右クリックに限られている。
- 影響: マウスを使用できない利用者が結果の詳細に進めない。照合値や保存内容を壊す問題ではなく、枠線変更に伴う退行でもない。
- 修正案: `doubleClicked` 接続を `activated` 接続に置き換える。両方を接続するとプラットフォームによって重複起動の恐れがあるため、一本化する。
- 独立検証: 本体の編集をせず実行中の接続だけを置き換え、Returnから詳細1回、マウスのクリック→ダブルクリックから詳細1回を確認。Fusion、実QTestイベントで検証。
- 再現／修正案プローブ: `/tmp/final_ui_review/check_activation.py`。
- ログ: `/tmp/final_ui_review/activation.log`。

なお、offscreenの `QTest.keyClick(Key_Menu)` はcontextイベントを生成しない。ネイティブ相当の `QContextMenuEvent.Keyboard` をviewportへ送ると既存のcustomContextMenuRequestedが1回発火した。そのため、メニューキー非対応を実装上の不具合としては扱わない。

## 検証済み

- `test_trial33_ui`: 9件合格。メイン1040×690／1280×860、両テーマ、長いステータス、結果の空表示、和文・全角空白を含む検索、解除ボタン、状態フィルタ、テーマ変更後の結果維持、詳細760×550、設定780×580の全タブ保存／キャンセル、主要本文のコントラスト比4.5以上。
- `test_trial39_manual`: 10件合格。18章、同梱画像・alt・ローカル参照・内部アンカー、ボタンとF1、日本語・空白を含むパス、ブラウザ失敗時の復帰、起動時のマニュアル未読込、onedir資料コピー、JSON拡張項目の保存。
- 独立プローブ `/tmp/final_ui_review/probe.py`: 検索欄にフォーカスした状態のF1呼び出し1回。両テーマでメインサイズ1040×690を維持し、結果表viewport952×119、`showGrid=True`。
- 実Qtキャプチャ4枚を目視確認: 最小メインのライト／ダーク、最小設定のライト／ダーク。外枠、入力欄、表罫線、設定グループが表示され、重なり・主要操作の切れを検出していない。画像: `/tmp/final_ui_review/main-light.png`、`main-dark.png`、`settings-light.png`、`settings-dark.png`。
- マニュアル本文で月度の起動日指定（1～15日含め日付の月）、9/16～10/15（30日）、読み込み設定の優先配置、結果設定スナップショット、比較数と追加診断の区別、JSON追加・未知属性保持、CSV未読込で保存した旧版IDの復元案内、onedirの全フォルダ配布が現行実装の説明と整合していることを確認。
- 補足画面がTrial42継承であることはPreview/README.txtとギャラリーに明記されている。

## 限界

Windowsの高DPI・実モニター・スクリーンリーダー・ビルド済みEXE・Excel COM・実プリンターはこのLinux実行で検証できない。ブラウザを実起動したマニュアルの検索／拡大／印刷の動作は今回再実行していない（HTML／リンク／画像構造とアプリのローカルURL起動経路を確認した）。キーボードcontextイベントの配送先や座標の実Windows挙動は未検証。

複数のGUIテストモジュールを同一Pythonプロセスへまとめると、import時の一時パスの干渉によりモーダル待ちが発生する場合がある。今回の成功結果はモジュール別プロセスで取得した。このテストハーネスの制約は製品の起動不具合とは判定していない。

## 追加の関連テスト

モジュール別の新規プロセスで `test_trial34_settings` 27件、`test_trial43_startup_period` 6件、`test_trial43_mapping_default` 7件、`test_trial44_audit` 8件がすべて合格。上記UI／マニュアル19件と合わせ、今回の専門レビューで実行した既存テストは67件合格。関連ログは `/tmp/final_ui_review/test_trial*.log` に保存。

## Trial46 修正後の独立再検証

対象 `/workspace/attendsync-trial46/AttendSync`。本体編集なしで再実行。

- `main.py:840` の `activated.connect(self.open_detail)` により、Return・マウスのダブルクリックとも、詳細起動がそれぞれ1回。Trial45の指摘は解消した。
- ネイティブ相当の `QContextMenuEvent.Keyboard` を結果表viewportへ配送し、カスタムcontext signalが1回であることを再確認。メニューのアプリ側ハンドラが2アクションを組み立て、exec・deleteLaterが各1回であることも確認（メニューオブジェクトはモックしてoffscreenのモーダル待ちを回避）。
- 検索欄からF1でマニュアル起動1回。
- 実 `DetailDialog` をReturnで開き、Qtタイマーで閉じる操作を2回実行。各回のdestroyed signalを確認し、閉じた後に残留するDetailDialogがなく、メインの読み込みボタンが利用でき、フィルタ変更も正常。
- 再検証ログ `/tmp/final_ui_review/recheck_trial46.log`。
- 配布へ追加可能な独立回帰テスト `/tmp/final_ui_review/test_trial46_keyboard.py` を作成。5テストすべて合格、実行ログ `/tmp/final_ui_review/test_trial46_keyboard.log`。本体フォルダへコピー後は他の既存テストと同じく `python test_trial46_keyboard.py` または `python -m unittest -v test_trial46_keyboard` で実行できる。

この再検証で新たなUI不具合は検出していない。Windows／実ブラウザに関する上記の限界は継続する。
