# Trial66 検証記録

検証環境：Linux / Python3.12.14 / PySide6 6.12.0 / openpyxl3.1.5、Qt offscreen。

新規回帰 test_trial66_completion_fixes.py は13メソッド成功。実ReadWorker、SQLiteヘッダ/内部ページ破損、同サイズ日時差替え、キャッシュ必須metadata、実社員UI保存と進行中/待機通知、模擬Outlookの宛先等価性と旧履歴移行、600人編集候補2400件、6000人取込、実エラー項目のフォーカスを検証しています。

既存回帰と追加回帰を合わせた53スクリプトの最終結果・個別ログは TestEvidence/Trial66/Regression に、独立した修正後監査と最終判定は TestEvidence/Trial66/FinalReview に同梱します。中断前の結果と再修正前の指摘は別ディレクトリへ保持し、最終成功件数へ混在させません。

仕様変更に合わせ、旧キャッシュ正常fixtureへ出典/欠損フラグを補い、旧キャッシュ破損の期待を自動回復へ更新しました。回復不能の致命例外による旧結果保護は別途故障注入で確認します。単に失敗する期待を削除したものではありません。

実社員データ・実認証・実メール配送は使用していません。Windows実機、実Excel/Outlook COM、配送完了、Windows EXEビルドは未検証です。旧ハッシュだけの送信履歴の復元限界とCSVをExcelで開く際の式評価リスクは CHANGES_TRIAL66.md に明記しています。
