"""Guide (onboarding tour) definitions and display settings — no Qt imports.

The tour walks a first-time user through the real workflow in order:

1. ``employee``       register employee information (ID / name / e-mail)
2. ``period_folder``  check the target month and choose the attendance folder
3. ``csv_load``       confirm the client CSV is in the same folder and run the read
4. ``results``        review the comparison results
5. ``mail``           create mail for employees with mismatches (only when needed)

Display preferences live in the main settings JSON under ``guides``::

    {"all_off": false, "hidden": ["results", "mail"]}

``all_off`` hides every guide; ``hidden`` hides individual guides.  Both are
editable from the guide panel itself and from 設定 → ガイド, and the two stay
in sync because they read and write the same structure.
"""
from __future__ import annotations

import copy

GUIDE_STEPS = [
    {
        'id': 'employee',
        'title': 'まず、社員情報を読み込みます',
        'body': (
            '勤怠チェックの前に、派遣先の「スタッフ基本情報」CSVを読み込んで社員情報を登録します。\n'
            '右上の「社員情報」を押すと社員情報の画面が開きます。その画面にも専用のガイドが表示されるので、'
            '案内に沿ってCSVを読み込み、一覧を確認して「社員情報を登録」を押してください。\n'
            '登録が終わると、次のガイドが自動で表示されます。'
        ),
        'action': '社員情報を開く',
    },
    {
        'id': 'period_folder',
        'title': '月度を確認し、勤怠ファイルのフォルダを選びます',
        'body': (
            '対象月度は起動日の年・月が自動で入っています。別の月度を調べるときだけ変更してください。\n'
            '次に、「日報報告」Excelと「日別勤務情報」CSVが入ったフォルダを「フォルダ選択」から選ぶか、'
            'メイン画面へフォルダをドロップします。フォルダを選ぶと次のガイドへ進みます。'
        ),
        'action': 'フォルダを選ぶ',
    },
    {
        'id': 'csv_load',
        'title': '派遣先CSVも同じフォルダに入れて、読み込みます',
        'body': (
            '派遣先の「日別勤務情報」CSV（末尾に日付が入ります。例：日別勤務情報20261019.csv）は、'
            '「日報報告」Excelと同じフォルダに入れてください。'
            '「読み込み・照合」を押すと、ExcelとCSVをまとめて読み込んで照合します。\n'
            '「スタッフ基本情報」CSVは社員情報用なので、勤怠としては読み込みません。'
            '日別勤務情報が入っていないフォルダでは読み込みを始められません。'
        ),
        'action': '読み込み・照合を実行',
    },
    {
        'id': 'results',
        'title': '照合結果を確認します',
        'body': (
            '読み込みが終わると、上の数字と一覧に結果が出ます。\n'
            '「不一致のみ」で差異のある行だけを確認できます。行をダブルクリックすると詳細の対比表、'
            '右クリックで元のExcelの該当セルを開けます。\n'
            '問題（不一致・要確認）がなければ、これで完了です。'
        ),
        'action': '確認しました',
    },
    {
        'id': 'mail',
        'title': '問題があれば、メールを作成します',
        'body': (
            '不一致がある社員には、照合結果の「メールを作成」から連絡メールを作れます。\n'
            '宛先は社員情報に登録したメールアドレスです。設定により、Outlookの下書き保存か、'
            'そのまま送信かが変わります（設定 → メール）。\n'
            'メール画面を閉じるとガイドは終了です。'
        ),
        'action': 'メールを作成',
    },
]

STEP_IDS = [step['id'] for step in GUIDE_STEPS]
STEP_TITLES = {step['id']: step['title'] for step in GUIDE_STEPS}

# Per-screen guide for the 社員情報 editor (Trial68): each UI owns its own
# guide.  The editor's preferences live under guides['employee'] in the
# settings JSON, with the same {'all_off', 'hidden'} shape as the main tour.
EMPLOYEE_GUIDE_STEPS = [
    {
        'id': 'import',
        'title': '「スタッフ基本情報」CSVを読み込みます',
        'body': (
            '上の欄に派遣先の「スタッフ基本情報」CSVを指定します（この画面へCSVをドロップしても構いません）。'
            '対象フォルダにこのCSVがあれば、開いたときに自動で読み込まれます。\n'
            '列の対応（スタッフID=A列、社員ID=B列、氏名=C列、メール=J列）は「設定 → 読み込み設定 → 社員情報 CSV」で変更できます。'
            '読み込むと、下の一覧へ自動で反映されます。'
        ),
        'action': 'CSVを選択',
    },
    {
        'id': 'review',
        'title': '一覧を確認し、必要なら手直しします',
        'body': (
            '読み込んだ内容が一覧に入りました。上の絞り込みで「ID未紐付け」「メール未紐付け」を確認できます。\n'
            '各行のスタッフIDとメールアドレスは、その場で選び直したり入力したりできます。'
            '読み込んだ行をダブルクリックすると、元CSVのセルをExcelで開けます。'
        ),
        'action': '',
    },
    {
        'id': 'register',
        'title': '社員情報を登録します',
        'body': (
            '内容が合っていれば「社員情報を登録」を押します。登録するまで保存されません。\n'
            'キャンセルすると、読み込んだ内容も含めて破棄されます。'
        ),
        'action': '社員情報を登録',
    },
]

EMPLOYEE_STEP_IDS = [step['id'] for step in EMPLOYEE_GUIDE_STEPS]
EMPLOYEE_STEP_TITLES = {step['id']: step['title'] for step in EMPLOYEE_GUIDE_STEPS}

DEFAULT_GUIDE_SETTINGS = {'all_off': False, 'hidden': []}


def normalize_guide_settings(raw, ids=None):
    """Return a clean ``{'all_off': bool, 'hidden': [step_id, ...]}`` dict.

    Unknown step ids and malformed values are dropped rather than raising,
    so a hand-edited or older settings file can never break startup.
    Use ``validate_guide_settings`` where a strict check is required
    (the settings dialog's JSON validation).  ``ids`` selects the step set
    (main tour by default; pass EMPLOYEE_STEP_IDS for a per-screen guide).
    """
    valid_ids = STEP_IDS if ids is None else ids
    if not isinstance(raw, dict):
        return copy.deepcopy(DEFAULT_GUIDE_SETTINGS)
    hidden = raw.get('hidden')
    if not isinstance(hidden, list):
        hidden = []
    cleaned = []
    for step_id in hidden:
        if step_id in valid_ids and step_id not in cleaned:
            cleaned.append(step_id)
    return {'all_off': bool(raw.get('all_off', False)), 'hidden': cleaned}


def validate_guide_settings(raw):
    """Raise ValueError with a Japanese message if ``raw`` is malformed."""
    if raw is None:
        return
    if not isinstance(raw, dict):
        raise ValueError('JSONのガイド設定はオブジェクト形式で入力してください。')
    if 'all_off' in raw and not isinstance(raw['all_off'], bool):
        raise ValueError('JSONのガイド設定「all_off」はtrueまたはfalseで入力してください。')
    hidden = raw.get('hidden')
    if hidden is not None:
        if not isinstance(hidden, list) or not all(isinstance(v, str) for v in hidden):
            raise ValueError('JSONのガイド設定「hidden」はガイドIDのリストで入力してください。')
        unknown = [v for v in hidden if v not in STEP_IDS]
        if unknown:
            raise ValueError('JSONのガイド設定「hidden」に不明なガイドIDがあります：' + ', '.join(unknown))
    employee = raw.get('employee')
    if employee is not None:
        if not isinstance(employee, dict):
            raise ValueError('JSONのガイド設定「employee」はオブジェクト形式で入力してください。')
        if 'all_off' in employee and not isinstance(employee['all_off'], bool):
            raise ValueError('JSONのガイド設定「employee.all_off」はtrueまたはfalseで入力してください。')
        emp_hidden = employee.get('hidden')
        if emp_hidden is not None:
            if not isinstance(emp_hidden, list) or not all(isinstance(v, str) for v in emp_hidden):
                raise ValueError('JSONのガイド設定「employee.hidden」はガイドIDのリストで入力してください。')
            unknown = [v for v in emp_hidden if v not in EMPLOYEE_STEP_IDS]
            if unknown:
                raise ValueError('JSONのガイド設定「employee.hidden」に不明なガイドIDがあります：' + ', '.join(unknown))


def step_visible(settings, step_id):
    """True when the guide for ``step_id`` should be shown under ``settings``."""
    cleaned = normalize_guide_settings(settings)
    return not cleaned['all_off'] and step_id not in cleaned['hidden']


def visible_step_ids(settings):
    cleaned = normalize_guide_settings(settings)
    if cleaned['all_off']:
        return []
    return [step_id for step_id in STEP_IDS if step_id not in cleaned['hidden']]


def next_visible_step(settings, after_id=None):
    """First visible step id after ``after_id`` (from the start when None)."""
    visible = visible_step_ids(settings)
    if after_id is None:
        return visible[0] if visible else None
    if after_id in STEP_IDS:
        later = STEP_IDS[STEP_IDS.index(after_id) + 1:]
        return next((step_id for step_id in later if step_id in visible), None)
    return visible[0] if visible else None


def with_step_hidden(settings, step_id, hidden=True):
    """Copy of ``settings`` with one step hidden (or shown again)."""
    cleaned = normalize_guide_settings(settings)
    if step_id in STEP_IDS:
        if hidden and step_id not in cleaned['hidden']:
            cleaned['hidden'].append(step_id)
        if not hidden and step_id in cleaned['hidden']:
            cleaned['hidden'].remove(step_id)
    return cleaned


def with_all_off(settings, off=True):
    """Copy of ``settings`` with the master hide switch set."""
    cleaned = normalize_guide_settings(settings)
    cleaned['all_off'] = bool(off)
    return cleaned
