"""Trial68: integrated employee editor + per-screen guides + start buttons.

The 社員情報 CSV import used to open a second dialog from the editor; it
now lives inside the editor itself.  Each screen owns its guide: the
editor has its own 3-step guide stored under guides['employee'], and both
the main window header and the editor carry a ガイド開始 button that
replays that screen's guide for the current session without changing the
saved hide preferences.
"""
from __future__ import annotations

import copy
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

from guide_config import (
    EMPLOYEE_GUIDE_STEPS, EMPLOYEE_STEP_IDS, normalize_guide_settings,
    validate_guide_settings,
)

try:
    from PySide6.QtCore import QTimer
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QApplication, QLineEdit, QPushButton, QTableWidget, QWidget
except ModuleNotFoundError as exc:
    if exc.name != 'PySide6':
        raise
    QT_AVAILABLE = False
else:
    QT_AVAILABLE = True
    import runtime_paths
    _import_directory = tempfile.TemporaryDirectory(prefix='attendsync-trial68-import-')
    with patch.object(runtime_paths, 'get_data_dir', return_value=Path(_import_directory.name)):
        import main
    import engine
    from guide import DialogGuideManager


class EmployeeGuideConfigLogic(unittest.TestCase):
    def test_employee_steps_and_normalize(self):
        self.assertEqual(EMPLOYEE_STEP_IDS, ['import', 'review', 'register'])
        for step in EMPLOYEE_GUIDE_STEPS:
            self.assertTrue(step['title'])
            self.assertTrue(step['body'])
        cleaned = normalize_guide_settings({'all_off': 1, 'hidden': ['review', 'mail', 'review']}, ids=EMPLOYEE_STEP_IDS)
        self.assertEqual(cleaned, {'all_off': True, 'hidden': ['review']})

    def test_validate_employee_section(self):
        validate_guide_settings({'all_off': False, 'hidden': [], 'employee': {'all_off': True, 'hidden': ['import']}})
        for bad in ({'employee': 'x'}, {'employee': {'all_off': 'yes'}}, {'employee': {'hidden': ['mail']}}):
            with self.assertRaises(ValueError):
                validate_guide_settings(bad)


@unittest.skipUnless(QT_AVAILABLE, 'PySide6 is required for real Qt checks')
class EditorAndGuideFlow(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
        cls.app.setQuitOnLastWindowClosed(False)

    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(prefix='attendsync-trial68-test-')
        self.addCleanup(self.directory.cleanup)
        self.data_dir = Path(self.directory.name)
        self.paths_patch = patch.multiple(
            main, DATA_DIR=self.data_dir, CONFIG=self.data_dir / 'settings.json',
            MAP=self.data_dir / 'staff_mapping.json', DB=self.data_dir / 'attendance_cache.sqlite3',
        )
        self.paths_patch.start()
        self.addCleanup(self.paths_patch.stop)
        self.window = None
        self.addCleanup(self.close_window)
        self.csv = self.data_dir / '社員情報.csv'
        self.csv.write_text(
            'スタッフID,派遣元スタッフコード,氏名,D,E,F,G,H,I,メール\n'
            'S01,0001,確認社員,,,,,,,one@example.com\n', encoding='utf-8-sig')
        self.errors = []

    def close_window(self):
        if self.window is not None:
            self.window.close()
            self.window.deleteLater()
            self.app.processEvents()

    def make_window(self, guides=None):
        if guides is not None:
            cfg = copy.deepcopy(engine.DEFAULT)
            cfg['guides'] = guides
            (self.data_dir / 'settings.json').write_text(json.dumps(cfg, ensure_ascii=False), encoding='utf-8')
        with patch.object(main, 'current_attendance_month', return_value=(2026, 10)):
            self.window = main.Window()
        self.window.show()
        self.app.processEvents()
        return self.window

    def open_editor(self, operate):
        def guarded():
            dialog = self.app.activeModalWidget()
            try:
                operate(dialog)
            except Exception as exc:
                self.errors.append(exc)
                dialog.reject()
        with patch.object(self.window, 'run_read'):
            QTimer.singleShot(0, guarded)
            self.window.edit_map()
            self.app.processEvents()
        self.assertFalse(self.errors, self.errors)

    def guide_manager_of(self, dialog):
        panel = dialog.findChild(QWidget, 'guidePanel')
        self.assertIsNotNone(panel)
        manager = panel._manager
        self.assertIsInstance(manager, DialogGuideManager)
        return manager

    # -- integrated editor -------------------------------------------
    def test_editor_is_a_single_ui_with_import_controls(self):
        self.make_window()
        def operate(dialog):
            self.assertIsNone(next((b for b in dialog.findChildren(QPushButton) if b.text() == '社員情報を読み込む'), None))
            # Trial71: the import column fields moved into 設定.
            for key in ('staff', 'employee', 'name', 'email'):
                self.assertIsNone(dialog.findChild(QLineEdit, 'informationColumn_' + key))
            self.assertIsNotNone(dialog.findChild(QPushButton, 'informationCsvChoose'))
            self.assertIsNotNone(dialog.findChild(QPushButton, 'employeeGuideStart'))
            dialog.reject()
        self.open_editor(operate)

    # -- per-screen guide ---------------------------------------------
    def test_employee_guide_opens_and_advances_on_import(self):
        self.make_window()
        def operate(dialog):
            QTest.qWait(700)
            manager = self.guide_manager_of(dialog)
            self.assertTrue(manager.active)
            self.assertEqual(manager.current_id, 'import')
            self.assertTrue(manager.panel.isVisible())
            box = dialog.findChild(QWidget, 'employeeImportBox')
            self.assertIn(box, manager.overlay._targets)
            dialog.findChild(QLineEdit, 'informationCsvPath').setText(str(self.csv))
            QTest.qWait(700)
            self.app.processEvents()
            self.assertEqual(dialog.findChild(QTableWidget, 'employeeIdTable').rowCount(), 1)
            self.assertEqual(manager.current_id, 'review')
            manager.advance()
            self.assertEqual(manager.current_id, 'register')
            dialog.reject()
        self.open_editor(operate)

    def test_employee_guide_hide_checkbox_persists_its_own_section(self):
        self.make_window(guides={'all_off': False, 'hidden': ['mail'],
                                 'employee': {'all_off': False, 'hidden': []}})
        def operate(dialog):
            QTest.qWait(700)
            manager = self.guide_manager_of(dialog)
            manager.panel.check_step.setChecked(True)
            self.assertEqual(self.window.cfg['guides']['employee']['hidden'], ['import'])
            # The main tour's section is untouched.
            self.assertEqual(self.window.cfg['guides']['hidden'], ['mail'])
            self.assertFalse(self.window.cfg['guides']['all_off'])
            dialog.reject()
        self.open_editor(operate)

    def test_employee_guide_hidden_stays_closed_but_start_button_replays(self):
        self.make_window(guides={'all_off': False, 'hidden': [],
                                 'employee': {'all_off': True, 'hidden': []}})
        def operate(dialog):
            QTest.qWait(700)
            manager = self.guide_manager_of(dialog)
            self.assertFalse(manager.panel.isVisible())
            dialog.findChild(QPushButton, 'employeeGuideStart').click()
            self.app.processEvents()
            self.assertTrue(manager.panel.isVisible())
            self.assertEqual(manager.current_id, 'import')
            manager.advance()
            self.assertEqual(manager.current_id, 'review')
            # Saved preferences were not rewritten by the replay.
            self.assertTrue(self.window.cfg['guides']['employee']['all_off'])
            dialog.reject()
        self.open_editor(operate)

    # -- main window guide start button ---------------------------------
    def test_header_guide_button_replays_even_when_all_hidden(self):
        window = self.make_window(guides={'all_off': True, 'hidden': ['period_folder']})
        manager = window.guide_manager
        manager.start()
        self.assertFalse(manager.panel.isVisible())
        self.assertEqual(window.btn_guide.text(), 'ガイド開始')
        window.btn_guide.click()
        self.app.processEvents()
        self.assertTrue(manager.panel.isVisible())
        self.assertEqual(manager.current_id, 'employee')
        manager.advance()
        self.assertEqual(manager.current_id, 'period_folder')
        self.assertTrue(window.cfg['guides']['all_off'])

    # -- settings tab ----------------------------------------------------
    def test_settings_guide_tab_has_employee_section(self):
        window = self.make_window(guides={'all_off': False, 'hidden': [],
                                          'employee': {'all_off': False, 'hidden': ['review']}})
        dialog = main.SettingsDialog(window, copy.deepcopy(window.cfg))
        self.addCleanup(dialog.deleteLater)
        self.assertTrue(dialog.guide_employee_checks['review'].isChecked())
        dialog.guide_employee_all_off.setChecked(True)
        dialog.accept()
        self.assertEqual(dialog.value['guides']['employee'], {'all_off': True, 'hidden': ['review']})
        self.assertEqual(dialog.value['guides']['hidden'], [])


if __name__ == '__main__':
    unittest.main(verbosity=2)
