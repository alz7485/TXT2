# Trial46 最終専門レビュー修正版

- engine.py：不正日/月/不存在日を区別。日別列・基本情報セルの未計算/エラー数式を検査し、計算済み空文字/0を保持。全設定列の異常情報をキャッシュに保持し、ON照合で要確認にする。
- main.py：不正XLSX行の全数一致遮断、保存先初期化の説明、Enter詳細起動、各modal/menuの終了後解放。
- runtime_paths.py：代替保存先のwrite/flush検査と保存先を含む説明。
- cache_tags.py：旧抽出キャッシュを使わないよう版を更新。初回は再解析、設定・社員IDは維持。
- test_trial46_engine.py / test_trial46_startup.py / test_trial46_dialog_lifecycle.py / test_trial46_keyboard.pyを追加（計31メソッド）。Python削除なし。
- 4専門レビュー、マニュアル、主要実画面、会社向けonedir手順、最新資料リンクを更新。

全39スクリプト成功。独立再監査の結果と実施範囲はAUDIT_TRIAL46.md参照。Windows実機とEXE実ビルドは未実施。
