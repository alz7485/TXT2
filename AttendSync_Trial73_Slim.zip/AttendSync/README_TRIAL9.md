# AttendSync Trial 9 (onedir)

- 名前・exe名・アプリアイコンを AttendSync に変更
- 詳細対比表: XLSX/CSVを青/緑の太い縦境界で区別、不一致値は赤太字
- 詳細XLSX値のダブルクリック: Excelを開いて対応セルを選択
- メイン一覧右クリック: Excelの該当セルを開く
- 詳細印刷: 赤太字と列境界を反映
- 元の読み込み方式は変更せず、Excel COMをクリックした際だけ利用
- 既存設定は元の userdata を新しい dist/AttendSync/userdata にコピーして継承可能

Windowsビルド（.bat不要）:
```
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-build.txt
.\.venv\Scripts\python.exe build_onedir.py
```
配布はdist/AttendSyncフォルダごと。元Excelは書き込まず、未起動ブックは読み取り専用で開きます。
既存のブックが開いている場合はそのまま使用し保存しません。
Excel COM動作・Windows GUI・120ファイルの速度は現地確認が必要です。
