"""Trial72: day-off formula zeros for durations are blanks, not 0:00.

Reported from real use: on days off the source workbook's time cells only
look blank — they hold formulas whose cached result is 0, displayed blank
by the number format.  Start/end were already read as blank (Trial52's
hidden-zero rule for clocks), but 実働時間 kept 0:00 and mismatched the
client CSV's real blank.

Rule: when a row has no start and no end (nothing was worked that day),
a display-hidden formula zero in a duration field （実働時間・休憩時間）
is a blank too.  On a worked day the same zero stays a real 0:00, and a
typed (non-formula) 0 always stays.
"""
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from xml.etree import ElementTree as ET

from openpyxl import Workbook

from engine import DEFAULT, xlsx_read, compare_time, xlsx_duration_keys

NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
HIDDEN = 'h:mm;;'


def build(path, cells):
    """cells: {coordinate: (value, number_format)}; formula values get a
    cached result of 0 written into the sheet XML, like a saved Excel file."""
    wb = Workbook()
    ws = wb.active
    ws.title = '10月'
    for cell, val in [('A1', '2026年10月度'), ('N1', 'E1'), ('U1', '確認社員'),
                      ('A9', 10), ('B9', 1), ('F9', 5)]:
        ws[cell] = val
    for cell, (val, fmt) in cells.items():
        ws[cell] = val
        ws[cell].number_format = fmt
    wb.save(path)
    wb.close()
    with ZipFile(path) as z:
        parts = {n: z.read(n) for n in z.namelist()}
    sheet = ET.fromstring(parts['xl/worksheets/sheet1.xml'])
    for c in sheet.iter(NS + 'c'):
        if c.find(NS + 'f') is not None:
            v = c.find(NS + 'v')
            if v is None:
                v = ET.SubElement(c, NS + 'v')
            v.text = '0'
            c.set('t', 'n')
    parts['xl/worksheets/sheet1.xml'] = ET.tostring(sheet)
    with ZipFile(path, 'w', ZIP_DEFLATED) as z:
        for n, data in parts.items():
            z.writestr(n, data)


class HiddenZeroDuration(unittest.TestCase):
    def read(self, cells):
        with tempfile.TemporaryDirectory() as t:
            p = Path(t) / 'input.xlsx'
            build(p, cells)
            result = xlsx_read(p, DEFAULT)
            self.assertNotIn('error', result)
            return result['records'][0]

    def test_day_off_hidden_zeros_are_blank_for_work_and_break(self):
        r = self.read({'G9': ('=0', HIDDEN), 'H9': ('=0', HIDDEN),
                       'T9': ('=0', HIDDEN), 'M9': ('=0', HIDDEN)})
        self.assertIsNone(r['values']['start'])
        self.assertIsNone(r['values']['end'])
        self.assertIsNone(r['values']['work'])
        self.assertIsNone(r['values']['break_total'])
        # The reported case: matches the client CSV's real blank.
        self.assertEqual(compare_time(r['values']['work'], '', 'duration'), '一致')

    def test_worked_day_hidden_zero_work_is_retained(self):
        r = self.read({'G9': ('9:00', 'h:mm'), 'H9': ('18:00', 'h:mm'),
                       'T9': ('=0', HIDDEN)})
        self.assertEqual(compare_time(r['values']['work'], '0:00', 'duration'), '一致')
        self.assertEqual(compare_time(r['values']['work'], '', 'duration'), '不一致')

    def test_day_off_typed_zero_work_is_retained(self):
        r = self.read({'G9': ('=0', HIDDEN), 'H9': ('=0', HIDDEN),
                       'T9': (0, HIDDEN)})
        self.assertEqual(compare_time(r['values']['work'], '0:00', 'duration'), '一致')

    def test_day_off_visible_zero_work_is_retained(self):
        # A formula zero that Excel would SHOW as 0:00 (format has a zero
        # section) is not a hidden blank, even on a day off.
        r = self.read({'G9': ('=0', HIDDEN), 'H9': ('=0', HIDDEN),
                       'T9': ('=0', 'h:mm')})
        self.assertEqual(compare_time(r['values']['work'], '0:00', 'duration'), '一致')

    def test_duration_keys_cover_work_and_break(self):
        self.assertTrue({'work', 'break_total'} <= xlsx_duration_keys(DEFAULT))


if __name__ == '__main__':
    unittest.main(verbosity=2)
