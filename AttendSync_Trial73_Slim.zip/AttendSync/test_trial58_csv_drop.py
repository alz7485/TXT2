"""Native CSV drop events and automatic reflection in the integrated editor.

Trial68: the employee CSV import lives inside the 社員情報 editor itself
(there is no separate import dialog anymore).  Dropping a CSV anywhere on
the editor reads it and reflects the plan into the editor table; nothing
is saved until 社員情報を登録 is pressed.
"""
import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import tempfile
import unittest
import sys
from types import SimpleNamespace
from pathlib import Path
from unittest.mock import patch
from PySide6.QtCore import QMimeData, QPoint, QPointF, Qt, QUrl, QTimer
from PySide6.QtGui import QDragEnterEvent, QDragMoveEvent, QDropEvent
from PySide6.QtWidgets import QApplication, QComboBox, QLineEdit, QPushButton, QSpinBox, QTableWidget, QLabel
from PySide6.QtTest import QTest
import runtime_paths
_import_data = tempfile.TemporaryDirectory()
with patch.object(runtime_paths, 'get_data_dir', return_value=Path(_import_data.name)):
    import main
from employee_contacts import load_contacts, email_for, selected_email
from engine import save_json

APP = QApplication.instance() or QApplication([])
APP.setQuitOnLastWindowClosed(False)
EMPTY = {'version': 1, 'contacts': []}


class CsvDrop58(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.folder = Path(self.tmp.name)
        self.paths = patch.multiple(main, CONFIG=self.folder/'settings.json',
                                    MAP=self.folder/'staff_mapping.json', DB=self.folder/'cache.db')
        self.paths.start(); self.addCleanup(self.paths.stop)
        self.window = main.Window(); self.addCleanup(self.window.close)
        self.csv = self.folder/'社員 情報.CSV'
        self.csv.write_text('スタッフID,派遣元スタッフコード,氏名,D,E,F,G,H,I,メール\n'
                            'S01,0001,確認社員,,,,,,,one@example.com\n', encoding='utf-8-sig')
        self.errors = []

    def dispatch(self, target, urls=None, text=None):
        mime = QMimeData()
        if text is not None: mime.setText(text)
        else: mime.setUrls(urls or [QUrl.fromLocalFile(str(self.csv))])
        events = [QDragEnterEvent(QPoint(5, 5), Qt.CopyAction|Qt.MoveAction, mime, Qt.LeftButton, Qt.NoModifier),
                  QDragMoveEvent(QPoint(5, 5), Qt.CopyAction|Qt.MoveAction, mime, Qt.LeftButton, Qt.NoModifier),
                  QDropEvent(QPointF(5, 5), Qt.CopyAction|Qt.MoveAction, mime, Qt.LeftButton, Qt.NoModifier)]
        for event in events: APP.sendEvent(target, event)
        return events

    def button(self, dialog, text):
        return next(b for b in dialog.findChildren(QPushButton) if b.text() == text)

    def editor(self, operate):
        def guarded():
            dialog = APP.activeModalWidget()
            try: operate(dialog)
            except Exception as exc: self.errors.append(exc); dialog.reject()
        with patch.object(self.window, 'run_read'):
            QTimer.singleShot(0, guarded); self.window.edit_map(); APP.processEvents()
        self.assertFalse(self.errors, self.errors)

    def table(self, dialog):
        return dialog.findChild(QTableWidget, 'employeeIdTable')

    def test_drop_over_dialog_fields_and_viewport_automatically_reflects(self):
        def operate(dialog):
            table = self.table(dialog)
            targets = [dialog, dialog.findChild(QLineEdit, 'informationCsvPath'),
                       dialog.findChild(QSpinBox, 'informationFirstRow'), table.viewport()]
            for target in targets:
                events = self.dispatch(target)
                self.assertTrue(all(e.isAccepted() and e.dropAction() == Qt.CopyAction for e in events))
                QTest.qWait(600); APP.processEvents()
                self.assertEqual(table.rowCount(), 1)
                self.assertEqual(table.columnCount(), 4)
                self.assertEqual(table.item(0, 0).text(), '0001')
                self.assertEqual(main.selected_staff_id(table.cellWidget(0, 2)), 'S01')
                self.assertEqual(selected_email(table.cellWidget(0, 3)), 'one@example.com')
            self.assertFalse(main.MAP.exists())
            dialog.reject()
        self.editor(operate)

    def test_invalid_drops_do_not_paste_into_columns_or_change_filename(self):
        bad = self.folder/'other.xlsx'; bad.write_text('invalid')
        directory = self.folder/'fake.csv'; directory.mkdir()
        invalid = [[QUrl.fromLocalFile(str(bad))], [QUrl.fromLocalFile(str(directory))],
                   [QUrl.fromLocalFile(str(self.csv))]*2, [QUrl('https://example.com/staff.csv')],
                   [QUrl.fromLocalFile(str(self.folder/'missing.csv'))]]
        def operate(dialog):
            filename = dialog.findChild(QLineEdit, 'informationCsvPath')
            for urls in invalid:
                self.assertFalse(any(e.isAccepted() for e in self.dispatch(filename, urls)))
            self.assertFalse(any(e.isAccepted() for e in self.dispatch(filename, text='unexpected')))
            APP.processEvents()
            self.assertEqual(filename.text(), '')
            self.assertEqual(self.table(dialog).rowCount(), 0)
            dialog.reject()
        self.editor(operate)

    def test_editor_has_no_second_dialog_controls(self):
        def operate(dialog):
            self.assertIsNone(dialog.findChild(QComboBox, 'informationCsvRole'))
            texts = [b.text() for b in dialog.findChildren(QPushButton)]
            self.assertNotIn('照合して確認', texts)
            self.assertNotIn('一覧に反映', texts)
            self.assertNotIn('社員情報を読み込む', texts)
            dialog.reject()
        self.editor(operate)

    def test_drop_respects_saved_columns(self):
        self.csv.write_text('mail,name,staff,employee\none@example.com,確認社員,S01,0001\n')
        save_json(main.MAP.with_name('employee_contacts.json'),
                  {**EMPTY, 'employee_import_settings': {'linking': {
                      'columns': {'email': 'A', 'name': 'B', 'staff': 'C', 'employee': 'D'}}}})
        def operate(dialog):
            # Trial71: the columns live in 設定 now; the editor still honours
            # the columns saved with the contacts until settings override them.
            self.assertIsNone(dialog.findChild(QLineEdit, 'informationColumn_employee'))
            self.dispatch(dialog); QTest.qWait(600); APP.processEvents()
            table = self.table(dialog)
            self.assertEqual(table.rowCount(), 1)
            self.assertEqual(main.selected_staff_id(table.cellWidget(0, 2)), 'S01')
            dialog.reject()
        self.editor(operate)

    def test_unreadable_drop_reports_problem_and_keeps_editor_rows(self):
        def operate(dialog):
            self.dispatch(dialog); QTest.qWait(600); APP.processEvents()
            self.assertEqual(self.table(dialog).rowCount(), 1)
            self.csv.write_bytes(b'\x81')
            with patch.object(main.QMessageBox, 'warning') as warning:
                self.dispatch(dialog); QTest.qWait(600); APP.processEvents()
                warning.assert_not_called()
                self.assertIn('読み込めません', dialog.findChild(QLabel, 'informationProblems').text())
            # The failed re-read must not wipe registrations being edited,
            # but the stale source rows can no longer be navigated to.
            self.assertEqual(self.table(dialog).rowCount(), 1)
            with patch('excel_jump.open_csv_cell') as opener:
                self.table(dialog).cellDoubleClicked.emit(0, 3); opener.assert_not_called()
            dialog.reject()
        self.editor(operate)

    def test_double_click_opens_original_csv_cell(self):
        def operate(dialog):
            self.dispatch(dialog); QTest.qWait(600); APP.processEvents()
            table = self.table(dialog)
            self.assertEqual(table.rowCount(), 1)
            with patch('excel_jump.open_csv_cell') as opener:
                table.cellDoubleClicked.emit(0, 3)
                opener.assert_called_once()
                record, column = opener.call_args.args
                self.assertEqual(Path(record['file']), self.csv)
                self.assertEqual(record['row'], 2); self.assertEqual(column, 'J')
                self.assertEqual(record['file_size'], self.csv.stat().st_size)
                table.cellDoubleClicked.emit(0, 0)
                self.assertEqual(opener.call_args.args[1], 'B')
                table.cellDoubleClicked.emit(0, 2)
                self.assertEqual(opener.call_args.args[1], 'A')
            # Changing an import setting invalidates the source rows and
            # stops navigation (columns themselves moved to 設定 in Trial71).
            dialog.findChild(QComboBox, 'informationEncoding').setCurrentText('utf-8-sig')
            APP.processEvents()
            with patch('excel_jump.open_csv_cell') as opener:
                table.cellDoubleClicked.emit(0, 3); opener.assert_not_called()
            dialog.reject()
        self.editor(operate)

    def test_csv_excel_navigation_reuses_existing_workbook_and_checks_updates(self):
        from excel_jump import open_csv_cell
        from test_trial31_excel_mock import Excel
        excel = Excel(self.csv, already_open=True)
        com = SimpleNamespace(GetActiveObject=lambda name: excel,
                              DispatchEx=lambda name: self.fail('Must reuse existing Excel'))
        pythoncom = SimpleNamespace(CoInitialize=lambda: None, CoUninitialize=lambda: None)
        stat = self.csv.stat()
        record = dict(file=str(self.csv), row=2, file_size=stat.st_size, file_mtime_ns=stat.st_mtime_ns)
        with patch.dict(sys.modules, {'pythoncom': pythoncom, 'win32com': SimpleNamespace(client=com),
                                    'win32com.client': com}), patch('excel_jump.sys.platform', 'win32'):
            result = open_csv_cell(record, 'J')
            self.assertEqual(result, (str(self.csv), 1, 'J2'))
            self.assertEqual(excel.wb.ws.selected, ['J2'])
            self.assertFalse(excel.wb.closed); self.assertFalse(excel.quit)
            with self.assertRaises(ValueError): open_csv_cell(record, 'XFE')
            self.csv.write_text('file changed')
            with self.assertRaisesRegex(RuntimeError, '再読込'): open_csv_cell(record, 'J')

    def editor_drop(self, save):
        def operate(dialog):
            events = self.dispatch(self.table(dialog).viewport())
            self.assertTrue(all(e.isAccepted() for e in events))
            QTest.qWait(600); APP.processEvents()
            self.assertEqual(self.table(dialog).rowCount(), 1)
            self.assertFalse(main.MAP.exists())
            if save: self.button(dialog, '社員情報を登録').click()
            else: dialog.reject()
        self.editor(operate)

    def test_editor_drop_then_cancel_does_not_save(self):
        self.editor_drop(False)
        self.assertFalse(main.MAP.exists())
        self.assertFalse(main.MAP.with_name('employee_contacts.json').exists())
        self.assertEqual(self.window.mapping, {})

    def test_editor_drop_commits_only_after_explicit_save(self):
        self.editor_drop(True)
        self.assertEqual(self.window.mapping, {'0001': 'S01'})
        self.assertEqual(email_for(load_contacts(main.MAP.with_name('employee_contacts.json')),
                                   '0001', 'S01'), 'one@example.com')


if __name__ == '__main__':
    unittest.main(verbosity=2)
