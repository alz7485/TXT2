# Trial41 最終検証

全31テストスクリプト合格。追加監査33件（エンジン11・設定8・起動/保存14）。

| スクリプト | 結果 | 秒 |
|---|---|---|
| test_120_performance.py | PASS | 10.33 |
| test_cache_tags.py | PASS | 0.91 |
| test_comparison_extensions.py | PASS | 2.34 |
| test_coverage_trial16.py | PASS | 8.85 |
| test_engine.py | PASS | 0.83 |
| test_excel_jump.py | PASS | 0.1 |
| test_final_validation.py | PASS | 0.52 |
| test_month_spacers_trial19.py | PASS | 1.11 |
| test_sample_integration.py | PASS | 0.77 |
| test_stable_read.py | PASS | 0.18 |
| test_trial15.py | PASS | 0.59 |
| test_trial21.py | PASS | 0.62 |
| test_trial22_static.py | PASS | 0.11 |
| test_trial23_static.py | PASS | 0.13 |
| test_trial24_integrity.py | PASS | 0.07 |
| test_trial27_toggle_static.py | PASS | 0.06 |
| test_trial28_input_review.py | PASS | 0.32 |
| test_trial29_completion.py | PASS | 0.14 |
| test_trial30_dynamic_failures.py | PASS | 0.79 |
| test_trial31_excel_mock.py | PASS | 0.35 |
| test_trial32_gui_print.py | PASS | 5.4 |
| test_trial32_sessions_mapping.py | PASS | 17.92 |
| test_trial33_ui.py | PASS | 28.48 |
| test_trial34_settings.py | PASS | 45.44 |
| test_trial38_audit.py | PASS | 24.84 |
| test_trial39_manual.py | PASS | 23.68 |
| test_trial40_completion.py | PASS | 9.93 |
| test_trial41_engine.py | PASS | 2.27 |
| test_trial41_runtime.py | PASS | 15.73 |
| test_trial41_settings.py | PASS | 3.61 |
| test_ui_static.py | PASS | 0.19 |

120人・3,600勤怠日・10,800照合：一致10,797／不一致3／要確認0。初回解析とキャッシュ再利用で同一。
実QThreadの中止/再開、古いsignalの無視、期間と列のスナップショット、設定拡張・未知JSON保持、印刷PDF・COMモック、明暗UIと最小サイズを検証。
26画面を更新した後、マニュアル10件（ボタン/F1・ローカル参照・画像・配布コピー・起動時に資料を読まない・未知列のJSON保存）を再実行し合格。

環境：Linux、Python3.12.14、PySide6 6.12.0、openpyxl3.1.5、Qtオフスクリーン。
Trial41の実ブラウザ描画の再検証は、環境のブラウザ実行制約のため未完了。目次/検索/画像拡大のJavaScriptとCSSはTrial40から変更していない。Trial40では実ブラウザ動作確認済み。今回のHTML参照・画像・18章の整合性は検証済み。
Windows11/Python3.11実起動、EXE作成、実Excel・実プリンタ・会社ネットワークは未検証。
