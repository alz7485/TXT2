# Trial 8 UI監査記録

## 実施済み

- `main.py`, `ui_theme.py`, `test_ui_static.py`, `engine.py` の構文検査。
- 既存 `test_engine.py`：時刻変換、XLSX日付抽出、CSV照合、欠落・重複ケースが通過。
- `test_sample_integration.py`：4 XLSX + 2 CSV、社員4人、120行、357一致・3不一致・0要確認。
- `test_ui_static.py`：3種類の表示モード、ID/氏名検索、印刷ボタン制御。
- `ui_theme.stylesheet`：ライト／ダーク両方とも置換可能、CSSに未展開の変数なし（スタブ実行）。

## 未実施／要Windows実機確認

- PySide6 6.xを使った画面表示（今回の実行環境ではインストールできない）。
- クリック・編集の実機テスト、色の見え方・拡大率125%/150%の視認性、印刷プレビュー。
- PyInstallerのonedirでのQtSvgモジュール取り込み。
- 約120 XLSXを実際の会社のストレージで読む所要時間。

## 引継ぎ

既存のJSON設定キー、`staff_mapping.json`、SQLiteキャッシュは維持しています。新規キーは `theme` と従来の `read_workers`（既定4）です。

従来の内部整合性・勤務体系の独自計算は今回の変更対象ではありません。CSVのM列「勤怠時間」とXLSXのT列「実働時間」の意味が一致することは実ファイルで確認してください。
