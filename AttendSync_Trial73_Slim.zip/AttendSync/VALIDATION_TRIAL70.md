# Trial70 検証記録

検証環境: Linux VM、Python 3.12、PySide6 6.12.0、openpyxl 3.1.5、`QT_QPA_PLATFORM=offscreen`。
Windows実機・実Outlook/Excel COM・EXE化は未検証です（従来Trialと同じ）。

## 追加テスト（test_trial70_report_filter.py、4件）
- 名前判定: 「日報報告_10001_佐藤花子.xlsx」「202610日報報告_10001.xlsx」は対象、「社員_10001.xlsx」「集計.xlsx」は対象外。選択関数は「日報報告あり→それだけ」「無し→全件」を確認。
- 混在フォルダ（日報報告_10001_確認社員.xlsx＋集計_10002.xlsx＋日別勤務情報20261019.csv）でReadWorkerを実行: 対象ファイル2件、読み込んだ社員は10001のみ（集計側の10002は読まれない）。
- 旧名フォルダ（社員_10002.xlsx＋日別勤務情報CSV、「日報報告」なし）では従来通り読み込めることを確認。

## 回帰
- 全58テストスクリプト（test_*.py 57本＋tests/test_audit_framework.py）、計374テストメソッドが成功（失敗0）。

## 残る未検証
- Windows実機での表示・操作、Excel COM連携、EXE化（Trial66から継続）。
- マニュアル（HTML/PDF）は未更新。
