"""Employee CSV registration, ID/email plans, and recoverable save."""
import csv,io,copy,os,json,base64,tempfile
from pathlib import Path
from collections import defaultdict
from openpyxl.utils.cell import column_index_from_string
from engine import save_json,load_json
from employee_contacts import validate_contacts,load_contacts,valid_email,merged_contacts
from mail_state import mail_lock

def source_key(path):return os.path.normcase(str(Path(path).expanduser().resolve()))

# Real file names used by the client's systems (confirmed by the user):
# the employee master CSV is スタッフ基本情報, the client attendance CSV is
# 日別勤務情報 followed by a date (e.g. 日別勤務情報20261019.csv), and the
# per-employee daily reports are Excel workbooks named 日報報告.
EMPLOYEE_INFORMATION_CSV_PREFIX='スタッフ基本情報'
DAILY_ATTENDANCE_CSV_PREFIX='日別勤務情報'
DAILY_REPORT_XLSX_MARK='日報報告'

def csv_name_role(path):
    """Classify a CSV by its real file name: 'linking' for the employee
    master (スタッフ基本情報…), 'attendance' for 日別勤務情報…, else ''."""
    stem=Path(path).stem
    if stem.startswith(EMPLOYEE_INFORMATION_CSV_PREFIX):return 'linking'
    if stem.startswith(DAILY_ATTENDANCE_CSV_PREFIX):return 'attendance'
    return ''

def is_employee_information_csv(path):return csv_name_role(path)=='linking'

def is_daily_report_workbook(path):return DAILY_REPORT_XLSX_MARK in Path(path).stem

def select_daily_report_workbooks(paths):
    """Pick the attendance workbooks among XLSX paths by name.

    The real workbooks are named 日報報告… (the name also carries the
    employee number and name, but the 日報報告 mark alone is the filter,
    per the user).  When at least one workbook carries the mark, only
    those are attendance workbooks and any other Excel file in the
    folder is ignored.  When none carries it (legacy or sample folders),
    every workbook stays a candidate, as before."""
    paths=list(paths)
    named=[p for p in paths if is_daily_report_workbook(p)]
    return named if named else paths

def load_information(path):
    return validate_information(load_contacts(path))

def validate_information(data):
    names=data.get('employee_names',{})
    if not isinstance(names,dict) or not all(isinstance(k,str) and isinstance(v,str) for k,v in names.items()):raise ValueError('社員名の保存形式が不正です。')
    candidates=data.get('staff_candidates',[])
    if not isinstance(candidates,list) or not all(isinstance(r,dict) and all(isinstance(r.get(k),str) for k in ('employee','staff','name')) for r in candidates):raise ValueError('スタッフID候補の保存形式が不正です。')
    sources=data.get('csv_sources',{})
    if not isinstance(sources,dict) or not all(isinstance(k,str) and v in ('linking','attendance') for k,v in sources.items()):raise ValueError('CSV用途の保存形式が不正です。')
    imports=data.get('employee_import_settings',{})
    if not isinstance(imports,dict):raise ValueError('社員情報CSVの読込設定が不正です。')
    if 'linking' in imports:
        profile=imports['linking']
        if not isinstance(profile,dict):raise ValueError('社員情報CSVの読込設定が不正です。')
        columns=profile.get('columns',{})
        if not isinstance(columns,dict) or not all(isinstance(columns.get(k,''),str) for k in ('staff','employee','name','email')):raise ValueError('社員情報CSVの列設定が不正です。')
        first=profile.get('first_row',2)
        if isinstance(first,bool) or not isinstance(first,int) or not 1<=first<=1048576:raise ValueError('社員情報CSVの開始行が不正です。')
        if profile.get('encoding','auto') not in ('auto','utf-8-sig','cp932'):raise ValueError('社員情報CSVの文字コード設定が不正です。')
    if not isinstance(data.get('employee_information_registered',False),bool):raise ValueError('社員情報の登録状態が不正です。')
    return data

def registration_is_ready(data,mapping):
    registered=data.get('employee_information_registered',any(role=='linking' for role in data.get('csv_sources',{}).values()))
    return bool(registered and any(str(sid).strip() for sid in mapping.values()))

def excluded_link_csv_paths(contacts_path):
    data=load_information(contacts_path)
    sources=data.get('csv_sources',{})
    if not isinstance(sources,dict):raise ValueError('CSV用途設定が不正です。社員情報を確認してください。')
    return {source_key(path) for path,role in sources.items() if role=='linking'}

def _restore(path,raw):
    if raw is None:
        if path.exists():path.unlink()
        return
    if path.exists() and path.read_bytes()==raw:return
    temporary=None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent,delete=False) as stream:
            temporary=Path(stream.name);stream.write(raw);stream.flush();os.fsync(stream.fileno())
        temporary.replace(path)
    finally:
        if temporary and temporary.exists():temporary.unlink()

def _recover(mapping_path,contacts_path):
    journal=Path(mapping_path).with_name('employee_save_transaction.json')
    if not journal.exists():return
    snapshots=load_json(journal,{})
    if not isinstance(snapshots,dict) or set(snapshots)!={'mapping','contacts'}:raise ValueError('社員情報の保存回復データが不正です。')
    # Validate every snapshot before restoring or deleting either live file.
    decoded={}
    try:
        for key,value in snapshots.items():
            if value is not None and not isinstance(value,str):raise ValueError('snapshot type')
            decoded[key]=None if value is None else base64.b64decode(value,validate=True)
            if decoded[key] is not None:
                data=json.loads(decoded[key].decode('utf-8-sig'))
                if key=='mapping':
                    if not isinstance(data,dict) or not all(isinstance(k,str) and k.strip() and isinstance(v,str) for k,v in data.items()):raise ValueError('mapping snapshot')
                else:validate_information(validate_contacts(data))
    except (ValueError,TypeError,UnicodeError) as exc:
        raise ValueError('社員情報の保存回復データが不正です。') from exc
    for key,path in [('contacts',Path(contacts_path)),('mapping',Path(mapping_path))]:_restore(path,decoded[key])
    journal.unlink()

def recover_employee_save(mapping_path,contacts_path):
    if Path(mapping_path).with_name('employee_save_transaction.json').exists():
        with mail_lock(Path(mapping_path).parent):_recover(mapping_path,contacts_path)

def commit_employee_information(mapping_path,contacts_path,mapping,contacts,writer=save_json):
    mapping_path=Path(mapping_path);contacts_path=Path(contacts_path);journal=mapping_path.with_name('employee_save_transaction.json')
    with mail_lock(mapping_path.parent):
        _recover(mapping_path,contacts_path)
        snapshots={key:base64.b64encode(path.read_bytes()).decode('ascii') if path.exists() else None for key,path in [('mapping',mapping_path),('contacts',contacts_path)]}
        save_json(journal,snapshots)
        try:
            writer(contacts_path,contacts);writer(mapping_path,mapping);journal.unlink()
        except Exception:
            _recover(mapping_path,contacts_path)
            raise

def read_information_csv(path,role,columns,first_row=2,encoding='auto'):
    if role!='linking':raise ValueError('IDとメールは社員情報CSVから登録してください。')
    required=('employee','staff','name','email')
    indices={}
    for key in ('employee','staff','name','email'):
        value=str(columns.get(key,'')).strip().upper()
        if not value:
            if key in required:raise ValueError(f'{key}の列を指定してください。')
            continue
        index=column_index_from_string(value)-1
        if not 0<=index<16384:raise ValueError('列はA～XFDで指定してください。')
        indices[key]=index
    if len(indices)!=len(set(indices.values())):raise ValueError('項目ごとに異なる列を指定してください。')
    if isinstance(first_row,bool) or not isinstance(first_row,int) or first_row<1:raise ValueError('開始行は1以上で指定してください。')
    raw=Path(path).read_bytes()
    if encoding=='auto':
        for enc in ('utf-8-sig','cp932'):
            try:text=raw.decode(enc);break
            except UnicodeDecodeError:continue
        else:raise ValueError('CSVはUTF-8またはCP932で保存してください。')
    else:text=raw.decode(encoding)
    rows=[]
    for line,record in enumerate(csv.reader(io.StringIO(text,newline='')),1):
        if line<first_row or not any(value.strip() for value in record):continue
        item={key:record[indices[key]].strip() if key in indices and indices[key]<len(record) else '' for key in ('employee','staff','name','email')}
        item['line']=line;rows.append(item)
    return rows

def plan_employee_import(rows,role,mapping,contacts):
    if role!='linking':raise ValueError('勤怠データからのID紐付けは行いません。')
    new_mapping=copy.deepcopy(mapping);data=copy.deepcopy(contacts);pairs=defaultdict(set);owners=defaultdict(set);emails=defaultdict(set)
    unique=[];seen=set();pair_names=defaultdict(set);assigned_owners=defaultdict(set)
    for employee,staff in new_mapping.items():
        if str(staff).strip():assigned_owners[str(staff).strip()].add(employee)
    for row in rows:
        signature=tuple(row.get(key,'') for key in ('employee','staff','name','email'))
        if signature in seen:continue
        seen.add(signature);unique.append(row)
        eid,sid=row['employee'],row['staff']
        if eid and sid:pairs[eid].add(sid);owners[sid].add(eid)
        if eid and sid and row['email']:emails[eid,sid].add(row['email'])
        if row['name']:pair_names[eid,sid].add(row['name'])
    results=[];names=data.setdefault('employee_names',{});candidates={r['staff']:dict(r) for r in data.get('staff_candidates',[]) if r.get('staff')}
    for row in unique:
        item=dict(row);eid,sid=row['employee'],row['staff'];status='';linked=False
        if sid:candidates[sid]={key:row[key] for key in ('employee','staff','name')}
        if not sid:status='スタッフID空欄'
        elif not eid:status='社員ID空欄・候補として保持'
        elif len(pairs[eid])>1 or len(owners[sid])>1:status='CSV内のID重複・競合'
        elif eid in new_mapping and str(new_mapping[eid]).strip() and str(new_mapping[eid]).strip()!=sid:status='既存スタッフIDと不一致'
        elif assigned_owners[sid]-{eid}:status='スタッフIDが別社員へ割当済み'
        else:
            new_mapping[eid]=sid;assigned_owners[sid].add(eid);linked=True;status='ID一致' if mapping.get(eid)==sid else 'IDを紐付け'
        if eid and row['name']:
            if linked and len(pair_names[eid,sid])==1:names[eid]=row['name']
            else:names.setdefault(eid,row['name'])
        item['employee']=eid;item['matched']=False
        if linked:
            if len(emails[eid,sid])>1:status+='・メール競合'
            elif valid_email(row['email']):item['matched']=True;status+='・メール一致'
            else:status+='・メール空欄/不正'
        item['status']=status;item['id_matched']=linked;results.append(item)
    data=merged_contacts(data,results,data.get('import_settings',{}))
    data['employee_names']=names;data['staff_candidates']=list(candidates.values())
    if any(r['id_matched'] for r in results):data['employee_information_registered']=True
    return new_mapping,data,results

# Trial68: the former separate import dialog (show_employee_import_dialog) was
# removed; CSV import now lives inside the 社員情報 editor in main.py, which
# uses read_information_csv + plan_employee_import from this module directly.

def validate_information_rows(selections):
    result={};seen=set()
    for i,(eid,sid,name,email) in enumerate(selections):
        if not eid and not sid and not email:continue
        if not eid:raise ValueError(f'{i+1}行目の社員IDが空欄です。')
        if eid in seen:raise ValueError('社員IDの重複：'+eid)
        seen.add(eid)
        if email and not sid:raise ValueError('メールを紐付けるスタッフIDを指定してください：'+eid)
        if sid:result[eid]=sid
    ids=list(result.values())
    if len(ids)!=len(set(ids)):raise ValueError('同じスタッフIDが複数の社員に割り当てられています。')
    return result

def contacts_for_mapping(contacts,mapping):
    data=copy.deepcopy(contacts);active=[];candidates={r['email']:dict(r) for r in data.get('unlinked_contacts',[])}
    for row in data['contacts']:
        if mapping.get(row['employee'])==row['staff']:active.append(row)
        elif valid_email(row['email']):candidates[row['email']]=row
    used={r['email'] for r in active};data['contacts']=active;data['unlinked_contacts']=[r for email,r in candidates.items() if email not in used]
    return data
