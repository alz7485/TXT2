# Trial71 検証記録

検証環境: Linux VM、Python 3.12、PySide6 6.12.0、openpyxl 3.1.5、`QT_QPA_PLATFORM=offscreen`。
Windows実機・実Outlook/Excel COM・EXE化は未検証です（従来Trialと同じ）。

## 追加テスト（test_trial71_settings_moves.py、5件）
- ヘッダーにマニュアルボタンが無く、設定ダイアログの「マニュアルを開く」から従来通りマニュアルが開ける。
- 設定の読み込み設定に「社員情報 CSV」ページが増え、列（初期値A/B/C/J）を変更して保存すると `employee_import_columns` に反映される。不正な列記号では保存できない（JSON検証でも拒否）。
- 設定に列が無い場合、前回社員情報画面で使った列が設定画面へ初期値として引き継がれる。
- 社員情報画面に列フィールドが無く、設定で変えた列（メール=A列など）でCSVが正しく読み込まれる。

## 既存テストの追随
- test_trial33_ui（ヘッダーの操作対象一覧からマニュアルボタンを除外）、test_trial34_settings（読み込み設定のページ構成）、test_trial39_manual（ボタン位置の移設）、test_trial58_csv_drop（ドロップ対象・保存済み列・設定変更時の元CSVナビ無効化）、test_trial68_editor_guide（統合画面の構造）を新しい配置に合わせて更新。
- 影響範囲の8スイート・86件を先行実行し全て成功。全59テストスクリプト（test_*.py 58本＋tests/test_audit_framework.py）、計379テストメソッドが成功（失敗0）。設定画面のキャプチャでも、社員情報CSVページ（列A/B/C/J）とフッターの「マニュアルを開く」を目視確認しました。

## 残る未検証
- Windows実機での表示・操作、Excel COM連携、EXE化（Trial66から継続）。
- マニュアル（HTML/PDF）は未更新（ボタン位置・列変更の場所の説明が古いまま）。
