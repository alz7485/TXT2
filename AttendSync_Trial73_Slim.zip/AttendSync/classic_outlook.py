"""Read account identities from an already running classic Outlook on Windows."""
import sys
from contextlib import contextmanager, nullcontext
from employee_contacts import valid_email


def _get(value,name):
    try:return getattr(value,name)
    except Exception:return None


def _text(value):
    return value.strip() if isinstance(value,str) else ''


def _account_identity(account):
    user=_get(account,'CurrentUser')
    name=_text(_get(user,'Name')) or _text(_get(account,'DisplayName'))
    address=_text(_get(account,'SmtpAddress'))
    if not valid_email(address):
        entry=_get(user,'AddressEntry')
        try:exchange_user=entry.GetExchangeUser()
        except Exception:exchange_user=None
        address=_text(_get(exchange_user,'PrimarySmtpAddress'))
        if not valid_email(address):
            accessor=_get(entry,'PropertyAccessor')
            for tag in ('0x39FE001F','0x39FE001E'):
                try:address=_text(accessor.GetProperty('http://schemas.microsoft.com/mapi/proptag/'+tag))
                except Exception:continue
                if valid_email(address):break
    if not valid_email(address):return None
    return {'account':address,'sender_name':' '.join(name.split())}


@contextmanager
def running_outlook():
    """Attach to the running classic Outlook, initialize COM on this thread."""
    if sys.platform!='win32':raise RuntimeError('Outlook連携はWindowsのクラシックOutlookで利用できます。')
    try:
        import pythoncom
        import win32com.client
    except ImportError as exc:
        raise RuntimeError('Outlook連携にはpywin32が必要です。requirements-build.txtの依存関係をインストールしてください。') from exc
    pythoncom.CoInitialize();outlook=None
    try:
        try:outlook=win32com.client.GetActiveObject('Outlook.Application')
        except Exception as exc:
            raise RuntimeError('起動中のクラシックOutlookを取得できません。Outlookを開き、このツールと同じWindowsユーザー・権限で実行してください。') from exc
        yield outlook
    finally:
        outlook=None
        pythoncom.CoUninitialize()


def _accounts(outlook):
    try:
        collection=outlook.Session.Accounts;found=[]
        for index in range(1,collection.Count+1):
            try:
                account=collection.Item(index);identity=_account_identity(account)
            except Exception:continue
            if identity:found.append((account,identity))
        return found
    except Exception as exc:
        raise RuntimeError('Outlookのアカウント情報を取得できません。Outlookの起動状態を確認してください。') from exc


def running_outlook_accounts():
    """No launch, logon, mail creation or send. Return plain identity strings."""
    with running_outlook() as outlook:
        found=[];seen=set()
        for _,identity in _accounts(outlook):
            key=identity['account'].casefold()
            if key not in seen:seen.add(key);found.append(identity)
        if not found:raise RuntimeError('Outlookから有効なメールアドレスを取得できませんでした。接続するアカウントを手入力してください。')
        return found


def _check_sender(message,address):
    identity=_account_identity(message.SendUsingAccount)
    if not identity or identity['account'].casefold()!=address.casefold():
        raise RuntimeError('Outlookに指定した送信元を設定できません。送信を中止しました。')


def _plan_keys(settings,plan):
    """Current and historical ledger keys for one plan, newest first."""
    import json,hashlib
    from mail_state import mail_payload,mail_identity
    expected=settings['account']
    payload=mail_payload(plan)
    actual_payload=mail_payload({**plan,'recipient_names':{}})
    identity=mail_identity(plan)
    def digest(parts):return hashlib.sha256(json.dumps(parts,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
    return [digest([expected.casefold(),'classic_outlook_v3',settings['auto_send'],plan['employee'],plan['staff'],identity]),
            digest([expected.casefold(),'classic_outlook_v2',settings['auto_send'],plan['employee'],plan['staff'],actual_payload]),
            digest([expected.casefold(),'classic_outlook',settings['auto_send'],plan['employee'],plan['staff'],payload]),
            # Recognize the previous Graph implementation's history during migration.
            digest([expected.casefold(),settings['client_id'],settings['tenant_id'],settings['auto_send'],plan['employee'],plan['staff'],payload])]


def _process_classic_plans(plans,settings,data_dir,outlook):
    import json,hashlib
    from pathlib import Path
    from engine import load_json,save_json
    from mail_state import mail_identity
    expected=settings['account']
    matches=[account for account,identity in _accounts(outlook) if identity['account'].casefold()==expected.casefold()]
    if len(matches)!=1:raise ValueError('設定した送信元アカウントをOutlookで一意に確認できません。「設定 → メール」で起動中のOutlookから取得し直してください。')
    account=matches[0]
    path=Path(data_dir)/'mail_processing_history.json';ledger=load_json(path,{})
    if not isinstance(ledger,dict):raise ValueError('メール処理履歴が不正です。Outlookの下書き・送信済みを確認してください。')
    outcomes=[]
    for index,plan in enumerate(plans):
        identity=mail_identity(plan)
        keys=_plan_keys(settings,plan);key=keys[0]
        previous_key=next((candidate for candidate in keys if candidate in ledger),None)
        previous=ledger[previous_key] if previous_key is not None else None
        status=previous.get('status','') if isinstance(previous,dict) else ''
        if previous_key is not None and status=='failed':
            # A recorded failure from before any draft was saved: retrying
            # cannot duplicate anything, so the entry does not block.
            previous_key=None;previous=None;status=''
        if previous_key is not None:
            if previous_key!=key:
                ledger[key]=previous.copy() if isinstance(previous,dict) else previous
                save_json(path,ledger)
            if status=='sent':text='同内容の送信処理済み'
            elif status=='draft':text='同内容の下書き保存済み'
            elif status=='created' and not previous.get('auto_send'):
                # The draft was saved and its EntryID recorded; only the
                # final status write was lost.  Heal the record.
                ledger[key]['status']='draft'
                try:save_json(path,ledger)
                except Exception:pass
                text='同内容の下書き保存済み'
            elif status=='created':text='同内容の下書き保存済み（送信は未確認・再実行を停止）'
            else:text='処理状況要確認（再実行を停止）'
            outcomes.append({'employee':plan['employee'],'status':text})
            continue
        record={'employee':plan['employee'],'staff':plan['staff'],'status':'creating','backend':'classic_outlook',
                'identity_hash':hashlib.sha256(json.dumps(identity,ensure_ascii=False,sort_keys=True).encode()).hexdigest(),
                'account':expected.casefold(),'auto_send':settings['auto_send']};ledger[key]=record
        message=None;identifier='';stage='before_save'
        try:
            save_json(path,ledger) # Persist before Outlook could create a draft.
            drafts=account.DeliveryStore.GetDefaultFolder(16) # olFolderDrafts for this account
            message=drafts.Items.Add('IPM.Note');message.SendUsingAccount=account
            _check_sender(message,expected)
            message.Subject=plan['subject'];message.Body=plan['body']
            for kind,addresses in ((1,plan['to']),(2,plan['cc'])):
                for address in addresses:
                    recipient=message.Recipients.Add(address);recipient.Type=kind
            if not message.Recipients.ResolveAll():raise RuntimeError('Outlookで宛先を解決できません。下書き・社員メールアドレスを確認してください。')
            stage='save_attempted'
            message.Save();identifier=_text(message.EntryID)
            if not identifier:raise RuntimeError('下書きの保存IDを確認できません。Outlookの下書きを確認してください。')
            stage='saved'
            _check_sender(message,expected)
            record.update(id=identifier,status='created');save_json(path,ledger)
            if settings['auto_send']:
                record['status']='sending';save_json(path,ledger)
                stage='sending'
                message.Send()
                stage='sent'
                record['status']='sent';status='送信要求済み'
            else:record['status']='draft';status='下書き保存済み'
            save_json(path,ledger);outcomes.append({'employee':plan['employee'],'status':status})
        except Exception as exc:
            # Record how far processing got, so a re-run can tell a safe
            # retry (nothing was saved) from an unknown outcome.
            if stage=='before_save':
                record['status']='failed';record['error']=str(exc)
                try:save_json(path,ledger)
                except Exception:pass
            elif stage=='saved':
                record.update(id=identifier,status='created');record['error']=str(exc)
                try:save_json(path,ledger)
                except Exception:pass
            elif stage=='save_attempted':
                record['error']=str(exc)
                try:save_json(path,ledger)
                except Exception:pass
            outcomes.append({'employee':plan['employee'],'status':'処理失敗・Outlookを確認','error':str(exc)})
            outcomes.extend({'employee':p['employee'],'status':'未処理'} for p in plans[index+1:]);break
        finally:message=None
    return outcomes


def reset_mail_history(plans,settings,data_dir):
    """Forget stuck mail history entries so creation can be tried again.

    Only entries that never reached a confirmed end state are removed:
    records marked sent, draft or created (a saved draft with an EntryID)
    are kept, so a reset can never make the tool duplicate a completed
    notice.  The caller is responsible for having the user confirm in
    Outlook first that no matching draft or sent mail exists.
    """
    from pathlib import Path
    from engine import load_json,save_json
    from outlook_mail import validate_mail_settings
    from mail_state import mail_lock
    settings=validate_mail_settings(settings)
    removed=0
    with mail_lock(data_dir):
        path=Path(data_dir)/'mail_processing_history.json';ledger=load_json(path,{})
        if not isinstance(ledger,dict):raise ValueError('メール処理履歴が不正です。Outlookの下書き・送信済みを確認してください。')
        for plan in plans:
            for candidate in _plan_keys(settings,plan):
                record=ledger.get(candidate)
                if isinstance(record,dict) and record.get('status') in ('sent','draft','created'):continue
                if candidate in ledger:del ledger[candidate];removed+=1
        if removed:save_json(path,ledger)
    return removed


def process_classic_plans(plans,settings,data_dir,outlook=None):
    """Save drafts or request sending through the selected Outlook account only."""
    from outlook_mail import validate_mail_settings
    from mail_state import mail_lock
    settings=validate_mail_settings(settings)
    if not valid_email(settings['account']):raise ValueError('設定 → メールで送信元アカウントを指定してください。「起動中のOutlookから取得」で設定できます。')
    for plan in plans:
        if plan.get('problem') or not isinstance(plan.get('to'),list) or not plan['to']:raise ValueError('宛先未登録の社員が含まれています。')
        if not isinstance(plan.get('cc'),list) or any(not isinstance(address,str) or not valid_email(address) for address in plan['to']+plan['cc']):raise ValueError('宛先の形式が不正です。')
        if not isinstance(plan.get('subject'),str) or not isinstance(plan.get('body'),str):raise ValueError('件名と本文を確認してください。')
        if '\r' in plan['subject'] or '\n' in plan['subject']:raise ValueError('件名は1行で指定してください。')
    with mail_lock(data_dir):
        with (running_outlook() if outlook is None else nullcontext(outlook)) as application:
            return _process_classic_plans(plans,settings,data_dir,application)
