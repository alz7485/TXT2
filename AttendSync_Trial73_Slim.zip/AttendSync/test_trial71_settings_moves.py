"""Trial71: the manual button and the employee-import columns move into 設定.

- The header no longer carries a manual button; the settings dialog has a
  マニュアルを開く button instead (F1 still works).
- The スタッフ基本情報 column mapping (staff/employee/name/email) is edited
  in 設定 → 読み込み設定 → 社員情報 CSV and stored as
  cfg['employee_import_columns']; the 社員情報 editor no longer shows the
  column fields and honours the settings values (falling back to the
  columns last used in the editor, then A/B/C/J).
"""
from __future__ import annotations

import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

try:
    from PySide6.QtCore import QTimer
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QApplication, QLineEdit, QPushButton, QTableWidget
except ModuleNotFoundError as exc:
    if exc.name != 'PySide6':
        raise
    QT_AVAILABLE = False
else:
    QT_AVAILABLE = True
    import runtime_paths
    _import_directory = tempfile.TemporaryDirectory(prefix='attendsync-trial71-import-')
    with patch.object(runtime_paths, 'get_data_dir', return_value=Path(_import_directory.name)):
        import main
    import manual
    from engine import save_json
    from settings_dialog import SettingsDialog, SettingsError


@unittest.skipUnless(QT_AVAILABLE, 'PySide6 is required for real Qt checks')
class SettingsMoves(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
        cls.app.setQuitOnLastWindowClosed(False)

    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(prefix='attendsync-trial71-test-')
        self.addCleanup(self.directory.cleanup)
        self.data_dir = Path(self.directory.name)
        self.paths_patch = patch.multiple(
            main, DATA_DIR=self.data_dir, CONFIG=self.data_dir / 'settings.json',
            MAP=self.data_dir / 'staff_mapping.json', DB=self.data_dir / 'attendance_cache.sqlite3',
        )
        self.paths_patch.start()
        self.addCleanup(self.paths_patch.stop)
        self.window = None
        self.addCleanup(self.close_window)

    def close_window(self):
        if self.window is not None:
            self.window.close()
            self.window.deleteLater()
            self.app.processEvents()

    def make_window(self):
        with patch.object(main, 'current_attendance_month', return_value=(2026, 10)):
            self.window = main.Window()
        self.window.show()
        self.app.processEvents()
        return self.window

    def test_manual_button_lives_in_settings_not_header(self):
        window = self.make_window()
        self.assertFalse(hasattr(window, 'btn_manual'))
        dialog = SettingsDialog(window, window.cfg)
        try:
            button = dialog.findChild(QPushButton, 'settingsOpenManual')
            self.assertIsNotNone(button)
            with patch.object(manual, 'open_manual', return_value=True) as opener:
                button.click()
            opener.assert_called_once_with(dialog)
        finally:
            dialog.close()

    def test_employee_columns_round_trip_through_settings(self):
        window = self.make_window()
        dialog = SettingsDialog(window, window.cfg)
        try:
            self.assertEqual(list(dialog.read_navigation), ['xlsx', 'csv', 'linking'])
            fields = {key: dialog.findChild(QLineEdit, 'settingsEmployeeColumn_' + key)
                      for key in ('staff', 'employee', 'name', 'email')}
            self.assertEqual([fields[k].text() for k in ('staff', 'employee', 'name', 'email')],
                             ['A', 'B', 'C', 'J'])
            fields['email'].setText('K')
            dialog.accept()
            self.assertEqual(dialog.value['employee_import_columns'],
                             {'staff': 'A', 'employee': 'B', 'name': 'C', 'email': 'K'})
        finally:
            dialog.close()

    def test_employee_columns_are_validated(self):
        window = self.make_window()
        dialog = SettingsDialog(window, window.cfg)
        try:
            dialog.findChild(QLineEdit, 'settingsEmployeeColumn_staff').setText('1')
            dialog.accept()
            self.assertEqual(dialog.result(), 0)  # not accepted
        finally:
            dialog.close()
        with self.assertRaises(SettingsError):
            SettingsDialog.validate_json_config({**window.cfg, 'employee_import_columns': {'staff': 'A'}})

    def test_settings_seeded_from_last_used_editor_columns(self):
        window = self.make_window()
        save_json(main.MAP.with_name('employee_contacts.json'),
                  {'version': 1, 'contacts': [], 'employee_import_settings':
                   {'linking': {'columns': {'staff': 'A', 'employee': 'B', 'name': 'C', 'email': 'K'}}}})
        captured = {}

        class StubDialog:
            def __init__(self, parent, cfg):
                captured.update(cfg)
                self.restart_guides_requested = False

            def exec(self):
                return False

            def deleteLater(self):
                pass

        with patch.object(main, 'SettingsDialog', StubDialog):
            window.edit_settings()
        self.assertEqual(captured['employee_import_columns']['email'], 'K')

    def test_editor_honours_settings_columns(self):
        window = self.make_window()
        window.cfg['employee_import_columns'] = {'staff': 'C', 'employee': 'D', 'name': 'B', 'email': 'A'}
        csv_path = self.data_dir / 'スタッフ基本情報.csv'
        csv_path.write_text('メール,氏名,スタッフID,社員ID\none@example.com,確認社員,S01,0001\n', encoding='utf-8-sig')
        errors = []

        def operate():
            dialog = self.app.activeModalWidget()
            try:
                for key in ('staff', 'employee', 'name', 'email'):
                    self.assertIsNone(dialog.findChild(QLineEdit, 'informationColumn_' + key))
                dialog.findChild(QLineEdit, 'informationCsvPath').setText(str(csv_path))
                QTest.qWait(700)
                self.app.processEvents()
                table = dialog.findChild(QTableWidget, 'employeeIdTable')
                self.assertEqual(table.rowCount(), 1)
                self.assertEqual(table.item(0, 0).text(), '0001')
                self.assertEqual(main.selected_staff_id(table.cellWidget(0, 2)), 'S01')
            except Exception as exc:
                errors.append(exc)
            finally:
                dialog.reject()

        with patch.object(window, 'run_read'):
            QTimer.singleShot(0, operate)
            window.edit_map()
            self.app.processEvents()
        self.assertFalse(errors, errors)


if __name__ == '__main__':
    unittest.main(verbosity=2)
