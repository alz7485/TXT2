# Trial39 最終検証

全27テストスクリプトを実行し全合格。最終の列追加画像を補足後、マニュアル関連10件を再実行して合格。監査16件、設定27件、UI9件を含む。

| スクリプト | 結果 | 秒 |
|---|---|---|
| test_120_performance.py | PASS | 1.55 |
| test_cache_tags.py | PASS | 0.09 |
| test_comparison_extensions.py | PASS | 0.22 |
| test_coverage_trial16.py | PASS | 1.2 |
| test_engine.py | PASS | 0.12 |
| test_excel_jump.py | PASS | 0.02 |
| test_final_validation.py | PASS | 0.1 |
| test_month_spacers_trial19.py | PASS | 0.13 |
| test_sample_integration.py | PASS | 0.21 |
| test_stable_read.py | PASS | 0.02 |
| test_trial15.py | PASS | 0.11 |
| test_trial21.py | PASS | 0.12 |
| test_trial22_static.py | PASS | 0.06 |
| test_trial23_static.py | PASS | 0.02 |
| test_trial24_integrity.py | PASS | 0.02 |
| test_trial27_toggle_static.py | PASS | 0.02 |
| test_trial28_input_review.py | PASS | 0.1 |
| test_trial29_completion.py | PASS | 0.04 |
| test_trial30_dynamic_failures.py | PASS | 0.21 |
| test_trial31_excel_mock.py | PASS | 0.1 |
| test_trial32_gui_print.py | PASS | 1.39 |
| test_trial32_sessions_mapping.py | PASS | 7.03 |
| test_trial33_ui.py | PASS | 4.78 |
| test_trial34_settings.py | PASS | 6.73 |
| test_trial38_audit.py | PASS | 3.92 |
| test_trial39_manual.py | PASS | 4.28 |
| test_ui_static.py | PASS | 0.04 |

起動6プロセス測定はSTARTUP_TRIAL39.md。起動時の入力解析・manualモジュールの読み込みがないことを実プロセスで確認。ボタン/F1とローカルURLは実Qtで、既定ブラウザへの起動要求だけをモックして検証。
Manual全画像・目次の参照整合性、Windows配布先への同梱を検証。QtWebEngineの実ブラウザでHTML描画・検索・0件時・画像拡大を検証。APP実行依存にはQtWebEngineを追加していない。
最小1040×690のメイン画面で操作マニュアルを含む操作が収まり、明暗のUIテストも合格。120人照合は一致10,797／不一致3／要確認0を維持。
Windows実機・EXE起動・実Excel・実プリンタ・会社ネットワーク・Python3.11実起動は未検証。
