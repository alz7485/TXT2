"""Trial69: real file names drive the CSV classification.

The client's files are named スタッフ基本情報… (employee master CSV),
日別勤務情報<YYYYMMDD>.csv (client daily attendance CSV) and 日報報告…
(per-employee Excel daily reports).  A スタッフ基本情報 CSV sitting in the
attendance folder must never be parsed as attendance — by name, even if
it was never imported through the employee editor — and the employee
editor pre-loads it automatically when it is in the target folder.
"""
from __future__ import annotations

import os
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

from employee_information import csv_name_role, is_employee_information_csv

try:
    from PySide6.QtCore import QTimer
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QApplication, QLineEdit, QTableWidget, QWidget
except ModuleNotFoundError as exc:
    if exc.name != 'PySide6':
        raise
    QT_AVAILABLE = False
else:
    QT_AVAILABLE = True
    import runtime_paths
    _import_directory = tempfile.TemporaryDirectory(prefix='attendsync-trial69-import-')
    with patch.object(runtime_paths, 'get_data_dir', return_value=Path(_import_directory.name)):
        import main
    import engine
    from engine import DEFAULT, save_json

SAMPLES = Path(__file__).parent / 'SampleData'
EMPLOYEE_CSV = ('スタッフID,派遣元スタッフコード,氏名,D,E,F,G,H,I,メール\n'
                'S01,0001,確認社員,,,,,,,one@example.com\n')


class CsvNameRoleLogic(unittest.TestCase):
    def test_name_roles(self):
        self.assertEqual(csv_name_role('スタッフ基本情報.csv'), 'linking')
        self.assertEqual(csv_name_role('スタッフ基本情報_2026.csv'), 'linking')
        self.assertEqual(csv_name_role('日別勤務情報20261019.csv'), 'attendance')
        self.assertEqual(csv_name_role('日別勤務情報.csv'), 'attendance')
        self.assertEqual(csv_name_role('日報報告_10001.xlsx'), '')
        self.assertEqual(csv_name_role('other.csv'), '')
        self.assertTrue(is_employee_information_csv(Path('スタッフ基本情報.csv')))
        self.assertFalse(is_employee_information_csv(Path('日別勤務情報20261019.csv')))


@unittest.skipUnless(QT_AVAILABLE, 'PySide6 is required for real Qt checks')
class CsvNameFlow(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
        cls.app.setQuitOnLastWindowClosed(False)

    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(prefix='attendsync-trial69-test-')
        self.addCleanup(self.directory.cleanup)
        self.data_dir = Path(self.directory.name)
        self.paths_patch = patch.multiple(
            main, DATA_DIR=self.data_dir, CONFIG=self.data_dir / 'settings.json',
            MAP=self.data_dir / 'staff_mapping.json', DB=self.data_dir / 'attendance_cache.sqlite3',
        )
        self.paths_patch.start()
        self.addCleanup(self.paths_patch.stop)
        self.window = None
        self.addCleanup(self.close_window)
        self.folder = self.data_dir / 'input'
        self.folder.mkdir()
        shutil.copy(SAMPLES / '社員_10001.xlsx', self.folder / '日報報告_10001.xlsx')
        shutil.copy(SAMPLES / '派遣先_202610.csv', self.folder / '日別勤務情報20261019.csv')
        (self.folder / 'スタッフ基本情報.csv').write_text(EMPLOYEE_CSV, encoding='utf-8-sig')

    def close_window(self):
        if self.window is not None:
            self.window.close()
            self.window.deleteLater()
            self.app.processEvents()

    def make_window(self):
        with patch.object(main, 'current_attendance_month', return_value=(2026, 10)):
            self.window = main.Window()
        self.window.show()
        self.app.processEvents()
        return self.window

    def test_worker_skips_staff_master_by_name(self):
        results = []
        worker = main.ReadWorker(self.folder, DEFAULT)
        worker.result.connect(lambda *args: results.append(args))
        worker.run()
        self.assertEqual(len(results), 1)
        xdata, cdata, issues, stats = results[0]
        self.assertEqual(stats['files_found'], 2)  # 日報報告 XLSX + 日別勤務情報 CSV only
        self.assertEqual(len(xdata), 1)
        self.assertTrue(cdata)
        self.assertFalse(any('スタッフ基本情報' in text for text in issues))

    def test_missing_daily_csv_reports_shortage_and_names_the_files(self):
        (self.folder / '日別勤務情報20261019.csv').unlink()
        window = self.make_window()
        window.mapping = {'10001': 'S001'}
        save_json(main.MAP.with_name('employee_contacts.json'),
                  {'version': 1, 'contacts': [], 'import_settings': {}, 'employee_information_registered': True})
        window.path.setText(str(self.folder))
        warnings = []
        with patch.object(main.QMessageBox, 'warning', side_effect=lambda *a: warnings.append(a)), \
             patch.object(main, 'ReadWorker') as worker:
            window.run_read()
        self.assertEqual(len(warnings), 1)
        self.assertEqual(warnings[0][1], '入力ファイル不足')
        self.assertIn('CSV 0件', warnings[0][2])
        self.assertIn('日別勤務情報', warnings[0][2])
        self.assertIn('スタッフ基本情報', warnings[0][2])
        worker.assert_not_called()

    def test_editor_preloads_staff_master_from_target_folder(self):
        window = self.make_window()
        window.path.setText(str(self.folder))
        errors = []

        def operate():
            dialog = self.app.activeModalWidget()
            try:
                QTest.qWait(800)
                self.app.processEvents()
                field = dialog.findChild(QLineEdit, 'informationCsvPath')
                self.assertTrue(field.text().endswith('スタッフ基本情報.csv'), field.text())
                table = dialog.findChild(QTableWidget, 'employeeIdTable')
                self.assertEqual(table.rowCount(), 1)
                self.assertEqual(table.item(0, 0).text(), '0001')
                # The per-screen guide skips ahead to the review step because
                # the import was already reflected when it appeared.
                panel = dialog.findChild(QWidget, 'guidePanel')
                self.assertEqual(panel._manager.current_id, 'review')
            except Exception as exc:
                errors.append(exc)
            finally:
                dialog.reject()

        with patch.object(window, 'run_read'):
            QTimer.singleShot(0, operate)
            window.edit_map()
            self.app.processEvents()
        self.assertFalse(errors, errors)


if __name__ == '__main__':
    unittest.main(verbosity=2)
