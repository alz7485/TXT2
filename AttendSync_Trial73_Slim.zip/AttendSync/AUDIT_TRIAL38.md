# Trial38 監査・修正報告

2026-10-09 UTC。Trial37の既存25スクリプトは全合格だったが、追加の実Qt操作・実XLSX/CSV監査で未検出の問題を再現した。再現記録を同梱し、修正後に計26スクリプトを全実行して全合格。最後の印刷幅修正後は監査・GUI/印刷・UIの3本を再実行して合格。

| ID | 問題・具体的な再現 | 修正 | 回帰テスト |
|---|---|---|---|
| A01 | 読み込み中に照合条件を追加すると、旧列データに新条件を適用して未抽出の空欄同士を一致と判定。4人サンプルが360件から480件へ増える | 読み込みWorkerの設定で照合し、結果にも保持。次回設定とは独立 | completion_reconciles_with_worker_settings_snapshot |
| A02 | 2026年10月度の結果を残して2027年1月度を選択すると、印刷見出しだけ2027年1月度になる | 印刷と件数欄に照合済み年月度を使用 | print_uses_completed_period_after_controls_change |
| A03 | 結果を読んだ後で実働列をT→Vに変更すると、旧結果のExcelジャンプがVへ移動。詳細も次回用の照合名称を使用する | 詳細・Excel列は結果の設定を使用 | excel_jump_uses_columns_from_completed_read / detail_uses_completed_comparisons_not_pending_settings |
| A04 | 詳細から表示選択を保存すると、未知の表示キーplugin|futureが消える | 未知キーを保持し、現在の設定へ表示選択だけを反映 | detail_visibility_save_preserves_unknown_keys_and_pending_settings |
| A05 | OFFの既存休憩条件とONの追加条件が同じ対応項目の場合、詳細でOFF側の名称・比較形式を使用する | ONの条件を優先。開いた結果の条件に合わせて表示し、改名済み表示名も保持 | enabled_comparison_controls_detail_label_and_format / renamed_source_label_survives_selection_of_comparison_result |
| A06 | 同じ対応項目に一致・不一致の両条件がある場合、先頭の一致だけを見て不一致の強調が消える | 対応する結果を確認し、不一致を強調・印刷へ反映 | multiple_enabled_comparisons_do_not_hide_mismatch |
| A07 | XLSX基本情報に氏名があっても勤怠行が空の場合、社員ID管理の氏名が空になる | info.nameを優先して表示 | mapping_displays_name_from_info_for_employee_without_records |
| A08 | 読み込み前の検証がXFE列・上限超のセル/行・日/スタッフID未設定を通す | ExcelのXFD/1,048,576上限と必須列、有効照合元を確認 | runtime_rejects_layout_outside_excel_bounds_and_missing_required_keys |
| A09 | 実XLSXの[h]:mm形式26時間がtimedeltaの文字列になり、CSV 26:00と比べて要確認になる | Excel日数の数値へ正規化。JSONキャッシュでも時間長を維持。解析版更新 | real_excel_duration_over_24_hours_survives_cache_and_comparison |
| A10 | 設定保存でPermissionErrorが起きると警告なく例外、メモリ設定だけ変更される | 保存成功後に設定を更新。失敗は警告し以前の設定を維持 | failed_settings_write_does_not_replace_active_config / failed_detail_write_does_not_change_visibility_or_pending_config |

| A11 | 印刷表が用紙幅の一部しか使わず、横方向に大きな余白が残る | 一覧・詳細の表を用紙幅100%へ指定。Qtの実文書の表幅も検証 | list_and_detail_print_tables_use_available_paper_width |

追加で、読み込み中止後の結果・設定保持と、詳細表示null（全表示）の互換性を検証。監査回帰16件。テスト名はtest_trial38_audit.pyのメソッド名からtest_を省略したもの。

## 設定・画面・拡張性

- 読み込み速度 → 読み込み範囲 → 基本情報 → 日別列 → 月度設定の配置を維持。
- 設定の最小780×580で速度・範囲・保存・キャンセルを操作可能。メイン1040×690、明暗、空画面、検索・フィルタ、印刷表示選択も実Qtテストで確認。19枚の現状画像をPreviewへ同梱。Windowsではフォントなどが異なる場合がある。
- 追加列・名称変更・照合対応変更・未知属性の保存互換性は設定27テストと追加監査で確認。詳細表示と照合ON/OFFは独立。
- 旧userdataを引き継げる。解析キャッシュの版更新により初回は再解析するが、設定・ID紐付けを削除しない。

## 実行検証

既存25本＋監査1本＝26スクリプト全合格。監査16件、設定27件、UI9件、実QtのPDF/印刷失敗・中止再実行・古いシグナル無視、COMモックを含む。Python全構文を検査。

120人サンプルは一致10,797・不一致3・要確認0。初回とキャッシュ再利用の双方で同じ結果。

```text
trial12-120: 120 XLSX + 2 CSV, cache_hits=0/122, elapsed=1.58s; 一致=10797 不一致=3
trial12-120: 120 XLSX + 2 CSV, cache_hits=122/122, elapsed=0.11s; 一致=10797 不一致=3
PASS: 120人、3600勤怠日、10800照合、3不一致、キャッシュ再利用
```

## 証拠と検証範囲

- AUDIT_BASELINE_TRIAL37.json: 修正前の既存25本。
- AUDIT_REPRODUCTION_TRIAL38.txt: 最初の追加監査9件が修正前コードで失敗した記録（上限の複数ケースを含む）。
- AUDIT_DURATION_REPRODUCTION_TRIAL37.txt: 24時間超の実XLSXを旧Trial37で再現した記録。
- AUDIT_PRINT_WIDTH_REPRODUCTION.txt: 印刷表の幅が未指定になる実Qt文書の再現。
- TEST_RESULTS_TRIAL38.json / VALIDATION_TRIAL38.md: 最終版の全26本。
- Preview / 全画面一覧HTML: 実Qtの撮影画像。

検証環境はLinux、Python 3.12.14、PySide6 6.12.0、openpyxl 3.1.5。Windows実機、Python 3.11での実起動、ビルド済EXE、実Excel COM、実プリンタ、会社ネットワーク性能は未検証。ZIPは完全ソースでEXEを含まない。
