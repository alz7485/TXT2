"""Trial73: mail history recovery.

Reported from real use: an employee's draft creation ended in
処理状況要確認 and could never be retried.  Causes: failures before the
draft was saved still left a 'creating' history record (which blocks
forever), and a record stuck at 'created' (draft saved, final status
write lost) was treated as unknown.

- Failures before Save now record 'failed' and can be retried.
- A 'created' record in draft mode is a saved draft: reported as such
  and healed to 'draft'.  With auto-send it stays stopped, because the
  send was never confirmed.
- Genuinely unknown states ('creating', 'sending') still stop, but the
  history can be reset (reset_mail_history) after the user checks
  Outlook; records that prove completion are never removed.
"""
import json
import tempfile
import unittest
from pathlib import Path

from classic_outlook import process_classic_plans, reset_mail_history, _plan_keys
from outlook_mail import DEFAULT_MAIL_SETTINGS
from engine import save_json
from test_trial64_classic_mail import Outlook


class MailHistoryRecovery(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name)
        self.outlook = Outlook(self.path)
        self.settings = {**DEFAULT_MAIL_SETTINGS, 'account': 'operator@example.com'}
        self.plans = [{'employee': '21254', 'staff': 'S1', 'name': 'User 1',
                       'to': ['user1@example.com'], 'cc': [], 'subject': 'Subject 1',
                       'body': 'User 1殿\n派遣元：9:00\n派遣先：9:05', 'problem': ''}]

    def ledger(self):
        return json.loads((self.path / 'mail_processing_history.json').read_text())

    def seed(self, status, **extra):
        key = _plan_keys(self.settings, self.plans[0])[0]
        record = {'employee': '21254', 'staff': 'S1', 'status': status,
                  'backend': 'classic_outlook', 'account': 'operator@example.com',
                  'auto_send': self.settings['auto_send'], **extra}
        save_json(self.path / 'mail_processing_history.json', {key: record})
        return key

    def run_mail(self):
        return process_classic_plans(self.plans, self.settings, self.path, self.outlook)

    def test_pre_save_failure_is_retryable(self):
        self.outlook.resolve_failure = True
        result = self.run_mail()
        self.assertIn('error', result[0])
        self.assertEqual(next(iter(self.ledger().values()))['status'], 'failed')
        self.assertNotIn('Save', self.outlook.events)  # nothing was saved
        self.outlook.resolve_failure = False
        result = self.run_mail()
        self.assertEqual(result[0]['status'], '下書き保存済み')
        self.assertEqual(self.outlook.events.count('Save'), 1)

    def test_save_failure_stays_unknown_and_blocks(self):
        self.outlook.save_failure = True
        result = self.run_mail()
        self.assertIn('error', result[0])
        self.assertEqual(next(iter(self.ledger().values()))['status'], 'creating')
        events = list(self.outlook.events)
        result = self.run_mail()
        self.assertIn('処理状況要確認', result[0]['status'])
        self.assertEqual(self.outlook.events, events)

    def test_created_record_counts_as_saved_draft_and_heals(self):
        self.seed('created', id='id-1')
        result = self.run_mail()
        self.assertEqual(result[0]['status'], '同内容の下書き保存済み')
        self.assertFalse(self.outlook.messages)
        self.assertEqual(next(iter(self.ledger().values()))['status'], 'draft')

    def test_created_record_with_auto_send_stays_stopped(self):
        self.settings['auto_send'] = True
        self.seed('created', id='id-1')
        result = self.run_mail()
        self.assertIn('送信は未確認', result[0]['status'])
        self.assertFalse(self.outlook.messages)

    def test_stuck_creating_record_can_be_reset_and_recreated(self):
        self.seed('creating')
        result = self.run_mail()
        self.assertIn('処理状況要確認', result[0]['status'])
        removed = reset_mail_history(self.plans, self.settings, self.path)
        self.assertEqual(removed, 1)
        result = self.run_mail()
        self.assertEqual(result[0]['status'], '下書き保存済み')
        self.assertEqual(len(self.outlook.messages), 1)

    def test_reset_never_removes_completed_records(self):
        for status in ('sent', 'draft', 'created'):
            with self.subTest(status=status), tempfile.TemporaryDirectory() as t:
                self.path = Path(t)
                self.outlook = Outlook(self.path)
                self.seed(status, id='id-1')
                removed = reset_mail_history(self.plans, self.settings, self.path)
                self.assertEqual(removed, 0)
                self.assertEqual(next(iter(self.ledger().values()))['status'], status)


if __name__ == '__main__':
    unittest.main(verbosity=2)
