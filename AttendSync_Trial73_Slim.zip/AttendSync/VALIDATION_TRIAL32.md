# Trial32 検証報告

実行環境: Linux-6.18.44-x86_64-with-glibc2.41
Python: 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]
PySide6 6.12.0 / openpyxl 3.1.5 / QT_QPA_PLATFORM=offscreen

23本全合格。Python全ファイルのAST構文検査合格。

| テスト | 種類 | 結果 | 秒 |
|---|---|---|---|
| test_120_performance.py | 動的（環境依存箇所はモック） | PASS | 1.47 |
| test_cache_tags.py | 動的（環境依存箇所はモック） | PASS | 0.08 |
| test_comparison_extensions.py | 動的（環境依存箇所はモック） | PASS | 0.16 |
| test_coverage_trial16.py | 動的（環境依存箇所はモック） | PASS | 1.14 |
| test_engine.py | 動的（環境依存箇所はモック） | PASS | 0.1 |
| test_excel_jump.py | 動的（環境依存箇所はモック） | PASS | 0.02 |
| test_final_validation.py | 動的（環境依存箇所はモック） | PASS | 0.09 |
| test_month_spacers_trial19.py | 動的（環境依存箇所はモック） | PASS | 0.11 |
| test_sample_integration.py | 動的（環境依存箇所はモック） | PASS | 0.18 |
| test_stable_read.py | 動的（環境依存箇所はモック） | PASS | 0.02 |
| test_trial15.py | 動的（環境依存箇所はモック） | PASS | 0.11 |
| test_trial21.py | 動的（環境依存箇所はモック） | PASS | 0.1 |
| test_trial22_static.py | 静的/AST抽出 | PASS | 0.02 |
| test_trial23_static.py | 静的/AST抽出 | PASS | 0.02 |
| test_trial24_integrity.py | 静的/AST抽出 | PASS | 0.02 |
| test_trial27_toggle_static.py | 静的/AST抽出 | PASS | 0.02 |
| test_trial28_input_review.py | 動的（環境依存箇所はモック） | PASS | 0.08 |
| test_trial29_completion.py | 静的/AST抽出 | PASS | 0.05 |
| test_trial30_dynamic_failures.py | 動的（環境依存箇所はモック） | PASS | 0.18 |
| test_trial31_excel_mock.py | 動的（環境依存箇所はモック） | PASS | 0.09 |
| test_trial32_gui_print.py | 動的（環境依存箇所はモック） | PASS | 1.46 |
| test_trial32_sessions_mapping.py | 動的（環境依存箇所はモック） | PASS | 6.72 |
| test_ui_static.py | 静的/AST抽出 | PASS | 0.04 |

## 主要な実行結果

```
trial12-120: 120 XLSX + 2 CSV, cache_hits=0/122, elapsed=1.25s; 一致=10797 不一致=3
trial12-120: 120 XLSX + 2 CSV, cache_hits=122/122, elapsed=0.10s; 一致=10797 不一致=3
PASS: 120人、3600勤怠日、10800照合、3不一致、キャッシュ再利用
```

```
PASS: XLSX 4件 / CSV 2件 / CSV 120行
PASS: 一致 357項目 / 不一致 3項目 / 要確認 0件
PASS: 同姓同名2人の候補選択・対象年月チェック・期待不一致3項目
```

```
PASS: real Qt filters/detail/empty/theme/settings/log/Excel failure; PDF 21 pages; preview, cancel, no printer, print error
```

```
PASS: real QThread repeated stop/restart, 10800 rows, stale signals ignored; mapping labels, unsaved edits, name priority, duplicate rejection
```

## 未検証と受入確認

- Windows 11 / Python 3.11でonedirビルドとEXE起動。
- 実Excel（Office 32bit利用環境を含む）の既存ブック保護・セル選択・戻り操作。
- Windowsネイティブ印刷ダイアログ、物理プリンタ、途中のスプーラ取消、プリンタ切断。
- Windowsの日本語フォントでの長い氏名・ページ境界・テーマの目視確認。
- 会社ネットワーク上の120ファイル性能。Linuxローカル計測値は会社環境の保証値ではありません。

Qtオフスクリーンではクリック/イベントを実行。画面の目視品質を実機合格とは扱っていません。
Fontconfigキャッシュ警告とoffscreenのpropagateSizeHints警告が出ましたが、テストは全合格です。
