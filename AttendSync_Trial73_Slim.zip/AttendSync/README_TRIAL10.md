AttendSync Trial10（Trial9監査修正版）
起動・EXE化: build_onedir.py（Windows上で実行）
同梱: SampleData、アイコンICO/Base64、検証スクリプト。
変更内容と既知の制限はAUDIT_TRIAL10.mdを参照してください。
