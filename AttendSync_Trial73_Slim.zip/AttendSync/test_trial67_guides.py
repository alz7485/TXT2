"""Trial67: onboarding guide (coach marks) checks.

Pure guide-settings logic is tested without Qt.  The Qt checks run the
real main window and the real settings dialog offscreen, with all user
data isolated in temporary folders.  Run with
``python -m unittest -v test_trial67_guides``.
"""
from __future__ import annotations

import copy
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

from guide_config import (
    GUIDE_STEPS, STEP_IDS, normalize_guide_settings, next_visible_step,
    validate_guide_settings, visible_step_ids, with_all_off, with_step_hidden,
)

try:
    from PySide6.QtCore import QTimer
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QApplication, QCheckBox
except ModuleNotFoundError as exc:
    if exc.name != 'PySide6':
        raise
    QT_AVAILABLE = False
else:
    QT_AVAILABLE = True
    import runtime_paths
    _import_directory = tempfile.TemporaryDirectory(prefix='attendsync-guide-import-')
    with patch.object(runtime_paths, 'get_data_dir', return_value=Path(_import_directory.name)):
        import main
    import engine


class GuideConfigLogic(unittest.TestCase):
    def test_step_order_matches_the_workflow(self):
        self.assertEqual(STEP_IDS, ['employee', 'period_folder', 'csv_load', 'results', 'mail'])
        for step in GUIDE_STEPS:
            self.assertTrue(step['title'])
            self.assertTrue(step['body'])
            self.assertTrue(step['action'])

    def test_normalize_drops_unknown_ids_and_duplicates(self):
        cleaned = normalize_guide_settings({'all_off': 1, 'hidden': ['mail', 'nope', 'mail', 3]})
        self.assertEqual(cleaned, {'all_off': True, 'hidden': ['mail']})
        self.assertEqual(normalize_guide_settings(None), {'all_off': False, 'hidden': []})
        self.assertEqual(normalize_guide_settings('bad'), {'all_off': False, 'hidden': []})

    def test_visible_and_next_step(self):
        settings = {'all_off': False, 'hidden': ['employee', 'csv_load']}
        self.assertEqual(visible_step_ids(settings), ['period_folder', 'results', 'mail'])
        self.assertEqual(next_visible_step(settings), 'period_folder')
        self.assertEqual(next_visible_step(settings, 'period_folder'), 'results')
        self.assertIsNone(next_visible_step(settings, 'mail'))
        self.assertEqual(visible_step_ids({'all_off': True, 'hidden': []}), [])

    def test_with_helpers_do_not_mutate(self):
        base = {'all_off': False, 'hidden': []}
        hidden = with_step_hidden(base, 'results')
        self.assertEqual(hidden['hidden'], ['results'])
        self.assertEqual(base['hidden'], [])
        self.assertEqual(with_step_hidden(hidden, 'results', hidden=False)['hidden'], [])
        self.assertTrue(with_all_off(base)['all_off'])
        self.assertFalse(base['all_off'])

    def test_validate_rejects_bad_shapes(self):
        validate_guide_settings(None)
        validate_guide_settings({'all_off': True, 'hidden': ['mail']})
        for bad in ('x', {'all_off': 'yes'}, {'hidden': 'mail'}, {'hidden': ['nope']}):
            with self.assertRaises(ValueError):
                validate_guide_settings(bad)


@unittest.skipUnless(QT_AVAILABLE, 'PySide6 is required for real Qt guide checks')
class GuideWindowFlow(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
        cls.app.setQuitOnLastWindowClosed(False)

    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(prefix='attendsync-guide-test-')
        self.addCleanup(self.directory.cleanup)
        self.data_dir = Path(self.directory.name)
        self.paths_patch = patch.multiple(
            main, DATA_DIR=self.data_dir, CONFIG=self.data_dir / 'settings.json',
            MAP=self.data_dir / 'staff_mapping.json', DB=self.data_dir / 'attendance_cache.sqlite3',
        )
        self.paths_patch.start()
        self.addCleanup(self.paths_patch.stop)
        self.window = None
        self.addCleanup(self.close_window)

    def close_window(self):
        if self.window is not None:
            self.window.close()
            self.window.deleteLater()
            self.app.processEvents()

    def make_window(self, guides=None):
        if guides is not None:
            cfg = copy.deepcopy(engine.DEFAULT)
            cfg['guides'] = guides
            (self.data_dir / 'settings.json').write_text(json.dumps(cfg, ensure_ascii=False), encoding='utf-8')
        with patch.object(main, 'current_attendance_month', return_value=(2026, 10)):
            self.window = main.Window()
        self.window.show()
        self.app.processEvents()
        return self.window

    def test_start_shows_employee_guide_with_red_frame_targets(self):
        window = self.make_window()
        manager = window.guide_manager
        manager.start()
        self.assertTrue(manager.active)
        self.assertEqual(manager.current_id, 'employee')
        self.assertTrue(manager.panel.isVisible())
        self.assertTrue(manager.overlay.isVisible())
        self.assertEqual(manager.panel.check_all.text(), '次回から全てのガイドを表示しない')
        self.assertEqual(manager.panel.check_step.text(), '次回からこのガイドを表示しない')
        self.assertIn(window.btn_map, manager.overlay._targets)
        rects = manager.overlay._target_rects()
        self.assertEqual(len(rects), 1)
        expected = window.btn_map.rect()
        self.assertEqual(rects[0].width(), expected.width() + 12)
        # The panel sits at the centre of the window.
        centre = manager.panel.geometry().center()
        self.assertAlmostEqual(centre.x(), window.rect().center().x(), delta=30)
        self.assertAlmostEqual(centre.y(), window.rect().center().y(), delta=60)

    def test_employee_registered_advances_to_period_folder(self):
        window = self.make_window()
        manager = window.guide_manager
        manager.start()
        manager.notify('employee_registered')
        self.assertEqual(manager.current_id, 'period_folder')
        self.assertIn(window.path, manager.overlay._targets)
        self.assertIn(window.year, manager.overlay._targets)
        manager.notify('folder_selected')
        QTest.qWait(700)
        self.app.processEvents()
        self.assertEqual(manager.current_id, 'csv_load')
        self.assertIn(window.run_button, manager.overlay._targets)

    def test_hide_checkboxes_persist_immediately_and_show_notice(self):
        window = self.make_window()
        manager = window.guide_manager
        manager.start()
        self.assertFalse(manager.panel.notice_label.isVisible())
        manager.panel.check_step.setChecked(True)
        self.assertTrue(manager.panel.notice_label.isVisible())
        self.assertIn('設定', manager.panel.notice_label.text())
        self.assertIn('ガイド', manager.panel.notice_label.text())
        saved = json.loads((self.data_dir / 'settings.json').read_text(encoding='utf-8'))
        self.assertEqual(saved['guides']['hidden'], ['employee'])
        self.assertEqual(window.cfg['guides']['hidden'], ['employee'])
        manager.panel.check_step.setChecked(False)
        saved = json.loads((self.data_dir / 'settings.json').read_text(encoding='utf-8'))
        self.assertEqual(saved['guides']['hidden'], [])
        manager.panel.check_all.setChecked(True)
        saved = json.loads((self.data_dir / 'settings.json').read_text(encoding='utf-8'))
        self.assertTrue(saved['guides']['all_off'])

    def test_all_off_and_hidden_steps_are_skipped(self):
        window = self.make_window(guides={'all_off': True, 'hidden': []})
        window.guide_manager.start()
        self.assertFalse(window.guide_manager.active)
        self.assertFalse(window.guide_manager.panel.isVisible())

    def test_hidden_first_step_starts_at_period_folder(self):
        window = self.make_window(guides={'all_off': False, 'hidden': ['employee']})
        window.guide_manager.start()
        self.assertEqual(window.guide_manager.current_id, 'period_folder')

    def test_read_flow_reaches_results_then_mail_only_with_problems(self):
        window = self.make_window(guides={'all_off': False, 'hidden': ['employee', 'period_folder']})
        manager = window.guide_manager
        manager.start()
        self.assertEqual(manager.current_id, 'csv_load')
        manager.notify('read_started')
        self.assertFalse(manager.panel.isVisible())
        window.results = [{'status': '不一致'}]
        manager.notify('read_succeeded')
        self.assertEqual(manager.current_id, 'results')
        self.assertTrue(manager.panel.isVisible())
        manager.advance()
        self.assertEqual(manager.current_id, 'mail')
        self.assertIn(window.mail_button, manager.overlay._targets)
        manager.notify('mail_done')
        self.assertTrue(manager.finished)
        self.assertFalse(manager.panel.isVisible())

    def test_results_without_problems_finish_without_mail_guide(self):
        window = self.make_window(guides={'all_off': False, 'hidden': ['employee', 'period_folder', 'csv_load']})
        manager = window.guide_manager
        manager.start()
        self.assertEqual(manager.current_id, 'results')
        window.results = [{'status': '一致'}]
        manager.advance()
        self.assertTrue(manager.finished)

    def test_review_only_results_do_not_open_mail_guide(self):
        # Mail is created from mismatches only (same rule that enables the
        # mail button); 要確認 alone must finish after the results guide.
        window = self.make_window(guides={'all_off': False, 'hidden': ['employee', 'period_folder', 'csv_load']})
        manager = window.guide_manager
        manager.start()
        self.assertEqual(manager.current_id, 'results')
        window.results = [{'status': '要確認'}]
        manager.advance()
        self.assertTrue(manager.finished)
        self.assertFalse(manager.panel.isVisible())

    def test_mail_step_is_skipped_when_no_problems(self):
        window = self.make_window(guides={'all_off': False, 'hidden': ['employee', 'period_folder', 'csv_load', 'results']})
        manager = window.guide_manager
        window.results = [{'status': '一致'}]
        manager.start()
        self.assertTrue(manager.finished)
        self.assertFalse(manager.panel.isVisible())

    def test_failed_read_returns_to_csv_guide(self):
        window = self.make_window(guides={'all_off': False, 'hidden': ['employee', 'period_folder']})
        manager = window.guide_manager
        manager.start()
        manager.notify('read_started')
        manager.notify('read_failed')
        self.assertEqual(manager.current_id, 'csv_load')
        self.assertTrue(manager.panel.isVisible())

    def test_settings_dialog_guide_tab_roundtrip(self):
        window = self.make_window()
        dialog = main.SettingsDialog(window, copy.deepcopy(window.cfg))
        self.addCleanup(dialog.deleteLater)
        titles = [dialog.tabs.tabText(i) for i in range(dialog.tabs.count())]
        self.assertIn('ガイド', titles)
        dialog.guide_all_off.setChecked(True)
        dialog.guide_hidden_checks['mail'].setChecked(True)
        dialog.accept()
        self.assertTrue(dialog.value['guides']['all_off'])
        self.assertEqual(dialog.value['guides']['hidden'], ['mail'])

    def test_settings_restart_button_clears_hide_checks(self):
        window = self.make_window(guides={'all_off': True, 'hidden': ['employee', 'mail']})
        dialog = main.SettingsDialog(window, copy.deepcopy(window.cfg))
        self.addCleanup(dialog.deleteLater)
        dialog.guide_restart_button.click()
        self.assertTrue(dialog.restart_guides_requested)
        self.assertFalse(dialog.guide_all_off.isChecked())
        self.assertFalse(any(check.isChecked() for check in dialog.guide_hidden_checks.values()))
        dialog.accept()
        self.assertEqual(dialog.value['guides'], {'all_off': False, 'hidden': [], 'employee': {'all_off': False, 'hidden': []}})

    def test_saving_settings_all_off_closes_active_guide(self):
        window = self.make_window()
        manager = window.guide_manager
        manager.start()
        self.assertTrue(manager.active)

        def act():
            dialog = self.app.activeModalWidget()
            self.assertIsNotNone(dialog)
            dialog.findChild(QCheckBox, 'guideAllOff').setChecked(True)
            dialog.accept()

        QTimer.singleShot(0, act)
        window.edit_settings()
        self.app.processEvents()
        self.assertTrue(window.cfg['guides']['all_off'])
        self.assertFalse(manager.active)


if __name__ == '__main__':
    unittest.main(verbosity=2)
