# 1.72.7-beta112の検証

コア528件成功。実Tk 8.6/Xorgで関連GUI18件成功。モデルでVIEWPORTボタンdisabled、レイアウトでは有効、LAYOUTの追加一覧除外、直接追加経路拒否、空フォルダだけのSCR作成、旧LAYOUTの実行互換を確認。空間カメラとSELECTの100件超選択も回帰確認。
スモーク成功。Windows／AutoCAD実機・SCR実行・EXEビルドは未実施。
