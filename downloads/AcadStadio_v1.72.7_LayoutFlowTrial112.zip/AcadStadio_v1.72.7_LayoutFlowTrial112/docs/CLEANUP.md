# 整理内容

2026-11-16。Trial107を基準に資料と配布構成を整理。

- README・開発引き継ぎ・変更履歴・検証資料を短縮。
- 古い引き継ぎ・試行資料・生ログを別ZIPへ退避。
- src・assets・examples・testsは元ZIPとバイト単位で同一。
- アプリの実行速度を変える最適化は行っていません。
- scripts/package_release.pyの配布名を整理版へ更新。

## 今回の検証

- コアテスト500件成功。スモークテスト成功。
- GUI・Windows／AutoCAD実機は今回未実施。
- 配布ZIPは生成時に全収録ファイルのSHA256とZIP整合性を確認。
