"""Expose drawing attributes as ordered settings, omitting redundant settings."""
import copy
from decimal import Decimal, InvalidOperation
from command_types import DRAWING_TYPES, DIMENSION_TYPES
FIELDS = ('layer', 'color', 'linetype', 'linetype_scale', 'text_style', 'dim_style')


def _constant(field, value):
    """Only compare literals: identical expressions may evaluate differently later."""
    text = str(value).strip()
    if field in ('color', 'linetype_scale'):
        if field == 'color':
            text = {'bylayer': '256', 'byblock': '0'}.get(text.casefold(), text)
        try:
            number = Decimal(text)
            return number if number.is_finite() else None
        except InvalidOperation:
            return None
    if field == 'layer' and (text.startswith('=') or text.startswith('settings.')):
        return None
    return str(value).casefold()


def extract_appearance(commands, *, deduplicate=True):
    result = []
    known = {}

    def setting(attrs, condition, original=None):
        constants = {key: _constant(key, value) for key, value in attrs.items()}
        redundant = deduplicate and bool(attrs) and not condition and all(
            value is not None and key in known and known[key] == value
            for key, value in constants.items()
        )
        if not redundant:
            result.append(original if original is not None else
                          dict(type='APPEARANCE', **attrs, condition=condition))
        if condition:
            # A guarded setting might not execute. Do not infer its final state.
            known.clear()
        else:
            for key, value in constants.items():
                if value is None: known.pop(key, None)
                else: known[key] = value

    for original in commands:
        command = copy.deepcopy(original)
        typ = command.get('type')
        condition = command.get('condition', '').strip()
        for branch in ('commands', 'else'):
            if isinstance(command.get(branch), list):
                # Each branch/loop starts independently, including its first iteration.
                command[branch] = extract_appearance(command[branch], deduplicate=deduplicate)
        if typ in DRAWING_TYPES:
            attrs = {key: command.pop(key) for key in FIELDS if key in command}
            attrs = {k: v for k, v in attrs.items() if str(v).strip()}
            if typ not in ('TEXT', 'MTEXT'): attrs.pop('text_style', None)
            if typ not in DIMENSION_TYPES: attrs.pop('dim_style', None)
            if attrs: setting(attrs, condition)
            result.append(command)
            if condition: known.clear()
        elif typ == 'APPEARANCE':
            attrs = {key: command[key] for key in FIELDS
                     if key in command and str(command[key]).strip()}
            # Nonstandard attributes (e.g. lineweight) must never be dropped.
            extra = set(command) - set(FIELDS) - {'type', 'condition'}
            if extra:
                result.append(command); known.clear()
            else:
                setting(attrs, condition, command)
        else:
            result.append(command)
            # Variables, nested blocks, CAD state and custom commands can change
            # values or settings. Resume with an unknown state after them.
            known.clear()
    return result
