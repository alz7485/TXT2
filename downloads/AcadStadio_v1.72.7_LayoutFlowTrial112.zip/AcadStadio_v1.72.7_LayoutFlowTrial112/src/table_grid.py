"""Visible cell borders on ttk tables, including scrolling and resized columns."""
import tkinter as tk
from tkinter import ttk


class GridTreeview(ttk.Treeview):
    def __init__(self, *args, **kwargs):
        self._grid_job = None
        self._grid_lines = []
        self._color_cells = []
        self._color_column = None
        self._grid_on_top = kwargs.pop("grid_on_top", False)
        super().__init__(*args, **kwargs)
        for event in ('<Configure>', '<Expose>', '<ButtonRelease-1>', '<MouseWheel>',
                      '<Button-4>', '<Button-5>', '<KeyRelease>',
                      '<<TreeviewOpen>>', '<<TreeviewClose>>'):
            self.bind(event, self._queue_grid, add='+')
        self.bind('<Destroy>', self._cancel_grid, add='+')
        self._queue_grid()

    def set_color_column(self, column, getter):
        self._color_column = (column, getter)
        self._queue_grid()

    def _draw_colors(self, rows, width, height):
        used = 0
        if self._color_column:
            column, getter = self._color_column
            for identity in rows:
                bounds = self.bbox(identity, column)
                if not bounds: continue
                x, y, w, h = bounds
                if x < 0 or x + 22 > width or y < 0 or y + h > height: continue
                if used == len(self._color_cells):
                    cell = tk.Frame(self, borderwidth=1, relief='solid', takefocus=False)
                    for seq in ('<ButtonPress-1>', '<ButtonRelease-1>', '<ButtonPress-3>'):
                        cell.bind(seq, lambda e, s=seq: self._forward(e, s))
                    cell.bind('<MouseWheel>', lambda e: self.yview_scroll(-1 if e.delta > 0 else 1, 'units'))
                    cell.bind('<Button-4>', lambda e: self.yview_scroll(-1, 'units'))
                    cell.bind('<Button-5>', lambda e: self.yview_scroll(1, 'units'))
                    self._color_cells.append(cell)
                cell = self._color_cells[used]
                cell.configure(bg=getter(identity))
                cell.place(x=x+4, y=y+(h-14)//2, width=14, height=14)
                cell.lift(); used += 1
        for cell in self._color_cells[used:]: cell.place_forget()

    def _cancel_grid(self, event):
        if event.widget is self and self._grid_job:
            self.after_cancel(self._grid_job)
            self._grid_job = None

    def _queue_grid(self, *_):
        if self._grid_job is None:
            self._grid_job = self.after_idle(self._draw_grid)

    def _forward(self, event, sequence):
        self.focus_set()
        self.event_generate(sequence, x=event.x_root-self.winfo_rootx(),
                            y=event.y_root-self.winfo_rooty(), state=event.state,
                            when='tail')
        return 'break'

    def _line(self, index, x, y, width, height):
        while len(self._grid_lines) <= index:
            line = tk.Frame(self, bg='#c4cedb', borderwidth=0, takefocus=False)
            for seq in ('<ButtonPress-1>', '<ButtonRelease-1>', '<ButtonPress-3>'):
                line.bind(seq, lambda e, s=seq: self._forward(e, s))
            line.bind('<MouseWheel>', lambda e: (self.yview_scroll(-1 if e.delta>0 else 1, 'units'), 'break')[-1])
            line.bind('<Button-4>', lambda e: self.yview_scroll(-1, 'units'))
            line.bind('<Button-5>', lambda e: self.yview_scroll(1, 'units'))
            self._grid_lines.append(line)
        line = self._grid_lines[index]
        line.place(x=x, y=y, width=width, height=height)
        if self._grid_on_top:
            line.lift()
        else:
            line.lower()

    def _draw_grid(self):
        self._grid_job = None
        if not self.winfo_exists() or not self.winfo_ismapped():
            return
        h, w = self.winfo_height(), self.winfo_width()
        rowheight = int(ttk.Style(self).lookup(self.cget('style') or 'Treeview', 'rowheight') or 28)
        rows = {}
        for y in range(0, h+rowheight, max(1, rowheight)):
            identity = self.identify_row(min(y, h-1))
            if identity:
                bounds = self.bbox(identity)
                if bounds: rows[identity] = bounds
        used = 0
        if rows:
            first = next(iter(rows))
            x, top, total, _ = min(rows.values(), key=lambda b:b[1])
            bottom = min(h-1, max(b[1]+b[3] for b in rows.values()))
            for bounds in rows.values():
                y = bounds[1]+bounds[3]-1
                if 0 <= y < h:
                    self._line(used, max(0,x), y, min(w,total), 1); used += 1
            display = tuple(map(str, self.cget('displaycolumns')))
            count = len(self.cget('columns')) if '#all' in display else len(display)
            columns = (['#0'] if 'tree' in tuple(map(str, self.cget('show'))) else []) + [f'#{i}' for i in range(1,count+1)]
            for column in columns:
                bounds = self.bbox(first, column)
                if not bounds: continue
                x = bounds[0]+bounds[2]-1
                if 0 <= x < w:
                    self._line(used, x, max(0,top), 1, max(1,bottom-max(0,top))); used += 1
        for line in self._grid_lines[used:]: line.place_forget()
        self._draw_colors(rows, w, h)

    def insert(self, *a, **kw):
        result = super().insert(*a, **kw); self._queue_grid(); return result

    def delete(self, *a):
        result = super().delete(*a); self._queue_grid(); return result

    def item(self, *a, **kw):
        result = super().item(*a, **kw)
        if kw: self._queue_grid()
        return result

    def yview(self, *a):
        result = super().yview(*a)
        if a: self._queue_grid()
        return result

    def xview(self, *a):
        result = super().xview(*a)
        if a: self._queue_grid()
        return result

    def yview_scroll(self, *a):
        result = super().yview_scroll(*a); self._queue_grid(); return result

    def xview_scroll(self, *a):
        result = super().xview_scroll(*a); self._queue_grid(); return result

    def see(self, *a):
        result = super().see(*a); self._queue_grid(); return result

    def column(self, *a, **kw):
        result = super().column(*a, **kw)
        if kw: self._queue_grid()
        return result

    def xview_moveto(self, *a):
        result = super().xview_moveto(*a); self._queue_grid(); return result

    def yview_moveto(self, *a):
        result = super().yview_moveto(*a); self._queue_grid(); return result

    def move(self, *a):
        result = super().move(*a); self._queue_grid(); return result
