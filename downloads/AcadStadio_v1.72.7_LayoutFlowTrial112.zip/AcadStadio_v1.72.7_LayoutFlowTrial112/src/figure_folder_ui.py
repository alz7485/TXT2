"""Modeless preview selection for organizing imported logical figures."""
import copy
import tkinter as tk
from tkinter import ttk, simpledialog, messagebox
from figure_folders import eligible, folderize, sort_folder, sort_blocks


def logical(item):
    seen=set()
    while item.get('_logical_parent') is not None and id(item) not in seen:
        seen.add(id(item));item=item['_logical_parent']
    return item


class FigureFolderSelection:
    def __init__(self, app):
        self.app=app;self.canvas=app.canvas;self.selected=set();self.active=True;self.start=None;self.rect=None
        app.table_editor.finish();app.preview(quiet=True)
        self.snapshot=copy.deepcopy(app.data)
        self.space=self.canvas.space_tabs.active if self.canvas.space_tabs else 'Model'
        win=self.win=tk.Toplevel(app.root);win.title('図形を選んでフォルダ化');win.transient(app.root)
        self.mode=tk.StringVar(value='追加');self.crossing=tk.BooleanVar(value=False);self.caption=tk.StringVar(value='0コマンド選択')
        ttk.Label(win,text='プレビューを囲って選択。クリックでも選べます。Ctrlを押すと解除。',padding=8).pack(anchor='w')
        row=ttk.Frame(win,padding=(8,2));row.pack(fill='x')
        for mode in ('追加','解除'):ttk.Radiobutton(row,text=mode,variable=self.mode,value=mode).pack(side='left',padx=4)
        ttk.Checkbutton(row,text='範囲に触れる図形も含む',variable=self.crossing).pack(side='left',padx=12)
        ttk.Label(win,textvariable=self.caption,padding=(8,4)).pack(anchor='w')
        ttk.Label(win,text='元コマンド単位の選択です。表の全行に反映されます。',padding=(8,2)).pack(anchor='w')
        buttons=ttk.Frame(win,padding=8);buttons.pack(fill='x')
        ttk.Button(buttons,text='選択を解除',command=self.clear).pack(side='left')
        ttk.Button(buttons,text='終了',command=self.close).pack(side='right')
        ttk.Button(buttons,text='フォルダ化…',command=self.commit).pack(side='right',padx=8)
        win.protocol('WM_DELETE_WINDOW',self.close);win.bind('<Escape>',lambda e:self.close())
        win.bind('<Destroy>',lambda e:self.stop() if e.widget is win else None)
        self.bindings={};self.tokens={}
        for sequence,handler in [('<ButtonPress-1>',self.press),('<B1-Motion>',self.motion),('<ButtonRelease-1>',self.release),('<Double-1>',lambda e:'break'),('<Escape>',lambda e:(self.close(),'break')[-1]),('<ButtonPress-2>',lambda e:setattr(self.canvas,'drag_point',(e.x,e.y))),('<B2-Motion>',self.canvas.drag)]:
            self.bindings[sequence]=self.canvas.bind(sequence)
            self.tokens[sequence]=self.canvas.bind(sequence,handler)
        self.old_cursor=self.canvas.cget('cursor');self.canvas.configure(cursor='crosshair')
        self.original_highlight=self.canvas.highlight
        def highlight(*args,**kwargs):
            self.original_highlight(*args,**kwargs);self.paint()
        self.canvas.highlight=highlight
        self.paint()
        app.status.set('囲って図形を追加選択し、「フォルダ化…」を押してください。中ボタンで移動できます。')

    def current(self):
        space=self.canvas.space_tabs.active if self.canvas.space_tabs else 'Model'
        if self.app.data != self.snapshot or space != self.space:
            self.selected.clear();self.snapshot=copy.deepcopy(self.app.data);self.space=space
        return self.active

    def token(self,item):
        item=logical(item)
        if item.get('guide'):return None
        addresses=item.get('command_addresses')
        address=addresses[-1] if addresses else ('blocks',item.get('block_index'),'commands',item.get('command_index'))
        if len(address)!=4 or address[0]!='blocks' or address[2]!='commands':return None
        try:
            block=self.app.data['blocks'][address[1]];command=block['commands'][address[3]]
        except (IndexError,KeyError,TypeError):return None
        if not eligible(command):return None
        return block['id'],command['point_id']

    def visible(self):
        result={}
        for node,item,_ in self.canvas.geometry:
            token=self.token(item)
            if token is not None:result.setdefault((token,logical(item).get("row",0)),[]).append(node)
        return result

    def select_box(self,box,remove=False,crossing=False,click=False):
        self.current();x,y,u,v=box;x,u=sorted((x,u));y,v=sorted((y,v))
        overlap=set(self.canvas.find_overlapping(x,y,u,v))
        hits=set()
        for (token,row),nodes in self.visible().items():
            if crossing or click:
                match=bool(overlap.intersection(nodes))
            else:
                bounds=[self.canvas.bbox(node) for node in nodes];bounds=[b for b in bounds if b]
                match=bool(bounds) and all(x<=a and y<=b and u>=c and v>=d for a,b,c,d in bounds)
            if match:hits.add(token)
        if remove:self.selected.difference_update(hits)
        else:self.selected.update(hits)
        self.canvas.highlight(*self.canvas.highlight_filter)
        return hits

    def press(self,event):
        self.current();self.canvas.focus_set();self.start=(event.x,event.y);return 'break'
    def motion(self,event):
        if self.start is None:return 'break'
        if self.rect:self.canvas.delete(self.rect)
        self.rect=self.canvas.create_rectangle(*self.start,event.x,event.y,outline='#ffdb59',dash=(5,3),width=2,tags='folder_selection_box')
        return 'break'
    def release(self,event):
        if self.start is None:return 'break'
        start=self.start;self.start=None
        if self.rect:self.canvas.delete(self.rect);self.rect=None
        click=abs(start[0]-event.x)+abs(start[1]-event.y)<5
        box=(event.x-4,event.y-4,event.x+4,event.y+4) if click else (*start,event.x,event.y)
        self.select_box(box,remove=self.mode.get()=='解除' or bool(event.state & 4),crossing=self.crossing.get(),click=click)
        return 'break'

    def paint(self):
        if not self.active:return
        self.current();changed=False
        for node,item,_ in self.canvas.geometry:
            if self.token(item) not in self.selected:continue
            typ=self.canvas.type(node);shade='#ffdb59'
            if typ=='image':self.canvas._text_colors[node]=shade;changed=True
            elif typ=='polygon':self.canvas.itemconfigure(node,outline=shade,width=3,**({'fill':shade} if self.canvas.itemcget(node,'fill') else {}))
            else:
                options={'outline' if typ in ('oval','rectangle') else 'fill':shade}
                if typ!='text':options['width']=3
                self.canvas.itemconfigure(node,**options)
        if changed:self.canvas.redraw_text()
        self.caption.set(f'{self.space} / {len(self.selected)}コマンド選択')

    def clear(self):
        self.selected.clear();self.canvas.highlight(*self.canvas.highlight_filter)

    def commit(self,name=None):
        self.app.table_editor.finish();self.current()
        if not self.selected:return messagebox.showinfo('フォルダ化','プレビューで読込図形を選択してください',parent=self.win)
        if name is None:
            from space_folders import root_for
            parent = root_for(self.app.data,self.space)['id']
            names={f['name'] for f in self.app.data.get('block_folders',[]) if f.get('parent_id')==parent}
            number=1
            while f'フォルダ{number}' in names:number+=1
            name=simpledialog.askstring('選択図形をフォルダ化','フォルダ名',initialvalue=f'フォルダ{number}',parent=self.win)
        if name is None:return
        try:trial,identity,created=folderize(self.app.data,self.selected,name,self.space)
        except ValueError as exc:return messagebox.showerror('フォルダ化',str(exc),parent=self.win)
        self.close();apply_folder_change(self.app,trial,identity)
        self.app.status.set(f'選択図形を「{name.strip()}」に移動しました。{len(created)}ブロックを作成。')
        return identity

    def stop(self):
        if not self.active:return
        self.active=False
        try:
            if self.canvas.winfo_exists():
                for sequence,token in self.tokens.items():
                    self.canvas.unbind(sequence,token);self.canvas.bind(sequence,self.bindings[sequence])
                self.canvas.configure(cursor=self.old_cursor)
                if self.rect:self.canvas.delete(self.rect)
                self.canvas.highlight=self.original_highlight;self.original_highlight(*self.canvas.highlight_filter)
        except tk.TclError:pass
    def close(self):
        self.stop()
        if self.win.winfo_exists():self.win.destroy()


def apply_folder_change(app,trial,identity):
    app._checkpoint();app.data.clear();app.data.update(trial);app.refresh();app.preview(quiet=True)
    app.block_browser.clear_search();app.block_browser.select_folder(identity)
    node='folder:'+identity
    if app.block_list.exists(node):app.block_list.item(node,open=True)


def sort_selected_folder(app,identity):
    try:trial=sort_folder(app.data,identity)
    except ValueError as exc:return messagebox.showerror('フォルダ内を属性順に整理',str(exc),parent=app.root)
    apply_folder_change(app,trial,identity);app.status.set('選択フォルダ内の読込図形を、同じ作図属性ごとに整理しました。')
    return True


def sort_selected_blocks(app,identities):
    try:trial=sort_blocks(app.data,identities)
    except ValueError as exc:return messagebox.showerror('ブロック内を属性順に整理',str(exc),parent=app.root)
    app._checkpoint();app.data.clear();app.data.update(trial);app.refresh();app.preview(quiet=True)
    for index,b in enumerate(app.data['blocks']):
        if b['id'] in identities:app.block_browser.reveal(index)
    app.status.set('選択ブロックを属性順に並べ替え、重複する作図属性を削除しました。')
    return True
