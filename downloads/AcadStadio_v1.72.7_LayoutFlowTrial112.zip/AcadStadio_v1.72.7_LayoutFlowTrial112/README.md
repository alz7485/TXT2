# AcadStadio 1.72.7-beta112

レイアウト作成はプレビュータブの「＋」へ統一。コマンド追加一覧からLAYOUTを除外し、モデルブロックではVIEWPORTの追加を無効にしました。空のレイアウトフォルダもSCRで作成します。

# AcadStadio 1.72.6-beta111

モデルと各レイアウトの拡大率・表示位置・基準縮尺を個別に保持し、レイアウト作成後に戻っても元の視点を復元します。

# 従来の操作

SELECTをプレビューだけで操作する画面へ整理しました。

- クリック：図形を選択／選択済み図形を解除。
- ドラッグ：囲んだ図形をまとめて選択。
- Shift＋ドラッグ：まとめて解除。
- 「選択を確定」で完了。

画面に座標入力・参照式・条件一覧・保存方式を表示せず、各図形の重ならない点参照を自動で生成します。選択数と強調表示で対象を確認できます。「元に戻す」「すべて解除」も利用可能です。

## 起動

Python 3.11以上、Tkinterが必要です。

```sh
python -m pip install -r requirements.txt
python src/main.py
```

EXEの作成はEXE_BUILD_ONEDIR.md。Windows/AutoCAD実機・SCR実行・EXEビルドは未確認です。

点参照のX→Y→次点XYフロー、SELECTの作成・削除時の保護、DXF/DWGドロップ対策、Qtビルド設定を維持しています。
詳細はdocs/SELECT.md、検証はdocs/VALIDATION.md、開発引き継ぎはSTART_HERE_FOR_CODEX.md。
