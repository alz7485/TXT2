import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from selection_deletion import plan,apply
class Deletion(unittest.TestCase):
 def test_missing_selection_requires_cascade(self):
  c=[dict(type='SELECT',point_id='s'),dict(type='COPY',selection_ref='@previous')]
  self.assertEqual(len(plan(c,[0])[0]),1)
  self.assertEqual(apply(c,[0]),[])
  with self.assertRaises(ValueError):apply(c,[0],True)
 def test_consecutive_selects_can_retain_users(self):
  c=[dict(type='SELECT',point_id='a'),dict(type='SELECT',point_id='b'),dict(type='COPY',selection_ref='b')]
  result=apply(c,[1],True)
  self.assertEqual(result[1]['selection_ref'],'a');self.assertEqual(c[2]['selection_ref'],'b')
 def test_next_select_stops_previous_dependency(self):
  c=[dict(type='SELECT',point_id='a'),dict(type='SELECT',point_id='b'),dict(type='COPY',selection_ref='@previous')]
  self.assertFalse(plan(c,[0])[0]);self.assertEqual(len(apply(c,[0])),2)
