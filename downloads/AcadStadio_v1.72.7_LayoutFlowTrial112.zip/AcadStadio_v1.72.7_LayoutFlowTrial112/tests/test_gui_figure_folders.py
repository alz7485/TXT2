import copy,json,unittest
from pathlib import Path
from unittest.mock import patch
import test_gui as gui
from cad_drawing_import import imported_project,read_cad_drawing,extract_drawing
from engine import compile_project
from figure_folders import _visual_signature
from block_folders import folders
SAMPLES=Path(__file__).resolve().parents[1]/'examples'/'DWG読込と表割当テスト'

class FigureFolderGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown
    def load(self):
        self.app.replace_document(imported_project(read_cad_drawing(SAMPLES/'plate_base.dxf')));self.root.geometry('1280x900');self.root.update();self.app.preview(quiet=True);self.root.update()
    def bounds(self,c,instance):
        box=c.canvas.bbox(*c.visible()[instance]);return (box[0]-5,box[1]-5,box[2]+5,box[3]+5)
    def drag(self,c,box,state=0):
        canvas=c.canvas;x,y,u,v=map(round,box)
        canvas.event_generate('<ButtonPress-1>',x=x,y=y,state=state)
        canvas.event_generate('<B1-Motion>',x=u,y=v,state=state)
        canvas.event_generate('<ButtonRelease-1>',x=u,y=v,state=state);self.root.update()
    def test_drag_add_remove_cancel_restores_canvas_and_does_not_edit(self):
        self.load();before=copy.deepcopy(self.app.data);canvas=self.app.canvas;binding=canvas.bind('<ButtonPress-1>')
        c=self.app.start_figure_folder_selection();self.root.update();instances=list(c.visible());first=instances[0];second=next(k for k in instances if k[0]!=first[0] and self.app.data['blocks'][0]['commands'][4]['point_id']==k[0][1])
        self.drag(c,self.bounds(c,first));self.assertIn(first[0],c.selected)
        self.drag(c,self.bounds(c,second));self.assertIn(second[0],c.selected)
        box=self.bounds(c,first);self.drag(c,box,state=4);self.assertNotIn(first[0],c.selected);self.assertIn(second[0],c.selected)
        self.assertTrue(any(self.app.canvas.itemcget(n,'outline' if self.app.canvas.type(n)=='oval' else 'fill')=='#ffdb59' for n,i,_ in canvas.geometry if c.token(i)==second[0] and canvas.type(n) in ('oval','line')))
        c.close();self.root.update();self.assertEqual(canvas.bind('<ButtonPress-1>'),binding);self.assertEqual(self.app.data,before)
    def test_folder_commit_types_undo_redo_and_explicit_sort(self):
        self.load();before=copy.deepcopy(self.app.data);old=_visual_signature(self.app.compile()[1]);c=self.app.start_figure_folder_selection();self.root.update()
        self.drag(c,(0,0,c.canvas.winfo_width()-1,c.canvas.winfo_height()-1));self.assertEqual(len(c.selected),19)
        with patch('figure_folder_ui.simpledialog.askstring',return_value='部品1'):gui.button(c.win,'フォルダ化').invoke()
        self.root.update();self.assertFalse(c.active);self.assertEqual(self.messages,[])
        f=next(f for f in folders(self.app.data) if f['name']=='部品1');members=[b for b in self.app.data['blocks'] if b.get('folder_id')==f['id']]
        self.assertEqual(len(members),2);self.assertEqual(sum(c['type']=='APPEARANCE' for b in members for c in b['commands']),19)
        self.assertEqual(_visual_signature(self.app.compile()[1]),old)
        legend=' '.join(str(self.app.canvas.itemcget(n,'text')) for n in self.app.canvas.find_withtag('legend'))
        for layer in ('PART','HOLES','AXIS','DIMS'):self.assertIn(layer,legend)
        self.assertNotIn('現在のレイヤー',legend)
        grouped=copy.deepcopy(self.app.data);self.assertTrue(self.app.sort_figure_folder(f['id']));self.root.update()
        members=[b for b in self.app.data['blocks'] if b.get('folder_id')==f['id']]
        self.assertEqual(sum(c['type']=='APPEARANCE' for b in members for c in b['commands']),5)
        self.app.undo_project();self.root.update();self.assertEqual(self.app.data,grouped)
        self.app.undo_project();self.root.update();self.assertEqual(self.app.data,before)
        self.app.redo_project();self.root.update();self.assertEqual(self.app.data,grouped)
    def test_native_dimension_is_selected_as_one_and_layout_is_respected(self):
        import ezdxf
        doc=ezdxf.new(setup=True);paper=doc.layouts.new('SheetA');dim=paper.add_linear_dim(base=(0,10),p1=(0,0),p2=(30,0));dim.render()
        self.app.replace_document(imported_project(extract_drawing(doc,include_layouts=True)));self.root.update();self.app.preview(quiet=True);self.root.update();self.app.canvas.space_tabs.select_space('SheetA');self.root.update()
        c=self.app.start_figure_folder_selection();self.root.update();self.assertEqual(c.space,'SheetA')
        self.drag(c,(0,0,c.canvas.winfo_width()-1,c.canvas.winfo_height()-1));self.assertEqual(len(c.selected),1)
        f=c.commit('寸法');self.root.update();self.assertIsNotNone(f);self.assertEqual(self.messages,[])
        blocks=[b for b in self.app.data['blocks'] if b.get('folder_id')==f];self.assertEqual(len(blocks),1);self.assertEqual(blocks[0]['drawing_space'],'SheetA');self.assertEqual(sum(c['type']=='DIMLINEAR' for c in blocks[0]['commands']),1)
    def test_one_instance_selects_source_command_for_all_table_rows(self):
        self.app.replace_document(json.loads((SAMPLES/'04_assigned_complete.json').read_text()));self.root.update()
        c=self.app.start_figure_folder_selection();self.root.update();self.app.canvas.set_items(compile_project(self.app.data,[0,1,2])[1]);self.root.update()
        instances=c.visible();target=next(k for k in instances if k[1]==0)
        self.drag(c,self.bounds(c,target));self.assertIn(target[0],c.selected)
        self.assertTrue(all(c.token(i) in c.selected for n,i,_ in c.canvas.geometry if c.token(i)==target[0]))
        self.assertIn('全行',next(w.cget('text') for w in c.win.winfo_children() if 'text' in w.keys() and '全行' in str(w.cget('text'))));c.close()
