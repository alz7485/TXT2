import sys,unittest,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from space_command_rules import block_space,creation_reason
from command_types import COMMAND_GROUPS
from space_folders import create_layout
from test_native_operations import project
from engine import compile_project
class SpaceCommandRules(unittest.TestCase):
 def test_model_rejects_viewport_layout_allows_it(self):
  self.assertTrue(creation_reason('VIEWPORT','Model'))
  self.assertFalse(creation_reason('VIEWPORT','A4'))
  self.assertTrue(creation_reason('LAYOUT','A4'))
  self.assertNotIn('LAYOUT',[k for _,group in COMMAND_GROUPS for k in group])
 def test_empty_folder_generates_layout_without_layout_command(self):
  p,_=create_layout(project([]),'テストA4')
  script,_=compile_project(p,[0])
  self.assertIn('"_.-LAYOUT" "_New" "テストA4"',script)
  self.assertFalse(any(c.get('type')=='LAYOUT' for b in p['blocks'] for c in b['commands']))
 def test_existing_layout_commands_remain_compatible(self):
  script,_=compile_project(project([dict(type='LAYOUT',layout_name='A4',layout_action='作成して選択',execution='once')]),[0])
  self.assertIn('"_.-LAYOUT" "_New"',script)
