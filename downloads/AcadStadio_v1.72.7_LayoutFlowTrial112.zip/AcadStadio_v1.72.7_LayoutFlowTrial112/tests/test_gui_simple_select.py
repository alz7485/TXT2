import os,sys,unittest,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from macro_editor import edit_command
from engine import compile_project
@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI display unavailable')
class SimpleSelectGui(unittest.TestCase):
 setUp=gui.Gui.setUp
 tearDown=gui.Gui.tearDown
 def test_preview_click_toggle_and_drag_save_exact_members(self):
  prior=[dict(type='CIRCLE',x='0',y='0',r='10'),dict(type='LINE',x1='-20',y1='0',x2='20',y2='0')]
  def inspect():
   w=gui.top(self.root,'コマンドの設定')
   try:
    w.refresh_command_preview();self.root.update()
    self.assertFalse(w.coordinate_toolbar.winfo_ismapped())
    self.assertEqual(w.command_entries,{})
    editor=w.select_editor;canvas=w.command_preview.canvas
    self.assertTrue(canvas.object_range_callback)
    a=canvas.screen_point((-25,-15));b=canvas.screen_point((25,15))
    canvas.event_generate('<ButtonPress-1>',x=round(a[0]),y=round(a[1]))
    canvas.event_generate('<B1-Motion>',x=round(b[0]),y=round(b[1]))
    canvas.event_generate('<ButtonRelease-1>',x=round(b[0]),y=round(b[1]))
    self.root.update();w.refresh_command_preview();self.root.update()
    self.assertEqual(canvas.selection_count,2)
    circle=next(s for s in canvas.items if s['type']=='CIRCLE')
    editor.simple_point((10,0),circle);self.root.update();w.refresh_command_preview();self.root.update()
    self.assertEqual(canvas.selection_count,1)
    circle=next(s for s in canvas.items if s['type']=='CIRCLE')
    editor.simple_point((10,0),circle);self.root.update();w.refresh_command_preview();self.root.update()
    self.assertEqual(canvas.selection_count,2)
    a=canvas.screen_point((-25,-15));b=canvas.screen_point((25,15))
    canvas.event_generate('<ButtonPress-1>',x=round(a[0]),y=round(a[1]),state=1)
    canvas.event_generate('<B1-Motion>',x=round(b[0]),y=round(b[1]),state=257)
    canvas.event_generate('<ButtonRelease-1>',x=round(b[0]),y=round(b[1]),state=1)
    self.root.update();w.refresh_command_preview();self.root.update()
    self.assertEqual(canvas.selection_count,0)
    editor.simple_rectangle((-25,-15),(25,15));self.root.update()
    gui.button(w,'選択を確定').invoke()
   except Exception as exc:self.errors.append(exc);w.destroy()
  self.root.after(200,inspect)
  result=edit_command(self.root,dict(type='SELECT'),self.app.data['blocks'],self.app.data,point_sources=prior)
  self.assertIsNotNone(result)
  self.assertTrue(all('点(' in q['x1'] for q in result['selections']))
  p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=prior+[result])]
  self.assertEqual(compile_project(p,[0])[1][-1]['selected_count'],2)
 def test_more_than_100_figures_need_no_extra_user_action(self):
  prior=[dict(type='LINE',x1='0',y1=str(i*5),x2='10',y2=str(i*5)) for i in range(101)]
  def inspect():
   w=gui.top(self.root,'コマンドの設定')
   try:
    w.refresh_command_preview();self.root.update()
    w.select_editor.simple_rectangle((-1,-1),(11,501));self.root.update();w.refresh_command_preview();self.root.update()
    self.assertEqual(w.command_preview.canvas.selection_count,101)
    self.assertFalse(self.messages)
    self.assertIn('101',w.select_editor.simple_count.get())
    gui.button(w,'選択を確定').invoke()
   except Exception as exc:self.errors.append(exc);w.destroy()
  self.root.after(200,inspect)
  result=edit_command(self.root,dict(type='SELECT'),self.app.data['blocks'],self.app.data,point_sources=prior)
  self.assertIsInstance(result,dict);self.assertEqual(len(result['selections']),101)
  self.assertFalse(self.messages)
  p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=prior+[result])]
  self.assertEqual(compile_project(p,[0])[1][-1]['selected_count'],101)
