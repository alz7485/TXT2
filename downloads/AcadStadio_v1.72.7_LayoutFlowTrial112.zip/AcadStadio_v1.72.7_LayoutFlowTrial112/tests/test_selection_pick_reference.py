import unittest,sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from selection_pick_reference import exclusion_reference
from selection_sets import resolve,select_queries
from test_native_operations import project
from engine import compile_project,number,MacroError

class ReferencePick(unittest.TestCase):
 def test_crossing_lines_choose_safe_reference_and_follow_move(self):
  aid='p_'+'a'*32;bid='p_'+'b'*32;sid='p_'+'c'*32
  a=dict(type='LINE',point_id=aid,x1='-10',y1='0',x2='10',y2='0')
  b=dict(type='LINE',point_id=bid,x1='0',y1='-10',x2='0',y2='10')
  _,items=compile_project(project([a,b]),[0])
  q=exclusion_reference(items[0],items,(0,0),.01,lambda s:s['point_id'])
  self.assertIn(aid,q['x1']);self.assertTrue(q['unique_pick'])
  q['operation']='subtract'
  selector=dict(type='SELECT',point_id=sid,selection_name='残す線',selections=[dict(mode='window',x1='-100',y1='-100',x4='100',y4='100'),q])
  for y in ('0','20'):
   _,result=compile_project(json.loads(json.dumps(project([dict(a,y1=y,y2=y),b,selector]))),[0])
   self.assertEqual(result[-1]['selected_count'],1)
 def test_circle_avoids_other_types_at_quadrants(self):
  circle=dict(type='CIRCLE',coords=(0,0,10),point_id='p_circle')
  others=[dict(type='POINT',coords=p) for p in ((10,0),(-10,0),(0,10),(0,-10))]
  q=exclusion_reference(circle,[circle]+others,(10,0),.01,lambda s:s['point_id'])
  self.assertIn('点(',q['x1']);self.assertTrue(q['unique_pick'])
  from command_points import selection_geometry_points
  context={'__command_points__':{'p_circle':selection_geometry_points(circle)}}
  evaluated=resolve(dict(selections=[q]),context,number)
  self.assertEqual(select_queries([circle]+others,evaluated,.01),[circle])
 def test_fully_overlapping_lines_are_not_silently_picked(self):
  a=dict(type='LINE',coords=(0,0,10,0))
  with self.assertRaises(ValueError):exclusion_reference(a,[a,dict(a)],(5,0),.01,lambda s:'p_id')
 def test_cross_type_overlap_is_rechecked_during_compilation(self):
  from command_points import selection_geometry_points
  a=dict(type='LINE',coords=(0,0,10,0))
  q=exclusion_reference(a,[a],(5,0),.01,lambda s:'p_id')
  values={'__command_points__':{'p_id':selection_geometry_points(a)}}
  query=resolve(dict(selections=[q]),values,number)[0]
  with self.assertRaises(ValueError):select_queries([a,dict(type='POINT',coords=query['point'])],[query],.01)
