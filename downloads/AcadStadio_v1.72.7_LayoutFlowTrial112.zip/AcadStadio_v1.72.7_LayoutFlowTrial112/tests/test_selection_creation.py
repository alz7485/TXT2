import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from selection_sets import can_create, OPERATORS
class SelectionCreation(unittest.TestCase):
 def test_all_operations_require_immediately_preceding_select(self):
  for kind in OPERATORS:
   with self.subTest(kind=kind):
    self.assertFalse(can_create(kind,[]))
    self.assertFalse(can_create(kind,[{'type':'SELECT'},{'type':'LINE'}]))
    self.assertTrue(can_create(kind,[{'type':'LINE'},{'type':'SELECT'}]))
 def test_normal_commands_can_be_created_without_select(self):
  for kind in ('SELECT','LINE','CIRCLE','IF','REPEAT'):
   self.assertTrue(can_create(kind,[]))
 def test_insertion_position_controls_availability(self):
  from macro_editor import CommandList
  class Listing:
   commands=[{'type':'SELECT'},{'type':'LINE'}]
   def indices(self):return [0]
  self.assertTrue(CommandList.can_add_kind(Listing(),'COPY'))
