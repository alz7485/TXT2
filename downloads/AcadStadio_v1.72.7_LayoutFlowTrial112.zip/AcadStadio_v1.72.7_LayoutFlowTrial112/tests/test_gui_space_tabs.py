import copy,os,sys,unittest
import test_gui as gui
from block_model import new_block
from point_preview_ui import PointCanvas

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class SpaceTabsGui(unittest.TestCase):
 setUp=gui.Gui.setUp
 tearDown=gui.Gui.tearDown
 def test_tabs_switch_block_list_and_geometry_without_changing_output(self):
  p=copy.deepcopy(self.app.data)
  p['blocks']=[new_block('モデル図形',commands=[dict(type='CIRCLE',x='0',y='0',r='10')]),new_block('A4作成',commands=[dict(type='LAYOUT',layout_name='A4')]),new_block('A4図形',commands=[dict(type='CIRCLE',x='100',y='100',r='20')])]
  self.app.replace_document(p);self.root.update();self.app.preview(quiet=True);self.root.update()
  before=self.app.compile()[0];canvas=self.app.canvas;tabs=canvas.space_tabs
  self.assertEqual(tabs.active,'Model');self.assertEqual({i.get('cad_space') for i in canvas.items},{'Model'})
  self.assertTrue(self.app.block_list.exists('0'));self.assertTrue(self.app.block_list.exists('2'))
  self.assertFalse(self.app.block_list.item(self.app.block_list.parent('2'),'open'))
  tabs.notebook.select(tabs.pages['A4']);self.root.update()
  self.assertEqual(tabs.active,'A4');self.assertEqual({i['cad_space'] for i in canvas.items},{'A4'})
  self.assertTrue(self.app.block_list.exists('0'));self.assertTrue(self.app.block_list.exists('2'))
  self.assertFalse(self.app.block_list.item(self.app.block_list.parent('0'),'open'));self.assertTrue(self.app.block_list.item(self.app.block_list.parent('2'),'open'))
  self.assertEqual(self.app.compile()[0],before)
  self.assertEqual(self.errors,[])
 def test_model_camera_restored_after_layout_tab_switch(self):
  self.app.data['blocks'].append(new_block('紙',commands=[dict(type='CIRCLE',x='1000',y='1000',r='10')]))
  self.app.data['blocks'][-1]['drawing_space']='A4'
  self.app.refresh();self.app.preview(quiet=True);self.root.update()
  canvas=self.app.canvas;canvas.pan=[21.,32.];canvas.view_ratio=1.5;canvas.fit(preserve=True)
  before=(canvas.view_ratio,list(canvas.pan));tabs=canvas.space_tabs
  tabs.notebook.select(tabs.pages['A4']);self.root.update();tabs.notebook.select(tabs.pages['Model']);self.root.update()
  self.assertEqual((canvas.view_ratio,list(canvas.pan)),before)
 def test_new_block_uses_selected_layout(self):
  self.app.data['blocks'].append(new_block('A4',commands=[dict(type='LAYOUT',layout_name='A4')]))
  self.app.refresh();self.app.preview(quiet=True);self.root.update()
  tabs=self.app.canvas.space_tabs;tabs.notebook.select(tabs.pages['A4']);self.root.update()
  self.app.add_block();self.root.update();win=gui.top(self.root,'ブロック編集')
  gui.button(win,'ブロックを反映').invoke();self.root.update()
  self.assertEqual(self.app.data['blocks'][-1]['drawing_space'],'A4')
 def test_world_camera_is_independent_after_creating_empty_layout(self):
  from unittest.mock import patch
  self.root.update();self.app.preview(quiet=True);self.root.update()
  c=self.app.canvas;c.view_ratio=2.3;c.pan=[75.,-31.];c.fit(preserve=True,preserve_camera=True)
  before=(PointCanvas.screen_point(c,(0,0)),PointCanvas.screen_point(c,(100,50)),c.get_view())
  with patch('tkinter.simpledialog.askstring',return_value='新レイアウト'):self.app.create_layout()
  self.root.update();self.assertEqual(c.space_tabs.active,'新レイアウト')
  c.view_ratio=1.4;c.pan=[-11.,44.];c.fit(preserve=True,preserve_camera=True)
  paper=(PointCanvas.screen_point(c,(0,0)),c.get_view())
  for _ in range(3):
   c.space_tabs.select_space('Model');self.root.update()
   self.assertEqual(c.get_view(),before[2])
   for actual,expected in zip((PointCanvas.screen_point(c,(0,0)),PointCanvas.screen_point(c,(100,50))),before[:2]):
    for a,b in zip(actual,expected):self.assertAlmostEqual(a,b)
   c.space_tabs.select_space('新レイアウト');self.root.update()
   self.assertEqual(c.get_view(),paper[1])
   for a,b in zip(PointCanvas.screen_point(c,(0,0)),paper[0]):self.assertAlmostEqual(a,b)
 def test_layout_refresh_preserves_model_world_camera(self):
  self.app.data['blocks'].append(dict(new_block('用紙',commands=[dict(type='CIRCLE',x='1000',y='1000',r='50')]),drawing_space='A4'))
  self.app.refresh();self.app.preview(quiet=True);self.root.update();c=self.app.canvas;t=c.space_tabs
  c.view_ratio=1.8;c.pan=[33.,44.];c.fit(preserve=True,preserve_camera=True)
  before=PointCanvas.screen_point(c,(23,45));t.select_space('A4');self.root.update()
  c.view_ratio=.7;c.pan=[-40.,50.];c.fit(preserve=True,preserve_camera=True)
  self.app.preview(quiet=True);self.root.update();t.select_space('Model');self.root.update()
  for a,b in zip(PointCanvas.screen_point(c,(23,45)),before):self.assertAlmostEqual(a,b)
