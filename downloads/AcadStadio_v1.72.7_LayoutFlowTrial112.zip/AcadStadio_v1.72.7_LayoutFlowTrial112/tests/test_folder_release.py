import copy,json,unittest
from sample_project import EXAMPLE
from block_folders import create_folder,release_folder,ordered_child_tokens,folder,validate_folders
from block_model import new_block
from space_folders import ensure_space_folders,root_for,create_layout
from engine import compile_project
from project_model import normalize_sequential_project

class FolderRelease(unittest.TestCase):
    def sample(self):
        p=copy.deepcopy(EXAMPLE);ensure_space_folders(p);root=root_for(p)['id']
        before=create_folder(p,'前',root);target=create_folder(p,'解放',root);after=create_folder(p,'後',root);child=create_folder(p,'子',target['id'])
        p['blocks']=[new_block('先',commands=[dict(type='POINT',x='0',y='0')]),new_block('中',commands=[dict(type='POINT',x='1',y='0')]),new_block('子内',commands=[dict(type='POINT',x='2',y='0')]),new_block('後内',commands=[dict(type='POINT',x='3',y='0')])]
        for b,f in zip(p['blocks'],(root,target['id'],child['id'],after['id'])):b['folder_id']=f
        return p,root,before,target,after,child
    def test_lifts_at_folder_slot_without_changing_commands_ids_or_drawing_order(self):
        p,root,before,target,after,child=self.sample();ids=[b['id'] for b in p['blocks']];commands=copy.deepcopy([b['commands'] for b in p['blocks']]);script=compile_project(p,[0])[0]
        result=release_folder(p,target['id'])
        self.assertEqual([b['id'] for b in p['blocks']],ids);self.assertEqual([b['commands'] for b in p['blocks']],commands);self.assertEqual(compile_project(p,[0])[0],script)
        self.assertEqual(p['blocks'][1]['folder_id'],root);self.assertEqual(p['blocks'][2]['folder_id'],child['id']);self.assertEqual(folder(p,child['id'])['parent_id'],root)
        self.assertEqual(ordered_child_tokens(p,root),['folder:'+before['id'],'block:'+ids[0],'block:'+ids[1],'folder:'+child['id'],'folder:'+after['id']])
        self.assertEqual(validate_folders(p),[]);self.assertEqual(normalize_sequential_project(json.loads(json.dumps(p)))['block_tree_order'],p['block_tree_order'])
    def test_names_collisions_and_nested_release(self):
        p,root,before,target,after,child=self.sample();create_folder(p,'子',root)
        release_folder(p,target['id']);self.assertEqual(folder(p,child['id'])['name'],'子 (2)')
        release_folder(p,child['id']);self.assertEqual(p['blocks'][2]['folder_id'],root)
        self.assertEqual(validate_folders(p),[])
    def test_root_protection_and_empty_folder(self):
        p,root,*_=self.sample();before=copy.deepcopy(p)
        with self.assertRaises(ValueError):release_folder(p,root)
        self.assertEqual(p,before)
        p,f=create_layout(p,'A4');before=copy.deepcopy(p)
        with self.assertRaises(ValueError):release_folder(p,f)
        self.assertEqual(p,before)
        empty=create_folder(p,'空',root);release_folder(p,empty['id']);self.assertFalse(any(f['id']==empty['id'] for f in p['block_folders']))
    def test_later_execution_order_move_updates_block_slots(self):
        from block_folders import sync_tree_block_order
        p,root,before,target,after,child=self.sample();release_folder(p,target['id']);baseline=copy.deepcopy(p)
        p['blocks'][0],p['blocks'][1]=p['blocks'][1],p['blocks'][0]
        sync_tree_block_order(baseline,p)
        tokens=ordered_child_tokens(p,root)
        self.assertEqual([t for t in tokens if t.startswith('folder:')],['folder:'+before['id'],'folder:'+child['id'],'folder:'+after['id']])
        self.assertEqual([t for t in tokens if t.startswith('block:')],['block:'+p['blocks'][0]['id'],'block:'+p['blocks'][1]['id']])
