# -*- coding: utf-8 -*-
"""各種ダイアログ：項目マスタ編集、項目追加、水平移動の選択、設定、新規工事。"""
from __future__ import annotations

from datetime import date, timedelta

from PySide6.QtCore import QDate, QPointF, QSize, Qt
from PySide6.QtGui import QColor, QIcon, QPainter, QPen, QPolygonF
from PySide6.QtWidgets import (QAbstractItemView, QSplitter, QTabWidget, QCheckBox, QColorDialog, QComboBox, QDateEdit,
                               QDialog, QDialogButtonBox, QDoubleSpinBox,
                               QFormLayout, QGroupBox, QHBoxLayout, QLabel,
                               QHeaderView, QInputDialog, QLineEdit, QMenu, QMessageBox,
                               QListWidget, QListWidgetItem, QPushButton, QRadioButton,
                               QScrollArea, QSpinBox, QTreeWidget, QTreeWidgetItem,
                               QStackedWidget, QTableWidget, QTableWidgetItem,
                               QVBoxLayout, QWidget)

from . import model as md
from .fontutil import font, style_calendar
from .gantt import vivid
from .icons import icon_pixmap
from .item_editor import HoursSpinBox
from .panels import fmt_d


def _hours_to_text(hours: dict) -> str:
    return ", ".join(f"{k}:{v:g}" for k, v in (hours or {}).items())


def _text_to_hours(text: str) -> dict:
    out = {}
    for part in text.replace("、", ",").split(","):
        part = part.strip()
        if not part or ":" not in part:
            continue
        k, v = part.split(":", 1)
        try:
            out[k.strip()] = float(v.strip())
        except ValueError:
            pass
    return out


class MasterDialog(QDialog):
    """Item defaults with typed per-role unit hours and a live bar preview."""

    def __init__(self, master: md.Master | None = None, parent=None, used_colors=None):
        super().__init__(parent)
        from .item_editor import EDITOR_STYLE, button, card, label
        from .ui import action_icon, install_ui
        install_ui()
        self.setObjectName('itemEditor')
        self.setStyleSheet(EDITOR_STYLE)
        self.setWindowTitle('項目の登録' if master is None else '項目マスタの編集')
        self.resize(960, 680)
        self.master = master if master is not None else md.Master(name='', color=md.suggest_master_color(used_colors or []))
        self._color = self.master.color
        self._attr_hours = {}
        self._attr_key = 0
        self._loading_roles = True
        lay = QVBoxLayout(self)
        lay.addWidget(label('項目を登録' if master is None else '項目マスタを編集', title=True))
        lay.addWidget(label('新しく配置する項目の初期値を設定します。配置済みの項目は変更されません。', hint=True))
        name_form = QFormLayout()
        self.name_edit = QLineEdit(self.master.name)
        self.name_edit.setPlaceholderText('例：図面作成')
        self.name_edit.setAccessibleName('項目名')
        name_form.addRow('項目名', self.name_edit)
        lay.addLayout(name_form)
        self.editor_tabs = QTabWidget()
        lay.addWidget(self.editor_tabs, 1)
        general = QWidget()
        general_lay = QHBoxLayout(general)
        general_lay.setContentsMargins(0, 14, 0, 0)
        settings, settings_lay = card()
        form = QFormLayout()
        form.setVerticalSpacing(16)
        settings_lay.addLayout(form)
        self.kind_combo = QComboBox()
        self.kind_combo.addItem('自部門', 'own')
        self.kind_combo.addItem('他部門', 'ref')
        self.kind_combo.setCurrentIndex(0 if self.master.kind == 'own' else 1)
        form.addRow('種別', self.kind_combo)
        self.cal_combo = QComboBox()
        for key, value in md.CALENDARS.items():
            self.cal_combo.addItem(value['label'], key)
        self.cal_combo.setCurrentIndex(max(0, self.cal_combo.findData(self.master.calendar)))
        form.addRow('カレンダー', self.cal_combo)
        self.days_spin = QSpinBox()
        self.days_spin.setRange(1, 365)
        self.days_spin.setValue(self.master.default_days or 5)
        self.days_spin.setSuffix(' 営業日')
        form.addRow('標準の期間', self.days_spin)
        self.mile_check = QCheckBox('節目として表示する（菱形・日付のみ）')
        self.mile_check.setChecked(self.master.milestone)
        form.addRow('', self.mile_check)
        self.color_btn = button('色を選ぶ', 'palette', self._pick_color)
        form.addRow('バーの色', self.color_btn)
        settings_lay.addStretch(1)
        general_lay.addWidget(settings, 3)
        preview, preview_lay = card()
        preview_lay.addWidget(label('表示プレビュー', hint=True))
        preview_lay.addStretch(1)
        self.bar_preview = QLabel()
        self.bar_preview.setTextFormat(Qt.TextFormat.PlainText)
        self.bar_preview.setWordWrap(True)
        self.bar_preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.bar_preview.setMinimumHeight(56)
        preview_lay.addWidget(self.bar_preview)
        self.preview_caption = label('', hint=True)
        preview_lay.addWidget(self.preview_caption)
        preview_lay.addStretch(1)
        general_lay.addWidget(preview, 2)
        self.editor_tabs.addTab(general, action_icon('gear', on_color='#475569'), '基本設定')
        work = QWidget()
        work_lay = QHBoxLayout(work)
        work_lay.setContentsMargins(0, 14, 0, 0)
        work_lay.setSpacing(12)
        roles_card, roles_lay = card()
        roles_card.setMinimumWidth(200)
        roles_card.setMaximumWidth(270)
        roles_lay.addWidget(label('人員の初期値'))
        roles_lay.addWidget(label('役割名と人数を入力します。', hint=True))
        self.roles_table = QTableWidget(0, 2)
        self.roles_table.setHorizontalHeaderLabels(['役割名', '人数'])
        self._setup_edit_table(self.roles_table)
        self.roles_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.roles_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
        self.roles_table.setColumnWidth(1, 70)
        roles_lay.addWidget(self.roles_table, 1)
        role_actions = QHBoxLayout()
        self.add_role_btn = button('追加', 'plus', lambda: self._add_role_row(md.RoleDef('', 1)))
        self.del_role_btn = button('削除', 'trash', lambda: self._del_row(self.roles_table))
        role_actions.addWidget(self.add_role_btn)
        role_actions.addWidget(self.del_role_btn)
        roles_lay.addLayout(role_actions)
        work_lay.addWidget(roles_card, 1)
        attrs_card, attrs_lay = card()
        attrs_lay.addWidget(label('作業内容・単位時間'))
        attrs_lay.addWidget(label('1単位あたりの時間を、役割ごとに数値で入力します。', hint=True))
        self.attrs_table = QTableWidget(0, 2)
        self._setup_edit_table(self.attrs_table)
        attrs_lay.addWidget(self.attrs_table, 1)
        attr_actions = QHBoxLayout()
        self.add_attr_btn = button('作業内容を追加', 'plus', lambda: self._add_attr_row(md.AttrDef('', '枚', {})))
        self.del_attr_btn = button('削除', 'trash', lambda: self._del_row(self.attrs_table))
        attr_actions.addWidget(self.add_attr_btn)
        attr_actions.addStretch(1)
        attr_actions.addWidget(self.del_attr_btn)
        attrs_lay.addLayout(attr_actions)
        self.hours_hint = label('', hint=True)
        attrs_lay.addWidget(self.hours_hint)
        work_lay.addWidget(attrs_card, 3)
        self.editor_tabs.addTab(work, action_icon('clock', on_color='#475569'), '人員・作業内容')
        for role in self.master.roles:
            self._add_role_row(role)
        self._loading_roles = False
        self._rebuild_attr_columns(self.master.attrs)
        self.roles_table.itemChanged.connect(self._role_name_changed)
        self.roles_table.itemSelectionChanged.connect(self._update_delete_buttons)
        self.attrs_table.itemSelectionChanged.connect(self._update_delete_buttons)
        self.error_label = label('')
        self.error_label.setStyleSheet('color: #b03a2e;')
        self.error_label.hide()
        lay.addWidget(self.error_label)
        footer = QHBoxLayout()
        footer.addWidget(label('変更は「決定」で反映されます。', hint=True))
        footer.addStretch(1)
        self.button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.button_box.button(QDialogButtonBox.StandardButton.Ok).setText('決定')
        self.button_box.button(QDialogButtonBox.StandardButton.Cancel).setText('キャンセル')
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        footer.addWidget(self.button_box)
        lay.addLayout(footer)
        for signal in (self.name_edit.textChanged, self.kind_combo.currentIndexChanged,
                       self.cal_combo.currentIndexChanged, self.days_spin.valueChanged,
                       self.mile_check.toggled):
            signal.connect(self._update_preview)
        self._paint_color_btn()
        self._update_delete_buttons()

    @staticmethod
    def _setup_edit_table(table):
        table.verticalHeader().hide()
        table.verticalHeader().setDefaultSectionSize(38)
        table.setAlternatingRowColors(True)
        table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)

    def _paint_color_btn(self):
        # Keep a neutral, readable color-picker button even for light swatches.
        self.color_btn.setToolTip(self._color)
        self._update_preview()

    def _update_preview(self, *_args):
        color = QColor(self._color)
        luminance = .2126 * color.redF() + .7152 * color.greenF() + .0722 * color.blueF()
        ink = '#24313f' if luminance > .6 else '#ffffff'
        self.bar_preview.setStyleSheet(f'background: {color.name()}; color: {ink}; border-radius: 7px; padding: 12px; font-weight: bold;')
        name = self.name_edit.text().strip() or '項目名のプレビュー'
        self.bar_preview.setText(('◇ ' if self.mile_check.isChecked() else '') + name)
        self.days_spin.setEnabled(not self.mile_check.isChecked())
        duration = '日付のみ' if self.mile_check.isChecked() else f'{self.days_spin.value()}営業日'
        self.preview_caption.setText(f'{self.kind_combo.currentText()}  /  {duration}\n{self.cal_combo.currentText()}  /  {color.name().upper()}')

    def _pick_color(self):
        color = QColorDialog.getColor(QColor(self._color), self)
        if color.isValid():
            self._color = color.name()
            self._paint_color_btn()

    def _add_role_row(self, role):
        row = self.roles_table.rowCount()
        self.roles_table.insertRow(row)
        item = QTableWidgetItem(role.name)
        item.setData(Qt.ItemDataRole.UserRole, role.name)
        self.roles_table.setItem(row, 0, item)
        spin = QSpinBox()
        spin.setRange(0, 99)
        spin.setValue(role.headcount or 0)
        spin.setSuffix(' 人')
        spin.setAccessibleName(f'{role.name or "役割"}の人数')
        self.roles_table.setCellWidget(row, 1, spin)
        if not self._loading_roles:
            self._rebuild_attr_columns(self._read_attrs())
            self.roles_table.setCurrentCell(row, 0)
            self.roles_table.editItem(item)
            self._update_delete_buttons()

    def _role_name_changed(self, item):
        if item.column() != 0:
            return
        old = item.data(Qt.ItemDataRole.UserRole) or ''
        new = item.text().strip()
        records = self._read_attrs()
        names = [self.roles_table.item(row, 0).text().strip() for row in range(self.roles_table.rowCount())]
        # Do not merge two different rates if a duplicate name is being entered.
        if old and new and old != new and names.count(new) == 1:
            for attr in records:
                if old in attr.hours and new not in attr.hours:
                    attr.hours[new] = attr.hours.pop(old)
        self.roles_table.blockSignals(True)
        if new and names.count(new) == 1:
            item.setData(Qt.ItemDataRole.UserRole, new)
        self.roles_table.blockSignals(False)
        self._rebuild_attr_columns(records)

    def _read_attrs(self):
        records = []
        for row in range(self.attrs_table.rowCount()):
            name_item = self.attrs_table.item(row, 0)
            unit_item = self.attrs_table.item(row, 1)
            records.append(md.AttrDef(name_item.text() if name_item else '',
                                      unit_item.text() if unit_item else '枚',
                                      dict(self._attr_hours.get(name_item.data(Qt.ItemDataRole.UserRole), {}))))
        return records

    def _rebuild_attr_columns(self, records):
        role_names = list(dict.fromkeys(self.roles_table.item(row, 0).text().strip()
                          for row in range(self.roles_table.rowCount())
                          if self.roles_table.item(row, 0).text().strip()))
        all_names = list(role_names)
        for attr in records:
            all_names.extend(name for name in (attr.hours or {}) if name not in all_names)
        self.hours_hint.setText(
            '例：配管図・単位「枚」・作成3h → 配管図1枚の作成に3時間。\n未登録の役割の時間も保持し、「未登録」と表示します。' if all_names else
            '左の人員で役割を追加すると、単位時間の入力欄が表示されます。')
        self._hours_columns = all_names
        self.attrs_table.setRowCount(0)
        self._attr_hours.clear()
        self.attrs_table.setColumnCount(2 + len(all_names))
        self.attrs_table.setHorizontalHeaderLabels(['作業名', '単位'] +
            [f'{name}\n' + ('時間 (h)' if name in role_names else '未登録 (h)') for name in all_names])
        self.attrs_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.attrs_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.attrs_table.setColumnWidth(1, 64)
        for col in range(2, self.attrs_table.columnCount()):
            self.attrs_table.setColumnWidth(col, 100)
        for attr in records:
            self._insert_attr(attr)
        if hasattr(self, 'del_attr_btn'):
            self._update_delete_buttons()

    def _insert_attr(self, attr):
        row = self.attrs_table.rowCount()
        self.attrs_table.insertRow(row)
        key = self._attr_key
        self._attr_key += 1
        self._attr_hours[key] = dict(attr.hours or {})
        name = QTableWidgetItem(attr.name)
        name.setData(Qt.ItemDataRole.UserRole, key)
        name.setToolTip(attr.name)
        self.attrs_table.setItem(row, 0, name)
        unit = QTableWidgetItem(attr.unit)
        unit.setToolTip(attr.unit)
        self.attrs_table.setItem(row, 1, unit)
        for col, role in enumerate(self._hours_columns, 2):
            spin = HoursSpinBox()
            spin.setDecimals(6)
            spin.setRange(0, 1000000000)
            spin.setSingleStep(.5)
            spin.setSuffix(' h')
            spin.setValue((attr.hours or {}).get(role, 0))
            spin.setAccessibleName(f'{attr.name or "作業"}・{role}の1単位あたりの時間')
            spin.setToolTip('1単位あたりの時間。右上・右下のボタンで0.5時間ずつ変更できます。')
            spin.valueChanged.connect(lambda value, k=key, r=role: self._attr_hours[k].__setitem__(r, value))
            self.attrs_table.setCellWidget(row, col, spin)

    def _add_attr_row(self, attr):
        records = self._read_attrs() + [attr]
        self._rebuild_attr_columns(records)
        row = self.attrs_table.rowCount() - 1
        self.attrs_table.setCurrentCell(row, 0)
        self.attrs_table.editItem(self.attrs_table.item(row, 0))

    def _del_row(self, table):
        row = table.currentRow()
        if row < 0:
            return
        records = self._read_attrs()
        table.removeRow(row)
        if table is self.roles_table:
            self._rebuild_attr_columns(records)
        self._update_delete_buttons()

    def _update_delete_buttons(self):
        self.del_role_btn.setEnabled(self.roles_table.currentRow() >= 0)
        self.del_attr_btn.setEnabled(self.attrs_table.currentRow() >= 0)

    def accept(self):
        if not self.name_edit.text().strip():
            self.error_label.setText('項目名を入力してください。')
            self.error_label.show()
            self.name_edit.setFocus()
            return
        names = [self.roles_table.item(row, 0).text().strip() for row in range(self.roles_table.rowCount())]
        attr_names = [attr.name.strip() for attr in self._read_attrs()]
        message = ('役割名を入力してください。' if any(not name for name in names) else
                   '同じ役割名が重複しています。名前を分けてください。' if len(names) != len(set(names)) else
                   '作業名を入力してください。' if any(not name for name in attr_names) else
                   '同じ作業名が重複しています。名前を分けてください。' if len(attr_names) != len(set(attr_names)) else '')
        if message:
            self.editor_tabs.setCurrentIndex(1)
            self.error_label.setText(message)
            self.error_label.show()
            return
        super().accept()

    def result_master(self):
        master = self.master
        master.name = self.name_edit.text().strip() or '（無名）'
        master.kind = self.kind_combo.currentData()
        master.calendar = self.cal_combo.currentData()
        master.default_days = self.days_spin.value()
        master.color = self._color
        master.milestone = self.mile_check.isChecked()
        master.roles = [md.RoleDef(self.roles_table.item(row, 0).text().strip(),
                                   self.roles_table.cellWidget(row, 1).value())
                        for row in range(self.roles_table.rowCount())
                        if self.roles_table.item(row, 0).text().strip()]
        master.attrs = [md.AttrDef(attr.name.strip(), attr.unit.strip() or '枚', dict(attr.hours))
                        for attr in self._read_attrs() if attr.name.strip()]
        return master


class AddItemDialog(QDialog):
    """登録済み項目から選ぶ。新規作成もここから。"""

    def __init__(self, data: md.AppData, tracks, parent=None):
        super().__init__(parent)
        self.setWindowTitle("項目を追加")
        self.data = data
        self.new_master_requested = False
        lay = QVBoxLayout(self)
        form = QFormLayout()
        self.track_combo = QComboBox()
        for tr in tracks:
            self.track_combo.addItem(tr.name, tr.id)
        form.addRow("追加先の系列", self.track_combo)
        lay.addLayout(form)
        self.list = QListWidget()
        for m in data.masters:
            self.list.addItem(m.name)
        if data.masters:
            self.list.setCurrentRow(0)
        lay.addWidget(self.list)
        btns = QHBoxLayout()
        add_btn = QPushButton("選択した項目を追加")
        add_btn.clicked.connect(self.accept)
        new_btn = QPushButton("新たに作成して登録…")
        new_btn.clicked.connect(self._new)
        cancel_btn = QPushButton("キャンセル")
        cancel_btn.clicked.connect(self.reject)
        btns.addWidget(add_btn)
        btns.addWidget(new_btn)
        btns.addStretch(1)
        btns.addWidget(cancel_btn)
        lay.addLayout(btns)

    def _new(self):
        self.new_master_requested = True
        self.accept()

    def chosen_master(self):
        row = self.list.currentRow()
        if 0 <= row < len(self.data.masters):
            return self.data.masters[row]
        return None

    def chosen_track_id(self):
        return self.track_combo.currentData()


class ShiftDialog(QDialog):
    """水平移動の対象を選ぶチェックリスト。"""

    def __init__(self, candidates, parent=None):
        super().__init__(parent)
        self.setWindowTitle("水平移動する後ろ工程の選択")
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("チェックした工程だけを、重なった分だけ横にずらします（期間は変わりません）。"))
        self.checks = []
        first_open = next((i for i, t in enumerate(candidates)
                           if not t.locked_any), -1)
        for i, t in enumerate(candidates):
            cb = QCheckBox(
                f"{t.name}"
                f"（{t.start[2:].replace('-', '/')} 〜 {t.end[2:].replace('-', '/')}）")
            if t.locked_any:
                cb.setChecked(False)
                cb.setEnabled(False)   # ロック中の工程は動かせない
            else:
                cb.setChecked(i == first_open)
            cb.setProperty("task_id", t.id)
            self.checks.append(cb)
            if t.locked_any:
                row_w = QWidget()
                hb = QHBoxLayout(row_w)
                hb.setContentsMargins(0, 0, 0, 0)
                hb.setSpacing(4)
                hb.addWidget(cb)
                ic = QLabel()
                ic.setPixmap(icon_pixmap("lock", "#786e64").scaled(
                    15, 15, Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation))
                ic.setToolTip("日付ロック中は動かせません")
                hb.addWidget(ic)
                hb.addStretch(1)
                lay.addWidget(row_w)
            else:
                lay.addWidget(cb)
        box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                               | QDialogButtonBox.StandardButton.Cancel)
        box.button(QDialogButtonBox.StandardButton.Ok).setText("決定")
        box.accepted.connect(self.accept)
        box.rejected.connect(self.reject)
        lay.addWidget(box)

    def chosen_ids(self):
        return [cb.property("task_id") for cb in self.checks if cb.isChecked()]


class SettingsDialog(QDialog):
    def __init__(self, settings: md.Settings, parent=None):
        super().__init__(parent)
        self.setWindowTitle("設定")
        lay = QVBoxLayout(self)
        self.strips_check = QCheckBox("ガントに作業時間・作業内容を表示する")
        self.strips_check.setChecked(settings.show_jinko
                                      and settings.show_attrs)
        lay.addWidget(self.strips_check)
        lay.addWidget(QLabel("※オフでも、ドラッグ中はバーの側に選択中の日付を表示します"))
        form = QFormLayout()
        self.hours_spin = QDoubleSpinBox()
        self.hours_spin.setRange(1.0, 24.0)
        self.hours_spin.setSingleStep(0.25)
        self.hours_spin.setValue(settings.hours_per_day)
        self.hours_spin.setSuffix(" 時間")
        form.addRow("1日の勤務時間（作業時間の換算）", self.hours_spin)
        lay.addLayout(form)
        lay.addWidget(QLabel(md.holiday_status_text()))
        box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                               | QDialogButtonBox.StandardButton.Cancel)
        box.button(QDialogButtonBox.StandardButton.Ok).setText("決定")
        box.accepted.connect(self.accept)
        box.rejected.connect(self.reject)
        lay.addWidget(box)

    def apply_to(self, settings: md.Settings):
        settings.hours_per_day = self.hours_spin.value()
        settings.hours_per_day_set = True
        settings.show_jinko = self.strips_check.isChecked()
        settings.show_attrs = self.strips_check.isChecked()


class ItemPresetDialog(QDialog):
    """Searchable preset preview and master library in one editing hub."""

    def __init__(self, data, parent=None, on_save=None, on_manage=None):
        super().__init__(parent)
        from .item_editor import EDITOR_STYLE, MasterLibrary, button, card, label, table
        from .ui import action_icon, install_ui
        install_ui()
        self.data = data
        self.apply_id = ''
        self._on_save, self._on_manage = on_save, on_manage
        self.changed = False
        self.setObjectName('itemEditor')
        self.setStyleSheet(EDITOR_STYLE)
        self.setWindowTitle('項目編集')
        self.resize(980, 700)
        lay = QVBoxLayout(self)
        lay.addWidget(label('項目編集', title=True))
        lay.addWidget(label('工程の並びを選ぶ、または新しく配置する項目の初期値を編集します。', hint=True))
        self.tabs = QTabWidget()
        lay.addWidget(self.tabs, 1)
        preset_page = QWidget()
        page = QVBoxLayout(preset_page)
        page.setContentsMargins(0, 12, 0, 0)
        page.setSpacing(12)
        search_row = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText('プリセット名で検索…')
        self.search.setClearButtonEnabled(True)
        self.search.setAccessibleName('項目プリセットを検索')
        search_row.addWidget(self.search, 1)
        self.save_btn = button('現在の並びを登録…', 'floppy', self._save)
        self.save_btn.setEnabled(on_save is not None)
        search_row.addWidget(self.save_btn)
        page.addLayout(search_row)
        split = QSplitter()
        split.setChildrenCollapsible(False)
        self.list = QListWidget()
        self.list.setMinimumWidth(210)
        self.list.setAccessibleName('項目プリセット一覧')
        split.addWidget(self.list)
        preview, preview_lay = card()
        self.preview_title = label('プリセットを選択してください', title=True)
        self.preview_summary = label('', hint=True)
        preview_lay.addWidget(self.preview_title)
        preview_lay.addWidget(self.preview_summary)
        self.preview_table = table(['順番', '項目名', '系列', '標準期間'])
        self.preview_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        self.preview_table.setColumnWidth(0, 48)
        preview_lay.addWidget(self.preview_table, 1)
        self.preview_hint = label('', hint=True)
        preview_lay.addWidget(self.preview_hint)
        split.addWidget(preview)
        split.setSizes([280, 550])
        page.addWidget(split, 1)
        self.notice = label('適用すると、現在の工事の項目と日付をプリセットで置き換えます。確認後に実行されます。', hint=True)
        self.notice.setStyleSheet('background: #fff3dc; color: #806026; padding: 10px; border-radius: 6px;')
        page.addWidget(self.notice)
        row = QHBoxLayout()
        self.rename_btn = button('名前変更…', 'pencil', self._rename)
        self.del_btn = button('削除…', 'trash', self._delete)
        self.apply_btn = button('このプリセットで並べ直す', 'check', self._apply, primary=True)
        row.addWidget(self.rename_btn)
        row.addWidget(self.del_btn)
        self.count = label('', hint=True)
        row.addWidget(self.count)
        row.addStretch(1)
        row.addWidget(self.apply_btn)
        page.addLayout(row)
        self.tabs.addTab(preset_page, action_icon('list', on_color='#475569'), '項目プリセット')
        self.library = MasterLibrary(data, self)
        self.library.changed.connect(self._masters_changed)
        self.tabs.addTab(self.library, action_icon('pencil', on_color='#475569'), '項目マスタ')
        footer = QHBoxLayout()
        footer.addWidget(label('登録内容はメイン画面の「保存」で保存されます。', hint=True), 1)
        self.close_btn = button('閉じる', 'close', self.reject)
        footer.addWidget(self.close_btn)
        lay.addLayout(footer)
        self.search.textChanged.connect(self._reload)
        self.list.currentItemChanged.connect(self._preview)
        self.list.itemDoubleClicked.connect(lambda *_: self._apply())
        self._reload()

    def _selected(self):
        item = self.list.currentItem()
        return next((p for p in self.data.presets if item and p.id == item.data(Qt.ItemDataRole.UserRole)), None)

    def _reload(self, *_args, select_id=None):
        selected = select_id or (self._selected().id if self._selected() else '')
        query = self.search.text().strip().casefold()
        self.list.blockSignals(True)
        self.list.clear()
        for preset in self.data.presets:
            if query and query not in preset.name.casefold():
                continue
            item = QListWidgetItem(f'{preset.name}\n{len(preset.entries)}項目 · {len(preset.tracks)}系列')
            item.setData(Qt.ItemDataRole.UserRole, preset.id)
            item.setToolTip(preset.name)
            self.list.addItem(item)
        row = next((i for i in range(self.list.count()) if self.list.item(i).data(Qt.ItemDataRole.UserRole) == selected), 0)
        self.list.setCurrentRow(row if self.list.count() else -1)
        self.list.blockSignals(False)
        self.count.setText(f'{self.list.count()} / {len(self.data.presets)} 件')
        self._preview()

    def _preview(self, *_args):
        preset = self._selected()
        self.preview_table.setRowCount(0)
        self.del_btn.setEnabled(preset is not None)
        self.rename_btn.setEnabled(preset is not None)
        missing = []
        if preset:
            self.preview_title.setText(preset.name)
            self.preview_summary.setText(f'{len(preset.entries)}項目  /  {len(preset.tracks)}系列')
            for row, entry in enumerate(preset.entries):
                master = self.data.master_by_id(entry.master_id)
                self.preview_table.insertRow(row)
                name = master.name if master else '未登録の項目マスタ'
                duration = ('節目' if master.milestone else f'{master.default_days}営業日') if master else '—'
                if master is None:
                    missing.append(entry.master_id)
                for col, value in enumerate((str(row + 1), name, entry.track_name, duration)):
                    item = QTableWidgetItem(value)
                    item.setToolTip(value)
                    if master is None:
                        item.setForeground(QColor('#b03a2e'))
                    self.preview_table.setItem(row, col, item)
            self.preview_hint.setText('未登録の項目マスタが含まれています。マスタを復元してから適用してください。' if missing else
                                      '登録順に表示しています。日付は現在の工事の開始日を基準に設定されます。')
        else:
            self.preview_title.setText('該当するプリセットがありません')
            self.preview_summary.setText('検索条件を変えるか、現在の並びを登録してください。')
            self.preview_hint.setText('')
        read_only = bool(getattr(self.parent(), '_read_only', False))
        self.apply_btn.setEnabled(preset is not None and not missing and not read_only)
        self.apply_btn.setToolTip('現在の工事は閲覧専用です。編集権を取得してから適用してください。' if read_only else '')
        if read_only:
            self.notice.setText('現在の工事は閲覧専用です。編集権を取得するとプリセットを適用できます。')

    def _rename(self):
        preset = self._selected()
        if preset is None:
            return
        name, ok = QInputDialog.getText(
            self, 'プリセットの名前変更', '新しいプリセット名', text=preset.name)
        if not ok:
            return
        name = name.strip()
        if not name:
            QMessageBox.warning(self, '名前を確認してください', 'プリセット名を入力してください。')
            return
        if name == preset.name:
            return
        if any(p.id != preset.id and p.name.strip().casefold() == name.casefold()
               for p in self.data.presets):
            QMessageBox.warning(self, '名前を確認してください', '同じ名前のプリセットがあります。別の名前を入力してください。')
            return
        preset.name = name
        self.changed = True
        # Keep the renamed preset selected, including when a filter was active.
        if self.search.text().strip().casefold() not in name.casefold():
            self.search.blockSignals(True)
            self.search.clear()
            self.search.blockSignals(False)
        self._reload(select_id=preset.id)

    def _delete(self):
        preset = self._selected()
        if preset and QMessageBox.question(self, 'プリセットを削除',
                f'項目プリセット「{preset.name}」を削除しますか？\n配置済みの項目は残ります。') == QMessageBox.StandardButton.Yes:
            self.data.presets.remove(preset)
            self.changed = True
            self._reload()

    def _apply(self):
        if self._selected() and self.apply_btn.isEnabled():
            self.apply_id = self._selected().id
            self.accept()

    def _save(self):
        if self._on_save:
            before = {p.id for p in self.data.presets}
            self._on_save()
            added = [p.id for p in self.data.presets if p.id not in before]
            if added:
                self.changed = True
                self.search.clear()
            self._reload(select_id=added[-1] if added else None)

    def _masters_changed(self):
        self.changed = True
        self._preview()

    def _manage(self):
        self.tabs.setCurrentWidget(self.library)


class NewProjectDialog(QDialog):
    def __init__(self, data: md.AppData, parent=None):
        super().__init__(parent)
        self.setWindowTitle("新規工事")
        lay = QVBoxLayout(self)
        form = QFormLayout()
        self.name_edit = QLineEdit()
        form.addRow("工事名", self.name_edit)
        self.preset_combo = QComboBox()
        self.preset_combo.addItem("（空で始める）", "")
        for pr in data.presets:
            self.preset_combo.addItem(pr.name, pr.id)
        if data.presets:
            self.preset_combo.setCurrentIndex(1)
        form.addRow("項目のプリセット", self.preset_combo)
        self.base_edit = QDateEdit()
        self.base_edit.setDisplayFormat("yy/MM/dd")
        self.base_edit.setCalendarPopup(True)
        style_calendar(self.base_edit)
        today = date.today()
        self.base_edit.setDate(QDate(today.year, today.month, 1))
        form.addRow("開始の基準日", self.base_edit)
        lay.addLayout(form)
        hint = QLabel("選んだプリセットの項目が、基準日から順に並びます。\n"
                      "日付は後から項目ごとに直せます。")
        hint.setStyleSheet("color: #786e64;")
        lay.addWidget(hint)
        box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                               | QDialogButtonBox.StandardButton.Cancel)
        box.button(QDialogButtonBox.StandardButton.Ok).setText("決定")
        box.accepted.connect(self.accept)
        box.rejected.connect(self.reject)
        lay.addWidget(box)

    def values(self):
        qd = self.base_edit.date()
        return (self.name_edit.text().strip() or "新規工事",
                self.preset_combo.currentData(),
                date(qd.year(), qd.month(), qd.day()))


class MiniGanttPreview(QWidget):
    """日付設定用の簡易ガント。バーの色は項目の色（メインのガントと同じ）。"""

    HEADER_H = 18
    LABEL_W = 104

    def __init__(self, project, parent=None):
        super().__init__(parent)
        self.project = project
        self._row_h = 15
        self._fit_height()

    def refresh(self):
        self._fit_height()
        self.update()

    def _flat(self):
        rows = []
        if not self.project:
            return rows
        for tr in self.project.tracks:
            for t in self.project.tasks_in_track(tr.id):
                rows.append((tr, t))
        return rows

    def _fit_height(self):
        n = len(self._flat())
        self._row_h = 15 if n <= 14 else max(9, 210 // max(1, n))
        self.setFixedHeight(self.HEADER_H + n * self._row_h + 6)

    def paintEvent(self, _ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        rows = self._flat()
        w = self.width()
        if not rows:
            p.setPen(QColor("#9a927e"))
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter,
                       "項目がありません")
            p.end()
            return
        s = min(t.dstart for _tr, t in rows) - timedelta(days=2)
        e = max(t.dend for _tr, t in rows) + timedelta(days=2)
        span = max(1, (e - s).days)
        plot_w = max(10, w - self.LABEL_W - 8)

        def X(d):
            return self.LABEL_W + (d - s).days / span * plot_w

        p.setFont(font(8))
        cur = date(s.year, s.month, 1)
        while cur <= e:
            x = X(cur)
            p.setPen(QPen(QColor("#e3dcc9"), 1))
            p.drawLine(int(x), self.HEADER_H - 3, int(x), self.height() - 2)
            if x >= self.LABEL_W:
                p.setPen(QColor("#786e64"))
                p.drawText(int(x) + 3, self.HEADER_H - 5, f"{cur.month}月")
            cur = date(cur.year + (1 if cur.month == 12 else 0),
                       1 if cur.month == 12 else cur.month + 1, 1)
        y = self.HEADER_H
        prev_track = None
        for tr, t in rows:
            if prev_track is not None and tr.id != prev_track:
                p.setPen(QPen(QColor("#b8ad92"), 1))
                p.drawLine(0, y, w, y)
            prev_track = tr.id
            cy = y + self._row_h // 2
            p.setFont(font(8))
            p.setPen(QColor("#4a4232") if tr.kind == "own"
                     else QColor("#9a927e"))
            fm = p.fontMetrics()
            name = fm.elidedText(t.name, Qt.TextElideMode.ElideRight,
                                 self.LABEL_W - 6)
            p.drawText(0, y, self.LABEL_W - 6, self._row_h,
                       Qt.AlignmentFlag.AlignRight
                       | Qt.AlignmentFlag.AlignVCenter, name)
            grey = tr.kind == "ref"
            if t.milestone:
                col = QColor("#8a8272") if grey else vivid(QColor(t.color))
                cx = (X(t.dstart)
                      + (X(t.dend + timedelta(days=1)) - X(t.dstart)) / 2)
                r = 4.5
                p.setBrush(col)
                p.setPen(QPen(col.darker(120), 1))
                p.drawPolygon(QPolygonF([
                    QPointF(cx, cy - r), QPointF(cx + r, cy),
                    QPointF(cx, cy + r), QPointF(cx - r, cy)]))
            else:
                col = QColor("#d2ccbd") if grey else vivid(QColor(t.color))
                x1, x2 = X(t.dstart), X(t.dend + timedelta(days=1))
                p.setBrush(col)
                p.setPen(QPen(col.darker(115), 1))
                p.drawRoundedRect(int(x1), int(cy - 4.5),
                                  max(3, int(x2 - x1)), 9, 3, 3)
            y += self._row_h
        p.end()


# ---------------- 日付設定の専用UI（Trial18） ----------------

class DateSettingsPanel(QWidget):
    """項目ごとに開始・終了・期間（営業日）を連動して入れる専用UI。"""

    def __init__(self, project, parent=None):
        super().__init__(parent)
        self.project = project
        self._rows = {}
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        outer.addWidget(scroll, 1)
        cap = QLabel("簡易プレビュー")
        cap.setStyleSheet("font-weight: bold; color: #4a4232;")
        outer.addWidget(cap)
        self.preview = MiniGanttPreview(project)
        outer.addWidget(self.preview)
        body = QWidget()
        self._lay = QVBoxLayout(body)
        self._lay.setContentsMargins(8, 8, 8, 8)
        self._lay.setSpacing(4)
        scroll.setWidget(body)
        self._build()

    def _build(self):
        while self._lay.count():
            item = self._lay.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self._rows = {}
        proj = self.project
        if not proj or not proj.tasks:
            self._lay.addWidget(QLabel(
                "まだ項目がありません。プリセットで並べるか、項目を追加してください。"))
            self._lay.addStretch(1)
            return
        for tr in proj.tracks:
            tasks = proj.tasks_in_track(tr.id)
            if not tasks:
                continue
            head = QLabel(tr.name)
            head.setStyleSheet(
                "font-weight: bold; color: #ffffff; background: #2e4a66;"
                " padding: 3px 8px; border-radius: 3px;"
                if tr.kind == "own" else
                "font-weight: bold; color: #4a4234; background: #d9d3c3;"
                " padding: 3px 8px; border-radius: 3px;")
            self._lay.addWidget(head)
            prev = None
            for t in tasks:
                self._lay.addWidget(self._row_widget(t, prev))
                prev = t
        self._lay.addStretch(1)

    def _row_widget(self, t, prev):
        w = QWidget()
        lay = QHBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(6)
        chip = QLabel()
        chip.setFixedSize(14, 14)
        chip.setStyleSheet(
            f"background: {vivid(QColor(t.color)).name()};"
            " border: 1px solid #8a8272; border-radius: 3px;")
        lay.addWidget(chip)
        name_w = QWidget()
        name_box = QHBoxLayout(name_w)
        name_box.setContentsMargins(0, 0, 0, 0)
        name_box.setSpacing(3)
        if t.locked_any:
            ic = QLabel()
            ic.setPixmap(icon_pixmap("lock", "#786e64").scaled(
                14, 14, Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation))
            name_box.addWidget(ic)
        name_box.addWidget(QLabel(t.name))
        name_w.setFixedWidth(136)
        lay.addWidget(name_w)
        start = QDateEdit()
        start.setDisplayFormat("yy/MM/dd")
        start.setCalendarPopup(True)
        style_calendar(start)
        start.setDate(QDate(t.dstart.year, t.dstart.month, t.dstart.day))
        lay.addWidget(start)
        lay.addWidget(QLabel("～"))
        end = QDateEdit()
        end.setDisplayFormat("yy/MM/dd")
        end.setCalendarPopup(True)
        style_calendar(end)
        end.setDate(QDate(t.dend.year, t.dend.month, t.dend.day))
        lay.addWidget(end)
        period = QSpinBox()
        period.setRange(1, 365)
        period.setValue(max(1, md.task_duration_bd(t)))
        period.setSuffix(" 日")
        period.setFixedWidth(76)
        lay.addWidget(period)
        lock_s = t.lock_start or (t.milestone and t.locked_any)
        lock_e = t.lock_end or (t.milestone and t.locked_any)
        if lock_s:
            start.setEnabled(False)
        if lock_e:
            end.setEnabled(False)
            period.setEnabled(False)
        self._rows[t.id] = {"start": start, "end": end, "period": period}
        start.dateChanged.connect(lambda qd, tid=t.id: self._on_start(tid, qd))
        end.dateChanged.connect(lambda qd, tid=t.id: self._on_end(tid, qd))
        period.valueChanged.connect(lambda v, tid=t.id: self._on_period(tid, v))
        if t.milestone:
            end.setEnabled(False)
            period.setEnabled(False)
            lay.addWidget(QLabel("節目（同日）"))
        elif prev is not None and not lock_s:
            btn = QPushButton("前工程の翌日から")
            btn.setToolTip("開始日を、同じ系列の前工程の終了翌日（営業日）に合わせます")
            btn.clicked.connect(
                lambda _=False, tid=t.id, pid=prev.id: self._chain(tid, pid))
            lay.addWidget(btn)
        lay.addStretch(1)
        return w

    def _task(self, tid):
        return next(t for t in self.project.tasks if t.id == tid)

    def _set_row(self, t):
        row = self._rows.get(t.id)
        if not row:
            return
        for key, d in (("start", t.dstart), ("end", t.dend)):
            w = row[key]
            w.blockSignals(True)
            w.setDate(QDate(d.year, d.month, d.day))
            w.blockSignals(False)
        row["period"].blockSignals(True)
        row["period"].setValue(max(1, md.task_duration_bd(t)))
        row["period"].blockSignals(False)
        self.preview.refresh()

    def _on_start(self, tid, qd):
        t = self._task(tid)
        dur = max(1, md.task_duration_bd(t))
        s = date(qd.year(), qd.month(), qd.day())
        t.start = s.isoformat()
        t.end = (s if t.milestone
                 else md.end_from_duration(s, dur, t.calendar)).isoformat()
        self._set_row(t)

    def _on_end(self, tid, qd):
        t = self._task(tid)
        e = date(qd.year(), qd.month(), qd.day())
        if e < t.dstart:
            e = t.dstart
        t.end = e.isoformat()
        self._set_row(t)

    def _on_period(self, tid, v):
        t = self._task(tid)
        t.end = md.end_from_duration(t.dstart, max(1, v), t.calendar).isoformat()
        self._set_row(t)

    def _chain(self, tid, pid):
        t = self._task(tid)
        prev = self._task(pid)
        dur = max(1, md.task_duration_bd(t))
        s = prev.dend + timedelta(days=1)
        while not md.is_workday(s, t.calendar):
            s += timedelta(days=1)
        t.start = s.isoformat()
        t.end = md.end_from_duration(s, dur, t.calendar).isoformat()
        self._set_row(t)


class DateSettingsDialog(QDialog):
    """日付設定ダイアログ。キャンセルすると変更前の日付に戻る。"""

    def __init__(self, project, parent=None):
        super().__init__(parent)
        self.setWindowTitle("日付の設定")
        self.resize(680, 620)
        self.project = project
        self._snapshot = {t.id: (t.start, t.end) for t in project.tasks}
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("開始・終了・期間は連動します（期間は営業日）。"))
        self.panel = DateSettingsPanel(project)
        lay.addWidget(self.panel, 1)
        box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                               | QDialogButtonBox.StandardButton.Cancel)
        box.button(QDialogButtonBox.StandardButton.Ok).setText("決定")
        box.accepted.connect(self.accept)
        box.rejected.connect(self.reject)
        lay.addWidget(box)

    def reject(self):
        for t in self.project.tasks:
            s, e = self._snapshot.get(t.id, (t.start, t.end))
            t.start, t.end = s, e
        super().reject()


# ---------------- 人員・属性の設定（ウィザード用） ----------------

class PeopleAttrsPanel(QWidget):
    """人員・属性の設定: 名前の変更・追加・削除もその場でできる。"""

    def __init__(self, data, project, parent=None):
        super().__init__(parent)
        self.data = data
        self.project = project
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        outer.addWidget(scroll, 1)
        cap = QLabel("簡易プレビュー")
        cap.setStyleSheet("font-weight: bold; color: #4a4232;")
        outer.addWidget(cap)
        self.preview = MiniGanttPreview(project)
        outer.addWidget(self.preview)
        body = QWidget()
        self._lay = QVBoxLayout(body)
        self._lay.setContentsMargins(8, 8, 8, 8)
        self._lay.setSpacing(4)
        scroll.setWidget(body)
        self._build()

    # ---------- 候補 ----------
    def _role_candidates(self):
        names = []
        for m in self.data.masters:
            for r in m.roles:
                if r.name not in names:
                    names.append(r.name)
        for proj in [self.project] + list(self.data.projects):
            for t in proj.tasks:
                for r in t.roles:
                    if r.name not in names:
                        names.append(r.name)
        return names

    def _attr_candidates(self):
        names = []
        for m in self.data.masters:
            for a in m.attrs:
                if a.name not in names:
                    names.append(a.name)
        for proj in self._all_projects():
            for t in proj.tasks:
                for a in t.attr_defs:
                    if a.name not in names:
                        names.append(a.name)
        return names

    # ---------- 構築 ----------
    @staticmethod
    def _clear_layout(lay):
        while lay.count():
            item = lay.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
            elif item.layout():
                PeopleAttrsPanel._clear_layout(item.layout())

    def _build(self):
        self._clear_layout(self._lay)
        shown = False
        for tr in self.project.tracks:
            for t in self.project.tasks_in_track(tr.id):
                master = self.data.master_by_id(t.master_id)
                defs = t.attr_defs
                if master is None and not t.roles and not defs:
                    continue
                shown = True
                head = QLabel(f"{t.name}（{tr.name}）")
                head.setStyleSheet("font-weight: bold; color: #2e4a66;")
                self._lay.addWidget(head)
                gb_people = self._group_box("人員")
                gl = gb_people.layout()
                for i, r in enumerate(t.roles):
                    gl.addLayout(self._role_row(t, i, r))
                gl.addLayout(self._add_row(
                    [("＋ 役割を追加",
                      lambda task=t: self._add_role(task))]))
                row = QHBoxLayout()
                row.setSpacing(8)
                row.addWidget(gb_people, 1)
                self._lay.addLayout(row)
                gb_attrs = self._group_box("作業内容")
                gl = gb_attrs.layout()
                for i, d in enumerate(defs):
                    gl.addLayout(self._attr_row(t, i, d))
                gl.addLayout(self._add_row(
                    [("＋ 作業内容を追加",
                      lambda task=t: self._add_attr(task))]))
                row.addWidget(gb_attrs, 1)
        if not shown:
            self._lay.addWidget(QLabel(
                "人員・作業内容を設定できる項目がありません。後からプロパティで設定できます。"))
        self._lay.addStretch(1)

    @staticmethod
    def _group_box(title):
        gb = QGroupBox(title)
        gb.setStyleSheet(
            "QGroupBox { border: 1px solid #b8ad92; border-radius: 6px;"
            " margin-top: 10px; background: #ffffff; }"
            "QGroupBox::title { subcontrol-origin: margin; left: 8px;"
            " padding: 0 3px; font-weight: bold; color: #4a4232; }")
        lay = QVBoxLayout(gb)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(4)
        return gb

    @staticmethod
    def _add_row(pairs):
        row = QHBoxLayout()
        row.setContentsMargins(2, 0, 0, 0)
        row.setSpacing(6)
        for text, slot in pairs:
            btn = QPushButton(text)
            btn.clicked.connect(lambda _=False, fn=slot: fn())
            row.addWidget(btn)
        row.addStretch(1)
        return row

    def _role_row(self, t, i, r):
        row = QHBoxLayout()
        row.setContentsMargins(2, 0, 0, 0)
        row.setSpacing(6)
        combo = QComboBox()
        combo.setEditable(True)
        combo.addItems(self._role_candidates())
        combo.setCurrentText(r.name)
        combo.setFixedWidth(130)
        col = md.role_color(r.name)
        combo.setStyleSheet(f"color: {col}; font-weight: bold;")
        combo.lineEdit().setStyleSheet(f"color: {col}; font-weight: bold;")
        combo.lineEdit().editingFinished.connect(
            lambda c=combo, task=t, idx=i: self._role_renamed(task, idx, c))
        combo.currentIndexChanged.connect(
            lambda _ix, c=combo, task=t, idx=i: self._role_renamed(task, idx, c))
        row.addWidget(combo, 0, Qt.AlignmentFlag.AlignVCenter)
        spin = QSpinBox()
        spin.setRange(0, 99)
        spin.setValue(r.headcount or 0)
        spin.setSuffix(" 人")
        spin.setFixedWidth(84)
        spin.valueChanged.connect(
            lambda v, role=r: setattr(role, "headcount", v))
        row.addWidget(spin, 0, Qt.AlignmentFlag.AlignVCenter)
        del_btn = QPushButton("✕")
        del_btn.setFixedWidth(28)
        del_btn.setToolTip("この役割を削除")
        del_btn.clicked.connect(
            lambda _=False, task=t, idx=i: self._del_role(task, idx))
        row.addWidget(del_btn)
        row.addStretch(1)
        return row

    def _attr_row(self, t, i, d):
        row = QHBoxLayout()
        row.setContentsMargins(2, 0, 0, 0)
        row.setSpacing(6)
        combo = QComboBox()
        combo.setEditable(True)
        combo.addItems(self._attr_candidates())
        combo.setCurrentText(d.name)
        combo.setFixedWidth(130)
        combo.setStyleSheet("font-weight: bold;")
        combo.lineEdit().editingFinished.connect(
            lambda c=combo, task=t, idx=i:
            self._attr_renamed(task, idx, c))
        combo.currentIndexChanged.connect(
            lambda _ix, c=combo, task=t, idx=i:
            self._attr_renamed(task, idx, c))
        row.addWidget(combo, 0, Qt.AlignmentFlag.AlignVCenter)
        spin = QSpinBox()
        spin.setRange(0, 99999)
        spin.setValue(int(t.attrs.get(d.name, 0) or 0))
        spin.setSuffix(f" {d.unit}")
        spin.setFixedWidth(96)
        spin.valueChanged.connect(
            lambda v, task=t, name=d.name: task.attrs.__setitem__(name, v))
        row.addWidget(spin, 0, Qt.AlignmentFlag.AlignVCenter)
        del_btn = QPushButton("✕")
        del_btn.setFixedWidth(28)
        del_btn.setToolTip("この作業内容を削除（この項目だけ）")
        del_btn.clicked.connect(
            lambda _=False, task=t, idx=i:
            self._del_attr(task, idx))
        row.addWidget(del_btn)
        row.addStretch(1)
        return row

    # ---------- 編集 ----------
    def _role_renamed(self, task, idx, combo):
        if idx >= len(task.roles):
            return
        role = task.roles[idx]
        new = combo.currentText().strip()
        if not new or new == role.name:
            combo.setCurrentText(role.name)
            return
        if any(r.name == new for r in task.roles):
            combo.setCurrentText(role.name)
            return
        role.name = new
        self._build()

    def _del_role(self, task, idx):
        if idx < len(task.roles):
            task.roles.pop(idx)
            self._build()

    def _add_role(self, task):
        used = {r.name for r in task.roles}
        name = next((c for c in self._role_candidates() if c not in used),
                    "役割")
        base, n = name, 2
        while name in used:
            name = f"{base}{n}"
            n += 1
        task.roles.append(md.RoleDef(name, 0))
        self._build()

    def _all_projects(self):
        return [self.project] + list(self.data.projects)

    def _attr_renamed(self, task, idx, combo):
        if idx >= len(task.attr_defs):
            return
        d = task.attr_defs[idx]
        new = combo.currentText().strip()
        if not new or new == d.name:
            combo.setCurrentText(d.name)
            return
        if any(x.name == new for x in task.attr_defs):
            combo.setCurrentText(d.name)
            return
        old = d.name
        d.name = new
        if old in task.attrs:
            task.attrs[new] = task.attrs.pop(old)
        self._build()

    def _del_attr(self, task, idx):
        if idx >= len(task.attr_defs):
            return
        d = task.attr_defs.pop(idx)
        task.attrs.pop(d.name, None)
        self._build()

    def _add_attr(self, task):
        used = {a.name for a in task.attr_defs}
        name = next((c for c in self._attr_candidates() if c not in used),
                    "新規の作業内容")
        base, n = name, 2
        while name in used:
            name = f"{base}{n}"
            n += 1
        task.attr_defs.append(md.AttrDef(name, "枚", {}))
        task.attrs.setdefault(name, 0)
        self._build()


# ---------------- 作成の案内（ウィザード） ----------------

class CreationWizard(QDialog):
    """一連の案内で工程表を作る: 工事を追加 → プリセット選択 → 日付 → 人員・属性。"""

    TITLES = ["工事を追加", "項目のプリセット選択", "日付の設定",
              "人員・作業内容の設定"]

    def __init__(self, data, parent=None, plants=(), default_plant=""):
        super().__init__(parent)
        self.setWindowTitle("工程表を作成")
        self.resize(720, 640)
        self.data = data
        self.temp_project = None
        self._temp_template_key = None
        self._page3_project_id = None
        root = QVBoxLayout(self)
        self.step_label = QLabel("")
        self.step_label.setStyleSheet(
            "font-size: 13px; font-weight: bold; color: #2e4a66;")
        root.addWidget(self.step_label)
        self.stack = QStackedWidget()
        root.addWidget(self.stack, 1)
        # ページ1: 工事を追加
        p1 = QWidget()
        l1 = QVBoxLayout(p1)
        l1.addWidget(QLabel("工事名を入力してください。"))
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("例：C工事 配管更新")
        l1.addWidget(self.name_edit)
        l1.addSpacing(10)
        l1.addWidget(QLabel("所属プラント（新しい名前を入力すると"
                            "プラントが増えます）"))
        self.plant_combo = QComboBox()
        self.plant_combo.setEditable(True)
        for name in plants:
            self.plant_combo.addItem(name, name)
        if default_plant:
            self.plant_combo.setCurrentText(default_plant)
        elif not plants:
            self.plant_combo.setCurrentText("プラント1")
        l1.addWidget(self.plant_combo)
        l1.addStretch(1)
        self.stack.addWidget(p1)
        # ページ2: 項目のプリセット選択
        p2 = QWidget()
        l2 = QVBoxLayout(p2)
        form = QFormLayout()
        self.preset_combo = QComboBox()
        self.preset_combo.addItem("（空で始める）", "")
        for pr in data.presets:
            self.preset_combo.addItem(pr.name, pr.id)
        if data.presets:
            self.preset_combo.setCurrentIndex(1)
        form.addRow("項目のプリセット", self.preset_combo)
        self.base_edit = QDateEdit()
        self.base_edit.setDisplayFormat("yy/MM/dd")
        self.base_edit.setCalendarPopup(True)
        style_calendar(self.base_edit)
        today = date.today()
        self.base_edit.setDate(QDate(today.year, today.month, 1))
        form.addRow("開始の基準日", self.base_edit)
        l2.addLayout(form)
        l2.addWidget(QLabel("並ぶ項目："))
        self.preview = QListWidget()
        l2.addWidget(self.preview, 1)
        self.preset_combo.currentIndexChanged.connect(self._refresh_preview)
        self._refresh_preview()
        self.stack.addWidget(p2)
        # ページ3・4は入る時に中身を作る
        self.page3 = QWidget()
        self.page3_lay = QVBoxLayout(self.page3)
        self.stack.addWidget(self.page3)
        self.page4 = QWidget()
        self.page4_lay = QVBoxLayout(self.page4)
        self.stack.addWidget(self.page4)
        # ナビゲーション
        nav = QHBoxLayout()
        self.cancel_btn = QPushButton("キャンセル")
        self.cancel_btn.clicked.connect(self.reject)
        self.back_btn = QPushButton("戻る")
        self.back_btn.clicked.connect(self._back)
        self.next_btn = QPushButton("次へ")
        self.next_btn.setProperty("pfPrimary", True)
        self.next_btn.clicked.connect(self._next)
        nav.addWidget(self.cancel_btn)
        nav.addStretch(1)
        nav.addWidget(self.back_btn)
        nav.addWidget(self.next_btn)
        root.addLayout(nav)
        self._enter_page(0)

    def _refresh_preview(self):
        self.preview.clear()
        pid = self.preset_combo.currentData()
        preset = next((x for x in self.data.presets if x.id == pid), None)
        if not preset:
            self.preview.addItem("（項目なし。後から追加できます）")
            return
        for td in preset.tracks:
            self.preview.addItem(f"■ {td['name']}")
            for e in preset.entries:
                if e.track_name != td["name"]:
                    continue
                m = self.data.master_by_id(e.master_id)
                self.preview.addItem(f"　・{m.name if m else '?'}")

    def _ensure_temp(self):
        """戻る/次へでは入力値を保持。プリセット/基準日の変更時のみ作り直す。"""
        name = self.name_edit.text().strip() or "新規工事"
        pid = self.preset_combo.currentData()
        preset = next((x for x in self.data.presets if x.id == pid), None)
        qd = self.base_edit.date()
        base = date(qd.year(), qd.month(), qd.day())
        template_key = (pid, base)
        if self.temp_project is not None and template_key == self._temp_template_key:
            self.temp_project.name = name
            return False
        if preset:
            self.temp_project = md.expand_preset(self.data, preset, name, base)
        else:
            pr = md.Project(name=name)
            pr.tracks.append(md.Track(name="自部門", kind="own"))
            self.temp_project = pr
        self._temp_template_key = template_key
        return True

    @staticmethod
    def _clear(lay):
        while lay.count():
            item = lay.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def _enter_page(self, idx):
        if idx == 2:
            rebuilt = self._ensure_temp()
            if rebuilt or self._page3_project_id != self.temp_project.id:
                self._clear(self.page3_lay)
                self.page3_lay.addWidget(QLabel(
                    "項目ごとに開始・終了・期間を決めてください。仮の日付が入っているので、直すだけで大丈夫です。"))
                self.page3_lay.addWidget(DateSettingsPanel(self.temp_project), 1)
                self._page3_project_id = self.temp_project.id
        elif idx == 3:
            if self.temp_project is None:
                self._ensure_temp()
            self._clear(self.page4_lay)
            self.page4_lay.addWidget(QLabel(
                "人数と数量を入れてください。役割・作業内容は名前の変更や追加・削除もこの画面でできます。"
                "空欄（0）のままでも作成できます。"))
            self.page4_lay.addWidget(
                PeopleAttrsPanel(self.data, self.temp_project), 1)
        seq = " ＞ ".join(
            f"【{t}】" if i == idx else t
            for i, t in enumerate(self.TITLES))
        self.step_label.setText(seq)
        self.back_btn.setEnabled(idx > 0)
        self.next_btn.setText("完了" if idx == len(self.TITLES) - 1 else "次へ")
        from .ui import action_icon
        self.next_btn.setIcon(action_icon("check" if idx == len(self.TITLES) - 1 else "right", "#ffffff"))
        self.next_btn.setAccessibleName(self.next_btn.text())

    def _next(self):
        idx = self.stack.currentIndex()
        if idx == len(self.TITLES) - 1:
            if self.temp_project is None:
                self._ensure_temp()
            self.accept()
            return
        self.stack.setCurrentIndex(idx + 1)
        self._enter_page(idx + 1)

    def _back(self):
        idx = self.stack.currentIndex()
        if idx > 0:
            self.stack.setCurrentIndex(idx - 1)
            self._enter_page(idx - 1)

    def chosen_plant(self):
        return self.plant_combo.currentText().strip()

    def result_project(self):
        return self.temp_project


class PdfExportDialog(QDialog):
    """PDF出力のミニ窓：PDF化する項目にチェックを入れる。"""

    def __init__(self, project_name, saved_items, parent=None):
        super().__init__(parent)
        self.setWindowTitle("PDF出力")
        self.setFont(font(10))
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("PDFにするものを選んでください"))
        from .exports import PDF_ITEMS
        suffix = {"gantt": f"（{project_name}）", "dates": f"（{project_name}）",
                  "parallel": "（全工事）", "jinko": "（全工事）"}
        self.checks = {}
        for key, label in PDF_ITEMS:
            cb = QCheckBox(label + suffix.get(key, ""))
            cb.setChecked(not saved_items or key in saved_items)
            cb.toggled.connect(self._sync)
            self.checks[key] = cb
            lay.addWidget(cb)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel)
        self.ok_btn = bb.addButton("出力…",
                                   QDialogButtonBox.ButtonRole.AcceptRole)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self._sync()

    def _sync(self):
        self.ok_btn.setEnabled(any(cb.isChecked()
                                   for cb in self.checks.values()))

    def items(self):
        return [k for k, cb in self.checks.items() if cb.isChecked()]


class StartupGuideDialog(QDialog):
    """起動時の案内：表示の選び方を決める。前回と同じ表示も選べる。"""

    def __init__(self, data, plants, parent=None, current_ids=None):
        super().__init__(parent)
        self.setWindowTitle("表示の選択")
        self.setFont(font(10))
        self.data = data
        self._current_ids = list(current_ids or [])
        self.presets_changed = False
        st = data.settings
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("どの表示で開きますか？"))
        self.radios = {}
        self.combos = {}

        def add_radio(key, label):
            rb = QRadioButton(label)
            self.radios[key] = rb
            lay.addWidget(rb)
            return rb

        def add_combo(key, items):
            cb = QComboBox()
            for text, val in items:
                cb.addItem(text, val)
            cb.setEnabled(False)
            self.combos[key] = cb
            row = QHBoxLayout()
            row.addSpacing(22)
            row.addWidget(cb, 1)
            lay.addLayout(row)
            return cb

        # 前回と同じ表示（概要つき）
        last_label = "前回と同じ表示"
        if st.view_mode == "preset":
            vp = data.view_preset_by_id(st.view_preset_id)
            if vp:
                last_label += f"（表示プリセット「{vp.name}」）"
        elif st.view_mode == "plant" and st.view_plant:
            last_label += f"（{st.view_plant}の進行中・今後）"
        elif len(st.view_ids) == 1:
            pr = next((x for x in data.projects if x.id == st.view_ids[0]),
                      None)
            if pr:
                last_label += f"（{pr.name}）"
        elif st.view_ids:
            last_label += f"（工事{len(st.view_ids)}件）"
        self.rb_last = add_radio("last", last_label)
        if not st.view_ids and not st.view_mode:
            self.rb_last.setEnabled(False)
            self.rb_last.setText("前回と同じ表示（まだありません）")
        add_radio("single", "工事を単体で開く")
        add_combo("single", [(f"{pr.name}（{pr.plant}）", pr.id)
                             for pr in data.projects])
        self.rb_preset = add_radio("preset", "表示プリセットを開く")
        add_combo("preset", [(vp.name, vp.id) for vp in data.view_presets])
        if not data.view_presets:
            self.rb_preset.setEnabled(False)
            self.combos["preset"].setEnabled(False)
        # 表示プリセットの登録・削除もここで行う（Trial74）
        prow = QHBoxLayout()
        prow.addSpacing(22)
        self.vp_save_btn = QPushButton("現在の表示を登録…")
        self.vp_save_btn.setToolTip("今の表示セットを表示プリセットとして登録")
        self.vp_save_btn.setEnabled(bool(self._current_ids))
        self.vp_save_btn.clicked.connect(self._save_view_preset)
        prow.addWidget(self.vp_save_btn)
        self.vp_del_btn = QPushButton("プリセットを削除…")
        self.vp_del_btn.setEnabled(bool(data.view_presets))
        self.vp_del_btn.clicked.connect(self._delete_view_preset)
        prow.addWidget(self.vp_del_btn)
        prow.addStretch(1)
        lay.addLayout(prow)
        add_radio("plant", "プラントの進行中・今後を表示")
        add_combo("plant", [(name, name) for name in plants])
        for key, rb in self.radios.items():
            rb.toggled.connect(lambda on, k=key: self._sync(k, on))
        # 初期選択：前回があれば前回、なければ単体
        initial = "last" if self.rb_last.isEnabled() else "single"
        if (st.view_mode in ("single", "preset", "plant")
                and not self.rb_last.isEnabled()):
            initial = st.view_mode
        self.radios[initial].setChecked(True)
        self._sync_all()
        if initial == "single" and st.view_ids:
            idx = self.combos["single"].findData(st.view_ids[0])
            if idx >= 0:
                self.combos["single"].setCurrentIndex(idx)
        if initial == "plant" and st.view_plant:
            idx = self.combos["plant"].findData(st.view_plant)
            if idx >= 0:
                self.combos["plant"].setCurrentIndex(idx)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel)
        self.ok_btn = bb.addButton("開く",
                                   QDialogButtonBox.ButtonRole.AcceptRole)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def _refresh_preset_combo(self):
        cb = self.combos["preset"]
        cur = cb.currentData()
        cb.clear()
        for vp in self.data.view_presets:
            cb.addItem(vp.name, vp.id)
        idx = cb.findData(cur)
        if idx >= 0:
            cb.setCurrentIndex(idx)
        has = bool(self.data.view_presets)
        self.rb_preset.setEnabled(has)
        cb.setEnabled(has and self.rb_preset.isChecked())
        self.vp_del_btn.setEnabled(has)

    def _save_view_preset(self):
        if not self._current_ids:
            return
        name, ok = QInputDialog.getText(self, "表示プリセットを登録", "名前：")
        name = (name or "").strip()
        if not ok or not name:
            return
        existing = next((v for v in self.data.view_presets
                         if v.name == name), None)
        if existing:
            if QMessageBox.question(
                    self, "確認",
                    f"「{name}」は既にあります。上書きしますか？") \
                    != QMessageBox.StandardButton.Yes:
                return
            existing.project_ids = list(self._current_ids)
            vid = existing.id
        else:
            vp = md.ViewPreset(name=name,
                               project_ids=list(self._current_ids))
            self.data.view_presets.append(vp)
            vid = vp.id
        self.presets_changed = True
        self._refresh_preset_combo()
        idx = self.combos["preset"].findData(vid)
        if idx >= 0:
            self.combos["preset"].setCurrentIndex(idx)

    def _delete_view_preset(self):
        vid = self.combos["preset"].currentData()
        vp = self.data.view_preset_by_id(vid) if vid else None
        if not vp:
            return
        if QMessageBox.question(
                self, "表示プリセットを削除",
                f"表示プリセット「{vp.name}」を削除しますか？") \
                != QMessageBox.StandardButton.Yes:
            return
        self.data.view_presets.remove(vp)
        self.presets_changed = True
        self._refresh_preset_combo()

    def _sync(self, key, on):
        if key in self.combos:
            self.combos[key].setEnabled(on)

    def _sync_all(self):
        for key, rb in self.radios.items():
            if key in self.combos:
                self.combos[key].setEnabled(rb.isChecked())

    def choice(self):
        """(mode, value)。mode は last/single/preset/plant。"""
        for key, rb in self.radios.items():
            if rb.isChecked():
                if key == "last":
                    return "last", None
                return key, self.combos[key].currentData()
        return "last", None


class ProjectPickerDialog(QDialog):
    """表示セットへ追加する工事を選ぶ（別プラントも選べる）。"""

    def __init__(self, data, exclude_ids, parent=None, title="工事を追加",
                 button_text="追加", single=False):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setFont(font(10))
        # Avoid the compact sizeHint that leaves only two visible rows.
        available = self.screen().availableGeometry()
        self.setMinimumSize(min(440, max(280, available.width() - 48)),
                            min(360, max(240, available.height() - 64)))
        self.resize(min(600, available.width() - 48),
                    min(520, available.height() - 64))
        self.setSizeGripEnabled(True)
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("工事を選んでください" if single else
                             "追加する工事を選んでください（複数選択可）"))
        self.list = QListWidget()
        self.list.setUniformItemSizes(True)
        self.list.setMinimumHeight(180)
        self.list.setAccessibleName('追加する工事の一覧')
        self.list.setSelectionMode(
            QListWidget.SelectionMode.SingleSelection if single
            else QListWidget.SelectionMode.ExtendedSelection)
        for pr in data.projects:
            if pr.id in exclude_ids:
                continue
            item = QListWidgetItem(f"{pr.plant} ／ {pr.name}")
            item.setData(Qt.ItemDataRole.UserRole, pr.id)
            item.setToolTip(f"{pr.plant} ／ {pr.name}")
            item.setSizeHint(QSize(0, max(30, self.list.fontMetrics().height() + 10)))
            self.list.addItem(item)
        self.list.itemDoubleClicked.connect(lambda _i: self.accept())
        lay.addWidget(self.list, 1)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel)
        bb.addButton(button_text, QDialogButtonBox.ButtonRole.AcceptRole)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def chosen_ids(self):
        return [it.data(Qt.ItemDataRole.UserRole)
                for it in self.list.selectedItems()]


class ProjectListDialog(QDialog):
    """工事一覧：プラントと工事の管理画面。

    開き直し／追加表示は callbacks 経由で本体に即反映する。
    新規作成と置き場を開くは requested に積んで閉じ、本体が続ける。
    プラントの追加・名称変更・削除はこの中で data を直接直す（changed）。
    """

    def __init__(self, data, plant_names, callbacks, parent=None,
                 view_provider=None):
        super().__init__(parent)
        self.setWindowTitle("工事一覧")
        self.setFont(font(10))
        self.resize(1180, 680)
        self.data = data
        self.plant_names = plant_names
        self.cb = callbacks
        self.view_provider = view_provider
        self._view_ids = []
        self._base_names = {}
        self.setStyleSheet(
            "QPushButton { background: #fdfbf5; border: 1px solid #b3a888;"
            " border-radius: 4px; padding: 5px 9px; text-align: left; }"
            "QPushButton:hover { background: #f7efdb; }"
            "QPushButton:pressed { background: #fdeed3; }"
            "QPushButton:disabled { color: #a3987f; background: #f3efe4;"
            " border-color: #d5ccb2; }")
        self.changed = False
        self.requested = ""
        root = QVBoxLayout(self)
        body = QHBoxLayout()
        root.addLayout(body, 1)
        left = QVBoxLayout()
        self.view_label = QLabel("現在の表示（0件）")
        self.view_label.setStyleSheet("font-weight: bold; color: #2e4a66;")
        left.addWidget(self.view_label)
        self.view_list = QListWidget()
        self.view_list.setMinimumWidth(215)
        self.view_list.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.view_list.currentRowChanged.connect(
            lambda row: self.btn_arrow_r.setEnabled(row >= 0))
        left.addWidget(self.view_list, 1)
        body.addLayout(left)
        mid = QVBoxLayout()
        mid.addStretch(1)
        self.btn_arrow = QPushButton("◀")
        self.btn_arrow.setFixedWidth(46)
        self.btn_arrow.setToolTip(
            "選んだ工事（プラント）を現在の表示に追加する")
        self.btn_arrow.setStyleSheet("text-align: center; font-size: 15px;")
        self.btn_arrow.clicked.connect(self._add_arrow)
        mid.addWidget(self.btn_arrow)
        self.btn_arrow_r = QPushButton("▶")
        self.btn_arrow_r.setFixedWidth(46)
        self.btn_arrow_r.setToolTip(
            "現在の表示で選んだ工事を表示から外す")
        self.btn_arrow_r.setStyleSheet("text-align: center; font-size: 15px;")
        self.btn_arrow_r.clicked.connect(self._remove_arrow)
        self.btn_arrow_r.setEnabled(False)
        mid.addWidget(self.btn_arrow_r)
        mid.addStretch(1)
        body.addLayout(mid)
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["名前", "期間", "総作業時間"])
        self.tree.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        # 列ごとに縦罫線を入れ、全列ドラッグで幅変更できるようにする（Trial75）
        self.tree.setStyleSheet(
            "QTreeWidget::item { border-right: 1px solid #ddd3b8; }"
            "QTreeWidget::item:selected { background: #2e4a66;"
            " color: #ffffff; }"
            "QTreeWidget::item:selected:!active { background: #c9d6e2;"
            " color: #241f18; }")
        hdr = self.tree.header()
        hdr.setStretchLastSection(False)   # 最終列が伸びて名前列を奪うのを防ぐ
        for col in range(3):
            hdr.setSectionResizeMode(col, QHeaderView.ResizeMode.Interactive)
        self.tree.setColumnWidth(0, 420)
        self.tree.setColumnWidth(1, 216)
        self.tree.setColumnWidth(2, 96)
        saved = getattr(self.data.settings, "project_list_widths", [])
        if len(saved) == 3 and all(isinstance(w, int) and w >= 40
                                   for w in saved):
            for col, w in enumerate(saved):
                self.tree.setColumnWidth(col, w)
        hdr.sectionResized.connect(self._on_columns_resized)
        self.tree.currentItemChanged.connect(lambda *_: self._sync())
        self.tree.itemDoubleClicked.connect(self._double_clicked)
        body.addWidget(self.tree, 1)
        # 操作ボタンは下段の横並びにして、ツリー（名前列）を広く取る（Trial68）
        foot = QHBoxLayout()

        def btn(text, slot, tip="", kind=""):
            b = QPushButton(text)
            if kind:
                b.setIcon(QIcon(icon_pixmap(kind, "#57503f")))
                b.setIconSize(QSize(19, 19))
            if tip:
                b.setToolTip(tip)
            b.clicked.connect(slot)
            foot.addWidget(b)
            return b

        self.btn_open = btn("工事を開く", self._open_single,
                            "選んだ工事だけを表示し、詳細を開く", "folder")
        self.btn_open_plant = btn("プラントを開く",
                                  self._open_plant,
                                  "選んだプラントの工事を全て表示する", "folder")
        self.btn_new = btn("工事を新規作成…", self._request_new, "", "new_doc")
        foot.addSpacing(6)
        self.btn_del_pr = btn("工事を削除…", self._delete_project,
                              "工事ファイルは backup フォルダに退避される", "trash")
        # プラント操作は1つのメニューに集約（Trial75）
        self.plant_menu = QMenu(self)
        self.act_add_p = self.plant_menu.addAction(
            "プラントを追加…", self._add_plant_name)
        self.act_ren_p = self.plant_menu.addAction(
            "プラント名を変更…", self._rename_plant_name)
        self.act_del_p = self.plant_menu.addAction(
            "プラントを削除", self._delete_plant_name)
        plant_btn = QPushButton("プラント操作")
        plant_btn.setIcon(QIcon(icon_pixmap("folder", "#57503f")))
        plant_btn.setIconSize(QSize(19, 19))
        plant_btn.setMenu(self.plant_menu)
        foot.addWidget(plant_btn)
        foot.addStretch(1)
        utilities = QHBoxLayout()
        utilities.setSpacing(8)
        ws = QPushButton("置き場を開く…")
        ws.setIcon(QIcon(icon_pixmap("folder", "#57503f")))
        ws.setIconSize(QSize(19, 19))
        ws.setToolTip("データの置き場（フォルダ）を開き直す")
        ws.clicked.connect(self._request_workspace)
        utilities.addWidget(ws)
        utilities.addStretch(1)
        close_btn = QPushButton("閉じる")
        close_btn.clicked.connect(self.accept)
        utilities.addWidget(close_btn)
        root.addLayout(foot)
        root.addLayout(utilities)
        self._rebuild()

    # ---------- 構築 ----------
    def _on_columns_resized(self, *_):
        self.data.settings.project_list_widths = [
            self.tree.columnWidth(c) for c in range(3)]
        self.changed = True

    def _rebuild(self):
        self.tree.clear()
        plants = list(self.plant_names)
        for pr in self.data.projects:
            if pr.plant and pr.plant not in plants:
                plants.append(pr.plant)
        for name in plants:
            top = QTreeWidgetItem([f"{name}", "", ""])
            top.setData(0, Qt.ItemDataRole.UserRole, ("plant", name))
            top.setFont(0, font(10, True))
            self.tree.addTopLevelItem(top)
            for pr in self.data.projects:
                if pr.plant != name:
                    continue
                s0, e0 = md.project_span(pr)
                span = (f"{fmt_d(s0)} – {fmt_d(e0)}"
                        if s0 else "（日付なし）")
                item = QTreeWidgetItem(
                    [pr.name, span,
                     f"{md.fmt_hours(md.project_hours_total(self.data, pr))}h"])
                item.setData(0, Qt.ItemDataRole.UserRole,
                             ("project", pr.id))
                self._base_names[pr.id] = pr.name
                top.addChild(item)
            top.setText(0, f"{name}（{top.childCount()}件）")
            top.setExpanded(True)
        self.refresh_view()
        self._sync()

    def refresh_view(self, added=()):
        """現在の表示セットを一覧に出し、ツリーに（表示中）を付ける。"""
        ids = list(self.view_provider()) if self.view_provider else []
        self._view_ids = ids
        by_id = {pr.id: pr for pr in self.data.projects}
        self.view_label.setText(f"現在の表示（{len(ids)}件）")
        self.view_list.clear()
        for pid in ids:
            pr = by_id.get(pid)
            if pr:
                self.view_list.addItem(f"{pr.plant} {pr.name}")
        for pid in added:
            if pid in ids:
                self.view_list.setCurrentRow(ids.index(pid))
        for i in range(self.tree.topLevelItemCount()):
            top = self.tree.topLevelItem(i)
            for j in range(top.childCount()):
                item = top.child(j)
                kind, val = item.data(0, Qt.ItemDataRole.UserRole)
                if kind == "project" and val in self._base_names:
                    item.setText(0, self._base_names[val]
                                 + ("（表示中）" if val in ids else ""))
        self._sync()

    def _selection(self):
        item = self.tree.currentItem()
        if item is None:
            return None, None
        return item.data(0, Qt.ItemDataRole.UserRole)

    def _sync(self):
        kind, val = self._selection()
        self.btn_open.setEnabled(kind == "project")
        self.btn_del_pr.setEnabled(kind == "project")
        if kind == "project":
            self.btn_arrow.setEnabled(val not in self._view_ids)
        elif kind == "plant":
            self.btn_arrow.setEnabled(any(
                pr.plant == val and pr.id not in self._view_ids
                for pr in self.data.projects))
        else:
            self.btn_arrow.setEnabled(False)
        self.btn_open_plant.setEnabled(kind in ("plant", "project"))
        self.act_ren_p.setEnabled(kind == "plant")
        if kind == "plant":
            n = sum(1 for pr in self.data.projects if pr.plant == val)
            self.act_del_p.setEnabled(n == 0)
        else:
            self.act_del_p.setEnabled(False)

    def _delete_project(self):
        kind, val = self._selection()
        if kind != "project":
            return
        if self.cb["delete_project"](val):
            self.changed = True
            self._rebuild()

    def _plant_of_selection(self):
        kind, val = self._selection()
        if kind == "plant":
            return val
        if kind == "project":
            pr = next((x for x in self.data.projects if x.id == val), None)
            return pr.plant if pr else None
        return None

    # ---------- 開く／追加 ----------
    def _open_single(self):
        kind, val = self._selection()
        if kind == "project":
            self.cb["open_single"](val)
            self.accept()

    def _double_clicked(self, item, _col):
        kind, val = item.data(0, Qt.ItemDataRole.UserRole)
        if kind == "project":
            self.cb["open_single"](val)
            self.accept()

    def _remove_arrow(self):
        row = self.view_list.currentRow()
        if 0 <= row < len(self._view_ids):
            pid = self._view_ids[row]
            self.cb["remove_projects"]([pid])
            self.refresh_view()
            if self.view_list.count():
                self.view_list.setCurrentRow(
                    min(row, self.view_list.count() - 1))

    def _add_arrow(self):
        kind, _val = self._selection()
        if kind == "project":
            self._add_selected()
        elif kind == "plant":
            self._add_plant()

    def _add_selected(self):
        kind, val = self._selection()
        if kind == "project":
            self.cb["add_projects"]([val])
            self.refresh_view(added=[val])

    def _open_plant(self):
        name = self._plant_of_selection()
        if name:
            self.cb["open_plant"](name)
            self.accept()

    def _add_plant(self):
        name = self._plant_of_selection()
        if name:
            self.cb["add_plant"](name)
            ids = [pr.id for pr in self.data.projects if pr.plant == name]
            self.refresh_view(added=ids[:1])

    def _request_new(self):
        self.requested = "new_project"
        self.accept()

    def _request_workspace(self):
        self.requested = "open_workspace"
        self.accept()

    # ---------- プラント編集 ----------
    def _add_plant_name(self):
        from PySide6.QtWidgets import QInputDialog, QMessageBox
        name, ok = QInputDialog.getText(self, "プラントを追加", "プラント名：")
        name = name.strip()
        if not ok or not name:
            return
        if name in self.plant_names:
            QMessageBox.information(self, "プラント",
                                    "同名のプラントがあります。")
            return
        self.plant_names.append(name)
        self.changed = True
        self._rebuild()

    def _rename_plant_name(self):
        from PySide6.QtWidgets import QInputDialog, QMessageBox
        kind, old = self._selection()
        if kind != "plant":
            return
        name, ok = QInputDialog.getText(self, "プラント名を変更",
                                        "プラント名：", text=old)
        name = name.strip()
        if not ok or not name or name == old:
            return
        if name in self.plant_names:
            QMessageBox.information(self, "プラント",
                                    "同名のプラントがあります。")
            return
        affected = [pr.id for pr in self.data.projects if pr.plant == old]
        claim = self.cb.get("lock_projects")
        if claim and affected and not claim(affected):
            return
        for pr in self.data.projects:
            if pr.plant == old:
                pr.plant = name
        self.plant_names[self.plant_names.index(old)] = name
        if self.data.settings.view_plant == old:
            self.data.settings.view_plant = name
        self.changed = True
        self._rebuild()

    def _delete_plant_name(self):
        from PySide6.QtWidgets import QMessageBox
        kind, old = self._selection()
        if kind != "plant":
            return
        if any(pr.plant == old for pr in self.data.projects):
            QMessageBox.information(
                self, "プラント",
                "工事が残っているプラントは削除できません。")
            return
        if QMessageBox.question(
                self, "確認", f"プラント「{old}」を削除しますか？") \
                != QMessageBox.StandardButton.Yes:
            return
        self.plant_names.remove(old)
        self.changed = True
        self._rebuild()
