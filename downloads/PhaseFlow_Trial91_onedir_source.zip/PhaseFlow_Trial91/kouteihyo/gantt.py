# -*- coding: utf-8 -*-
"""ガントチャート描画＋ドラッグ調整ウィジェット。"""
from __future__ import annotations

from datetime import date, timedelta

from PySide6.QtCore import QRect, Qt, QRectF, Signal
from PySide6.QtGui import (QBrush, QColor, QCursor, QFont, QFontMetrics,
                           QPainter, QPainterPath, QPen, QPolygonF)
from PySide6.QtCore import QPointF
from PySide6.QtWidgets import QMenu, QWidget

from . import model as md
from .fontutil import font
from .icons import draw_person_glyph, icon_pixmap

NAME_W = 176
HEADER_H = 44
TRACK_H = 26
ROW_H = 36
BAR_H = 22
PEOPLE_H = 15        # 人工表示の帯の高さ
ATTR_H = 15          # 属性表示の帯の高さ
EDGE_W = 14          # バー端のつまみ幅（px）。短いバーでは幅の1/3まで縮める

# --- Trial3: メリハリ配色 ---
# 狙い: 一番強い模様が週末の縞になっていた主従逆転を直す。
# 背景は白＋ごく薄いオーバーレイに落とし、濃くするのは
# 月ヘッダー帯・自部門の系列帯・バー本体・選択行だけにする。
INK = QColor("#241f18")
SUB = QColor("#6e6455")
LINE = QColor("#d8cfb8")
LINE_MONTH = QColor("#8a7a52")
WEEKEND = QColor(176, 141, 74, 34)       # 半透明（バーの下に敷く）
HEADER_DARK = QColor("#38332b")          # 月ヘッダーの帯
HEADER_LIGHT = QColor("#eae3d0")         # 週／日ラベルの帯
NAME_BG = QColor("#f3efe3")              # 左の項目名カラム
TRACK_OWN = QColor("#2e4a66")            # 自部門の系列帯（濃い青）
TRACK_REF = QColor("#d9d3c3")            # 参照の系列帯（薄い）
TRACK_REF_INK = QColor("#57503f")
REF_BAR = QColor("#d2ccbd")              # 参照バー（落として脇役に）
SELECT_BG = QColor(224, 112, 32, 34)     # 選択行のオーバーレイ
ORANGE = QColor("#e07020")
ORANGE_D = QColor("#c65c14")
RED = QColor("#cd3c32")
WD_CHARS = "月火水木金土日"


def vivid(c: QColor) -> QColor:
    """保存済みデータの淡いバー色も、描画時に彩度を上げて濃く見せる。"""
    h, s, l, a = c.getHsl()
    if h < 0:
        return c
    s = min(255, int(s * 1.35) + 12)
    l = max(70, min(l, 148))
    return QColor.fromHsl(h, s, l, a)


def month_iter(start: date, end: date):
    y, m = start.year, start.month
    while (y, m) <= (end.year, end.month):
        yield y, m
        m += 1
        if m == 13:
            y, m = y + 1, 1


def draw_time_header(p: QPainter, x0: float, days_px: float,
                     start: date, total_days: int, height: int = HEADER_H):
    """月＋週ラベル（拡大時は日＋曜日）のヘッダーを描く。"""
    end = start + timedelta(days=total_days)
    # 下帯（週／日ラベル）→ 上帯（月・濃色）の2段にする
    p.fillRect(QRectF(x0, 0, days_px * total_days, height), HEADER_LIGHT)
    p.fillRect(QRectF(x0, 0, days_px * total_days, 20), HEADER_DARK)
    day_mode = days_px >= 17
    for (y, m) in month_iter(start, end):
        mstart = date(y, m, 1)
        mend = date(y + (1 if m == 12 else 0), 1 if m == 12 else m + 1, 1)
        sx = x0 + (max(mstart, start) - start).days * days_px
        ex = x0 + (min(mend, end) - start).days * days_px
        if ex <= sx:
            continue
        # 月の境界: 濃い帯の上では明るく、週の行では濃く（両方で対比を出す）
        p.setPen(QPen(QColor("#a89e88"), 1))
        p.drawLine(QPointF(sx, 0), QPointF(sx, 20))
        p.setPen(QPen(QColor("#8a7c5c"), 1))
        p.drawLine(QPointF(sx, 20), QPointF(sx, height))
        p.setPen(QPen(QColor("#ffffff"), 1))
        p.setFont(font(11, True))
        p.drawText(QRectF(sx, 1, ex - sx, 18), Qt.AlignmentFlag.AlignCenter,
                   f"{m}月")
        if day_mode:
            d = max(mstart, start)
            while d < min(mend, end):
                cx = x0 + (d - start).days * days_px
                wd = d.weekday()
                col = RED if wd == 6 else (QColor("#9a6206") if wd == 5 else INK)
                p.setPen(QPen(col, 1))
                p.setFont(font(8, wd >= 5))
                p.drawText(QRectF(cx, 20, days_px, 12), Qt.AlignmentFlag.AlignCenter, str(d.day))
                p.drawText(QRectF(cx, 32, days_px, 12), Qt.AlignmentFlag.AlignCenter, WD_CHARS[wd])
                d += timedelta(days=1)
        else:
            # 月内の週セグメント（1-7, 8-14, 15-21, 22-28, 29-末日）
            segs = [(1, 7), (8, 14), (15, 21), (22, 28), (29, 31)]
            for i, (d1, d2) in enumerate(segs):
                try:
                    s1 = date(y, m, d1)
                except ValueError:
                    continue
                s2 = min(mend, date(y, m, min(d2, 28)) if d2 <= 28 else mend)
                if d2 > 28:
                    s2 = mend
                cx0 = x0 + (max(s1, start) - start).days * days_px
                cx1 = x0 + (min(s2, end) - start).days * days_px
                if cx1 - cx0 >= 13:
                    p.setPen(QPen(SUB, 1))
                    p.setFont(font(8))
                    p.drawText(QRectF(cx0, 25, cx1 - cx0, 12),
                               Qt.AlignmentFlag.AlignCenter, f"{i+1}週")
    p.setPen(QPen(HEADER_DARK, 2))
    p.drawLine(QPointF(x0, height), QPointF(x0 + days_px * total_days, height))


class GanttWidget(QWidget):
    view_changed = Signal()                  # ズーム／パンで表示範囲が変わった
    selection_changed = Signal(str)
    nudge_requested = Signal(int)   # 矢印キーでのバー移動（Trial75）          # task_id（空=解除）
    edit_finished = Signal()                 # 編集が確定した
    overlap_pending = Signal(object, object, object)  # task, overlapped, revert(dict)
    context_requested = Signal(str, object)  # task_id, global_pos
    track_context_requested = Signal(str, object)  # track_id, global_pos
    track_rename_requested = Signal(str)     # track_id（ダブルクリック）

    def __init__(self, parent=None):
        super().__init__(parent)
        # クリックでフォーカスを取り、矢印キー等をウィンドウへ伝える（Trial75）
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.project = None
        self.read_only = False
        self.view_start = date(2026, 4, 1)
        self.view_days = 150
        self.selected_id = ""
        self.show_jinko = False   # バーの下に作業時間を表示
        self.data = None           # 作業時間の計算用（MainWindowが設定）
        self.show_attrs = False   # バーの下に属性（タスク量）を表示
        self.master_by_id = {}    # 属性の単位・順序を引くため MainWindow が渡す
        self._rows = []          # (kind, track, task, y) kind: track/task
        self._drag = None        # dict
        self._hover_id = ""      # マウスが乗っている task_id
        self._hover_mode = None  # そのときの mode（resize_l/resize_r/move/select）
        self._pending = None     # ドラッグ候補（しきい値を超えるまで未確定）
        self.setMinimumHeight(300)
        self.setMinimumWidth(600)
        self.setMouseTracking(True)

    # ---------- レイアウト ----------
    def set_project(self, project):
        self.project = project
        self.fit_view()
        # スクロール側が表示幅に合わせて伸縮させる（widgetResizable前提）。
        # 最小高さ＝中身の高さにしておくと、縦は収まらない時だけスクロールする
        self.setMinimumHeight(self.content_height())
        self.update()

    def span(self):
        """横スクロール用の全体範囲 (開始日, 総日数)。項目が無ければ None。"""
        if not self.project or not self.project.tasks:
            return None
        s0 = min(t.dstart for t in self.project.tasks)
        e = max(t.dend for t in self.project.tasks)
        start = date(s0.year, s0.month, 1)
        return start, (e - start).days + 20

    def fit_view(self):
        span = self.span()
        if not span:
            return
        start, total = span
        self.view_start = start
        self.view_days = max(30, total)
        self.update()
        self.view_changed.emit()

    def show_daily_view(self, available_width=None):
        """Show up to about two months, keeping each day label at least 17px."""
        if not self.span():
            return
        width = min(self.width(), available_width) if available_width is not None else self.width()
        self.view_days = max(1, min(62, int(max(17, width - NAME_W - 8) // 17)))
        task = self.project.task_by_id(self.selected_id) if self.project else None
        start = task.dstart - timedelta(days=3) if task else self.view_start
        first, total = self.span()
        latest = first + timedelta(days=max(0, total - self.view_days))
        self.view_start = min(max(start, first), latest)
        self.update()
        self.view_changed.emit()

    def set_view_start(self, d):
        span = self.span()
        if span:
            start, total = span
            latest = start + timedelta(days=max(0, total - self.view_days))
            d = min(max(d, start), latest)
        if d != self.view_start:
            self.view_start = d
            self.update()
            self.view_changed.emit()

    def _people_count(self, t):
        """その項目の人数（役割の人数合計）。マイルストーンは0。"""
        if t is None or t.milestone:
            return 0
        return sum(r.headcount for r in t.roles)

    def _has_attrs(self, t):
        if t is None or t.milestone:
            return False
        return any((q or 0) > 0 for q in t.attrs.values())

    def _attr_text(self, t):
        """属性の表示文字列。マスタ定義の順序と単位を優先する。"""
        master = self.master_by_id.get(t.master_id)
        if master is not None:
            parts = [f"{d.name} {t.attrs.get(d.name, 0):g}{d.unit}"
                     for d in master.attrs if (t.attrs.get(d.name, 0) or 0) > 0]
            if parts:
                return " ・ ".join(parts)
        return " ・ ".join(f"{k} {v:g}" for k, v in t.attrs.items()
                           if (v or 0) > 0)

    def _row_height(self, kind, t):
        if kind == "track":
            return TRACK_H
        h = ROW_H
        if self.show_jinko and self._people_count(t) > 0:
            h += PEOPLE_H
        if self.show_attrs and self._has_attrs(t):
            h += ATTR_H
        return h

    def set_show_options(self, jinko: bool, attrs: bool):
        self.show_jinko = jinko
        self.show_attrs = attrs
        self.setMinimumHeight(self.content_height())
        self.update()

    def _layout(self):
        self._rows = []
        y = HEADER_H
        if not self.project:
            return y
        for tr in self.project.tracks:
            self._rows.append(("track", tr, None, y, TRACK_H))
            y += TRACK_H
            for t in self.project.tasks_in_track(tr.id):
                h = self._row_height("task", t)
                self._rows.append(("task", tr, t, y, h))
                y += h
        return y

    def content_height(self):
        return self._layout()

    def _px(self):
        w = max(50, self.width() - NAME_W)
        return w / max(1, self.view_days)

    def x_of(self, d: date) -> float:
        return NAME_W + (d - self.view_start).days * self._px()

    def date_at(self, x: float) -> date:
        return self.view_start + timedelta(days=round((x - NAME_W) / self._px()))

    def _bar_rect(self, task, y):
        x0 = self.x_of(task.dstart)
        x1 = self.x_of(task.dend + timedelta(days=1))
        return QRectF(x0, y + (ROW_H - BAR_H) / 2, max(4, x1 - x0), BAR_H)

    # ---------- 描画 ----------
    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), QColor("#ffffff"))
        total_h = self._layout()
        px = self._px()
        # 左の項目名カラム（地を変えてカラムとして立たせる）
        p.fillRect(QRectF(0, HEADER_H, NAME_W, total_h - HEADER_H), NAME_BG)
        # 行のゼブラ＋選択行（週末より先に敷く）
        ti = 0
        for kind, tr, t, y, rh in self._rows:
            if kind != "task":
                continue
            if ti % 2 == 1:
                p.fillRect(QRectF(0, y, self.width(), rh), QColor(70, 52, 20, 10))
            if t.id == self.selected_id:
                p.fillRect(QRectF(0, y, self.width(), rh), SELECT_BG)
            ti += 1
        # 週末の網掛け（半透明でバーの邪魔をしない程度に）
        for i in range(self.view_days):
            d = self.view_start + timedelta(days=i)
            if d.weekday() in (5, 6):
                p.fillRect(QRectF(NAME_W + i * px, HEADER_H, px, total_h - HEADER_H), WEEKEND)
        # ヘッダー（左上コーナーも月の濃色帯に揃え、「項目」を置く）
        draw_time_header(p, NAME_W, px, self.view_start, self.view_days)
        # コーナーは月の濃色帯を引かず淡色で統一（ボタンの背景、Trial47）
        p.fillRect(QRectF(0, 0, NAME_W, HEADER_H), HEADER_LIGHT)
        # 左上コーナーには表示切替ボタンが重なる（Trial45）
        p.setPen(QPen(HEADER_DARK, 2))
        p.drawLine(QPointF(0, HEADER_H), QPointF(NAME_W, HEADER_H))
        p.setPen(QPen(LINE_MONTH, 1))
        p.drawLine(QPointF(NAME_W, 0), QPointF(NAME_W, total_h))
        # 縦線: 月の区切りは濃く、月曜は薄く
        end_v = self.view_start + timedelta(days=self.view_days)
        for (yy, mm) in month_iter(self.view_start, end_v):
            mx = self.x_of(date(yy, mm, 1))
            if NAME_W <= mx <= self.width():
                p.setPen(QPen(LINE_MONTH, 1.2))
                p.drawLine(QPointF(mx, HEADER_H), QPointF(mx, total_h))
        p.setPen(QPen(QColor("#e6ddc9"), 1))
        for i in range(self.view_days + 1):
            cur = self.view_start + timedelta(days=i)
            if cur.weekday() == 0:
                x = NAME_W + i * px
                p.drawLine(QPointF(x, HEADER_H), QPointF(x, total_h))
        # 横罫線（左端から）
        p.setPen(QPen(LINE, 1))
        for kind, tr, t, y, rh in self._rows:
            p.drawLine(QPointF(0, y + rh), QPointF(self.width(), y + rh))
        # 系列ヘッダーとバー
        task_row = {}
        for kind, tr, t, y, rh in self._rows:
            if kind == "track":
                own = tr.kind == "own"
                p.fillRect(QRectF(0, y, self.width(), TRACK_H),
                           TRACK_OWN if own else TRACK_REF)
                p.fillRect(QRectF(0, y, 5, TRACK_H), ORANGE if own else QColor("#a39a83"))
                p.setPen(QPen(QColor("#ffffff") if own else TRACK_REF_INK, 1))
                p.setFont(font(11 if own else 10, True))
                label = tr.name   # 種別の注記は自動で付けない（Trial66）
                p.drawText(QRectF(12, y, 500, TRACK_H), Qt.AlignmentFlag.AlignVCenter, label)
            else:
                task_row[t.id] = (tr, y)
                self._paint_task(p, tr, t, y)
        # 依存の矢印
        p.save()
        p.setClipRect(QRectF(NAME_W, 0, self.width() - NAME_W, total_h))
        self._paint_deps(p, task_row)
        p.restore()
        # 今日線
        today = date.today()
        if self.view_start <= today <= self.view_start + timedelta(days=self.view_days):
            x = self.x_of(today)
            p.setPen(QPen(RED, 2))
            p.drawLine(QPointF(x, HEADER_H), QPointF(x, total_h))
            p.setFont(font(8, True))
            p.setPen(QPen(RED, 1))
            p.drawText(QRectF(x - 20, HEADER_H - 14, 40, 12), Qt.AlignmentFlag.AlignCenter, "今日")
        # 項目が空のときの案内（Trial17）
        if self.project and not self.project.tasks:
            p.setPen(QPen(QColor("#8a8272"), 1))
            p.setFont(font(13, True))
            p.drawText(QRectF(0, total_h + 18, self.width(), 28),
                       Qt.AlignmentFlag.AlignCenter, "まだ項目がありません")
            p.setFont(font(10))
            p.drawText(QRectF(0, total_h + 48, self.width(), 24),
                       Qt.AlignmentFlag.AlignCenter,
                       "上のプリセットで並べるか、下の「＋ 項目を追加」から始めてください")
        # ドラッグ中のチップ
        if self._drag:
            self._paint_chip(p)
        p.end()

    def _paint_lock(self, p, cx, cy, fg):
        # 専用の鍵アイコン（icons.py の線画、全体のトーンに合わせたもの）
        pm = icon_pixmap("lock", QColor(fg).name())
        p.drawPixmap(QRect(int(cx - 7), int(cy - 7), 14, 14), pm)

    def _paint_task(self, p, tr, t, y):
        grey = tr.kind == "ref"
        selected = t.id == self.selected_id
        if selected:
            name_col = ORANGE_D
        elif grey:
            name_col = QColor("#9a927e")
        else:
            name_col = INK
        p.setPen(QPen(name_col, 1))
        p.setFont(font(10, selected or not grey))
        p.drawText(QRectF(6, y, NAME_W - 34, ROW_H), Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter, t.name)
        if t.locked_any:
            # 日付ロック中は名前の左に小さな鍵マーク（Trial78）
            tw = QFontMetrics(p.font()).horizontalAdvance(t.name)
            lock_cx = (NAME_W - 28) - tw - 9
            if lock_cx >= 8:
                self._paint_lock(p, lock_cx, y + ROW_H / 2, name_col)
        if t.calendar == "saturday":
            p.setFont(font(7, True))
            p.setPen(QPen(QColor("#9a6206"), 1))
            p.drawText(QRectF(6, y + ROW_H - 11, NAME_W - 34, 10), Qt.AlignmentFlag.AlignRight, "土曜出勤")
        # ここから先（バー・日付・帯）は左の項目名カラムへ入らないよう制限する
        p.save()
        p.setClipRect(QRectF(NAME_W, 0, self.width() - NAME_W,
                             self.height()))
        drag = self._drag
        start, end = t.dstart, t.dend
        if drag and drag["task_id"] == t.id:
            start, end = drag["start"], drag["end"]
        if t.milestone:
            cx = self.x_of(start) + self._px() / 2
            cy = y + ROW_H / 2
            r = 8
            poly = QPolygonF([QPointF(cx, cy - r), QPointF(cx + r, cy),
                              QPointF(cx, cy + r), QPointF(cx - r, cy)])
            col = vivid(QColor(t.color)) if not grey else QColor("#8a8272")
            p.setBrush(QBrush(QColor("#ffffff")))
            p.setPen(QPen(col, 2))
            p.drawPolygon(poly)
            p.setBrush(QBrush(col))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawEllipse(QPointF(cx, cy), 2.6, 2.6)
            if md.role_shortages(self.data, t):
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.setPen(QPen(QColor("#d43a2f"), 2))
                p.drawRoundedRect(QRectF(cx - r - 3, cy - r - 3,
                                         2 * r + 6, 2 * r + 6), 3, 3)
            p.setPen(QPen(QColor("#6f6752"), 1))
            p.setFont(font(8, True))
            p.drawText(QRectF(cx - 60, cy + r + 1, 120, 11), Qt.AlignmentFlag.AlignCenter,
                       f"{t.name} {start.month}/{start.day}")
            p.restore()
            return
        rect = QRectF(self.x_of(start), y + (ROW_H - BAR_H) / 2,
                      max(4, self.x_of(end + timedelta(days=1)) - self.x_of(start)), BAR_H)
        col = REF_BAR if grey else vivid(QColor(t.color))
        if selected:
            p.setBrush(QBrush(QColor(0, 0, 0, 42)))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawRoundedRect(rect.translated(2, 2), 4, 4)
        p.setBrush(QBrush(col))
        p.setPen(QPen(col.darker(145), 1.2))
        p.drawRoundedRect(rect, 4, 4)
        if selected:
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.setPen(QPen(ORANGE, 2.5))
            p.drawRoundedRect(rect.adjusted(-2, -2, 2, 2), 5, 5)
        if md.role_shortages(self.data, t):
            # 人員不足の赤枠（Trial70）
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.setPen(QPen(QColor("#d43a2f"), 2))
            p.drawRoundedRect(rect.adjusted(-4.5, -4.5, 4.5, 4.5), 6, 6)
        # 端のつまみ（選択中／ホバー中のバーだけ、両端に白いグリップを出す）
        dragging_this = bool(drag and drag["task_id"] == t.id)
        if t.id == self.selected_id or t.id == self._hover_id or dragging_this:
            active = drag["mode"] if dragging_this else self._hover_mode
            for side, hx in (("resize_l", rect.x()), ("resize_r", rect.right())):
                hot = (t.id == self._hover_id or dragging_this) and active == side
                hw = 7
                hrect = QRectF(hx - hw / 2, rect.y() + 3, hw, BAR_H - 6)
                p.setBrush(QBrush(QColor(255, 255, 255, 245 if hot else 185)))
                p.setPen(QPen(ORANGE_D if hot else col.darker(140), 1.5 if hot else 1))
                p.drawRoundedRect(hrect, 2, 2)
                p.setPen(QPen(QColor("#5a5044"), 1))
                gx = hx
                p.drawLine(QPointF(gx, rect.y() + 6), QPointF(gx, rect.bottom() - 6))
        # 重なり部分のハッチ
        if self.project:
            for o in self.project.tasks:
                if o.track_id == t.track_id and o.id != t.id and o.dstart < start and o.dend >= start:
                    ox = self.x_of(start)
                    ox1 = self.x_of(min(o.dend, end) + timedelta(days=1))
                    p.setBrush(QBrush(ORANGE, Qt.BrushStyle.Dense4Pattern))
                    p.setPen(Qt.PenStyle.NoPen)
                    p.drawRoundedRect(QRectF(ox, rect.y(), max(2, ox1 - ox), BAR_H), 4, 4)
        # バー内項目名（入る場合だけ）。参照バーは地が薄いので濃い文字で
        p.setFont(font(9, True))
        name_w = p.fontMetrics().horizontalAdvance(t.name)
        if rect.width() > name_w + 12:
            p.setPen(QPen(QColor("#5d564a") if grey else QColor("#ffffff"), 1))
            p.drawText(QRectF(rect.x() + 6, rect.y(), rect.width() - 8, BAR_H),
                       Qt.AlignmentFlag.AlignVCenter, t.name)
        # 両端の日付（自部門は濃く、参照は落とす。選択中は太字）
        p.setPen(QPen(QColor("#9a927e") if grey else QColor("#4a4234"), 1))
        p.setFont(font(8, selected and not grey))
        p.drawText(QRectF(rect.x() - 44, rect.y(), 40, BAR_H),
                   Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
                   f"{start.month}/{start.day}")
        p.drawText(QRectF(rect.right() + 4, rect.y(), 44, BAR_H),
                   Qt.AlignmentFlag.AlignVCenter, f"{end.month}/{end.day}")
        # バーの下の情報帯（オプション表示。ドラッグ中の自バーには出さない）
        if not dragging_this:
            strip_y = y + ROW_H + 1
            people = self._people_count(t)
            if self.show_jinko and people > 0:
                # シンボルは役割ごとに色分けして並べる（Trial14）
                gx = rect.x() + 5
                drawn = 0
                for r in t.roles:
                    for _ in range(r.headcount or 0):
                        if drawn >= 14:
                            break
                        draw_person_glyph(p, gx, strip_y, PEOPLE_H - 3,
                                          QColor(md.role_color(r.name)))
                        gx += 10
                        drawn += 1
                # 括弧内も役割別に色分けして人数を示す
                p.setFont(font(9, True))
                fm = p.fontMetrics()
                tx = gx + 3
                ty = strip_y - 1

                def seg(text, color):
                    nonlocal tx
                    p.setPen(QPen(QColor(color), 1))
                    p.drawText(QRectF(tx, ty, 300, PEOPLE_H),
                               Qt.AlignmentFlag.AlignVCenter, text)
                    tx += fm.horizontalAdvance(text)

                seg("（", "#57503f")
                hours = md.task_hours(self.data, t)
                first = True
                for name, v in hours.items():
                    if name == "合計" or v <= 0:
                        continue
                    if not first:
                        seg("・", "#57503f")
                    seg(f"{name} {md.fmt_hours(v)}h", md.role_color(name))
                    first = False
                seg("）", "#57503f")
                strip_y += PEOPLE_H
            if self.show_attrs and self._has_attrs(t):
                txt = self._attr_text(t)
                p.setPen(QPen(QColor("#6f6752"), 1))
                p.setFont(font(8))
                p.drawText(QRectF(rect.x() + 2, strip_y - 1,
                                  max(10, self.width() - rect.x() - 6), ATTR_H),
                           Qt.AlignmentFlag.AlignVCenter, txt)
        p.restore()

    def _paint_deps(self, p, task_row):
        if not self.project:
            return
        for t in self.project.tasks:
            if not t.pred_id or t.id not in task_row or t.pred_id not in task_row:
                continue
            pred = self.project.task_by_id(t.pred_id)
            if not pred:
                continue
            _, py = task_row[pred.id]
            _, ty = task_row[t.id]
            cross = pred.track_id != t.track_id
            x0 = self.x_of(pred.dend + timedelta(days=1))
            y0 = py + ROW_H / 2
            x1 = self.x_of(t.dstart)
            y1 = ty + ROW_H / 2
            col = ORANGE if cross else QColor("#8a7a5c")
            pen = QPen(col, 2 if cross else 1.5)
            if cross:
                pen.setStyle(Qt.PenStyle.DashLine)
            p.setPen(pen)
            p.setBrush(Qt.BrushStyle.NoBrush)
            path = QPainterPath(QPointF(x0, y0))
            if abs(y1 - y0) < 1:
                path.lineTo(QPointF(x1, y1))
            else:
                path.lineTo(QPointF(x0 + 8, y0))
                path.lineTo(QPointF(x0 + 8, y1))
                path.lineTo(QPointF(x1, y1))
            p.drawPath(path)
            p.setBrush(QBrush(col))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawPolygon(QPolygonF([QPointF(x1, y1), QPointF(x1 - 7, y1 - 3.5),
                                     QPointF(x1 - 7, y1 + 3.5)]))

    def _paint_chip(self, p):
        drag = self._drag
        t = self.project.task_by_id(drag["task_id"])
        if not t:
            return
        row = next((r for r in self._rows if r[0] == "task" and r[2].id == t.id), None)
        if not row:
            return
        y = row[3]
        s, e = drag["start"], drag["end"]
        label = (f"開始 {s.month}/{s.day}（{WD_CHARS[s.weekday()]}） ／ "
                 f"終了 {e.month}/{e.day}（{WD_CHARS[e.weekday()]}）")
        p.setFont(font(9, True))
        w = p.fontMetrics().horizontalAdvance(label) + 20
        x = min(max(NAME_W, self.x_of(s)), self.width() - w - 4)
        cy = max(HEADER_H + 2, y - 30)
        p.fillRect(QRectF(x + 3, cy + 3, w, 22), QColor("#cdc5b9"))
        p.setBrush(QBrush(QColor("#3e3228")))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawRoundedRect(QRectF(x, cy, w, 22), 4, 4)
        p.setPen(QPen(QColor("#ffffff"), 1))
        p.drawText(QRectF(x + 10, cy, w - 16, 22), Qt.AlignmentFlag.AlignVCenter, label)
        # 掴んでいる端のガイド線
        gx = self.x_of(e + timedelta(days=1)) if drag["mode"] == "resize_r" else self.x_of(s)
        p.setPen(QPen(ORANGE, 1.5))
        p.drawLine(QPointF(gx, HEADER_H), QPointF(gx, self._layout()))

    # ---------- 操作 ----------
    def _hit(self, pos):
        y = pos.y()
        x = pos.x()
        for kind, tr, t, ry, rh in self._rows:
            if kind == "task" and ry <= y <= ry + rh:
                rect = self._bar_rect(t, ry)
                if t.milestone:
                    cx = self.x_of(t.dstart) + self._px() / 2
                    if abs(x - cx) <= 12:
                        return t, "move"
                    return t, "select"
                # バーのある行なら、バーの上下の余白でも x 位置で判定する
                # （バー高20px＜行高34pxで、端狙いが外れやすかったため）
                if rect.x() <= x <= rect.right():
                    w = rect.width()
                    edge = EDGE_W if w >= EDGE_W * 3 else max(5.0, w / 3)
                    if x <= rect.x() + edge:
                        return t, "resize_l"
                    if x >= rect.right() - edge:
                        return t, "resize_r"
                    return t, "move"
                # バーの行だがバー外 → 選択だけ
                return t, "select"
        return None, None

    def _track_at(self, y):
        for kind, tr, t, ry, rh in self._rows:
            if kind == "track" and ry <= y < ry + rh:
                return tr
        return None

    def mousePressEvent(self, ev):
        if not self.project:
            return
        self.setFocus(Qt.FocusReason.MouseFocusReason)
        t, mode = self._hit(ev.position())
        if self.read_only and ev.button() == Qt.MouseButton.RightButton:
            return
        if ev.button() == Qt.MouseButton.RightButton:
            trk = self._track_at(ev.position().y())
            if trk:
                self.track_context_requested.emit(
                    trk.id, ev.globalPosition().toPoint())
                return
            if t:
                self.selected_id = t.id
                self.selection_changed.emit(t.id)
                self.context_requested.emit(t.id, ev.globalPosition().toPoint())
                self.update()
            return
        if not t:
            self.selected_id = ""
            self.selection_changed.emit("")
            self.update()
            return
        self.selected_id = t.id
        self.selection_changed.emit(t.id)
        # ロック判定は操作ごと：移動は両方、左端は開始、右端は終了を見る
        if mode == "move" and t.locked_any:
            mode = "select"
        elif mode == "resize_l" and t.lock_start:
            mode = "select"
        elif mode == "resize_r" and t.lock_end:
            mode = "select"
        if mode == "select" or self.read_only:
            self.update()
            return
        # ドラッグ候補として保持し、しきい値（7px）を超えて動いたら
        # ドラッグ開始＋拡大する。短いクリックでは拡大しない。
        self._pending = {
            "task_id": t.id, "mode": mode,
            "press_x": ev.position().x(), "press_y": ev.position().y(),
            "orig_start": t.dstart, "orig_end": t.dend,
        }
        self.update()

    # ---------- ドラッグ開始 ----------
    def _begin_drag(self):
        pend, self._pending = self._pending, None
        t = self.project.task_by_id(pend["task_id"]) if self.project else None
        if not t:
            return
        mode = pend["mode"]
        self._drag = {
            "task_id": t.id, "mode": mode,
            "start_x": pend["press_x"],
            "orig_start": pend["orig_start"], "orig_end": pend["orig_end"],
            "start": pend["orig_start"], "end": pend["orig_end"],
        }
        self.update()

    # ---------- Ctrl+ホイールで拡大・縮小 ----------
    def zoom_by(self, steps, x):
        """カーソルの下の日を基点に表示日数を拡縮する。"""
        if not self.project:
            return
        anchor = self.date_at(x)
        new_days = int(round(self.view_days * (0.85 ** steps)))
        new_days = max(14, min(400, new_days))
        if new_days == self.view_days:
            return
        self.view_days = new_days
        px = self._px()
        offset = int(round((x - NAME_W) / px)) if px else 0
        self.view_start = anchor - timedelta(days=max(0, offset))
        self.update()
        self.view_changed.emit()

    def wheelEvent(self, ev):
        dy = ev.angleDelta().y()
        ctrl = ev.modifiers() & Qt.KeyboardModifier.ControlModifier
        if dy and self.project and ctrl:
            self.zoom_by(dy / 120.0, ev.position().x())
            ev.accept()
            return
        super().wheelEvent(ev)

    def mouseMoveEvent(self, ev):
        if not self.project:
            return
        if not self._drag and self._pending is not None:
            dx = ev.position().x() - self._pending["press_x"]
            dy = ev.position().y() - self._pending["press_y"]
            if dx * dx + dy * dy >= 49:   # 7px以上動いたらドラッグ開始
                self._begin_drag()
            else:
                return
        if not self._drag:
            # ホバー: 端なら ↔ カーソル＋つまみを出す（掴む前に分かるように）
            t, mode = self._hit(ev.position())
            if self.read_only or (t and (
                    (mode == "move" and t.locked_any)
                    or (mode == "resize_l" and t.lock_start)
                    or (mode == "resize_r" and t.lock_end))):
                mode = "select"
            hid = t.id if t else ""
            if (hid, mode) != (self._hover_id, self._hover_mode):
                self._hover_id, self._hover_mode = hid, mode
                self.update()
            if mode in ("resize_l", "resize_r"):
                self.setCursor(QCursor(Qt.CursorShape.SizeHorCursor))
            elif mode == "move":
                self.setCursor(QCursor(Qt.CursorShape.OpenHandCursor))
            else:
                self.unsetCursor()
            return
        drag = self._drag
        if drag["mode"] in ("resize_l", "resize_r"):
            self.setCursor(QCursor(Qt.CursorShape.SizeHorCursor))
        else:
            self.setCursor(QCursor(Qt.CursorShape.ClosedHandCursor))
        t = self.project.task_by_id(drag["task_id"])
        delta = round((ev.position().x() - drag["start_x"]) / self._px())
        s, e = drag["orig_start"], drag["orig_end"]
        if drag["mode"] == "move":
            # 範囲（暦日数）を保ったままずらす。土日祝日もそのまま使う
            drag["start"] = s + timedelta(days=delta)
            drag["end"] = e + timedelta(days=delta)
        elif drag["mode"] == "resize_r":
            ne = e + timedelta(days=delta)
            if ne < s:
                ne = s
            drag["end"] = ne
            drag["start"] = s
        elif drag["mode"] == "resize_l":
            ns = s + timedelta(days=delta)
            if ns > e:
                ns = e
            drag["start"] = ns
            drag["end"] = e
        self.update()

    def leaveEvent(self, ev):
        if not self._drag:
            self._hover_id, self._hover_mode = "", None
            self.unsetCursor()
            self.update()
        super().leaveEvent(ev)

    def mouseReleaseEvent(self, ev):
        if self._pending is not None:
            self._pending = None   # 短いクリック: 選択のみで終わる
            return
        if not self._drag or not self.project:
            return
        drag = self._drag
        self._drag = None
        self.unsetCursor()
        t = self.project.task_by_id(drag["task_id"])
        if not t:
            self.update()
            return
        if drag["start"] == drag["orig_start"] and drag["end"] == drag["orig_end"]:
            self.update()
            return
        revert = {"start": t.start, "end": t.end}
        t.start = drag["start"].isoformat()
        t.end = drag["end"].isoformat()
        self.update()
        hit = md.find_overlap(self.project, t)
        if hit:
            self.overlap_pending.emit(t, hit, revert)
        else:
            self.edit_finished.emit()

    def cancel_drag_revert(self, task, revert):
        task.start = revert["start"]
        task.end = revert["end"]
        self.update()

    def keyPressEvent(self, ev):
        # 矢印キー: 選択中のバーを前後へ（Shift で7日）。スクロールと競合しない
        # よう、ガント自身が受けて本体へ通知する（Trial75）
        if (ev.key() in (Qt.Key.Key_Left, Qt.Key.Key_Right)
                and self.selected_id and not self.read_only):
            days = 1 if ev.key() == Qt.Key.Key_Right else -1
            if ev.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                days *= 7
            self.nudge_requested.emit(days)
            ev.accept()
            return
        super().keyPressEvent(ev)

    def task_at(self, pos):
        """位置にある項目を返す（右クリックメニュー用）。"""
        t, _ = self._hit(pos)
        return t

    def mouseDoubleClickEvent(self, ev):
        if self.read_only:
            return
        trk = self._track_at(ev.position().y())
        if trk:
            self.track_rename_requested.emit(trk.id)
            return
        t, _ = self._hit(ev.position())
        if t:
            self.selected_id = t.id
            self.selection_changed.emit(t.id)
            self.update()
