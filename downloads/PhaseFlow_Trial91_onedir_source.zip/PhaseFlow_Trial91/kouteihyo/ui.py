"""Common action icons, button sizing and keyboard focus styling (Trial87)."""
from __future__ import annotations

from PySide6.QtCore import QByteArray, QEvent, QObject, QRectF, QSize, Qt
from PySide6.QtGui import QIcon, QPainter, QPixmap
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtWidgets import QApplication, QDialog, QDialogButtonBox, QMenu, QPushButton

# Draw at native sizes instead of shrinking the old 40px panel pictograms.
_PATHS = {
    'copy': '<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M16 8V3H3v13h5"/>',
    'zoom_in': '<circle cx="10" cy="10" r="7"/><path d="m15 15 6 6M6 10h8m-4-4v8"/>',
    'fit_view': '<path d="M4 4v16M20 4v16M5 12h14m-11-4-4 4 4 4m8-8 4 4-4 4"/>',
    'plus': '<path d="M12 5v14M5 12h14"/>',
    'trash': '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 10v7m4-7v7"/>',
    'pencil': '<path d="m4 16 12-12a2.1 2.1 0 0 1 3 3L7 19l-4 1zM14 6l3 3"/>',
    'floppy': '<path d="M5 3h12l4 4v13H3V3h2ZM7 3v6h10V3M7 20v-7h10v7M14 5v2"/>',
    'folder': '<path d="M3 7V5h6l2 3h10v11H3V7Zm0 4h18"/>',
    'new_doc': '<path d="M14 3H5v18h14V8l-5-5Zm0 0v5h5M8 14h8m-4-4v8"/>',
    'list': '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 8h1m3 0h6M7 12h1m3 0h6M7 16h1m3 0h6"/>',
    'export': '<path d="M12 15V3m-4 4 4-4 4 4M4 13v7h16v-7"/>',
    'print': '<path d="M7 8V3h10v5M7 17H4V8h16v9h-3M7 14h10v7H7zM17 11h.01"/>',
    'undo': '<path d="m8 4-5 5 5 5M3 9h10a7 7 0 0 1 7 7v4"/>',
    'redo': '<path d="m16 4 5 5-5 5M21 9H11a7 7 0 0 0-7 7v4"/>',
    'gear': '<path d="m9 3-.7 3-2 .9L3.6 6l-2 3.5 2.2 2v2.3l-2.2 2 2 3.5 2.7-.9 2 .9.7 3h4l.7-3 2-.9 2.7.9 2-3.5-2.2-2v-2.3l2.2-2-2-3.5-2.7.9-2-.9L13 3z" transform="translate(1 -1) scale(.95)"/><circle cx="12" cy="12" r="3"/>',
    'calendar': '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 10h18M7 14h2m4 0h2m-8 3h2"/>',
    'clock': '<circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2"/>',
    'detail': '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M14 4v16M6 8h5m-5 4h5m-5 4h3"/>',
    'parallel': '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M3 15h18M7 7h5m-2 6h7m-10 5h6"/>',
    'chart': '<path d="M4 3v17h17M8 16v-5m5 5V6m5 10V9"/>',
    'strips': '<path d="M9 6h12M9 12h12M9 18h12"/><circle cx="4" cy="6" r="1"/><circle cx="4" cy="12" r="1"/><circle cx="4" cy="18" r="1"/>',
    'lock': '<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/>',
    'check': '<path d="m5 12 4 4L19 6"/>',
    'close': '<path d="m6 6 12 12M6 18 18 6"/>',
    'left': '<path d="m14 5-7 7 7 7"/>',
    'right': '<path d="m10 5 7 7-7 7"/>',
    'up': '<path d="m5 14 7-7 7 7"/>',
    'down': '<path d="m5 10 7 7 7-7"/>',
    'eye': '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
    'palette': '<path d="M12 3a9 9 0 1 0 0 18h1a2 2 0 0 0 1-4c-1-1 0-3 2-3h2a3 3 0 0 0 3-3 9 9 0 0 0-9-8Z"/><path d="M7 9h.01M11 6h.01M16 8h.01M6 14h.01"/>',
    'milestone': '<path d="m12 3 9 9-9 9-9-9z"/>',
    'refresh': '<path d="M20 4v6h-6M4 20v-6h6M5 8a8 8 0 0 1 13-3l2 5M4 14l2 5a8 8 0 0 0 13-3"/>',
}
_CACHE = {}


def action_icon(kind, color='#475569', on_color='#ffffff'):
    key = (kind, color, on_color)
    if key in _CACHE:
        return QIcon(_CACHE[key])
    if kind not in _PATHS:
        from .icons import icon_pixmap
        return QIcon(icon_pixmap(kind, color))
    icon = QIcon()
    for mode, state, ink in (
            (QIcon.Mode.Normal, QIcon.State.Off, color),
            (QIcon.Mode.Normal, QIcon.State.On, on_color),
            (QIcon.Mode.Disabled, QIcon.State.Off, '#a6adb8'),
            (QIcon.Mode.Disabled, QIcon.State.On, '#a6adb8')):
        svg = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" '
               f'fill="none" stroke="{ink}" stroke-width="1.7" '
               'stroke-linecap="round" stroke-linejoin="round">'
               + _PATHS[kind] + '</svg>')
        renderer = QSvgRenderer(QByteArray(svg.encode()))
        for size in (16, 20, 24, 32, 40, 48, 64, 80):
            pixmap = QPixmap(size, size)
            pixmap.fill(Qt.GlobalColor.transparent)
            painter = QPainter(pixmap)
            renderer.render(painter, QRectF(0, 0, size, size))
            painter.end()
            icon.addPixmap(pixmap, mode, state)
    _CACHE[key] = icon
    return QIcon(icon)


BUTTON_STYLE = """
QPushButton { background: #ffffff; color: #332c24; border: 1px solid #b3a888; border-radius: 6px; padding: 6px 10px; }
QPushButton:hover { background-color: #eef3f8; border-color: #6383a2; }
QPushButton:pressed { background-color: #dce7f1; }
QPushButton:disabled { color: #9aa1aa; border-color: #d5d7db; background: #f2f3f5; }
QPushButton:focus { border: 2px solid #5687b4; }
QPushButton[pfRole="primary"] { background: #2e4a66; color: white; border: 1px solid #2e4a66; font-weight: bold; }
QPushButton[pfRole="primary"]:hover { background: #3b5f82; }
QPushButton[pfRole="primary"]:pressed { background: #213b54; }
QPushButton[pfRole="primary"]:disabled { background: #e1e5ea; color: #9aa1aa; border-color: #d5d7db; }
QPushButton[pfRole="danger"] { color: #b03a2e; }
QPushButton[pfRole="danger"]:hover { background: #fff0ee; border-color: #bf665c; }
QPushButton[pfRole="danger"]:disabled { color: #a6adb8; }
"""


def _kind(text):
    if text in ('✕', '×'):
        return 'trash'
    if text in ('◀', '▶'):
        return 'left' if text == '◀' else 'right'
    for words, kind in (
        (('削除',), 'trash'), (('キャンセル', '閉じる'), 'close'),
        (('戻る',), 'left'), (('次へ',), 'right'),
        (('詳細表示',), 'detail'), (('並列表示',), 'parallel'),
        (('表示の選択', '現在の表示'), 'eye'),
        (('編集権',), 'lock'), (('色を選ぶ',), 'palette'),
        (('プラント操作', '開く'), 'folder'),
        (('新規作成', '新たに作成'), 'new_doc'),
        (('追加',), 'plus'), (('保存', '登録'), 'floppy'),
        (('編集', '変更'), 'pencil'), (('マスタ管理', '設定'), 'gear'),
        (('日付', '前工程の翌日'), 'calendar'),
        (('決定', 'OK', '適用', '並べ直す', '完了'), 'check'),
        (('Excel', 'PDF', '出力'), 'export'),
        (('作業時間',), 'clock'), (('工程',), 'parallel'), (('節目',), 'milestone'),
    ):
        if any(word in text for word in words):
            return kind
    return None


def polish_button(button):
    text = button.text().replace('&', '')
    kind = button.property('pfIcon') or _kind(text)
    box = button.parent()
    if not kind and isinstance(box, QDialogButtonBox):
        standard = box.standardButton(button)
        kind = {QDialogButtonBox.StandardButton.Ok: 'check',
                QDialogButtonBox.StandardButton.Save: 'floppy',
                QDialogButtonBox.StandardButton.Cancel: 'close',
                QDialogButtonBox.StandardButton.Close: 'close',
                QDialogButtonBox.StandardButton.Apply: 'check',
                QDialogButtonBox.StandardButton.Yes: 'check',
                QDialogButtonBox.StandardButton.No: 'close'}.get(standard)
    # Existing icon-only controls retain their purpose and tooltip.
    if kind:
        primary = bool(button.property('pfPrimary')) or text in ('保存', '決定', 'OK', '選択した項目を追加', 'このプリセットで並べ直す')
        danger = kind == 'trash'
        role = 'primary' if primary else 'danger' if danger else 'secondary'
        button.setProperty('pfRole', role)
        # The Gantt add button already has its own primary background.
        ink = '#ffffff' if primary else '#b03a2e' if danger else '#475569'
        button.setIcon(action_icon(kind, ink))
        button.setIconSize(QSize(18, 18))
    local = button.styleSheet()
    if local and not button.property('pfStatesStyled'):
        button.setProperty('pfStatesStyled', True)
        if '{' not in local:
            local = 'QPushButton {' + local + '}'
        button.setStyleSheet(local + """
            QPushButton:focus { border: 2px solid #5687b4; }
            QPushButton:disabled { color: #9aa1aa; background: #f2f3f5; border-color: #d5d7db; }
        """)
    if kind == 'plus' and text.startswith(('＋', '+')):
        button.setText(text[1:].strip())
        text = button.text()
    if not button.accessibleName():
        button.setAccessibleName(text or button.toolTip())
    compact = text in ('✕', '×', '◀', '▶')
    if button.maximumHeight() >= 16777215:
        button.setMinimumHeight(28 if compact else 34)
    # Keep the existing compact remove buttons usable with a single icon.
    if text in ('✕', '×'):
        button.setText('')
        button.setAccessibleName('この行を削除')
        button.setToolTip('この行を削除')
        button.setStyleSheet('QPushButton { padding: 0; border-radius: 5px; }')
    if text in ('◀', '▶'):
        button.setText('')
        button.setAccessibleName(button.toolTip() or ('左へ' if text == '◀' else '右へ'))
        button.setStyleSheet('QPushButton { padding: 0; border-radius: 5px; }')


class _UiPolisher(QObject):
    def eventFilter(self, obj, event):
        if event.type() == QEvent.Type.Polish:
            if isinstance(obj, QPushButton):
                polish_button(obj)
            elif isinstance(obj, QDialog) and not obj.property('pfPolished'):
                obj.setProperty('pfPolished', True)
                obj.setStyleSheet(obj.styleSheet() + BUTTON_STYLE)
                layout = obj.layout()
                if layout:
                    layout.setContentsMargins(16, 16, 16, 16)
                    layout.setSpacing(10)
                screen = obj.screen()
                if screen:
                    available = screen.availableGeometry()
                    obj.resize(min(obj.width(), max(400, available.width() - 48)),
                               min(obj.height(), max(320, available.height() - 64)))
        if event.type() in (QEvent.Type.Show, QEvent.Type.Polish) and isinstance(obj, QMenu):
            for action in obj.actions():
                kind = _kind(action.text())
                if kind and action.icon().isNull() and not action.isCheckable():
                    action.setIcon(action_icon(kind, '#b03a2e' if kind == 'trash' else '#475569'))
        return False


def install_ui():
    app = QApplication.instance()
    if app and not hasattr(app, '_phaseflow_ui_polisher'):
        app._phaseflow_ui_polisher = _UiPolisher(app)
        app.installEventFilter(app._phaseflow_ui_polisher)
