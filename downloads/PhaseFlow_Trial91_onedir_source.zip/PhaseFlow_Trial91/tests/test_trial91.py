import copy
import pytest
from datetime import timedelta
from PySide6.QtWidgets import QApplication
from kouteihyo.main_window import MainWindow
from kouteihyo.sample import build_sample_data
from kouteihyo import model as md

@pytest.mark.parametrize('width', [1024, 1366, 1720])
def test_daily_zoom_and_full_schedule_fit(width):
    app=QApplication.instance()
    data=build_sample_data()
    window=MainWindow(data)
    before=copy.deepcopy(data)
    try:
        window.resize(width, 850)
        window.show()
        app.processEvents()
        window.daily_view_btn.click()
        assert 1 <= window.gantt.view_days <= 62
        assert window.gantt._px() >= 17
        assert window.gantt_hbar.maximum() > 0
        window.gantt_hbar.setValue(window.gantt_hbar.maximum())
        window.fit_gantt_btn.click()
        for task in window.project().tasks:
            assert window.gantt.view_start <= task.dstart
            assert window.gantt.x_of(task.dend+timedelta(days=1)) <= window.gantt.width()
        assert window.gantt_hbar.value() == 0
        assert not window.gantt_hbar.isEnabled()
        assert data == before and not window.dirty
        assert window.fit_gantt_btn.width() >= window.fit_gantt_btn.sizeHint().width()
    finally:
        window.dirty=False;window.close()


def test_daily_zoom_follows_selected_task_and_hidden_in_parallel():
    window=MainWindow(build_sample_data())
    try:
        window.resize(1366,850);window.show();QApplication.processEvents()
        task=window.project().tasks[-1]
        window._on_selection(task.id)
        window.daily_view_btn.click()
        assert window.gantt.view_start <= task.dstart < window.gantt.view_start+timedelta(days=window.gantt.view_days)
        window._switch_view(1)
        assert not window.gantt_zoom_tools.isVisible()
        window._switch_view(0)
        assert window.gantt_zoom_tools.isVisible()
    finally:
        window.dirty=False;window.close()


def test_zoom_buttons_disabled_for_empty_project():
    window=MainWindow(md.AppData(projects=[md.Project(name='空の工事')]))
    try:
        assert not window.daily_view_btn.isEnabled()
        assert not window.fit_gantt_btn.isEnabled()
    finally:
        window.dirty=False;window.close()
