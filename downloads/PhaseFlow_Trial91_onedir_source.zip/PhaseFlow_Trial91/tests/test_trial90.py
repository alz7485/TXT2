import pytest
from PySide6.QtWidgets import QApplication
from kouteihyo import model as md
from kouteihyo.dialogs import ProjectPickerDialog
from kouteihyo.ui import install_ui

@pytest.mark.parametrize('single', [False, True])
def test_picker_rows_and_selection_survive_resize(single):
    install_ui()
    data = md.AppData(projects=[md.Project(id=str(i), name=f'工事{i}', plant='プラントA') for i in range(20)])
    picker = ProjectPickerDialog(data, ['0'], single=single)
    try:
        picker.show()
        QApplication.processEvents()
        assert picker.list.count() == 19
        assert picker.list.viewport().height() >= picker.list.sizeHintForRow(0) * 7
        picker.list.item(0).setSelected(True)
        picker.list.item(1).setSelected(True)
        expected = picker.chosen_ids()
        assert len(expected) == (1 if single else 2)
        old_height = picker.list.viewport().height()
        picker.resize(picker.width(), picker.height() + 100)
        QApplication.processEvents()
        assert picker.list.viewport().height() > old_height
        assert picker.chosen_ids() == expected
    finally:
        picker.close()
