"""Shared geometry renderer. The compiler is the only source of coordinates."""

import math
import tkinter as tk
from tkinter import font, ttk

COLORS = ("#60a5fa", "#2dd4bf", "#fbbf24", "#c4b5fd", "#fb7185", "#a3e635")


class DrawingCanvas(tk.Canvas):
    def __init__(self, parent, *, workspace=False, space_tabs=False, **kwargs):
        super().__init__(parent, bg="#101d30", highlightthickness=0, **kwargs)
        self.items = []
        self.space_tabs_enabled=space_tabs or workspace
        self.space_tabs=None
        self.known_spaces=[]
        self.workspace = workspace
        self.workspace_info = ("", "")
        self.layer_colors = {}
        self.overlay_controls = None
        root = self._root()
        if not hasattr(root, "_acadstadio_actual_colors"):
            root._acadstadio_actual_colors = tk.BooleanVar(master=root, value=True)
        self.actual_color_mode = root._acadstadio_actual_colors
        self._color_trace = self.actual_color_mode.trace_add("write", self.recolor)
        self.hud_font = font.nametofont("TkDefaultFont").copy()
        self.hud_font.configure(size=9)
        self.scale_value = 1
        self.offset = (0, 0)
        self.view_ratio = 1.0
        self.pan = [0.0, 0.0]
        self.highlight_filter = ([], None, None)
        self.geometry = []
        self._pattern_items=[]
        self._text_nodes=[];self._text_images={};self._text_colors={}
        self._drawing_item = None
        self._viewport_images={}
        self._camera_ready = False
        self.bind("<Configure>", lambda e: self.fit(
            preserve=True, preserve_camera=getattr(self, "_preserve_camera", False)
        ))
        self.bind("<MouseWheel>", self.zoom)
        self.bind("<Button-4>", lambda e: self.zoom(e, 1.15))
        self.bind("<Button-5>", lambda e: self.zoom(e, 1 / 1.15))
        self.bind("<ButtonPress-1>", lambda e: setattr(self, "drag_point", (e.x, e.y)))
        self.bind("<B1-Motion>", self.drag)
        self.bind("<Double-1>", self.edit_on_double_click)
        self.bind("<Destroy>", self.remove_color_trace, add="+")

    def editable_figures_at(self, x, y):
        nodes=set(self.find_overlapping(x-5,y-5,x+5,y+5))
        result=[];seen=set()
        for node,drawn,_ in reversed(self.geometry):
            item=drawn.get('_logical_parent',drawn)
            if node not in nodes or item.get('operation_deleted') or not item.get('command_path'):continue
            traces=item.get('command_addresses')
            key=(tuple(traces[-1]) if traces else (item.get('block_index'),item['command_path']),item.get('row',0))
            if key not in seen:result.append(item);seen.add(key)
        return result

    def edit_on_double_click(self, event):
        callback=getattr(self,'on_edit_command',None)
        if callback is None:
            self.fit();return 'break'
        items=self.editable_figures_at(event.x,event.y)
        if not items:
            self.fit();return 'break'
        if len(items)==1:
            callback(items[0]);return 'break'
        menu=getattr(self,'edit_source_menu',None)
        if menu is None or not menu.winfo_exists():menu=tk.Menu(self,tearoff=False)
        else:menu.delete(0,'end')
        for item in items:
            traces=item.get('command_addresses')
            path='.'.join(str(i+1) for i in traces[-1][3:] if isinstance(i,int)) if traces else item['command_path'].split('/')[0]
            branch='（条件外）' if traces and 'else' in traces[-1] else ''
            label=f"{item.get('block','ブロック')} / コマンド{path}{branch} / {item.get('row',0)+1}行目"
            menu.add_command(label=label,command=lambda selected=item:callback(selected))
        self.edit_source_menu=menu
        menu.tk_popup(event.x_root,event.y_root)
        return 'break'

    def set_color_resources(self, project):
        from block_model import nested
        self.known_spaces=list(dict.fromkeys([b['drawing_space'] for b in project.get('blocks',[]) if isinstance(b,dict) and b.get('drawing_space')]+[c.get('layout_name','') for b in project.get('blocks',[]) if isinstance(b,dict) for c in nested(b.get('commands',[])) if c.get('type') in ('SPACE','LAYOUT') and c.get('layout_name') and not c['layout_name'].startswith('=')]))
        roots=[f for f in project.get('block_folders',[]) if f.get('space')]
        if roots:self.known_spaces=[f['space'] for f in roots]
        self.space_ids={f['space']:f['id'] for f in roots}
        self.layer_colors = {
            str(layer["name"]).casefold(): int(float(layer.get("color", 7)))
            for layer in project.get("cad_setup", {}).get("layers", [])
        }
        setup=project.get('cad_setup',{})
        self.line_patterns={str(row['name']).casefold():tuple(float(n) for n in row.get('pattern',[])) for row in setup.get('linetypes',[])}
        self.layer_linetypes={str(row['name']).casefold():str(row.get('linetype','Continuous')) for row in setup.get('layers',[])}
        self.global_linetype_scale=float(setup.get('drawing_variables',{}).get('LTSCALE',1))

    def make_color_toggle(self, parent):
        button = ttk.Checkbutton(parent, text="実色表示", variable=self.actual_color_mode,
                                 style="Preview.Toggle.Toolbutton")
        button.icon_button_style = "Preview.Toggle.Toolbutton"
        button.icon_white = True
        return button

    def set_overlay_controls(self, frame):
        self.overlay_controls = frame
        frame.bind("<Configure>", lambda event: self.draw_workspace_info(), add="+")

    def recolor(self, *_):
        if self.winfo_exists():
            self.fit(preserve=True, preserve_camera=True)

    def remove_color_trace(self, event):
        if event.widget is self:
            self.actual_color_mode.trace_remove("write", self._color_trace)

    def display_color(self, item, fallback):
        from cad_colors import swatch
        if item.get("guide"):
            return "#718096"
        aci = item.get("color")
        if type(aci) is int and 1 <= aci <= 255:
            return swatch(aci)
        if self.actual_color_mode.get():
            if aci == 0:
                return swatch(7)
            layer = item.get("effective_layer", item.get("layer", ""))
            index = item.get("resolved_layer_color",self.layer_colors.get(str(layer).casefold()))
            if index is not None and 1 <= index <= 255:
                return swatch(index)
        return fallback

    def set_items(self, items, message=None, *, layer_order=None,
                  preserve_camera=False, recenter=False, camera_items=None):
        from range_selection import entities
        items=list(entities(items))
        if camera_items is not None:camera_items=list(entities(camera_items))
        if self.space_tabs_enabled and not getattr(self,'_space_rendering',False):
            from space_tabs import SpaceTabs
            if self.space_tabs is None:self.space_tabs=SpaceTabs(self)
            self.space_tabs.set_items(items,dict(message=message,layer_order=layer_order,preserve_camera=preserve_camera,recenter=recenter),camera_items)
            return
        self.empty_message = message or "行を選択すると、ここに作図結果を表示します"
        self.layer_order = layer_order
        self._preserve_camera = preserve_camera
        preserve = (bool(self.items) and bool(items)) or (preserve_camera and self._camera_ready)
        self.items = [item for item in items if not item.get("operation_deleted") and not item.get("preview_layer_hidden")]
        self._camera_items = [item for item in (items if camera_items is None else camera_items) if not item.get("operation_deleted")]
        self.fit(preserve=preserve, preserve_camera=preserve_camera, recenter=recenter)

    def _create(self, itemType, args, kw):
        node = super()._create(itemType, args, kw)
        if self._drawing_item is not None and "geometry" in self.gettags(node):
            item, color = self._drawing_item
            self.geometry.append((node, item, color))
        return node

    def bounds(self, items=None):
        points = []
        for item in self.items if items is None else items:
            v = item["coords"]
            typ = item.get("display_type",item["type"])
            if item.get('bulges'):
                from range_selection import geometry_bounds
                b=geometry_bounds(item);points.extend((b[:2],b[2:]));continue
            if item.get("block_geometry"):
                points.extend(self.bounds(item["block_geometry"]));continue
            if typ in ("TEXT", "MTEXT"): 
                from range_selection import geometry_bounds
                b=geometry_bounds(item);points.extend((b[:2],b[2:]));continue
            if typ in ("CIRCLE", "ARC"):
                points.extend([(v[0] - v[2], v[1] - v[2]), (v[0] + v[2], v[1] + v[2])])
            elif typ == "ELLIPSE":
                angle = math.radians(item.get("angle", 0))
                dx = math.hypot(v[2] * math.cos(angle), v[3] * math.sin(angle))
                dy = math.hypot(v[2] * math.sin(angle), v[3] * math.cos(angle))
                points.extend([(v[0]-dx, v[1]-dy), (v[0]+dx, v[1]+dy)])
            elif typ in ("DIMRADIUS", "DIMDIAMETER"):
                points.extend([(v[0]-v[2], v[1]-v[2]), (v[0]+v[2], v[1]+v[2]), (v[3], v[4])])
            elif typ == "SPLINE":
                points.extend(zip(item.get("curve", v)[::2], item.get("curve", v)[1::2]))
            else:
                points.extend(zip(v[::2], v[1::2]))
        return points

    def fit(self, *, preserve=False, preserve_camera=False, recenter=False):
        view = self.get_view() if preserve else {"zoom": 1, "pan": [0, 0]}
        self.delete("all")
        self.geometry = []
        self._pattern_items=[]
        self._text_nodes=[];self._text_images={};self._text_colors={}
        self.view_ratio = 1
        self.pan = [0.0, 0.0]
        self.xview_moveto(0)
        self.yview_moveto(0)
        w, h = max(120, self.winfo_width()), max(120, self.winfo_height())
        if preserve_camera and self._camera_ready:
            scale = self._base_scale
            old_w, old_h = self._camera_size
            offset = (self._base_offset[0] + (w - old_w) / 2,
                      self._base_offset[1] + (h - old_h) / 2)
            if recenter and getattr(self, "_camera_items", self.items):
                points = self.bounds(self._camera_items)
                cx = (min(x for x, y in points) + max(x for x, y in points)) / 2
                cy = (min(y for x, y in points) + max(y for x, y in points)) / 2
                offset = (w / 2 - cx * scale, h / 2 + cy * scale)
                view["pan"] = [0, 0]
        elif self.items or getattr(self,"reference_bounds",None):
            pts = self.bounds()
            xmin, xmax = min(x for x, y in pts), max(x for x, y in pts)
            ymin, ymax = min(y for x, y in pts), max(y for x, y in pts)
            scale = min(
                (w - 90) / max(1, xmax - xmin),
                (h - max(44, min(100, h * 0.2))) / max(1, ymax - ymin),
            )
            offset = (w / 2 - (xmin + xmax) * scale / 2,
                      h / 2 + (ymin + ymax) * scale / 2)
            self._camera_ready = True
        else:
            scale, offset = 1, (0, 0)
            self._camera_ready = False
        self.scale_value, self.offset = scale, offset
        self._base_scale, self._base_offset = scale, offset
        self._camera_size = (w, h)
        for x in range(20, w, 28):
            self.create_line(x, 0, x, h, fill="#192a40", tags="grid")
        for y in range(20, h, 28):
            self.create_line(0, y, w, y, fill="#192a40", tags="grid")
        if not self.items:
            self.create_text(
                w / 2,
                h / 2,
                text=getattr(
                    self, "empty_message", "行を選択すると、ここに作図結果を表示します"
                ),
                fill="#91a5bf",
                font=("TkDefaultFont", 11),
            )
            self.restore_view(view)
            self.draw_workspace_info()
            return
        xy = lambda x, y: (self.offset[0] + x * scale, self.offset[1] - y * scale)
        from affine_geometry import visual_entities
        rendered=list(visual_entities(self.items))
        layers = list(dict.fromkeys([*(getattr(self,"layer_order",None) or []),*(i.get("effective_layer",i.get("layer","0")) for i in rendered)]))
        colors = {name: COLORS[i % len(COLORS)] for i, name in enumerate(layers)}
        if self.actual_color_mode.get():
            colors = {name: self.display_color({"layer": name}, color) for name, color in colors.items()}
        for item in rendered:
            v = item["coords"]
            typ = item.get("display_type",item["type"])
            color = self.display_color(item, colors[item.get("effective_layer",item.get("layer", "0"))])
            self._drawing_item = item, color
            options = dict(fill=color, width=1, tags="geometry")
            from dash_preview import paths as dash_paths
            if self.linetype_pattern(item) and dash_paths(item):
                self._pattern_items.append((item,color))
                continue
            dash = self.linetype_dash(item)
            if dash:
                options["dash"] = dash
            stroke = {key: value for key, value in options.items() if key != "fill"}
            if item.get('segments'):
                for segment in item['segments']:
                    self.create_line(*xy(*segment[:2]),*xy(*segment[2:]),**options)
            elif typ == "CIRCLE":
                self.create_oval(
                    *xy(v[0] - v[2], v[1] + v[2]),
                    *xy(v[0] + v[2], v[1] - v[2]),
                    outline=color,
                    **stroke,
                )
            elif typ == "ARC":
                self.create_arc(*xy(v[0]-v[2], v[1]+v[2]), *xy(v[0]+v[2], v[1]-v[2]),
                                start=item["start_angle"], extent=item["sweep"], style="arc", outline=color, **stroke)
            elif typ == "ELLIPSE":
                a = math.radians(item.get("angle", 0))
                points = []
                for i in range(97):
                    t = i * 2 * math.pi / 96
                    x, y = v[2]*math.cos(t), v[3]*math.sin(t)
                    points.extend(xy(v[0]+x*math.cos(a)-y*math.sin(a), v[1]+x*math.sin(a)+y*math.cos(a)))
                self.create_line(*points, **options)
            elif typ == "HATCH":
                points=list(zip(v[::2],v[1::2]))
                screen=[z for p in points for z in xy(*p)]
                if item.get('pattern','').upper()=='SOLID':
                    self.create_polygon(*screen, fill=color, outline=color, tags='geometry')
                else:
                    from extended_commands import hatch_segments
                    self.create_polygon(*screen, fill='', outline=color, tags='geometry')
                    for a,b in hatch_segments(points,item.get('angle',0),item.get('scale',1)):
                        self.create_line(*xy(*a),*xy(*b),**options)
            elif typ == "SPLINE":
                curve=item.get('curve',v)
                self.create_line(*[z for p in zip(curve[::2],curve[1::2]) for z in xy(*p)],**options)
            elif typ == "LEADER":
                self.create_line(*[z for p in zip(v[::2],v[1::2]) for z in xy(*p)],arrow='first',**options)
                self.create_text(*xy(*v[-2:]),text=item.get('text',''),anchor='sw',fill=color,
                                 font=('TkDefaultFont',max(8,min(42,int(item.get('height',3.5)*scale)))),tags='geometry')
            elif typ in ("INSERT", "OFFSET", "TRIM", "EXTEND", "CHAMFER", "FILLET", "COPY", "MIRROR", "ROTATE", "ROTATECOPY", "ARRAYRECT", "EXPLODE", "CADBLOCK", "SCALE"):
                marker_coords=v[:2] if item.get("preview_applied") else v
                for x,y in zip(marker_coords[::2],marker_coords[1::2]):
                    px,py=xy(x,y)
                    self.create_line(px-5,py,px+5,py,**options)
                    self.create_line(px,py-5,px,py+5,**options)
                if typ!='INSERT' and not item.get('preview_applied'):
                    self.create_line(*xy(*v[:2]),*xy(*v[2:4]),fill=color,dash=(3,4),tags='geometry')
                px,py=xy(*v[:2])
                self.create_text(px,py,text=item.get('text','')+' '+item.get('preview_note',''),
                                 anchor='se' if px>self.winfo_width()/2 else 'sw',
                                 width=max(100,min(280,self.winfo_width()-40)),fill=color,tags='geometry')
            elif typ == "POLYLINE" or (typ == "LINE" and len(v)>4):
                if item.get("bulges"):v=item.get("curve",v)
                points = [xy(x, y) for x, y in zip(v[::2], v[1::2])]
                if item.get("closed"):
                    points.append(points[0])
                self.create_line(*[value for point in points for value in point], **options)
            elif typ == "POINT":
                x, y = xy(v[0], v[1])
                self.create_oval(x-2, y-2, x+2, y+2, fill=color, outline=color, tags="geometry")
            elif typ in ('TEXT','MTEXT'):
                node=self.create_image(0,0,anchor='nw',tags='geometry')
                self._text_nodes.append((node,item,color))
            elif typ == "LINE":
                self.create_line(*xy(v[0], v[1]), *xy(v[2], v[3]), **options)
            elif typ in ("DIMLINEAR", "DIMALIGNED"):
                x1, y1, x2, y2, x3, y3 = v
                horizontal = (item["dimension_axis"]=="horizontal") if item.get("dimension_axis") else y1 == y2 or (x1 != x2 and min(x1, x2) <= x3 <= max(x1, x2))
                if typ == "DIMALIGNED":
                    length = math.hypot(x2-x1, y2-y1)
                    nx, ny = -(y2-y1)/length, (x2-x1)/length
                    distance = (x3-x1)*nx + (y3-y1)*ny
                    a, b = (x1+nx*distance, y1+ny*distance), (x2+nx*distance, y2+ny*distance)
                    measure = length
                else:
                    a, b = ((x1, y3), (x2, y3)) if horizontal else ((x3, y1), (x3, y2))
                    measure = abs(x2-x1) if horizontal else abs(y2-y1)
                extensions = dict(options, dash=(3, 3))
                self.create_line(*xy(x1, y1), *xy(*a), **extensions)
                self.create_line(*xy(x2, y2), *xy(*b), **extensions)
                self.create_line(*xy(*a), *xy(*b), arrow="both", **options)
                self.create_text(
                    *xy((a[0] + b[0]) / 2, (a[1] + b[1]) / 2),
                    text=item.get("dimension_text", "<>").replace("<>", f"{measure:.4g}"),
                    fill=color,
                    anchor="s",
                    tags="geometry",
                )
            elif typ in ("DIMRADIUS", "DIMDIAMETER"):
                cx, cy, radius, tx, ty = v
                length = math.hypot(tx-cx, ty-cy)
                dx, dy = (tx-cx)*radius/length, (ty-cy)*radius/length
                start = (cx-dx, cy-dy) if typ == "DIMDIAMETER" else (cx, cy)
                self.create_line(*xy(*start), *xy(cx+dx, cy+dy), arrow="both" if typ == "DIMDIAMETER" else "last", **options)
                self.create_line(*xy(cx+dx, cy+dy), *xy(tx, ty), **options)
                label = f"φ{2*radius:.4g}" if typ == "DIMDIAMETER" else f"R{radius:.4g}"
                self.create_text(*xy(tx, ty), text=label, anchor="sw", fill=color, tags="geometry")
            else:
                self.create_rectangle(
                    *xy(v[0], v[1]),
                    *xy(v[2], v[3]),
                    outline=color,
                    **stroke,
                )
        self._drawing_item = None
        if not self.workspace:
            self.create_text(
                18, h - 18, anchor="w",
                text=f"{len(self.items)} 図形  /  単位: 図面単位", fill="#91a5bf",
            )
        legend_x = 18
        for i, name in enumerate(layers[:5]):
            label = "●  " + name
            if self.workspace:
                limit = max(40, (w - 36) // min(5, len(layers)) - 12)
                while self.hud_font.measure(label) > limit and len(label) > 4:
                    label = label[:-2] + "…"
            self.create_text(
                legend_x if self.workspace else 18, 20 if self.workspace else 18 + i * 20,
                anchor="w", text=label, fill=colors[name], tags="legend",
                font=self.hud_font if self.workspace else "TkDefaultFont",
            )
            if self.workspace:
                legend_x += self.hud_font.measure(label) + 16
        notes=list(dict.fromkeys(item.get('preview_note','') for item in self.items if item.get('preview_note') and (item.get('display_type',item.get('type')) in ('HATCH','SPLINE','TEXT','MTEXT') or 'viewport_view' in item)))
        from text_preview import layout
        if any(layout(i).substituted for _,i,_ in self._text_nodes):notes.append('文字：CADフォントが未指定・未導入の場合は代替フォントで表示')
        if notes:
            self.create_text(12,max(40,self.winfo_height()-48),text=' ／ '.join(notes),anchor='sw',fill='#9fb4cc',tags='preview-note',font='TkDefaultFont')
        self.draw_workspace_info()
        self.restore_view(view)
        self.highlight(*self.highlight_filter)

    def set_workspace_info(self, text, compact=None):
        self.workspace_info = (text, compact or text)
        self.draw_workspace_info()

    def draw_workspace_info(self):
        if not self.workspace:
            return
        self.delete("workspace-info")
        w, h = self.winfo_width(), self.winfo_height()
        full, compact = self.workspace_info
        reserve = max(180, self.overlay_controls.winfo_width()+24) if self.overlay_controls else 180
        text = full if self.hud_font.measure(full) <= w - reserve else compact
        while self.hud_font.measure(text) > max(50, w - reserve) and len(text) > 4:
            text = text[:-2] + "…"
        node = self.create_text(18, h - 23, anchor="w", text=text, fill="#b7c8df",
                                font=self.hud_font, tags="workspace-info")
        box = self.bbox(node)
        if box:
            background = self.create_rectangle(box[0]-4, box[1]-4, box[2]+4, box[3]+4,
                                                fill=self.cget("bg"), outline="", tags="workspace-info")
            self.tag_lower(background, node)

    def highlight(self, rows=(), preset=None, address=None):
        self.highlight_filter = (list(rows), preset, address)
        active = bool(rows) or preset is not None
        text_changed=False
        for node, item, color in self.geometry:
            matches = (not rows or item.get("row") in rows) and (
                preset is None
                or item.get("block_index", item.get("preset_index")) == preset
                or item.get("definition_block_index") == preset
                or any(at[1] == preset for at in item.get("command_addresses", []))
            )
            if address and len(address) >= 4 and address[0] in ("blocks", "presets"):
                if "command_addresses" in item:
                    matches = matches and tuple(address) in item["command_addresses"]
                else:
                    matches = matches and item.get("command_index") == address[3]
            typ = self.type(node)
            if typ=='image':
                shade=color if matches or not active else '#3e5068'
                text_changed=text_changed or self._text_colors.get(node,color)!=shade
                self._text_colors[node]=shade
                continue
            options = {
                "outline" if typ in ("oval", "rectangle") else "fill": color
                if matches or not active
                else "#3e5068"
            }
            if typ == "polygon":
                shade=color if matches or not active else '#3e5068'
                options={'outline':shade, **({'fill':shade} if self.itemcget(node,'fill') else {})}
            if typ != "text":
                options["width"] = 1 if item.get("guide") else 2 if active and matches else 1
            self.itemconfigure(node, **options)
        if text_changed:self.redraw_text()

    def get_view(self):
        return {"zoom": self.view_ratio, "pan": list(self.pan)}

    def linetype_pattern(self, item):
        name=str(item.get('resolved_layer_linetype',item.get('linetype','BYLAYER')))
        if name.upper()=='BYLAYER':name=getattr(self,'layer_linetypes',{}).get(str(item.get('effective_layer',item.get('layer','0'))).casefold(),'Continuous')
        pattern=getattr(self,'line_patterns',{}).get(name.casefold())
        if not pattern and name.upper()=='CENTER':pattern=(31.75,-6.35,6.35,-6.35)
        return pattern

    def linetype_dash(self, item):
        pattern=self.linetype_pattern(item)
        if not pattern:return None
        ratio=float(item.get('linetype_scale',1))*getattr(self,'global_linetype_scale',1)*self.scale_value
        # Simple DXF patterns alternate drawn strokes (zero is a dot) and gaps.
        # Rotate a leading gap to the end; merge adjacent entries of one sign.
        runs=[]
        for length in pattern:
            drawn=length>=0;size=max(1,abs(length)*ratio)
            if runs and runs[-1][0]==drawn:runs[-1]=(drawn,runs[-1][1]+size)
            else:runs.append((drawn,size))
        if runs and not runs[0][0]:runs=runs[1:]+runs[:1]
        if len(runs)>1 and runs[-1][0]==runs[0][0]:runs[0]=(runs[0][0],runs[0][1]+runs.pop()[1])
        if len(runs)<2:return None
        return tuple(max(1,min(255,round(size))) for drawn,size in runs)

    def update_dash_patterns(self):
        from dash_preview import paths,strokes
        old=set(self.find_withtag('cad-dash'));self.delete('cad-dash')
        self.geometry=[record for record in self.geometry if record[0] not in old]
        w,h=self.winfo_width(),self.winfo_height()
        def screen(p):
            bx=self._base_offset[0]+p[0]*self._base_scale;by=self._base_offset[1]-p[1]*self._base_scale
            return (w/2+(bx-w/2)*self.view_ratio+self.pan[0],h/2+(by-h/2)*self.view_ratio+self.pan[1])
        for item,color in self._pattern_items:
            pattern=self.linetype_pattern(item)
            ratio=float(item.get('linetype_scale',1))*getattr(self,'global_linetype_scale',1)*self.scale_value
            self._drawing_item=item,color
            for path in paths(item):
                for segment in strokes([screen(p) for p in path],pattern,ratio,(w,h)):
                    self.create_line(*segment,fill=color,width=1,tags=('geometry','cad-dash'))
            self._drawing_item=None
        drawn=set(self.find_withtag('cad-dash'))
        for node, item, _ in self.geometry:
            if node in drawn:continue
            if item["type"] != "POINT" and self.type(node) not in ("text","image"):
                dash = self.linetype_dash(item)
                if dash and self.type(node) in ('line','arc','oval','rectangle','polygon'):
                    self.itemconfigure(node, dash=dash)
        self.highlight(*self.highlight_filter)

    def draw_viewport_projections(self):
        self.delete('viewport-projection');self._viewport_images={}
        if not getattr(self,'_viewport_model_items',None) or not hasattr(self,'_base_scale'):return
        from PIL import ImageTk
        from viewport_projection import render
        w,h=self.winfo_width(),self.winfo_height()
        def screen(x,y):return (w/2+(self._base_offset[0]+x*self._base_scale-w/2)*self.view_ratio+self.pan[0],h/2+(self._base_offset[1]-y*self._base_scale-h/2)*self.view_ratio+self.pan[1])
        model_layers=list(dict.fromkeys(i.get('effective_layer',i.get('layer','0')) for i in self._viewport_model_items))
        def color(item):
            layer=item.get('effective_layer',item.get('layer','0'));fallback=COLORS[model_layers.index(layer)%len(COLORS)] if layer in model_layers else COLORS[0]
            return DrawingCanvas.display_color(self,item,fallback)
        for frame in self.items:
            if not frame.get('viewport_view'):continue
            result=render(frame,self._viewport_model_items,screen,self.scale_value,(w,h),color,self.linetype_pattern,getattr(self,'global_linetype_scale',1))
            if result is None:continue
            image,pos=result;photo=ImageTk.PhotoImage(image,master=self)
            node=self.create_image(*pos,image=photo,anchor='nw',tags='viewport-projection');self._viewport_images[node]=photo
            # Projection is below paper geometry and above the background grid.
            self.tag_lower(node)
        self.tag_lower('grid')

    def redraw_text(self):
        self.draw_viewport_projections()
        from PIL import ImageTk
        from text_preview import raster
        w,h=self.winfo_width(),self.winfo_height()
        def screen(x,y):
            bx=self._base_offset[0]+x*self._base_scale;by=self._base_offset[1]-y*self._base_scale
            return (w/2+(bx-w/2)*self.view_ratio+self.pan[0],h/2+(by-h/2)*self.view_ratio+self.pan[1])
        for node,item,color in self._text_nodes:
            image,pos=raster(item,self._text_colors.get(node,color),screen,self.scale_value,(w,h))
            photo=ImageTk.PhotoImage(image,master=self);self._text_images[node]=photo
            self.itemconfigure(node,image=photo);self.coords(node,*pos)

    def reset_camera(self):
        if self.space_tabs is not None:self.space_tabs.cameras.clear()
        self._camera_ready = False
        self.view_ratio = 1
        self.pan = [0.0, 0.0]

    def restore_view(self, view):
        try:
            ratio = float(view.get("zoom", 1))
            dx, dy = [float(v) for v in view.get("pan", [0, 0])]
            if not (
                math.isfinite(ratio)
                and 0.01 <= ratio <= 1000
                and all(math.isfinite(v) and abs(v) <= 1e7 for v in (dx, dy))
            ):
                return
        except (TypeError, ValueError, AttributeError):
            return
        w, h = self.winfo_width(), self.winfo_height()
        # Undo any existing viewport transform before applying a stored one.
        self.move("geometry", -self.pan[0], -self.pan[1])
        self.scale(
            "geometry", w / 2, h / 2, ratio / self.view_ratio, ratio / self.view_ratio
        )
        self.move("geometry", dx, dy)
        self.scale_value *= ratio / self.view_ratio
        self.view_ratio, self.pan = ratio, [dx, dy]
        self.update_dash_patterns()
        self.redraw_text()

    def drag(self, event):
        previous = getattr(self, "drag_point", (event.x, event.y))
        dx, dy = event.x - previous[0], event.y - previous[1]
        self.move("geometry", dx, dy)
        self.pan[0] += dx
        self.pan[1] += dy
        self.drag_point = event.x, event.y
        self.update_dash_patterns()
        self.redraw_text()

    def zoom(self, event, factor=None):
        factor = factor or (1.15 if event.delta > 0 else 1 / 1.15)
        if not 0.000001 < self.scale_value * factor < 1e8:
            return
        if not 0.01 <= self.view_ratio * factor <= 1000:
            return
        self.scale("geometry", event.x, event.y, factor, factor)
        self.pan = [
            factor * self.pan[0] + (1 - factor) * (event.x - self.winfo_width() / 2),
            factor * self.pan[1] + (1 - factor) * (event.y - self.winfo_height() / 2),
        ]
        self.view_ratio *= factor
        self.scale_value *= factor
        self.update_dash_patterns()
        self.redraw_text()
