"""Display-only 2D viewport rasterization; never creates selectable CAD entities."""
import math
from PIL import Image,ImageDraw
from affine_geometry import visual_entities
from range_selection import geometry_bounds
from dash_preview import paths,strokes,clip


def paper_point(point,viewport):
    x,y,u,v=viewport['coords'];view=viewport['viewport_view'];cx,cy=view['center'];scale=view['scale']
    return ((x+u)/2+(point[0]-cx)*scale,(y+v)/2+(point[1]-cy)*scale)


def dimension_parts(item):
    """Approximate native dimensions not carrying imported rendered geometry."""
    kind=item.get('display_type',item['type']);c=item['coords'];style={k:item[k] for k in ('layer','effective_layer','color','linetype','linetype_scale') if k in item}
    if kind in ('DIMLINEAR','DIMALIGNED'):
        x,y,u,v,a,b=c
        if kind=='DIMALIGNED':
            length=math.hypot(u-x,v-y)
            if not length:return []
            nx,ny=-(v-y)/length,(u-x)/length;d=(a-x)*nx+(b-y)*ny
            p,q=(x+nx*d,y+ny*d),(u+nx*d,v+ny*d);measure=length
        else:
            horizontal=item.get('dimension_axis')=='horizontal' if item.get('dimension_axis') else y==v or x!=u and min(x,u)<=a<=max(x,u)
            p,q=((x,b),(u,b)) if horizontal else ((a,y),(a,v));measure=abs(u-x) if horizontal else abs(v-y)
        lines=[(x,y,*p),(u,v,*q),(*p,*q)];position=((p[0]+q[0])/2,(p[1]+q[1])/2)
        text=item.get('dimension_text','<>').replace('<>',f'{measure:.4g}')
    elif kind in ('DIMRADIUS','DIMDIAMETER'):
        x,y,r,a,b=c;angle=math.atan2(b-y,a-x);dx,dy=r*math.cos(angle),r*math.sin(angle)
        p=(x-dx,y-dy) if kind=='DIMDIAMETER' else (x,y);q=(x+dx,y+dy)
        lines=[(*p,*q)];position=(a,b);text=('φ' if kind=='DIMDIAMETER' else 'R')+f'{2*r if kind=="DIMDIAMETER" else r:.4g}'
    else:return []
    result=[dict(style,type='LINE',coords=line) for line in lines]
    if lines:
        a,b,u,v=lines[-1];angle=math.atan2(v-b,u-a);size=item.get('dimension_arrow_size',2.5)
        for tip,direction in ([((u,v),angle+math.pi)] if kind=='DIMRADIUS' else [((a,b),angle),((u,v),angle+math.pi)]):
            for turn in (-.3,.3):result.append(dict(style,type='LINE',coords=(*tip,tip[0]+size*math.cos(direction+turn),tip[1]+size*math.sin(direction+turn))))
    result.append(dict(style,type='TEXT',coords=(*position,item.get('dimension_text_height',2.5)),text=text,text_halign='1',text_valign='1'))
    return result


def render(viewport,models,screen,paper_scale,size,color_of,pattern_of=lambda item:None,global_scale=1.):
    """Return (RGBA image, top-left pixel); the image itself clips all strokes/text."""
    view=viewport.get('viewport_view')
    if not view or not view.get('enabled',True):return None
    x,y,u,v=viewport['coords'];a=screen(min(x,u),max(y,v));b=screen(max(x,u),min(y,v))
    left=max(0,math.ceil(a[0]));top=max(0,math.ceil(a[1]));right=min(size[0],math.floor(b[0])+1);bottom=min(size[1],math.floor(b[1])+1)
    if right<=left or bottom<=top:return None
    image=Image.new('RGBA',(right-left,bottom-top));draw=ImageDraw.Draw(image)
    scale=view['scale'];cx,cy=view['center'];world=(cx-abs(u-x)/2/scale,cy-abs(v-y)/2/scale,cx+abs(u-x)/2/scale,cy+abs(v-y)/2/scale)
    def local(px,py):
        q=paper_point((px,py),viewport);sx,sy=screen(*q);return sx-left,sy-top
    frozen={n.casefold() for n in view.get('frozen_layers',[])}
    model_scale=paper_scale*scale
    def paint(item):
        if item.get('guide') or item.get('operation_deleted') or item.get('preview_layer_hidden') or item.get('layer_hidden'):return
        layer=str(item.get('effective_layer',item.get('layer','0')))
        if layer.casefold() in frozen:return
        kind=item.get('display_type',item['type'])
        if kind in ('SELECT','CUSTOM'):return
        if kind.startswith('DIM'):
            for part in dimension_parts(item):paint(part)
            return
        try:box=geometry_bounds(item)
        except (KeyError,ValueError,IndexError,TypeError):return
        if box[2]<world[0] or box[0]>world[2] or box[3]<world[1] or box[1]>world[3]:return
        color=color_of(item)
        if kind in ('TEXT','MTEXT'):
            from text_preview import raster
            text,pos=raster(item,color,local,model_scale,image.size)
            image.alpha_composite(text,(int(pos[0]),int(pos[1])))
            return
        if kind=='POINT':
            px,py=local(*item['coords'][:2]);draw.ellipse((px-1,py-1,px+1,py+1),fill=color);return
        path_list=paths(item)
        if kind in ('SPLINE','HATCH','LEADER'):
            c=item.get('curve',item['coords']);points=list(zip(c[::2],c[1::2]));path_list=[points+([points[0]] if kind=='HATCH' and points else [])]
        if kind=='HATCH' and path_list:
            if item.get('pattern','').upper()=='SOLID':
                draw.polygon([local(*p) for p in path_list[0]],fill=color);return
            from extended_commands import hatch_segments
            boundary=list(zip(item['coords'][::2],item['coords'][1::2]))
            path_list.extend([[a,b] for a,b in hatch_segments(boundary,item.get('angle',0),item.get('scale',1))])
        pattern=pattern_of(item)
        for path in path_list:
            points=[local(*p) for p in path]
            if pattern:
                ratio=float(item.get('linetype_scale',1))*global_scale*model_scale
                for segment in strokes(points,pattern,ratio,image.size):draw.line(segment,fill=color,width=1)
            else:
                for a,b in zip(points,points[1:]):
                    visible=clip(a,b,*image.size)
                    if visible is not None:
                        lo,hi=visible;dx,dy=b[0]-a[0],b[1]-a[1]
                        draw.line((a[0]+dx*lo,a[1]+dy*lo,a[0]+dx*hi,a[1]+dy*hi),fill=color,width=1)
        if kind=='LEADER' and item.get('text'):
            paint(dict(item,type='TEXT',display_type='TEXT',coords=(*item['coords'][-2:],item.get('height',3.5))))
    for item in visual_entities(models):paint(item)
    return image,(left,top)
