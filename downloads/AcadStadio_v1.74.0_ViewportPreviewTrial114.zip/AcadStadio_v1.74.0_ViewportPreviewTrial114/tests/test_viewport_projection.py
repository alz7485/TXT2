import sys,unittest,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from viewport_projection import paper_point,render
from test_native_operations import project
from engine import compile_project
class ViewportProjection(unittest.TestCase):
 def frame(self,**view):return dict(type='RECTANGLE',coords=(20,20,100,100),cad_space='A4',viewport_view=dict(center=(0,0),scale=1,**view))
 def paint(self,frame,models):return render(frame,models,lambda x,y:(x,200-y),1,(200,200),lambda item:'#ffffff')
 def test_center_scale_and_clip_do_not_modify_model(self):
  frame=self.frame();frame['viewport_view'].update(center=(10,20),scale=.5)
  self.assertEqual(paper_point((10,20),frame),(60,60))
  self.assertEqual(paper_point((30,40),frame),(70,70))
  models=[dict(type='LINE',coords=(-1000,20,1000,20),cad_space='Model')];before=copy.deepcopy(models)
  image,pos=self.paint(frame,models)
  self.assertEqual(pos,(20,100));self.assertEqual(image.size,(81,81));self.assertTrue(image.getbbox())
  self.assertEqual(models,before)
 def test_hidden_frozen_guide_and_off_viewports_are_respected(self):
  line=dict(type='LINE',coords=(-10,0,10,0),layer='隠す')
  for item,frame in [(dict(line,guide=True),self.frame()),(dict(line,preview_layer_hidden=True),self.frame()),(line,self.frame(frozen_layers=['隠す']))]:
   image,_=self.paint(frame,[item]);self.assertIsNone(image.getbbox())
  self.assertIsNone(self.paint(self.frame(enabled=False),[line]))
 def test_text_curves_and_dimensions_are_clipped(self):
  models=[dict(type='TEXT',coords=(-50,0,20),text='CAD viewport text'),dict(type='CIRCLE',coords=(0,0,25)),dict(type='DIMLINEAR',coords=(-20,-10,20,-10,0,-20))]
  image,pos=self.paint(self.frame(),models)
  self.assertTrue(image.getbbox());self.assertLessEqual(pos[0]+image.width,101)
 def test_compiler_records_view_and_imported_view_update_without_projection_entities(self):
  model=dict(type='CIRCLE',x='0',y='0',r='10')
  create=dict(type='VIEWPORT',viewport_action='矩形を作成',x1='0',y1='0',x2='100',y2='80',configure_view=True,view_x='5',view_y='6',view_scale='1/2',import_viewport_id=3)
  p=project([model,dict(type='SPACE',space_mode='レイアウト空間',layout_name='A4'),create,dict(type='VIEWPORT',viewport_action='表示中心・尺度',viewport_id='3',view_x='20',view_y='30',view_scale='1/5')])
  from space_folders import ensure_space_folders
  ensure_space_folders(p)
  _,items=compile_project(p,[0]);frame=items[-1]
  self.assertEqual(len(items),2);self.assertEqual(frame['viewport_view']['center'],(20,30));self.assertAlmostEqual(frame['viewport_view']['scale'],.2)
  self.assertEqual(items[0]['cad_space'],'Model')
 def test_unknown_view_does_not_guess_projection(self):
  self.assertIsNone(self.paint(dict(type='RECTANGLE',coords=(0,0,100,100)),[]))
 def test_separate_views_and_text_clipping(self):
  line=dict(type='LINE',coords=(-10,0,10,0))
  image,_=self.paint(self.frame(),[line]);self.assertTrue(image.getbbox())
  frame=self.frame();frame['viewport_view']['center']=(1000,1000)
  image,_=self.paint(frame,[line]);self.assertIsNone(image.getbbox())
  image,pos=self.paint(self.frame(),[dict(type='TEXT',coords=(-45,0,20),text='Viewport clipped text')])
  self.assertTrue(image.getbbox());self.assertLessEqual(image.width,81)
 def test_solid_hatch_is_filled_within_frame(self):
  image,pos=self.paint(self.frame(),[dict(type='HATCH',coords=(-100,-100,100,-100,100,100,-100,100),pattern='SOLID')])
  self.assertEqual(image.getpixel((40,40))[3],255)
 def test_unknown_viewport_number_stops_stale_projection(self):
  from space_folders import ensure_space_folders
  p=project([dict(type='SPACE',space_mode='レイアウト空間',layout_name='A4'),dict(type='VIEWPORT',configure_view=True,x1='0',y1='0',x2='100',y2='100',view_x='0',view_y='0',view_scale='1'),dict(type='VIEWPORT',viewport_action='表示中心・尺度',viewport_id='5',view_x='500',view_y='500',view_scale='2')]);ensure_space_folders(p)
  _,items=compile_project(p,[0]);self.assertIsNone(items[0]['viewport_view']);self.assertIn('枠のみ',items[0]['preview_note'])
