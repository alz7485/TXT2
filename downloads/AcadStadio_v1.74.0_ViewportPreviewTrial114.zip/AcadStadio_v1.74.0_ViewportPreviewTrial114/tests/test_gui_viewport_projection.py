import sys,os,unittest,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from block_model import new_block
from macro_editor import edit_command
from engine import compile_project
from space_folders import ensure_space_folders
from PIL import ImageTk
@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI display unavailable')
class ViewportProjectionGui(unittest.TestCase):
 setUp=gui.Gui.setUp
 tearDown=gui.Gui.tearDown
 def scene(self):
  model=new_block('モデル円',commands=[dict(type='CIRCLE',x='0',y='0',r='20'),dict(type='LINE',x1='-100',y1='0',x2='100',y2='0')]);model['drawing_space']='Model'
  paper=new_block('レイアウト',commands=[]);paper['drawing_space']='A4'
  p=copy.deepcopy(self.app.data);p['blocks']=[model,paper];ensure_space_folders(p)
  return p,model,paper
 def test_layout_projects_model_clips_and_keeps_paper_selection_and_script(self):
  p,model,paper=self.scene();paper['commands']=[dict(type='VIEWPORT',viewport_action='矩形を作成',configure_view=True,x1='0',y1='0',x2='100',y2='80',view_x='0',view_y='0',view_scale='1')]
  self.app.replace_document(p);self.app.preview(quiet=True);self.root.update();before=self.app.compile()[0]
  c=self.app.canvas;c.space_tabs.select_space('A4');self.root.update()
  self.assertEqual(len(c._viewport_images),1)
  self.assertTrue(all(i['cad_space']=='A4' for i in c.items))
  self.assertTrue(all(c.type(n)=='image' for n in c._viewport_images))
  self.assertFalse(set(c._viewport_images)&{n for n,_,_ in c.geometry})
  self.assertTrue(any(ImageTk.getimage(photo).getbbox() for photo in c._viewport_images.values()))
  c.view_ratio=1.4;c.pan=[15,20];c.fit(preserve=True,preserve_camera=True);self.root.update()
  self.assertEqual(len(c._viewport_images),1)
  c.space_tabs.select_space('Model');self.root.update();self.assertFalse(c._viewport_images)
  c.space_tabs.select_space('A4');self.root.update();self.assertEqual(len(c._viewport_images),1)
  self.assertEqual(self.app.compile()[0],before)
 def test_create_editor_exposes_center_scale_and_configures_view(self):
  p,model,paper=self.scene()
  def inspect():
   w=gui.top(self.root,'コマンドの設定')
   try:
    for key in ('view_x','view_y','view_scale'):self.assertIn(key,w.command_entries)
    w.refresh_command_preview();self.root.update()
    self.assertTrue(w.command_preview.canvas._viewport_images)
    gui.button(w,'コマンドを反映').invoke()
   except Exception as exc:self.errors.append(exc);w.destroy()
  self.root.after(200,inspect)
  result=edit_command(self.root,dict(type='VIEWPORT'),p['blocks'],p,previous_blocks=[model],owner_block_id=paper['id'],owner_space='A4',creating=True)
  self.assertTrue(result['configure_view'])
  self.assertEqual(result['view_scale'],'1')
