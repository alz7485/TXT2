# 最新追加：図形の外接範囲を点参照

command_points.selection_geometry_pointsが外接範囲最小／最大を提供。engineとcommand_workbenchが登録し、selection_reference_boundsが各対象のmin/maxで選択窓を作成。円・楕円・円弧に対応。range_selection.geometry_boundsで円弧の実際の範囲を計算。コア513件・スモーク成功。

# 今回の追加：SELECTの作成案内と点参照範囲

変更先：macro_editor.py、select_editor.py、新規selection_reference_bounds.py。
仕様と制限：docs/SELECT.md。点参照範囲はmin/maxで窓を作成。生座標方式も維持。
前回整理時の「src・testsは不変」は今回の追加には当てはまりません。

# 開発引き継ぎ — 1.72.2-beta107

## 最初に読む資料

README.md → docs/VALIDATION.md。機能に関わる資料だけdocs/INDEX.mdから読むこと。
過去のTrialを順番に読む必要はありません。実装の正本はsrc/です。

## 維持する仕様

- 保存モデル版11。project → blocks配列 → commands。BLOCK.nameは参照先ID。
- blocks配列が実行順。block_tree_order等の表示順と混同しないこと。
- フォルダ分類や解放で作図順、ID、参照、SCRを変更しないこと。
- 点参照と設定参照のID、表参照式、Undo／Redo、原子的保存・世代バックアップを保持。
- 作図属性は読込／フォルダ化時に保持。重複削除は明示的な属性整理時だけ。
- 設定参照は同一ブロック内のAPPEARANCE／SYSVAR／SYSVARS／LAYEREDIT。
- 任意SCRの見た目はプレビューで再現しない。Windows／AutoCAD実機検証済みと主張しない。

## 最近の主な実装先

- プレビュータブ：src/space_tabs.py
- フォルダ表示：src/block_browser.py、block_folders.py
- 範囲フォルダ化：src/figure_folder_ui.py、figure_folders.py
- 設定参照：src/setting_references.py
- SCR選択行プレビュー：src/script_preview.py、engine.py
- 作図属性：src/appearance_commands.py

## 検証

```sh
python tests/smoke_test.py
python scripts/run_checks.py --mode core
python scripts/run_checks.py --mode gui
```

GUI試験は表示環境が必要。次の実機確認対象はWindows 11／Python 3.11とAutoCADでのSCR実行。
整理版ではアプリ本体・assets・examples・testsを変更していません。
過去の資料はHistoryArchive ZIPに退避。古い資料の記述より現在のソースと機能別資料を優先してください。
