"""Build a tight selection window from stable command point expressions."""
import math
from command_points import geometry_points, reference
from range_selection import geometry_bounds


def reference_window(members, identity):
    if not members:
        raise ValueError('範囲内に対象図形がありません。')
    axes=[[],[]]
    for item in members:
        if item.get('entity_parent') is not None:
            raise ValueError('連続線の一部分は点参照の自動範囲にできません。座標を使用してください。')
        from command_points import selection_geometry_points
        points=selection_geometry_points(item)
        if not all(name in points for name in ('外接範囲最小','外接範囲最大')):
            raise ValueError('図形の最大・最小座標を取得できません。座標を使用してください。')
        key=identity(item)
        if not key:raise ValueError('参照元のコマンドを特定できません。座標を使用してください。')
        for axis in (0,1):
            axes[axis].extend(reference(key,name,'XY'[axis]) for name in ('外接範囲最小','外接範囲最大'))
    result={'mode':'window'}
    for axis,expressions in enumerate(axes):
        expressions=list(dict.fromkeys(expressions))
        for suffix,fn,sign in (('1','min','-'),('4','max','+')):
            term=expressions[0] if len(expressions)==1 else fn+'('+', '.join(expressions)+')'
            result['xy'[axis]+suffix]=term+sign+'0.0000001'
    return result
