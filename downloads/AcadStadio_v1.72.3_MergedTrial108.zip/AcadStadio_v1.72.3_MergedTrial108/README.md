# AcadStadio 1.72.3-beta108（統合版）

添付Trial108の点参照フロー修正を、SELECT改良・ドロップ対策・ビルド修正を含む最新版へ統合しました。

## 今回の変更

点参照確定後は X → 同じ点のY → 次の点のXY。XYで確定した場合は次の点もXYのまま続けます。参照元・参照点・角度を保持し、最後の点で終了します。

SELECTの＋／−選択、最大最小XYの点参照化、安全な点参照による除外、作成制限・削除時の利用コマンド確認を維持しています。DXF／DWGのドロップ対策とPyInstallerのQt競合対策も含みます。

## 起動

Python 3.11以上とTkinterを用意してください。

```sh
python -m pip install -r requirements.txt
python src/main.py
```

Windows用ビルド手順はEXE_BUILD_ONEDIR.md。EXEは同梱していません。

## 資料

- 基本操作：docs/QUICK_START.txt
- SELECT：docs/SELECT.md
- 開発引き継ぎ：START_HERE_FOR_CODEX.md
- 統合内容：docs/MERGE_Trial108.md
- 検証結果：docs/VALIDATION.md
- その他の機能資料：docs/INDEX.md

Windows／AutoCAD実機・SCR実行・EXEビルドは未確認です。
