# 変更履歴

## 1.72.3-beta108 統合版

- 添付Trial108の点参照入力フロー（X→Y→次点XY／XY→次点XY）を統合。
- こちらのSELECT改良・安全な除外点参照・ドロップ対策・Qtビルド設定を保持。
- Treeviewの単位付きindentを標準変換で処理。
- コアと関連GUIで回帰確認。詳細はdocs/VALIDATION.md。

Trial107以前の全履歴は最初の整理時のHistoryArchive ZIPに保管しています。
