# 統合版の検証

## 今回実行した検証

- コア522件成功。
- スモークテスト成功。
- Linux／実Tk／Xorgで点参照関連GUI30件成功。
  - test_gui_point_continuation
  - test_gui_inline_point_reference
  - test_gui_direct_point_candidates
  - test_gui_command_points
  - test_gui_derived_points
  - test_gui_point_headers
- 同じ表示環境でSELECT関連GUI7件成功。
  - test_gui_safe_exclusion（今回追加1件）
  - test_gui_select_command
  - test_gui_range_selection

GUI合計37件。点参照のX→Y→次点XY、XY連続入力、確定経路、取消、参照元保持と、実SELECTエディタで安全な点参照除外→外接範囲参照化→確定後コンパイルを確認しました。

## 統合の整合性

添付の変更はTrial107整理版を共通の元として比較。macro_editor.pyの入力フロー2か所、バージョン、関連テストを反映。SELECT・ドロップ対策の主要ソースとspecは直前のSafeExclude版との一致を確認。
ZIP生成時に全収録ファイルのSHA256・ZIP整合性を検証します。

## 未実施

全GUI試験の一括実行、Windows実機、AutoCAD上のSCR実行、Windows EXEビルドは未実施です。
Windowsのドロップ対策はWin32 APIモックによるコア検証を含みますが、実際のExplorer操作での解消確認ではありません。
