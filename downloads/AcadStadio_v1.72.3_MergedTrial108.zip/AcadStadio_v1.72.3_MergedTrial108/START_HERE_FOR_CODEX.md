# 開発引き継ぎ：1.72.3-beta108 統合版

まずREADME.md → docs/MERGE_Trial108.md → docs/VALIDATION.mdを読むこと。古いTrial資料を順番に読む必要はありません。

## 現在の実装

- 点参照の入力フロー：macro_editor.py。X→Y→次点XY、XY→次点XY。参照元・参照点・角度を引き継ぐ。
- SELECT：selection_sets.py、select_editor.py。追加全体から除外全体を差し引く。
- 安全な除外：selection_pick_reference.py。新規−は個別クリック・元図形の点参照。unique_pick=Trueは異なる図形種類も含めて重複検査。旧数値除外は互換保持。
- 外接範囲：command_points.selection_geometry_points、selection_reference_bounds.py。最大最小XYを点参照式で窓へ変換し、除外条件は保持。
- SELECT削除：selection_deletion.py。利用コマンドの削除／キャンセル、直前に連続SELECTが残るときは付け替えて残す選択も可能。
- SELECT前提の新規作成は挿入位置の直前がSELECTのときだけ。
- Windowsドロップ：file_drop.py。ネイティブ受信はパスをキューへコピーし、Tkタイマーで配信。コールバック保持と終了時の後始末。
- EXE：AcadStadio.specでQt系6種を除外。Tkinterアプリ。

## 維持する仕様

保存モデル版11、project→blocks配列→commands。blocks配列が実行順。表示順と混同しないこと。
BLOCK.nameは参照先ID。点・設定参照のID、表参照式、Undo／Redo、原子的保存・バックアップを保持。
読込属性の重複削除は明示的な整理時だけ。任意SCRの見た目をプレビュー再現できると主張しない。

## 検証

python scripts/run_checks.py --mode core
python scripts/run_checks.py --mode gui（表示環境が必要）
python tests/smoke_test.py

Windows／AutoCAD実機の検証済みとは主張しないこと。
