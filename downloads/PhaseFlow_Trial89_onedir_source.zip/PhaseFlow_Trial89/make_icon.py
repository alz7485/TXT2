# -*- coding: utf-8 -*-
"""PhaseFlow 第一案アイコンをPNG/ICOへ再生成（Pillowが必要）。
承認済みのブランド画像 branding/PhaseFlow_icon_master.png を使用。
"""
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parent
MASTER = ROOT / "branding" / "PhaseFlow_icon_master.png"
OUT = ROOT / "kouteihyo" / "assets"

def main():
    if not MASTER.is_file():
        raise FileNotFoundError(f"アイコン原画がありません: {MASTER}")
    OUT.mkdir(parents=True, exist_ok=True)
    im = Image.open(MASTER).convert("RGBA")
    im.resize((256, 256), Image.Resampling.LANCZOS).save(OUT / "icon.png")
    im.save(OUT / "icon.ico", format="ICO", sizes=[
        (16, 16), (24, 24), (32, 32), (48, 48),
        (64, 64), (128, 128), (256, 256),
    ])
    print("PhaseFlow icon ready:", OUT)

if __name__ == "__main__":
    main()
