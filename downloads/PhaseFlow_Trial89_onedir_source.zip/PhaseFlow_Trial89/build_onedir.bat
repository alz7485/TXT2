﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem PhaseFlow / Windows onedir build
rem Output: dist\PhaseFlow\PhaseFlow.exe
python -m pip install PyInstaller PySide6 openpyxl reportlab
if errorlevel 1 goto :error
python -m PyInstaller --clean --noconfirm --windowed --onedir --name PhaseFlow --icon "kouteihyo\assets\icon.ico" --add-data "kouteihyo\assets;kouteihyo\assets" main.py
if errorlevel 1 goto :error
copy /Y "holidays.txt" "dist\PhaseFlow\holidays.txt" >nul
if errorlevel 1 goto :error
echo.
echo Build complete: dist\PhaseFlow\PhaseFlow.exe
echo Distribute the ENTIRE dist\PhaseFlow folder.
pause
exit /b 0
:error
echo.
echo Build failed. Review the error output.
pause
exit /b 1
