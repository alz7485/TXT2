# -*- coding: utf-8 -*-
"""プロパティパネル用の小さな線画アイコン（QPainter描画）。"""
from __future__ import annotations

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QBrush, QColor, QPainter, QPen, QPixmap, QPolygonF

_cache = {}


def _person(p: QPainter, cx: float, cy: float, scale: float, col: QColor,
            fill_bg: bool):
    r = 3.0 * scale
    head = QRectF(cx - r, cy - 8 * scale, 2 * r, 2 * r)
    body = QRectF(cx - 4.6 * scale, cy - 1.2 * scale, 9.2 * scale, 9.6 * scale)
    if fill_bg:
        p.setBrush(QColor("#ffffff"))
    else:
        p.setBrush(Qt.BrushStyle.NoBrush)
    p.setPen(QPen(col, 1.6))
    p.drawEllipse(head)
    p.drawRoundedRect(body, 2 * scale, 2 * scale)


def draw_person_glyph(p: QPainter, cx: float, top: float, h: float,
                      color: QColor):
    """ガント用: 高さ h の人のシンボル（塗りのシルエット）を描く。"""
    r = h * 0.17
    head_cy = top + r + 0.4
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QBrush(color))
    p.drawEllipse(QPointF(cx, head_cy), r, r)
    bw = h * 0.54
    body_top = head_cy + r * 0.8
    p.drawRoundedRect(QRectF(cx - bw / 2, body_top, bw, top + h - body_top),
                      bw * 0.34, bw * 0.34)


def icon_pixmap(kind: str, color: str = "#786e64") -> QPixmap:
    key = (kind, color)
    if key in _cache:
        return _cache[key]
    S = 40
    pm = QPixmap(S, S)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    col = QColor(color)
    cx = cy = S / 2
    pen = QPen(col, 2.2)
    p.setPen(pen)
    p.setBrush(Qt.BrushStyle.NoBrush)
    if kind == "start":
        p.setBrush(col)
        p.drawPolygon(QPolygonF([QPointF(cx - 6, cy - 8), QPointF(cx - 6, cy + 8),
                                 QPointF(cx + 8, cy)]))
    elif kind == "end":
        p.drawLine(QPointF(cx - 6, cy - 9), QPointF(cx - 6, cy + 9))
        p.setBrush(col)
        p.drawPolygon(QPolygonF([QPointF(cx - 6, cy - 9), QPointF(cx + 8, cy - 4),
                                 QPointF(cx - 6, cy + 1)]))
    elif kind == "span":
        p.drawLine(QPointF(cx - 10, cy), QPointF(cx + 10, cy))
        p.setBrush(col)
        p.drawPolygon(QPolygonF([QPointF(cx - 10, cy), QPointF(cx - 4, cy - 4),
                                 QPointF(cx - 4, cy + 4)]))
        p.drawPolygon(QPolygonF([QPointF(cx + 10, cy), QPointF(cx + 4, cy - 4),
                                 QPointF(cx + 4, cy + 4)]))
    elif kind == "calendar":
        p.drawRect(QRectF(cx - 10, cy - 8, 20, 17))
        p.drawLine(QPointF(cx - 10, cy - 2), QPointF(cx + 10, cy - 2))
        p.drawLine(QPointF(cx - 5, cy - 11), QPointF(cx - 5, cy - 5))
        p.drawLine(QPointF(cx + 5, cy - 11), QPointF(cx + 5, cy - 5))
    elif kind == "link":
        p.drawLine(QPointF(cx - 10, cy - 4), QPointF(cx + 6, cy - 4))
        p.setBrush(col)
        p.drawPolygon(QPolygonF([QPointF(cx + 10, cy - 4), QPointF(cx + 4, cy - 8),
                                 QPointF(cx + 4, cy)]))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawLine(QPointF(cx + 10, cy + 5), QPointF(cx - 6, cy + 5))
        p.setBrush(col)
        p.drawPolygon(QPolygonF([QPointF(cx - 10, cy + 5), QPointF(cx - 4, cy + 1),
                                 QPointF(cx - 4, cy + 9)]))
    elif kind == "people":
        _person(p, cx, cy, 1.3, col, True)
    elif kind == "strips":
        # 作業時間・属性の帯表示（人＋行リスト）
        _person(p, 12, 20, 1.05, col, True)
        p.setPen(QPen(col, 2.2))
        p.drawLine(QPointF(24, 13), QPointF(36, 13))
        p.drawLine(QPointF(24, 20), QPointF(36, 20))
        p.drawLine(QPointF(24, 27), QPointF(36, 27))
    elif kind == "chart":
        p.setBrush(col)
        p.drawRect(QRectF(cx - 10, cy + 1, 5, 8))
        p.drawRect(QRectF(cx - 2.5, cy - 3, 5, 12))
        p.drawRect(QRectF(cx + 5, cy - 8, 5, 17))
    elif kind == "clock":
        p.drawEllipse(QRectF(cx - 10, cy - 10, 20, 20))
        p.drawLine(QPointF(cx, cy), QPointF(cx, cy - 6))
        p.drawLine(QPointF(cx, cy), QPointF(cx + 5, cy + 3))
    elif kind == "memo":
        p.drawRect(QRectF(cx - 8, cy - 10, 16, 20))
        p.setPen(QPen(col, 1.4))
        for dy in (-4, 0, 4):
            p.drawLine(QPointF(cx - 4, cy + dy), QPointF(cx + 4, cy + dy))
    # --- 上部バー用（Trial10: 標準アイコンをやめて独自の線画に統一） ---
    elif kind == "new_doc":
        p.drawRect(QRectF(cx - 8, cy - 10, 16, 20))
        p.drawLine(QPointF(cx - 3.5, cy), QPointF(cx + 3.5, cy))
        p.drawLine(QPointF(cx, cy - 3.5), QPointF(cx, cy + 3.5))
    elif kind == "folder":
        p.drawLine(QPointF(cx - 10, cy + 8), QPointF(cx - 10, cy - 5))
        p.drawLine(QPointF(cx - 10, cy - 5), QPointF(cx - 3, cy - 5))
        p.drawLine(QPointF(cx - 3, cy - 5), QPointF(cx - 1, cy - 2))
        p.drawLine(QPointF(cx - 1, cy - 2), QPointF(cx + 10, cy - 2))
        p.drawLine(QPointF(cx + 10, cy - 2), QPointF(cx + 10, cy + 8))
        p.drawLine(QPointF(cx + 10, cy + 8), QPointF(cx - 10, cy + 8))
    elif kind == "floppy":
        p.drawRoundedRect(QRectF(cx - 9, cy - 9, 18, 18), 2, 2)
        p.drawRect(QRectF(cx - 5, cy - 9, 10, 7))
        p.drawRect(QRectF(cx - 6, cy + 2, 12, 7))
    elif kind == "gear":
        import math
        for k in range(8):
            a = math.radians(k * 45)
            p.drawLine(QPointF(cx + 6.2 * math.cos(a), cy + 6.2 * math.sin(a)),
                       QPointF(cx + 9.6 * math.cos(a), cy + 9.6 * math.sin(a)))
        p.drawEllipse(QRectF(cx - 6.5, cy - 6.5, 13, 13))
        p.drawEllipse(QRectF(cx - 2.4, cy - 2.4, 4.8, 4.8))
    elif kind == "list":
        for dy in (-6, 0, 6):
            p.drawRect(QRectF(cx - 10, cy + dy - 1.6, 3.2, 3.2))
            p.drawLine(QPointF(cx - 4, cy + dy), QPointF(cx + 10, cy + dy))
    elif kind == "export":
        p.drawLine(QPointF(cx, cy + 4), QPointF(cx, cy - 8))
        p.setBrush(col)
        p.drawPolygon(QPolygonF([QPointF(cx, cy - 10), QPointF(cx - 4, cy - 4),
                                 QPointF(cx + 4, cy - 4)]))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawLine(QPointF(cx - 10, cy + 1), QPointF(cx - 10, cy + 9))
        p.drawLine(QPointF(cx - 10, cy + 9), QPointF(cx + 10, cy + 9))
        p.drawLine(QPointF(cx + 10, cy + 9), QPointF(cx + 10, cy + 1))
    elif kind == "print":
        p.drawRect(QRectF(cx - 9, cy - 3, 18, 8))            # 本体
        p.drawRect(QRectF(cx - 5.5, cy - 9.5, 11, 6))        # 上の紙
        p.setBrush(QBrush(col))
        p.drawRect(QRectF(cx - 5.5, cy + 3.5, 11, 6.5))      # 出てきた紙
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawLine(QPointF(cx - 3.5, cy + 6), QPointF(cx + 3.5, cy + 6))
        p.drawLine(QPointF(cx - 3.5, cy + 8.4), QPointF(cx + 3.5, cy + 8.4))
    elif kind == "undo":
        p.drawArc(QRectF(cx - 7.5, cy - 7.5, 15, 15), 120 * 16, 300 * 16)
        p.setBrush(col)
        p.drawPolygon(QPolygonF([QPointF(cx - 8.6, cy - 6.2),
                                 QPointF(cx - 2.4, cy - 10.0),
                                 QPointF(cx - 2.9, cy - 3.4)]))
        p.setBrush(Qt.BrushStyle.NoBrush)
    elif kind == "redo":
        p.drawArc(QRectF(cx - 7.5, cy - 7.5, 15, 15), 60 * 16, -300 * 16)
        p.setBrush(col)
        p.drawPolygon(QPolygonF([QPointF(cx + 8.6, cy - 6.2),
                                 QPointF(cx + 2.4, cy - 10.0),
                                 QPointF(cx + 2.9, cy - 3.4)]))
        p.setBrush(Qt.BrushStyle.NoBrush)
    elif kind == "lock":
        # 南京錠（全体の線画トーンに合わせた専用アイコン）
        p.drawArc(QRectF(cx - 6, cy - 12, 12, 12), 0, 180 * 16)
        p.drawLine(QPointF(cx - 6, cy - 6), QPointF(cx - 6, cy - 2))
        p.drawLine(QPointF(cx + 6, cy - 6), QPointF(cx + 6, cy - 2))
        p.drawRoundedRect(QRectF(cx - 9, cy - 2, 18, 13), 2.5, 2.5)
        p.setBrush(col)
        p.drawEllipse(QPointF(cx, cy + 4.5), 1.9, 1.9)
        p.setBrush(Qt.BrushStyle.NoBrush)
    elif kind == "plus":
        p.drawLine(QPointF(cx - 8, cy), QPointF(cx + 8, cy))
        p.drawLine(QPointF(cx, cy - 8), QPointF(cx, cy + 8))
    elif kind == "pencil":
        p.save()
        p.translate(cx, cy)
        p.rotate(-45)
        p.drawRect(QRectF(-3, -8, 6, 13))
        p.drawLine(QPointF(-3, -4.5), QPointF(3, -4.5))
        p.drawLine(QPointF(-3, 5), QPointF(0, 10.5))
        p.drawLine(QPointF(3, 5), QPointF(0, 10.5))
        p.restore()
    elif kind == "trash":
        p.drawLine(QPointF(cx - 9.5, cy - 5.5), QPointF(cx + 9.5, cy - 5.5))
        p.drawLine(QPointF(cx - 3, cy - 5.5), QPointF(cx - 3, cy - 8.5))
        p.drawLine(QPointF(cx + 3, cy - 5.5), QPointF(cx + 3, cy - 8.5))
        p.drawLine(QPointF(cx - 3, cy - 8.5), QPointF(cx + 3, cy - 8.5))
        p.drawLine(QPointF(cx - 7, cy - 5.5), QPointF(cx - 5.2, cy + 9))
        p.drawLine(QPointF(cx + 7, cy - 5.5), QPointF(cx + 5.2, cy + 9))
        p.drawLine(QPointF(cx - 5.2, cy + 9), QPointF(cx + 5.2, cy + 9))
        p.drawLine(QPointF(cx - 2.4, cy - 1.5), QPointF(cx - 2.4, cy + 5))
        p.drawLine(QPointF(cx + 2.4, cy - 1.5), QPointF(cx + 2.4, cy + 5))
    p.end()
    _cache[key] = pm
    return pm


def app_icon():
    """アプリのアイコン（assets/icon.png を読む。無ければ空アイコン）。"""
    from pathlib import Path
    from PySide6.QtGui import QIcon
    path = Path(__file__).resolve().parent / "assets" / "icon.png"
    return QIcon(str(path)) if path.exists() else QIcon()
