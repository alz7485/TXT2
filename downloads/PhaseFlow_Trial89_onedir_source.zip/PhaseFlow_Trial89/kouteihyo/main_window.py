# -*- coding: utf-8 -*-
"""メインウィンドウ：詳細表示（ガント＋日付表/プロパティ）と並列表示。"""
from __future__ import annotations

import copy
import json
from datetime import date, timedelta

from PySide6.QtCore import QEvent, QPoint, QSize, Qt, QTimer
from PySide6.QtGui import (QCursor, QGuiApplication, QIcon, QKeySequence,
                           QPageLayout, QPainter, QShortcut)
from PySide6.QtPrintSupport import QPrintDialog, QPrinter
from PySide6.QtWidgets import (QApplication, QAbstractItemView, QAbstractSpinBox, QComboBox, QDialog, QFrame, QHBoxLayout,
                               QLabel, QLineEdit, QListWidget, QMainWindow, QMenu, QPlainTextEdit,
                               QMessageBox, QPushButton, QScrollArea, QScrollBar,
                               QSizePolicy,
                               QSplitter, QStackedWidget, QTabWidget,
                               QTextEdit, QVBoxLayout, QWidget, QFileDialog,
                               QInputDialog)

from . import exports, model as md
from .dialogs import (AddItemDialog, CreationWizard, DateSettingsDialog,
                      MasterDialog, ProjectListDialog, ProjectPickerDialog,
                      SettingsDialog, ShiftDialog, StartupGuideDialog,
                      PdfExportDialog,
                      ItemPresetDialog)
from .gantt import GanttWidget, NAME_W as GANTT_NAME_W, HEADER_H as GANTT_HEADER_H
from .icons import icon_pixmap
from .ui import action_icon, install_ui, BUTTON_STYLE
from .panels import DateTable, PropertyPanel
from .parallel import ParallelWidget


class MasterListDialog(QDialog):
    def __init__(self, data, parent=None):
        super().__init__(parent)
        from .item_editor import EDITOR_STYLE, MasterLibrary, button, label
        self.setObjectName('itemEditor')
        self.setStyleSheet(EDITOR_STYLE)
        self.setWindowTitle('項目マスタ管理')
        self.resize(960, 660)
        self.data = data
        self.changed = False
        layout = QVBoxLayout(self)
        layout.addWidget(label('項目マスタ', title=True))
        self.library = MasterLibrary(data, self)
        self.library.changed.connect(self._mark_changed)
        layout.addWidget(self.library, 1)
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(button('閉じる', 'close', self.accept))
        layout.addLayout(row)

    def _mark_changed(self):
        self.changed = True


class MainWindow(QMainWindow):
    def __init__(self, data: md.AppData, workspace: str = "", plants=None):
        super().__init__()
        install_ui()
        from .icons import app_icon
        self.setWindowIcon(app_icon())
        self.data = data
        self.workspace = workspace
        self.path = workspace  # 旧名の互換
        if plants is not None:
            self.plant_names = list(plants)
        else:
            self.plant_names = []
            for pr in data.projects:
                if pr.plant and pr.plant not in self.plant_names:
                    self.plant_names.append(pr.plant)
        self.dirty = False
        self.edit_session = None
        errors = getattr(data, "_load_errors", [])
        self.workspace_error = (
            "読み込めないファイルがあります。上書きを防ぐため閲覧専用で開きます。\n"
            + "\n".join(errors)
            + "\nbackup フォルダの正常な世代を確認し、元ファイルを退避して復元した後、置き場を開き直してください。"
            if errors else "")
        if workspace and md.Path(workspace).exists() and not self.workspace_error:
            try:
                self.edit_session = md.WorkspaceSession(workspace, data)
            except Exception as e:
                # 壊れた共有データは上書きせず閲覧専用で開く。
                self.workspace_error = str(e)
        self._edit_project_id = None
        self._read_only = False
        self._lock_owner = ""
        self._manual_readonly_id = ""
        self.current_project_id = data.projects[0].id if data.projects else ""
        first = data.projects[0] if data.projects else None
        self.current_plant = (first.plant if first and first.plant else
                              self.plant_names[0] if self.plant_names else "")
        _valid = {pr.id for pr in data.projects}
        self.view_ids = ([i for i in data.settings.view_ids if i in _valid]
                         or [pr.id for pr in data.projects])
        self._active_preset_id = (data.settings.view_preset_id
                                  if data.settings.view_mode == "preset"
                                  else "")
        self.selected_task_id = ""
        self._snapshot = {}
        self._undo_stack = []
        self._redo_stack = []
        self._last_json = None
        md.load_holidays()
        self.setWindowTitle("PhaseFlow")
        # 画面の実寸に合わせて起動し、小さい画面にも固定1420pxを強制しない。
        scr = QGuiApplication.primaryScreen()
        avail = scr.availableGeometry() if scr else None
        if avail:
            self.resize(min(1720, max(1000, avail.width() - 40)),
                        min(1040, max(640, avail.height() - 64)))
        else:
            self.resize(1720, 1040)
        self.setMinimumSize(1000, 640)
        self._build_ui()
        self._refresh_all()
        QShortcut(QKeySequence.StandardKey.Undo, self, self._undo)
        QShortcut(QKeySequence.StandardKey.Redo, self, self._redo)
        QShortcut(QKeySequence("Ctrl+Y"), self, self._redo)
        QShortcut(QKeySequence.StandardKey.Save, self, self._save)
        self._update_undo_buttons()
        QTimer.singleShot(0, self, self._place_toggle)
        QTimer.singleShot(0, self, self._place_corner_seg)
        self._poll_timer = QTimer(self)
        self._poll_timer.setInterval(10000)
        self._poll_timer.timeout.connect(self._poll_external_changes)
        self._poll_timer.start()
        if self.workspace_error:
            QTimer.singleShot(0, self, lambda: QMessageBox.warning(
                self, "共有データを確認してください",
                "置き場に問題があるため閲覧専用で開きました。\n" + self.workspace_error))

    # ---------- UI構築 ----------
    def _build_ui(self):
        central = QWidget()
        root = QVBoxLayout(central)
        self.setCentralWidget(central)
        # Trial3: 全体の強弱。地はグレージュ、押せるものは白、
        # 「今の表示」だけ濃い青で塗る。集計行は濃色帯にする（下記 summary）。
        self.setStyleSheet(
            "QMainWindow { background: #e8e4da; }"
            "QPushButton { background: #ffffff; border: 1px solid #b3a888;"
            " border-radius: 4px; padding: 5px 10px; color: #332c24; }"
            "QPushButton:hover { border-color: #2e4a66; color: #2e4a66; }"
            "QPushButton:checked { background: #2e4a66; color: #ffffff;"
            " font-weight: bold; border-color: #2e4a66; }"
            "QComboBox { background: #ffffff; border: 1px solid #b3a888;"
            " border-radius: 4px; padding: 4px 6px; color: #241f18; }"
            "QTabWidget::pane { background: #ffffff; border: 1px solid #c4b998; }"
            "QTabBar::tab { background: #ddd6c4; color: #6e6455;"
            " padding: 6px 16px; border: 1px solid #c4b998;"
            " border-bottom: none; }"
            "QTabBar::tab:selected { background: #ffffff; color: #241f18;"
            " font-weight: bold; }"
            # Trial40: 標準の付属ボタンは幅が広く、狭い欄で数値や日付が
            # 見切れるため細く固定する。プルダウンの選択中は濃青＋白字で
            # 明示する（既定だと黒地で文字が見えなかった）。
            "QSpinBox { background: #ffffff; border: 1px solid #b3a888;"
            " border-radius: 3px; }"
            "QSpinBox::up-button, QSpinBox::down-button { width: 14px; }"
            "QDoubleSpinBox::up-button, QDoubleSpinBox::down-button"
            " { width: 14px; }"
            "QDateEdit::drop-down { width: 16px; }"
            "QComboBox::drop-down { width: 16px; }"
            "QComboBox QAbstractItemView { background: #fdfbf5;"
            " color: #241f18; selection-background-color: #fdeed3;"
            " selection-color: #241f18; }")

        # --- 上部バー（Trial4: ボタン13個→アイコン＋メニューに集約） ---
        self.setStyleSheet(self.styleSheet() + BUTTON_STYLE)
        root.setContentsMargins(12, 10, 12, 10)
        root.setSpacing(8)
        bar = QHBoxLayout()
        bar.setSpacing(6)
        root.addLayout(bar)
        def icon_btn(kind, tooltip, slot):
            b = QPushButton()
            b.setIcon(action_icon(kind))
            b.setIconSize(QSize(18, 18))
            b.setFixedSize(34, 34)
            b.setToolTip(tooltip)
            b.setStyleSheet("padding: 0;")
            b.clicked.connect(slot)
            return b

        def text_btn(kind, text, tooltip, slot):
            b = QPushButton(text)
            b.setIcon(action_icon(kind))
            b.setIconSize(QSize(18, 18))
            b.setToolTip(tooltip)
            b.setStyleSheet("padding: 5px 9px;")
            b.clicked.connect(slot)
            return b

        def sep():
            f = QFrame()
            f.setFrameShape(QFrame.Shape.VLine)
            f.setStyleSheet("color: #b3a888;")
            return f

        # 1行目：ファイル系（開く・保存・プリセット・履歴・印刷・設定・出力）
        # 新規作成・開くは工事一覧から行う（Trial71）
        bar.addWidget(text_btn("list", "工事一覧",
                               "工事とプラントの一覧・管理", self._show_project_list))
        bar.addWidget(text_btn("floppy", "保存", "保存", self._save))
        bar.addWidget(sep())
        self._vp_menu = QMenu(self)
        self._vp_menu.aboutToShow.connect(self._build_vp_menu)
        # プリセット関係は「項目編集」ボタンに集約（Trial71）
        bar.addWidget(text_btn("pencil", "項目編集",
                               "項目プリセットの適用・登録と項目マスタの管理",
                               self._open_item_editor))
        bar.addWidget(sep())
        self.undo_btn = icon_btn("undo", "元に戻す (Ctrl+Z)", self._undo)
        self.redo_btn = icon_btn("redo", "やり直す (Ctrl+Y)", self._redo)
        bar.addWidget(self.undo_btn)
        bar.addWidget(self.redo_btn)
        bar.addSpacing(8)
        bar.addStretch(1)
        bar.addWidget(text_btn("print", "印刷", "今の画面を印刷",
                               self._print_current))
        bar.addWidget(text_btn("gear", "設定", "設定", self._settings))
        export_menu = QMenu(self)
        export_menu.addAction("Excel出力…", self._export_excel)
        export_menu.addAction("PDF出力…", self._export_pdf)
        export_btn = QPushButton("出力")
        export_btn.setIcon(action_icon("export"))
        export_btn.setIconSize(QSize(18, 18))
        export_btn.setToolTip("Excel / PDF 出力")
        export_btn.setStyleSheet(
            "QPushButton { padding: 5px 18px 5px 9px; }")
        export_btn.setMenu(export_menu)
        bar.addWidget(export_btn)

        # 2行目：表示関係（詳細／並列で中身が入れ替わる）
        bar2 = QHBoxLayout()
        bar2.setSpacing(4)
        root.addLayout(bar2)
        seg = QWidget(self)
        self.view_seg = seg
        seg_lay = QHBoxLayout(seg)
        seg_lay.setContentsMargins(0, 0, 0, 0)
        seg_lay.setSpacing(0)
        seg_style = ("QPushButton { background: #ffffff; border: 1px solid #b3a888;"
                     " padding: 5px 7px; color: #332c24; }"
                     "QPushButton:checked { background: #2e4a66; color: #ffffff;"
                     " font-weight: bold; border-color: #2e4a66; }")
        self.detail_btn = QPushButton("詳細表示")
        self.detail_btn.setMinimumWidth(120)
        self.detail_btn.setCheckable(True)
        self.detail_btn.setChecked(True)
        self.detail_btn.setStyleSheet(
            seg_style + "QPushButton { border-radius: 0; border-top-left-radius: 6px; border-bottom-left-radius: 6px; }")
        self.parallel_btn = QPushButton("並列表示")
        self.parallel_btn.setMinimumWidth(120)
        self.parallel_btn.setCheckable(True)
        self.parallel_btn.setStyleSheet(
            seg_style + "QPushButton { border-radius: 0; border-top-right-radius: 6px; border-bottom-right-radius: 6px; border-left: none; }")
        self.detail_btn.clicked.connect(self._goto_detail)
        self.parallel_btn.clicked.connect(lambda: self._switch_view(1))
        for b in (self.detail_btn, self.parallel_btn):
            b.setSizePolicy(QSizePolicy.Policy.Preferred,
                            QSizePolicy.Policy.Expanding)
        seg_lay.addWidget(self.detail_btn)
        seg_lay.addWidget(self.parallel_btn)
        self.strips_btn = QPushButton()
        self.strips_btn.setIcon(action_icon("strips", on_color="#2e4a66"))
        self.strips_btn.setIconSize(QSize(20, 20))
        self.strips_btn.setFixedSize(34, 34)
        self.strips_btn.setCheckable(True)
        self.strips_btn.setChecked(self.data.settings.show_jinko
                                    and self.data.settings.show_attrs)
        self.strips_btn.setStyleSheet(
            "QPushButton { background: #ffffff; border: 1px solid #8a7f63;"
            " border-radius: 4px; padding: 0; }"
            "QPushButton:checked { background: #fdeed3;"
            " border: 1px solid #8a7f63; }")
        self.strips_btn.setToolTip("ガントに作業時間・作業内容を表示")
        self.strips_btn.clicked.connect(self._toggle_strips)
        seg_lay.addSpacing(8)
        seg_lay.addWidget(self.strips_btn, 0, Qt.AlignmentFlag.AlignVCenter)
        # 表示切替は2行目へ分離し、ファイル操作の行に余裕を持たせる。
        bar2.addWidget(seg)
        bar2.addSpacing(16)

        # 並列側の表示道具（レーン表示・追加・表示の選択）
        self.parallel_tools = QWidget()
        pt = QHBoxLayout(self.parallel_tools)
        pt.setContentsMargins(0, 0, 0, 0)
        pt.setSpacing(0)
        mode_label = QLabel("レーン表示")
        mode_label.setStyleSheet("font-weight: bold; color: #57503f;")
        pt.addWidget(mode_label)
        pt.addSpacing(8)
        self.pmode_btns = {}
        pm_modes = (("milestone", "節目"), ("process", "工程"),
                    ("labor", "作業時間"))
        for i, (key, label) in enumerate(pm_modes):
            b = QPushButton(label)
            b.setCheckable(True)
            radius = ("border-top-left-radius: 6px; border-bottom-left-radius: 6px;" if i == 0 else
                      "border-top-right-radius: 6px; border-bottom-right-radius: 6px;" if i == len(pm_modes) - 1 else "")
            extra = "" if i == 0 else " border-left: none;"
            b.setStyleSheet(seg_style +
                            f"QPushButton {{ border-radius: 0; {radius}{extra} }}")
            b.clicked.connect(lambda _=False, k=key: self._set_parallel_mode(k))
            pt.addWidget(b)
            self.pmode_btns[key] = b
        pt.addSpacing(8)
        # 追加はレーン下段の「＋追加」カードに集約（Trial75）
        guide_btn = QPushButton("表示の選択…")
        guide_btn.setToolTip("表示の選び方を変える（起動時の案内と同じ）")
        guide_btn.clicked.connect(self.show_startup_guide)
        pt.addWidget(guide_btn)
        bar2.addWidget(self.parallel_tools)
        self.parallel_tools.setVisible(False)
        self.lock_status = QLabel("編集状態を確認中")
        self.lock_status.setToolTip("工事単位の編集権（他のPCの編集中は閲覧専用）")
        self.lock_status.setMinimumWidth(108)
        # 編集状態は保存の右に置く（Trial73）
        bar.insertWidget(2, self.lock_status)
        self.lock_retry_btn = QPushButton("編集権を取得")
        self.lock_retry_btn.setProperty("pfIcon", "lock")
        self.lock_retry_btn.clicked.connect(self._toggle_project_lock)
        bar.insertWidget(3, self.lock_retry_btn)
        self.lock_retry_btn.setVisible(False)
        bar2.addStretch(1)

        self.stack = QStackedWidget()
        root.addWidget(self.stack, 1)

        # --- 詳細ページ ---
        detail = QWidget()
        dlay = QVBoxLayout(detail)
        splitter = QSplitter(Qt.Orientation.Horizontal)
        self.splitter = splitter
        dlay.setContentsMargins(0, 0, 0, 0)
        dlay.setSpacing(8)
        splitter.setHandleWidth(8)
        splitter.setChildrenCollapsible(False)
        dlay.addWidget(splitter, 1)
        self._detail_page = detail
        # 開閉ボタン: 右パネルの左端（境界）に重ね、縦は中央に置く
        self.right_toggle = QPushButton("", detail)
        self.right_toggle.setIcon(action_icon("right"))
        self.right_toggle.setIconSize(QSize(16, 16))
        self.right_toggle.setAccessibleName("右パネルを閉じる")
        self.right_toggle.setFixedSize(22, 52)
        self.right_toggle.setToolTip("右パネルを閉じる")
        self.right_toggle.setStyleSheet(
            "QPushButton { background: #ffffff; border: 1px solid #b3a888;"
            " border-radius: 3px; padding: 0; font-size: 10px; color: #57503f; }"
            "QPushButton:hover { background: #fdeed3; }")
        self.right_toggle.clicked.connect(self._toggle_right_panel)
        self._right_open = True
        self._right_width = 500
        splitter.splitterMoved.connect(lambda *_: self._place_toggle())
        detail.installEventFilter(self)
        left = QWidget()
        llay = QVBoxLayout(left)
        llay.setContentsMargins(0, 0, 0, 0)
        llay.setSpacing(4)
        # 作成の流れ（4ステップ）の案内バーは廃止し、上に詰める（Trial63）。
        # step_btns は参照箇所のため空のまま残す（_update_steps 等は無動作）。
        self.step_btns = []
        self.gantt = GanttWidget()
        self.gantt.master_by_id = {m.id: m for m in self.data.masters}
        self.gantt.data = self.data
        self.gantt.set_show_options(self.data.settings.show_jinko,
                                    self.data.settings.show_attrs)
        self.scroll = QScrollArea()
        self.scroll.setWidget(self.gantt)
        # ガントは表示幅に合わせて伸縮する（右パネルを閉じたら全幅に広がる）
        self.scroll.setWidgetResizable(True)
        self.scroll.setStyleSheet(
            "QScrollArea { background: #e8e4da; border: 1px solid #b3a888; }")
        # 項目の追加・削除はガント左上の見出し位置に重ねる（Trial72）
        corner_seg = QWidget(self)
        self.corner_seg = corner_seg
        cs_lay = QHBoxLayout(corner_seg)
        cs_lay.setContentsMargins(0, 0, 0, 0)
        cs_lay.setSpacing(8)
        cs_lay.addStretch(1)
        add_btn = QPushButton("項目追加")
        add_btn.setProperty("pfPrimary", True)
        add_btn.setToolTip("この工事に項目を追加")
        add_btn.setStyleSheet(
            "background: #2e4a66; color: #ffffff; font-weight: bold;"
            " border: 1px solid #2e4a66; border-radius: 4px;"
            " padding: 6px 10px;")
        add_btn.clicked.connect(self._add_item)
        self.add_item_btn = add_btn
        cs_lay.addWidget(add_btn)
        del_btn = QPushButton("削除")
        del_btn.setStyleSheet(
            "background: #ffffff; color: #b03a2e; font-weight: bold;"
            " border: 1px solid #b03a2e; border-radius: 4px;"
            " padding: 6px 10px;")
        del_btn.setToolTip("選択中の項目をこの工事から削除")
        del_btn.clicked.connect(lambda: self._delete_task(self.selected_task_id))
        del_btn.setEnabled(False)
        self.del_item_btn = del_btn
        cs_lay.addWidget(del_btn)
        cs_lay.addStretch(1)
        llay.addWidget(self.scroll, 1)
        self.gantt_hbar = QScrollBar(Qt.Orientation.Horizontal)
        llay.addWidget(self.gantt_hbar)
        self.gantt_hbar.valueChanged.connect(self._gantt_pan)
        self.gantt.view_changed.connect(self._sync_gantt_hbar)
        splitter.addWidget(left)
        self.tabs = QTabWidget()
        self.table = DateTable()
        self.table.data = self.data
        self.prop = PropertyPanel()
        self.tabs.addTab(self.table, "日付表")
        self.tabs.addTab(self.prop, "プロパティ")
        self.tabs.setTabIcon(0, action_icon("calendar", on_color="#475569"))
        self.tabs.setTabIcon(1, action_icon("list", on_color="#475569"))
        self.tabs.setMinimumWidth(360)
        splitter.addWidget(self.tabs)
        splitter.setSizes([max(400, self.width() - 536), 500])
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 0)
        self.summary = QLabel("")
        self.summary.setStyleSheet(
            "background: #38332b; color: #ffffff; padding: 8px 10px;"
            " font-size: 12px; border-radius: 3px;")
        dlay.addWidget(self.summary)
        self.stack.addWidget(detail)

        # --- 並列ページ ---
        parallel_page = QWidget()
        self._parallel_page = parallel_page
        parallel_page.installEventFilter(self)
        parallel_page.setStyleSheet("background: #e8e4da;")
        play = QVBoxLayout(parallel_page)
        play.setContentsMargins(8, 6, 8, 0)
        play.setSpacing(4)
        self.parallel = ParallelWidget()
        self.parallel_scroll = QScrollArea()
        self.parallel_scroll.setWidgetResizable(True)
        self.parallel_scroll.setStyleSheet(
            "QScrollArea { background: #e8e4da; border: none; }")
        self.parallel_scroll.setWidget(self.parallel)
        play.addWidget(self.parallel_scroll, 1)
        self.parallel_hbar = QScrollBar(Qt.Orientation.Horizontal)
        play.addWidget(self.parallel_hbar)
        self.parallel_hbar.valueChanged.connect(self._parallel_pan)
        self.parallel.view_changed.connect(self._sync_parallel_hbar)
        self.stack.addWidget(parallel_page)
        for sc in (self.scroll, self.parallel_scroll):
            sc.verticalScrollBar().valueChanged.connect(
                lambda *_: self._place_corner_seg())
            sc.horizontalScrollBar().valueChanged.connect(
                lambda *_: self._place_corner_seg())

        # --- 信号 ---
        self.gantt.setContextMenuPolicy(
            Qt.ContextMenuPolicy.CustomContextMenu)
        self.gantt.customContextMenuRequested.connect(self._gantt_menu)
        self.gantt.nudge_requested.connect(self._nudge_selected)
        self.gantt.selection_changed.connect(self._on_selection)
        self.gantt.edit_finished.connect(lambda: self._after_edit(self.selected_task_id))
        self.gantt.overlap_pending.connect(self._on_gantt_overlap)
        self.gantt.context_requested.connect(self._on_context)
        self.gantt.track_context_requested.connect(self._on_track_context)
        self.gantt.track_rename_requested.connect(self._rename_track)
        # 日付表のクリックではプロパティへ移らない（Trial77）
        self.table.task_chosen.connect(
            lambda tid: self._on_selection(tid, switch_tab=False))
        self.table.dates_edited.connect(self._on_panel_edited)
        self.table.lock_changed.connect(self._on_table_lock_changed)
        self.prop.edited.connect(self._on_panel_edited)
        self.prop.changed.connect(lambda: self._after_edit(self.selected_task_id))
        self.parallel.project_chosen.connect(self._open_project_from_parallel)
        self.parallel.chart_toggled.connect(self._on_chart_toggled)
        self.parallel.add_requested.connect(self._add_project_to_view)
        self.parallel.remove_requested.connect(self._on_lane_context)

    # ---------- 基本状態 ----------
    def project(self):
        for p in self.data.projects:
            if p.id == self.current_project_id:
                return p
        return None

    def _take_snapshot(self):
        p = self.project()
        self._snapshot = {t.id: (t.start, t.end) for t in p.tasks} if p else {}

    def _update_title(self):
        p = self.project()
        title = "PhaseFlow"
        if p:
            title += f" — {p.name}（{p.plant}）"
        if getattr(self, "_read_only", False):
            title += " [閲覧専用]"
        if getattr(self, "dirty", False):
            title += " *"
        self.setWindowTitle(title)

    def _mark_dirty(self):
        self.dirty = True
        self._update_title()
        self._checkpoint()

    def _ensure_project_lock(self, force=False):
        """工事を開いた時にだけ編集権を取得。未保存工事のロックは維持。"""
        pid = self.current_project_id
        if not force and pid == self._edit_project_id:
            return
        if pid != self._manual_readonly_id:
            self._manual_readonly_id = ""
        if self.edit_session is not None:
            self.edit_session.release_clean(self.data, except_id=pid)
            try:
                self.edit_session.refresh(self.data)
            except Exception as e:
                self.workspace_error = str(e)
        self._edit_project_id = pid
        self._read_only = bool(self.workspace_error or (pid and pid == self._manual_readonly_id))
        self._lock_owner = "自分が編集権を解放しました" if pid == self._manual_readonly_id else ""
        if pid and not self._read_only and self.edit_session is not None:
            try:
                ok, owner = self.edit_session.claim(pid)
                self._read_only = not ok
                self._lock_owner = owner
            except OSError as e:
                self._read_only, self._lock_owner = True, str(e)
        if hasattr(self, "gantt"):
            self.gantt.read_only = self._read_only
            self.table.table.setEditTriggers(
                QAbstractItemView.EditTrigger.NoEditTriggers
                if self._read_only else
                QAbstractItemView.EditTrigger.DoubleClicked |
                QAbstractItemView.EditTrigger.EditKeyPressed |
                QAbstractItemView.EditTrigger.AnyKeyPressed)
            self.prop.setEnabled(not self._read_only)
            self.add_item_btn.setEnabled(not self._read_only)
            self.del_item_btn.setEnabled(
                not self._read_only and bool(self.selected_task_id))
            for b in self.step_btns[1:]:
                b.setEnabled(not self._read_only)
            if pid and self._read_only:
                self.lock_status.setText("● 閲覧専用")
                self.lock_status.setStyleSheet("color: #8a5d20; background: #fff3d8; border-radius: 5px; padding: 6px 8px;")
                self.lock_status.setToolTip(self._lock_owner or self.workspace_error)
                self.lock_retry_btn.setText("編集権を取得")
                self.lock_retry_btn.setAccessibleName("編集権を取得")
                self.lock_retry_btn.setVisible(bool(self.edit_session) and not self.workspace_error)
            else:
                self.lock_status.setText("● 編集可能" if pid else "工事未選択")
                self.lock_status.setStyleSheet("color: #32634d; background: #e6f0e8; border-radius: 5px; padding: 6px 8px;")
                self.lock_status.setToolTip("自分が編集権を保持しています" if pid else "")
                self.lock_retry_btn.setText("編集を終了")
                self.lock_retry_btn.setAccessibleName("編集を終了")
                self.lock_retry_btn.setVisible(bool(pid and self.edit_session))
        self._update_title()

    def _toggle_project_lock(self):
        pid = self.current_project_id
        if not pid or not self.edit_session:
            return
        if not self._read_only:
            # 未保存の工事を放置してロックだけ離すことは禁止。
            if self.edit_session.project_dirty(self.data, pid) and not self._save():
                return
            self.edit_session.release(pid)
            self._manual_readonly_id = pid
            self._edit_project_id = None
            self._refresh_all()
            return
        self._manual_readonly_id = ""
        self._ensure_project_lock(force=True)
        self._refresh_all()
        if self._read_only:
            QMessageBox.information(self, "編集中の工事",
                                    "ほかの利用者が編集中のため、閲覧専用です。\n"
                                    + (self._lock_owner or self.workspace_error))

    def _poll_external_changes(self):
        if self.dirty or self.workspace_error or not self.edit_session:
            return
        if QApplication.activeModalWidget() is not None:
            return
        try:
            changed = self.edit_session.refresh(self.data)
        except Exception as e:
            self.statusBar().showMessage(f"置き場の読込に失敗: {e}", 9000)
            return
        if changed:
            self._refresh_all()
            self._reset_undo()
            self.statusBar().showMessage("ほかの利用者の保存内容を反映しました。", 6000)

    def _claim_projects(self, ids):
        """プラント改名など複数工事を一括変更する操作前の安全確認。"""
        if self.workspace_error or not self.edit_session:
            return not self.workspace_error
        claimed = []
        for pid in ids:
            if pid in self.edit_session.locks:
                continue
            ok, owner = self.edit_session.claim(pid)
            if not ok:
                for previous in claimed:
                    self.edit_session.release(previous)
                QMessageBox.warning(self, "編集中の工事", "別の利用者が編集中です。\n" + owner)
                return False
            claimed.append(pid)
        # ロック取得前に別のPCが保存していた場合は、編集を中断。
        current = self.edit_session._get_new_files()
        for pid in ids:
            if ((current.get(pid) or (None, None))[1] !=
                    (self.edit_session.baseline_files.get(pid) or (None, None))[1]):
                for previous in claimed:
                    self.edit_session.release(previous)
                QMessageBox.warning(self, "最新データを再読み込みしてください",
                                    "ほかの利用者が工事を更新しています。工事一覧を開き直してください。")
                return False
        return True

    def _refresh_all(self, select_id: str = ""):
        self._ensure_project_lock()
        p = self.project()
        # プラント名の欠けを補う（データ内のプラントを拾う）
        for pr in self.data.projects:
            if pr.plant and pr.plant not in self.plant_names:
                self.plant_names.append(pr.plant)
        self._update_title()
        # ガント（大きさはスクロールの表示幅に連動させるので固定しない。
        # 最小高さは GanttWidget.set_project 側で中身の高さに設定される）
        self.gantt.master_by_id = {m.id: m for m in self.data.masters}
        self.gantt.data = self.data
        self.table.data = self.data
        self.gantt.set_project(p)
        self.gantt.selected_id = select_id or self.selected_task_id
        # 表とプロパティ
        self.table.set_project(p)
        task = p.task_by_id(select_id or self.selected_task_id) if p else None
        self.selected_task_id = task.id if task else ""
        self.prop.show_task(self.data, p, task)
        self.table.refresh(select_id=self.selected_task_id)
        # 並列（表示セット）
        self.parallel.set_data(self.data, self.view_ids)
        self._sync_parallel_mode()
        self._take_snapshot()
        self._refresh_summary()
        self._update_steps()
        self._checkpoint()

    # ---------- 作成の流れ（4ステップ） ----------
    STEP_LABELS = ["工事を追加", "項目のプリセット選択", "日付の設定",
                   "人員・作業内容の設定"]

    def _current_step(self):
        p = self.project()
        if not p:
            return 1
        if not p.tasks:
            return 2
        if not self.selected_task_id:
            return 3
        return 4

    def _update_steps(self):
        cur = self._current_step()
        for i, b in enumerate(self.step_btns, start=1):
            label = self.STEP_LABELS[i - 1]
            if i < cur:
                b.setText(f"✓ {label}")
                b.setStyleSheet(
                    "background: #e3ddcb; color: #57503f;"
                    " border: 1px solid #cfc4a6; border-radius: 10px;"
                    " padding: 3px 10px;")
            elif i == cur:
                b.setText(f"{i} {label}")
                b.setStyleSheet(
                    "background: #2e4a66; color: #ffffff; font-weight: bold;"
                    " border: 1px solid #2e4a66; border-radius: 10px;"
                    " padding: 3px 8px;")
            else:
                b.setText(f"{i} {label}")
                b.setStyleSheet(
                    "background: transparent; color: #9a927e;"
                    " border: 1px solid #d8d2c0; border-radius: 10px;"
                    " padding: 3px 8px;")

    def _goto_step(self, n):
        if n == 1:
            self._new_project()
            return
        if n == 2:
            self._open_item_editor()
            return
        if n == 3:
            self._open_date_settings()
            return
        p = self.project()
        if not p or not p.tasks:
            return
        first = None
        for tr in p.tracks:
            ts = p.tasks_in_track(tr.id)
            if ts:
                first = ts[0]
                break
        if first is None:
            first = p.tasks[0]
        self._switch_view(0)
        self._on_selection(first.id)
        if n == 4:
            self.tabs.setCurrentWidget(self.prop)

    def _refresh_summary(self):
        p = self.project()
        if not p:
            self.summary.setText("")
            return
        if not p.tasks:
            self.summary.setText(
                "次の手順：プリセットを選んで項目を並べるか、"
                "「＋ 項目を追加」してください")
            return
        total = md.project_hours_total(self.data, p)
        monthly = md.monthly_hours(self.data, p)
        mtxt = " ・ ".join(f"{m}月 <b>{md.fmt_hours(v)}</b>"
                           for (y, m), v in sorted(monthly.items()))
        txt = (f"総作業時間（自部門のみ）：<b style='color:#ffb066'>{md.fmt_hours(total)} 時間</b>"
               f"　／　月別：{mtxt or '―'}")
        task = p.task_by_id(self.selected_task_id)
        if task:
            th = md.task_hours(self.data, task)["合計"]
            if th:
                txt += (f"　／　選択中「<b>{task.name}</b>」の作業時間："
                        f"{md.fmt_hours(th)} 時間")
        else:
            txt += "　／　項目を選ぶと、日付・人員・作業内容を設定できます"
        self.summary.setText(txt)

    def _set_parallel_mode(self, mode):
        self.data.settings.parallel_mode = mode
        self.parallel.set_mode(mode)
        for k, b in self.pmode_btns.items():
            b.setChecked(k == mode)
        self._mark_dirty()

    def _sync_parallel_mode(self):
        mode = getattr(self.data.settings, "parallel_mode", "milestone")
        if mode not in self.pmode_btns:
            mode = "milestone"
        self.parallel.set_mode(mode)
        for k, b in self.pmode_btns.items():
            b.setChecked(k == mode)
        self.parallel.set_chart_open(
            getattr(self.data.settings, "parallel_chart_open", True))

    def _on_chart_toggled(self, open_):
        self.data.settings.parallel_chart_open = bool(open_)
        self._mark_dirty()

    def _goto_detail(self):
        # 並列で選択中のレーンがあれば、その工事の詳細へ
        pid = self.parallel.selected_id
        if pid and pid != self.current_project_id:
            self._open_project_from_parallel(pid)
        else:
            self._switch_view(0)

    def _switch_view(self, idx):
        self.stack.setCurrentIndex(idx)
        self.strips_btn.setVisible(idx == 0)
        self.detail_btn.setChecked(idx == 0)
        self.parallel_btn.setChecked(idx == 1)
        self.parallel_tools.setVisible(idx == 1)
        if idx == 1:
            self.parallel.set_data(self.data, self.view_ids)
            if any(pr.id == self.current_project_id
                   for pr in self.parallel.projects):
                self.parallel.selected_id = self.current_project_id
            self._sync_parallel_mode()
        else:
            QTimer.singleShot(0, self, self._place_toggle)
            QTimer.singleShot(0, self, self._place_corner_seg)

    def keyPressEvent(self, ev):
        editing = isinstance(QApplication.focusWidget(),
                             (QLineEdit, QTextEdit, QPlainTextEdit,
                              QAbstractSpinBox, QComboBox))
        # Delete: 選択中の項目を削除（入力欄にフォーカスがある時は除く）
        if (ev.key() == Qt.Key.Key_Delete and not ev.modifiers()
                and self.stack.currentIndex() == 0
                and self.selected_task_id and not self._read_only
                and not editing):
            self._delete_task(self.selected_task_id)
            ev.accept()
            return
        # ←→: 選択中のバーを前後に移動（Shift で7日）
        if (ev.key() in (Qt.Key.Key_Left, Qt.Key.Key_Right)
                and self.stack.currentIndex() == 0
                and self.selected_task_id and not self._read_only
                and not editing):
            days = 1 if ev.key() == Qt.Key.Key_Right else -1
            if ev.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                days *= 7
            self._nudge_selected(days)
            ev.accept()
            return
        super().keyPressEvent(ev)

    def _on_table_lock_changed(self, task):
        # 表を作り直すとチェックボックス自身が消えるため、次の周回で反映
        from PySide6.QtCore import QTimer
        QTimer.singleShot(0, self, lambda: self._sync_after_lock_change(task))

    def _sync_after_lock_change(self, task):
        self._mark_dirty()
        self._take_snapshot()
        self.gantt.update()
        self.table.refresh(select_id=task.id if task else "")
        p = self.project()
        cur = p.task_by_id(self.selected_task_id) if p else None
        self.prop.show_task(self.data, p, cur)
        self._refresh_summary()

    def _set_all_locks(self, locked):
        """工事単位で全項目を一括ロック／全解除する。"""
        p = self.project()
        if not p or self._read_only or not p.tasks:
            return
        verb = "ロック" if locked else "ロックを解除"
        ans = QMessageBox.question(
            self, "日付ロック",
            f"工事「{p.name}」の全{len(p.tasks)}件の項目を{verb}しますか？")
        if ans != QMessageBox.StandardButton.Yes:
            return
        for t in p.tasks:
            t.lock_start = locked
            t.lock_end = locked
        self._mark_dirty()
        self._take_snapshot()
        self._refresh_all()

    def _nudge_selected(self, days):
        """選択中のバーを前後にずらす（重なりは通常の3択で解決）。"""
        if self._read_only:
            return
        p = self.project()
        task = p.task_by_id(self.selected_task_id) if p else None
        if not task or task.locked_any:
            return
        from datetime import timedelta
        revert = (task.dstart, task.dend)
        task.start = (task.dstart + timedelta(days=days)).isoformat()
        task.end = (task.dend + timedelta(days=days)).isoformat()
        self._resolve_overlap(task, revert)

    def _toggle_right_panel(self):
        """右パネル（日付表／プロパティ）を ▶ 閉じる / ◀ 開く。"""
        if self._right_open:
            w = self.splitter.sizes()[1]
            if w > 0:
                self._right_width = w
            self.tabs.hide()
            self._right_open = False
            self.right_toggle.setIcon(action_icon("left"))
            self.right_toggle.setAccessibleName("右パネルを開く")
            self.right_toggle.setToolTip("右パネルを開く")
        else:
            self.tabs.show()
            total = self.splitter.width()
            rw = self._right_width or 500
            self.splitter.setSizes([max(200, total - rw), rw])
            self._right_open = True
            self.right_toggle.setIcon(action_icon("right"))
            self.right_toggle.setAccessibleName("右パネルを閉じる")
            self.right_toggle.setToolTip("右パネルを閉じる")
        self._place_toggle()
        QTimer.singleShot(0, self, self._place_toggle)

    def _place_toggle(self):
        """開閉ボタンを境界（右パネルの左端）・縦中央へ置く。"""
        if not hasattr(self, "right_toggle") or not hasattr(self, "tabs"):
            return
        detail = self._detail_page
        sp = self.splitter
        y = sp.y() + sp.height() // 2 - self.right_toggle.height() // 2
        if self._right_open:
            x = self.tabs.mapTo(detail, QPoint(0, 0)).x() - self.right_toggle.width() // 2
        else:
            x = detail.width() - self.right_toggle.width() - 1
        self.right_toggle.move(max(0, x), max(0, y))
        self.right_toggle.raise_()

    def eventFilter(self, obj, ev):
        if ev.type() == QEvent.Type.Resize and obj in (
                getattr(self, "_detail_page", None),
                getattr(self, "_parallel_page", None)):
            self._place_toggle()
            self._place_corner_seg()
        return super().eventFilter(obj, ev)

    def _place_corner_seg(self):
        """項目追加・削除を、ガント左上の見出し位置に重ねる（詳細表示のみ）。"""
        seg = getattr(self, "corner_seg", None)
        if seg is None or not hasattr(self, "stack"):
            return
        if self.stack.currentIndex() != 0:
            seg.hide()
            return
        seg.show()
        # 見出しセル（名前列×ヘッダ高さ）にちょうど重ね、ボタン群は
        # 中央寄せで左右の余白を同じにする（Trial85）
        seg.resize(GANTT_NAME_W, GANTT_HEADER_H)
        corner = self.gantt.mapTo(self, QPoint(0, 0))
        vp = self.scroll.viewport().mapTo(self, QPoint(0, 0))
        seg.move(max(corner.x(), vp.x()), max(corner.y(), vp.y()))
        seg.raise_()

    def _open_project_from_parallel(self, pid):
        self.current_project_id = pid
        p = self.project()
        if p:
            self.current_plant = p.plant
        self.selected_task_id = ""
        self._switch_view(0)
        self._refresh_all()

    def _gantt_menu(self, pos):
        menu = self._build_gantt_menu(pos)
        if menu:
            menu.exec(self.gantt.mapToGlobal(pos))

    def _build_gantt_menu(self, pos):
        """ガント上の右クリック：項目の追加・日付設定・削除。"""
        if self._read_only or not self.project():
            return None
        task = self.gantt.task_at(pos)
        menu = QMenu(self)
        menu.addAction("項目を追加…", self._add_item)
        if task:
            if task.id != self.selected_task_id:
                self._on_selection(task.id)
            menu.addSeparator()
            menu.addAction("日付を設定…", self._open_date_settings)
            menu.addAction("この項目を削除",
                           lambda: self._delete_task(task.id))
        menu.addSeparator()
        menu.addAction("全ての項目をロック",
                       lambda: self._set_all_locks(True))
        menu.addAction("全てのロックを解除",
                       lambda: self._set_all_locks(False))
        return menu

    def _on_selection(self, task_id, switch_tab=True):
        self.selected_task_id = task_id
        _db = getattr(self, "del_item_btn", None)
        if _db is not None:
            _db.setEnabled(bool(task_id) and not self._read_only)
        p = self.project()
        task = p.task_by_id(task_id) if p and task_id else None
        self.gantt.selected_id = task_id
        self.gantt.update()
        self.prop.show_task(self.data, p, task)
        if task and switch_tab:
            self.tabs.setCurrentWidget(self.prop)
        self._refresh_summary()
        self._update_steps()

    def _after_edit(self, select_id=""):
        if self._read_only:
            self._refresh_all()
            return
        self._mark_dirty()
        keep = select_id or self.selected_task_id
        p = self.project()
        self.gantt.update()
        self.gantt.setFixedHeight(max(320, self.gantt.content_height() + 8))
        self.table.refresh(select_id=keep)
        task = p.task_by_id(keep) if p else None
        self.prop.show_task(self.data, p, task)
        self.parallel.set_data(self.data)
        self._sync_parallel_mode()
        self._take_snapshot()
        self._refresh_summary()

    def _on_panel_edited(self, task):
        revert = self._snapshot.get(task.id)
        self._resolve_overlap(task, revert)

    def _on_gantt_overlap(self, task, hit, revert):
        self._resolve_overlap(task, (revert["start"], revert["end"]))

    def _resolve_overlap(self, task, revert):
        """重なりがあれば3択ポップアップ。キャンセル時は revert に戻す。"""
        p = self.project()
        hit = md.find_overlap(p, task) if p else None
        if not hit:
            self._after_edit(task.id)
            return
        menu, act_wrap, act_shrink, act_shift = \
            self._build_overlap_menu(task, hit)
        chosen = menu.exec(QCursor.pos())
        if chosen is act_wrap:
            self._after_edit(task.id)
        elif chosen is act_shrink:
            md.apply_shrink(task, hit)
            self._after_edit(task.id)
        elif chosen is act_shift:
            cands = [hit] + md.following_tasks(p, hit)
            dlg = ShiftDialog(cands, self)
            if dlg.exec():
                ids = dlg.chosen_ids()
                chosen_tasks = [t for t in cands
                                if t.id in ids and not t.locked_any]
                if chosen_tasks:
                    first = min(chosen_tasks, key=lambda t: t.start)
                    delta = md.shift_delta_for(task, first)
                    if delta > 0:
                        md.apply_shift(chosen_tasks, delta)
                self._after_edit(task.id)
            else:
                self._revert(task, revert)
        else:
            self._revert(task, revert)

    def _build_overlap_menu(self, task, hit):
        """重なり解消の3択メニューを作る（テストからも検証できるよう分離）。"""
        p = self.project()
        menu = QMenu(self)
        act_wrap = menu.addAction("ラップさせる（重ねたままにする）")
        act_shrink = menu.addAction(f"次の工程（{hit.name}）だけ縮める")
        if hit.lock_start:
            act_shrink.setEnabled(False)
            act_shrink.setText(f"次の工程（{hit.name}）だけ縮める（開始がロック中です）")
        elif not md.can_shrink(p, task, hit):
            act_shrink.setEnabled(False)
            act_shrink.setText(f"次の工程（{hit.name}）だけ縮める（これ以上縮められません）")
        act_shift = menu.addAction("後ろの工程を選んで水平移動…")
        menu.setTitle(f"「{task.name}」の終了が「{hit.name}」と重なります")
        return menu, act_wrap, act_shrink, act_shift

    def _revert(self, task, revert):
        if revert:
            task.start, task.end = revert
        self.gantt.update()
        self._after_edit(task.id)

    def _on_context(self, task_id, pos):
        menu = QMenu(self)
        act_prop = menu.addAction("プロパティを表示")
        act_del = menu.addAction("この項目を削除")
        chosen = menu.exec(pos)
        if chosen is act_prop:
            self._on_selection(task_id)
        elif chosen is act_del:
            self._delete_task(task_id)

    def _on_track_context(self, track_id, pos):
        menu = QMenu(self)
        act = menu.addAction("系列の名称変更…")
        if menu.exec(pos) is act:
            self._rename_track(track_id)

    def _rename_track(self, track_id):
        p = self.project()
        tr = next((x for x in p.tracks if x.id == track_id), None) if p else None
        if not tr:
            return
        name, ok = QInputDialog.getText(self, "系列の名称変更", "系列名：",
                                        text=tr.name)
        if ok:
            self._set_track_name(track_id, name)

    def _set_track_name(self, track_id, name):
        p = self.project()
        tr = next((x for x in p.tracks if x.id == track_id), None) if p else None
        name = (name or "").strip()
        if not tr or not name or name == tr.name:
            return False
        tr.name = name
        self._mark_dirty()
        self._refresh_all(select_id=self.selected_task_id)
        return True

    def _delete_task(self, task_id):
        p = self.project()
        task = p.task_by_id(task_id) if p else None
        if not task:
            return
        if QMessageBox.question(self, "確認", f"項目「{task.name}」をこの工事から削除しますか？\n（項目マスタからは消えません）") != QMessageBox.StandardButton.Yes:
            return
        p.tasks.remove(task)
        for t in p.tasks:
            if t.pred_id == task_id:
                t.pred_id = ""
        self.selected_task_id = ""
        self._mark_dirty()
        self._refresh_all()

    # ---------- 項目・プリセット ----------
    def _add_item(self):
        p = self.project()
        if not p:
            return
        dlg = AddItemDialog(self.data, p.tracks, self)
        if not dlg.exec():
            return
        if dlg.new_master_requested:
            md_dlg = MasterDialog(
                None, self,
                used_colors=[m.color for m in self.data.masters])
            if not md_dlg.exec():
                return
            master = md_dlg.result_master()
            self.data.masters.append(master)
        else:
            master = dlg.chosen_master()
            if not master:
                return
        track_id = dlg.chosen_track_id()
        siblings = p.tasks_in_track(track_id)
        if siblings:
            start = siblings[-1].dend
            from datetime import timedelta
            start = start + timedelta(days=1)
            pred = siblings[-1].id
        else:
            start = date.today().replace(day=1)
            pred = ""
        task = md.task_from_master(master, track_id, start)
        task.pred_id = pred
        p.tasks.append(task)
        self._mark_dirty()
        self._refresh_all(select_id=task.id)
        self.tabs.setCurrentWidget(self.prop)

    def _apply_preset(self, pid):
        p = self.project()
        preset = next((x for x in self.data.presets if x.id == pid), None)
        if not p or not preset:
            return
        if QMessageBox.question(self, "確認", f"工事「{p.name}」の並びをプリセット「{preset.name}」で置き換えますか？\n（現在の項目は消えます）") != QMessageBox.StandardButton.Yes:
            return
        base = min((t.dstart for t in p.tasks), default=date.today().replace(day=1))
        newp = md.expand_preset(self.data, preset, p.name, base)
        p.tracks, p.tasks = newp.tracks, newp.tasks
        self.selected_task_id = ""
        self._mark_dirty()
        self._refresh_all()

    def _open_item_editor(self):
        """項目プリセットの適用・登録と項目マスタ管理を1か所に集約（Trial71）。"""
        if not self.project():
            return
        dlg = ItemPresetDialog(self.data, self,
                               on_save=self._save_preset,
                               on_manage=self._manage_masters)
        applied = dlg.exec() and dlg.apply_id
        if dlg.changed:
            self._mark_dirty()
            self._refresh_all(select_id=self.selected_task_id)
        if applied:
            self._apply_preset(dlg.apply_id)

    def _save_preset(self):
        p = self.project()
        if not p:
            return
        name, ok = QInputDialog.getText(self, "プリセット登録", "プリセット名")
        if not ok or not name.strip():
            return
        preset = md.preset_from_project(self.data, p, name.strip())
        self.data.presets.append(preset)
        self._mark_dirty()
        self._refresh_all()
        QMessageBox.information(self, "登録", f"プリセット「{name.strip()}」を登録しました。")

    def _manage_masters(self):
        dlg = MasterListDialog(self.data, self)
        dlg.exec()
        if dlg.changed:
            self._mark_dirty()
            self._refresh_all(select_id=self.selected_task_id)

    def _open_date_settings(self):
        p = self.project()
        if not p or not p.tasks:
            return
        dlg = DateSettingsDialog(p, self)
        if dlg.exec():
            self._mark_dirty()
            self._refresh_all(select_id=self.selected_task_id)


    # ---------- 表示セット ----------
    def apply_view_choice(self, mode, value):
        st = self.data.settings
        by_id = {pr.id: pr for pr in self.data.projects}
        ids, preset_id, plant = [], "", ""
        if mode == "last":
            ids = [i for i in st.view_ids if i in by_id]
            preset_id = st.view_preset_id if st.view_mode == "preset" else ""
            plant = st.view_plant
            mode = st.view_mode or "single"
        elif mode == "single" and value in by_id:
            ids = [value]
        elif mode == "preset":
            vp = self.data.view_preset_by_id(value)
            if vp:
                ids = [i for i in vp.project_ids if i in by_id]
                preset_id = vp.id
        elif mode == "plant":
            plant = value
            ids = [pr.id for pr in self.data.projects
                   if pr.plant == value and md.is_current_or_future(pr)]
        self._set_view(ids, mode, preset_id, plant)

    def _set_view(self, ids, mode, preset_id="", plant=""):
        st = self.data.settings
        by_id = {pr.id: pr for pr in self.data.projects}
        self.view_ids = [i for i in ids if i in by_id]
        self._active_preset_id = preset_id
        anchor = by_id.get(self.view_ids[0]) if self.view_ids else None
        if anchor is None and plant:
            anchor = next((pr for pr in self.data.projects
                           if pr.plant == plant), None)
        if anchor is not None:
            self.current_project_id = anchor.id
            self.current_plant = anchor.plant
        st.view_mode = mode
        st.view_ids = list(self.view_ids)
        st.view_preset_id = preset_id
        st.view_plant = plant
        self._refresh_all()

    def show_startup_guide(self):
        if not self.data.projects:
            return
        dlg = StartupGuideDialog(self.data, self.plant_names, self,
                                 current_ids=list(self.view_ids))
        accepted = dlg.exec()
        if dlg.presets_changed:
            self._mark_dirty()
        if accepted:
            mode, value = dlg.choice()
            self.apply_view_choice(mode, value)
            self._mark_dirty()

    # ---------- 工事一覧・開く ----------
    def _show_project_list(self):
        callbacks = {
            "lock_projects": self._claim_projects,
            "open_single": self._list_open_single,
            "add_projects": self._add_ids_to_view,
            "remove_projects": lambda ids: [self._remove_from_view(i)
                                            for i in ids],
            "open_plant": self._list_open_plant,
            "add_plant": self._list_add_plant,
            "delete_project": self._delete_project,
        }
        dlg = ProjectListDialog(self.data, self.plant_names, callbacks, self,
                                view_provider=lambda: list(self.view_ids))
        dlg.exec()
        p = self.project()
        if p:
            self.current_plant = p.plant
        if dlg.changed:
            self._mark_dirty()
            self._refresh_all()
        if dlg.requested == "new_project":
            self._new_project()
        elif dlg.requested == "open_workspace":
            self._open()

    def _delete_project(self, pid):
        """工事を削除する。保存時にファイルは backup へ退避される。

        保存で削除が確定しなかった（競合・ロック等）場合は元に戻す。
        """
        pr = next((x for x in self.data.projects if x.id == pid), None)
        if not pr:
            return False
        if QMessageBox.question(
                self, "工事を削除",
                f"工事「{pr.plant} {pr.name}」を削除しますか？\n"
                "工事ファイルはプラントフォルダの backup フォルダに"
                "退避されます。") != QMessageBox.StandardButton.Yes:
            return False
        idx = self.data.projects.index(pr)
        was_current = pid == self.current_project_id
        was_in_view = pid in self.view_ids
        self.data.projects.remove(pr)
        if was_in_view:
            self.view_ids.remove(pid)
            self.data.settings.view_ids = list(self.view_ids)
            self.data.settings.view_mode = "custom"
            self._active_preset_id = ""
        if was_current:
            self.current_project_id = (
                self.view_ids[0] if self.view_ids else
                (self.data.projects[0].id if self.data.projects else ""))
            self.selected_task_id = ""
        self._mark_dirty()
        if self.workspace:
            self._save()
            if (self.edit_session is not None
                    and pid in self.edit_session.baseline_projects):
                # 削除が保存されなかったので復元する
                self.data.projects.insert(idx, pr)
                if was_in_view:
                    self.view_ids.append(pid)
                    self.data.settings.view_ids = list(self.view_ids)
                if was_current:
                    self.current_project_id = pid
                self._mark_dirty()
                self._refresh_all()
                QMessageBox.warning(
                    self, "工事を削除できませんでした",
                    "保存が完了しなかったため、削除を取り消しました。")
                return False
        p = self.project()
        if p:
            self.current_plant = p.plant
        self._refresh_all()
        return True

    def _list_open_single(self, pid):
        self.apply_view_choice("single", pid)
        self._switch_view(0)
        self._mark_dirty()

    def _list_open_plant(self, name):
        ids = [pr.id for pr in self.data.projects if pr.plant == name]
        self._set_view(ids, "plant_all", plant=name)
        self._switch_view(1)
        self._mark_dirty()

    def _list_add_plant(self, name):
        self._add_ids_to_view(
            [pr.id for pr in self.data.projects if pr.plant == name])

    def _add_ids_to_view(self, ids):
        for pid in ids:
            if pid not in self.view_ids:
                self.view_ids.append(pid)
        self._active_preset_id = ""
        self.data.settings.view_ids = list(self.view_ids)
        self.data.settings.view_mode = "custom"
        self._mark_dirty()
        self._refresh_all()

    def _open_single_project(self):
        dlg = ProjectPickerDialog(self.data, set(), self,
                                  title="工事を開く", button_text="開く",
                                  single=True)
        if dlg.exec():
            chosen = dlg.chosen_ids()
            if chosen:
                self._list_open_single(chosen[0])

    # ---------- 表示プリセット（1行目） ----------
    def _build_vp_menu(self):
        m = self._vp_menu
        m.clear()
        if not self.data.view_presets:
            act = m.addAction("（表示プリセットはまだありません）")
            act.setEnabled(False)
        for vp in self.data.view_presets:
            m.addAction(vp.name,
                        lambda vid=vp.id: self._open_view_preset(vid))
        if self.data.view_presets:
            m.addSeparator()
            sub = m.addMenu("プリセットを削除")
            for vp in self.data.view_presets:
                sub.addAction(
                    vp.name,
                    lambda vid=vp.id: self._delete_view_preset_by_id(vid))

    def _open_view_preset(self, vid):
        self.apply_view_choice("preset", vid)
        self._mark_dirty()

    def _save_view_preset(self):
        if not self.view_ids:
            QMessageBox.information(self, "表示プリセット",
                                    "表示中の工事がありません。")
            return
        name, ok = QInputDialog.getText(self, "表示プリセットを登録",
                                        "名前：")
        name = name.strip()
        if not ok or not name:
            return
        existing = next((v for v in self.data.view_presets
                         if v.name == name), None)
        if existing:
            if QMessageBox.question(
                    self, "確認",
                    f"「{name}」は既にあります。上書きしますか？") \
                    != QMessageBox.StandardButton.Yes:
                return
            existing.project_ids = list(self.view_ids)
            self._active_preset_id = existing.id
        else:
            vp = md.ViewPreset(name=name,
                               project_ids=list(self.view_ids))
            self.data.view_presets.append(vp)
            self._active_preset_id = vp.id
        st = self.data.settings
        st.view_mode = "preset"
        st.view_preset_id = self._active_preset_id
        st.view_ids = list(self.view_ids)
        self._mark_dirty()
        self._refresh_all()

    def _delete_view_preset_by_id(self, vid):
        vp = self.data.view_preset_by_id(vid)
        if vp and QMessageBox.question(
                self, "確認",
                f"表示プリセット「{vp.name}」を削除しますか？") \
                == QMessageBox.StandardButton.Yes:
            self.data.view_presets.remove(vp)
            if self._active_preset_id == vid:
                self._active_preset_id = ""
            self._mark_dirty()
            self._refresh_all()

    def _add_project_to_view(self):
        dlg = ProjectPickerDialog(self.data, set(self.view_ids), self)
        if dlg.exec():
            self._add_ids_to_view(dlg.chosen_ids())

    # ---------- 印刷 ----------
    def _print_current(self):
        printer = QPrinter(QPrinter.PrinterMode.HighResolution)
        printer.setPageOrientation(QPageLayout.Orientation.Landscape)
        if QPrintDialog(printer, self).exec():
            self._do_print(printer)

    def _do_print(self, printer):
        # 画面キャプチャではなく、チャートをプリンタへ直接描画する（Trial75）
        target = (self.gantt if self.stack.currentIndex() == 0
                  else self.parallel)
        size = target.size()
        painter = QPainter(printer)
        if size.width() > 0 and size.height() > 0:
            rect = printer.pageRect(QPrinter.Unit.DevicePixel)
            scale = min(rect.width() / size.width(),
                        rect.height() / size.height())
            x = rect.x() + (rect.width() - size.width() * scale) / 2
            y = rect.y() + (rect.height() - size.height() * scale) / 2
            painter.translate(x, y)
            painter.scale(scale, scale)
            target.render(painter, QPoint(0, 0))
        painter.end()

    def _on_lane_context(self, pid):
        menu = QMenu(self)
        menu.addAction("詳細で開く",
                       lambda: self._open_project_from_parallel(pid))
        menu.addAction("表示から外す", lambda: self._remove_from_view(pid))
        menu.exec(QCursor.pos())

    def _remove_from_view(self, pid):
        if pid in self.view_ids:
            self.view_ids.remove(pid)
            self._active_preset_id = ""
            self.data.settings.view_ids = list(self.view_ids)
            self.data.settings.view_mode = "custom"
            self._mark_dirty()
            self._refresh_all()

    def _sync_gantt_hbar(self):
        if not hasattr(self, "gantt_hbar"):
            return
        span = self.gantt.span()
        bar = self.gantt_hbar
        bar.blockSignals(True)
        if span:
            start, total = span
            bar.setRange(0, max(0, total - self.gantt.view_days))
            bar.setPageStep(max(1, self.gantt.view_days))
            bar.setSingleStep(7)
            bar.setValue((self.gantt.view_start - start).days)
            bar.setEnabled(total > self.gantt.view_days)
        else:
            bar.setRange(0, 0)
            bar.setEnabled(False)
        bar.blockSignals(False)

    def _gantt_pan(self, value):
        span = self.gantt.span()
        if span:
            self.gantt.set_view_start(span[0] + timedelta(days=value))

    def _sync_parallel_hbar(self):
        if not hasattr(self, "parallel_hbar"):
            return
        span = self.parallel.span()
        bar = self.parallel_hbar
        bar.blockSignals(True)
        if span:
            start, total = span
            bar.setRange(0, max(0, total - self.parallel.view_days))
            bar.setPageStep(max(1, self.parallel.view_days))
            bar.setSingleStep(7)
            bar.setValue((self.parallel.view_start - start).days)
            bar.setEnabled(total > self.parallel.view_days)
        else:
            bar.setRange(0, 0)
            bar.setEnabled(False)
        bar.blockSignals(False)

    def _parallel_pan(self, value):
        span = self.parallel.span()
        if span:
            self.parallel.set_view_start(span[0] + timedelta(days=value))

    def _new_project(self):
        if self.workspace_error:
            QMessageBox.warning(self, "閲覧専用", self.workspace_error)
            return
        default = self.current_plant or (
            self.plant_names[0] if self.plant_names else "プラント1")
        wiz = CreationWizard(self.data, self, plants=self.plant_names,
                             default_plant=default)
        if not wiz.exec():
            return
        proj = wiz.result_project()
        if proj is None:
            return
        plant = wiz.chosen_plant() or "プラント1"
        if plant not in self.plant_names:
            self.plant_names.append(plant)
        proj.plant = plant
        if self.edit_session:
            ok, owner = self.edit_session.claim(proj.id)
            if not ok:
                QMessageBox.warning(self, "編集できません", owner)
                return
        self.current_plant = plant
        self.data.projects.append(proj)
        self.current_project_id = proj.id
        self._mark_dirty()
        self._switch_view(0)
        if proj.tasks:
            # 作った直後は最初の項目を選んで、流れの続きに乗せる
            first = proj.tasks[0]
            for tr in proj.tracks:
                ts = proj.tasks_in_track(tr.id)
                if ts:
                    first = ts[0]
                    break
            self._refresh_all(select_id=first.id)
            self.tabs.setCurrentWidget(self.prop)
        else:
            self.selected_task_id = ""
            self._refresh_all()

    # ---------- ファイル・出力・設定 ----------
    def _confirm_unsaved(self):
        if not self.dirty:
            return True
        box = QMessageBox(self)
        box.setWindowTitle("未保存の変更")
        box.setText("保存していない変更があります。どうしますか？")
        save_btn = box.addButton("保存して続ける", QMessageBox.ButtonRole.AcceptRole)
        discard_btn = box.addButton("保存せず続ける", QMessageBox.ButtonRole.DestructiveRole)
        box.addButton("キャンセル", QMessageBox.ButtonRole.RejectRole)
        box.setDefaultButton(save_btn)
        box.exec()
        if box.clickedButton() is save_btn:
            return self._save()
        return box.clickedButton() is discard_btn

    def _open(self):
        start = self.workspace or str(md.workspace_root())
        root = QFileDialog.getExistingDirectory(self, "置き場を開く", start)
        if not root:
            return
        if not self._confirm_unsaved():
            return
        try:
            data, plants = md.load_workspace(root)
            if getattr(data, "_load_errors", []):
                raise RuntimeError("読み込めないファイルがあります。\n" + "\n".join(data._load_errors)
                                   + "\nbackup フォルダの正常な世代を確認して復元してください。")
            session = md.WorkspaceSession(root, data)
        except Exception as e:
            QMessageBox.critical(self, "置き場を開けません", str(e))
            return
        if self.edit_session:
            self.edit_session.close()
        self.edit_session = session
        self.workspace_error = ""
        self._edit_project_id = None
        self._manual_readonly_id = ""
        self.data, self.plant_names = data, plants
        self.workspace = root
        self.path = root
        self.current_project_id = (self.data.projects[0].id
                                   if self.data.projects else "")
        first = self.data.projects[0] if self.data.projects else None
        self.current_plant = (first.plant if first else
                              self.plant_names[0] if self.plant_names else "")
        self.selected_task_id = ""
        self.dirty = False
        self._refresh_all()
        self._reset_undo()

    # ---------- Undo/Redo（データ全体のスナップショット方式） ----------
    def _json_now(self) -> str:
        return json.dumps(md.data_to_dict(self.data),
                          ensure_ascii=False, sort_keys=True)

    def _checkpoint(self):
        cur = self._json_now()
        if self._last_json is None:
            self._last_json = cur
        elif cur != self._last_json:
            self._undo_stack.append(self._last_json)
            if len(self._undo_stack) > 60:
                self._undo_stack.pop(0)
            self._redo_stack.clear()
            self._last_json = cur
        self._update_undo_buttons()

    def _reset_undo(self):
        self._undo_stack.clear()
        self._redo_stack.clear()
        self._last_json = self._json_now()
        self._update_undo_buttons()

    def _update_undo_buttons(self):
        if hasattr(self, "undo_btn"):
            self.undo_btn.setEnabled(bool(self._undo_stack))
            self.redo_btn.setEnabled(bool(self._redo_stack))

    def _restore(self, state: str):
        if self.edit_session:
            target = md.data_from_dict(json.loads(state))
            before = {p.id: md.project_to_dict(p) for p in self.data.projects}
            after = {p.id: md.project_to_dict(p) for p in target.projects}
            ids = [pid for pid in before.keys() | after.keys()
                   if before.get(pid) != after.get(pid)]
            if not self._claim_projects(ids):
                return False
        keep_pid = self.current_project_id
        keep_tid = self.selected_task_id
        self.data = md.data_from_dict(json.loads(state))
        cur = self.project()
        if cur:
            self.current_plant = cur.plant
        if not any(pr.id == keep_pid for pr in self.data.projects):
            self.current_project_id = (self.data.projects[0].id
                                       if self.data.projects else "")
        p = self.project()
        if p is None or not p.task_by_id(keep_tid):
            self.selected_task_id = ""
        self._last_json = state
        self.strips_btn.blockSignals(True)
        self.strips_btn.setChecked(self.data.settings.show_jinko
                                   and self.data.settings.show_attrs)
        self.strips_btn.blockSignals(False)
        self._refresh_all(select_id=self.selected_task_id)
        self.dirty = True
        self.setWindowTitle("PhaseFlow *")
        self._update_undo_buttons()
        return True

    def _undo(self):
        if not self._undo_stack:
            return
        before = self._json_now()
        if self._restore(self._undo_stack[-1]):
            self._undo_stack.pop()
            self._redo_stack.append(before)
            self._update_undo_buttons()

    def _redo(self):
        if not self._redo_stack:
            return
        before = self._json_now()
        if self._restore(self._redo_stack[-1]):
            self._redo_stack.pop()
            self._undo_stack.append(before)
            self._update_undo_buttons()

    def _save(self):
        if self.workspace_error:
            QMessageBox.warning(self, "閲覧専用", self.workspace_error)
            return False
        if not self.workspace:
            root = QFileDialog.getExistingDirectory(
                self, "保存先の置き場を選ぶ", str(md.workspace_root()))
            if not root:
                return False
            self.workspace = root
            self.path = root
            try:
                self.edit_session = md.WorkspaceSession(root, self.data)
            except Exception as e:
                QMessageBox.critical(self, "保存できません", str(e))
                return False
        try:
            session = self.edit_session
            if session is None:
                # 初回起動後に別のPCが置き場を作成した場合は、
                # サンプルデータで共有設定を上書きしない。
                root = md.Path(self.workspace)
                if (root / "common.json").exists():
                    raise RuntimeError("他の利用者が置き場を作成しています。置き場を開き直してください。")
                session = md.WorkspaceSession(self.workspace, self.data)
                self.edit_session = session
            current = {pr.id for pr in self.data.projects}
            needed = [pr.id for pr in self.data.projects
                      if session.project_dirty(self.data, pr.id)
                      or pr.id not in session.baseline_files]
            needed.extend(pid for pid in session.baseline_projects if pid not in current)
            if not self._claim_projects(needed):
                return False
            md.save_workspace(self.data, self.workspace, self.plant_names,
                              session=session)
        except Exception as e:
            QMessageBox.critical(self, "保存を中止しました",
                                 "変更が競合しているか、書き込みに失敗しました。\n"
                                 "詳細を確認してから再度保存してください。\n\n" + str(e))
            return False
        self.dirty = False
        self._edit_project_id = None  # 保存時の解放に続き編集ロックを取り直す
        self._refresh_all()
        self._reset_undo()
        self.statusBar().showMessage("安全に保存しました。", 4000)
        return True

    def _scoped_data(self):
        keep = set(self.view_ids)
        scoped = copy.copy(self.data)
        scoped.projects = [pr for pr in self.data.projects
                           if pr.id in keep]
        return scoped

    def _export_excel(self):
        p = self.project()
        if not p:
            return
        path, _ = QFileDialog.getSaveFileName(self, "Excel出力", f"{p.name}.xlsx",
                                              "Excel (*.xlsx)")
        if not path:
            return
        exports.export_excel(self._scoped_data(), p, path)
        QMessageBox.information(self, "出力", "Excelを出力しました。")

    def _export_pdf(self):
        p = self.project()
        if not p:
            return
        dlg = PdfExportDialog(p.name, self.data.settings.pdf_items, self)
        if not dlg.exec():
            return
        items = dlg.items()
        self.data.settings.pdf_items = items
        self._mark_dirty()
        path, _ = QFileDialog.getSaveFileName(self, "PDF出力", "工程表.pdf",
                                              "PDF (*.pdf)")
        if not path:
            return
        n = exports.export_pdf_multi(self._scoped_data(), p, path, items)
        QMessageBox.information(self, "出力", f"PDFを出力しました（{n}ページ）。")

    def _settings(self):
        dlg = SettingsDialog(self.data.settings, self)
        if dlg.exec():
            dlg.apply_to(self.data.settings)
            self._sync_gantt_options()
            self._mark_dirty()
            self._refresh_all(select_id=self.selected_task_id)

    def _sync_gantt_options(self):
        """作業時間／属性の表示オプションをガントと合体ボタンへ反映する。"""
        s = self.data.settings
        self.gantt.set_show_options(s.show_jinko, s.show_attrs)
        self.strips_btn.blockSignals(True)
        self.strips_btn.setChecked(s.show_jinko and s.show_attrs)
        self.strips_btn.blockSignals(False)

    def _toggle_strips(self, checked):
        # 作業時間と属性は1つのボタンでまとめて切り替える
        self.data.settings.show_jinko = checked
        self.data.settings.show_attrs = checked
        self._sync_gantt_options()
        self._mark_dirty()

    def closeEvent(self, ev):
        if not self._confirm_unsaved():
            ev.ignore()
            return
        if self.edit_session:
            self.edit_session.close()
        ev.accept()
