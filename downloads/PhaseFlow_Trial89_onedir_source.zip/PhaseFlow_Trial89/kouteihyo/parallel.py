# -*- coding: utf-8 -*-
"""並列表示：工事ごとの圧縮レーン＋全工事の月別作業時間。

レーンの中身は3モード切替（節目／工程／作業時間）。
描画した全要素はホバーでツールチップを出す（当たり判定を paint 時に記録）。
"""
from __future__ import annotations

from datetime import date, timedelta

from PySide6.QtCore import Qt, QRectF, Signal, QPointF, QSize
from PySide6.QtGui import QBrush, QColor, QPainter, QPen, QPolygonF
from PySide6.QtWidgets import QPushButton, QToolTip, QWidget

from . import model as md
from .fontutil import font
from .ui import action_icon
from .gantt import HEADER_H, draw_time_header, month_iter, vivid

NAME_W = 260
ROW_H = {"milestone": 88, "process": 90, "labor": 100}
CHART_H = 190
INK = QColor("#241f18")
RED = QColor("#cd3c32")
DESK = QColor("#e8e4da")
PALETTE = ["#2f5da8", "#3e8a3e", "#26808f", "#7a4fa3", "#b26a00", "#c0532f"]
MODES = ("milestone", "process", "labor")


def _fmt(d: date) -> str:
    return f"{d.year % 100:02d}/{d.month:02d}/{d.day:02d}"


class ParallelWidget(QWidget):
    view_changed = Signal()           # ズーム／パンで表示範囲が変わった
    project_chosen = Signal(str)
    chart_toggled = Signal(bool)
    project_selected = Signal(str)    # レーンのクリック（選択のみ）
    add_requested = Signal()          # 空白カードの「+追加」が押された
    remove_requested = Signal(str)    # レーンの右クリック（表示から外す）

    def __init__(self, parent=None):
        super().__init__(parent)
        self.data = None
        self.projects = []        # 表示中の工事（表示セット）
        self.selected_id = ""     # 選択中のレーン（工事ID）
        self._add_rect = None
        self.chart_open = True
        self._chart_top = 0
        # 下部グラフの開閉ボタン（右パネルの開閉と同じ見た目で、境界に重ねる）
        self.chart_btn = QPushButton("", self)
        self.chart_btn.setIcon(action_icon("down"))
        self.chart_btn.setIconSize(QSize(16, 16))
        self.chart_btn.setAccessibleName("下のグラフを隠す")
        self.chart_btn.setFixedSize(52, 24)
        self.chart_btn.setToolTip("下のグラフを隠す")
        self.chart_btn.setStyleSheet(
            "QPushButton { background: #ffffff; border: 1px solid #b3a888;"
            " border-radius: 3px; padding: 0; font-size: 10px; color: #57503f; }"
            "QPushButton:hover { background: #fdeed3; }")
        self.chart_btn.clicked.connect(self._flip_chart)
        self.mode = "milestone"
        self.view_start = date(2026, 4, 1)
        self.view_days = 180
        self._row_project = []
        self._hits = []          # (QRectF, ツールチップ文字列) paint時に再構築
        self.setMouseTracking(True)

    # ---------- 基本 ----------
    def set_chart_open(self, open_):
        self.chart_open = bool(open_)
        self._sync_min_height()
        self.chart_btn.setIcon(action_icon("down" if self.chart_open else "up"))
        self.chart_btn.setAccessibleName("下のグラフを隠す" if self.chart_open else "下のグラフを表示する")
        self.chart_btn.setToolTip("下のグラフを隠す" if self.chart_open
                                  else "下のグラフを表示する")
        self.update()

    def _flip_chart(self):
        self.set_chart_open(not self.chart_open)
        self.chart_toggled.emit(self.chart_open)

    def _place_chart_btn(self):
        if self._chart_top:
            self.chart_btn.move((self.width() - self.chart_btn.width()) // 2,
                                self._chart_top - self.chart_btn.height() // 2)

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        self._place_chart_btn()

    def set_mode(self, mode):
        if mode in MODES and mode != self.mode:
            self.mode = mode
            self._sync_min_height()
            self.update()

    def set_data(self, data, ids=None):
        self.data = data
        if data is None:
            self.projects = []
        elif ids is None:
            self.projects = list(data.projects)
        else:
            by_id = {pr.id: pr for pr in data.projects}
            self.projects = [by_id[i] for i in ids if i in by_id]
        if self.projects:
            starts = [min(t.dstart for t in p.tasks) for p in self.projects if p.tasks]
            ends = [max(t.dend for t in p.tasks) for p in self.projects if p.tasks]
            if starts:
                s = min(starts)
                self.view_start = date(s.year, s.month, 1)
                self.view_days = max(60, (max(ends) - self.view_start).days + 20)
        if self.selected_id not in {pr.id for pr in self.projects}:
            self.selected_id = ""
        self._sync_min_height()
        self.update()
        self.view_changed.emit()

    def span(self):
        """横スクロール用の全体範囲 (開始日, 総日数)。対象が無ければ None。"""
        starts = [min(t.dstart for t in pr.tasks)
                  for pr in self.projects if pr.tasks]
        ends = [max(t.dend for t in pr.tasks)
                for pr in self.projects if pr.tasks]
        if not starts:
            return None
        s0 = min(starts)
        start = date(s0.year, s0.month, 1)
        return start, (max(ends) - start).days + 20

    def set_view_start(self, d):
        span = self.span()
        if span:
            start, total = span
            latest = start + timedelta(days=max(0, total - self.view_days))
            d = min(max(d, start), latest)
        if d != self.view_start:
            self.view_start = d
            self.update()
            self.view_changed.emit()

    def _row_h(self):
        return ROW_H[self.mode]

    def _blank_count(self):
        """画面に余りがあるとき、下に表示する空欄行の数。"""
        if not self.data or self.height() <= 0:
            return 0
        bottom = (CHART_H + 16) if self.chart_open else 26
        fit = (self.height() - HEADER_H - 26 - bottom - 12) // self._row_h()
        return max(0, fit - len(self.projects))

    def _content_height(self):
        n = len(self.projects)
        bottom = (CHART_H + 16) if self.chart_open else 26
        return HEADER_H + n * self._row_h() + 26 + bottom + 12

    def _sync_min_height(self):
        self.setMinimumHeight(self._content_height())

    def _px(self):
        return max(20, self.width() - NAME_W - 16) / max(1, self.view_days)

    def _x(self, d):
        return NAME_W + (d - self.view_start).days * self._px()

    # ---------- Ctrl+ホイールで拡大・縮小 ----------
    def zoom_by(self, steps, x):
        """カーソルの下の日を基点に表示日数を拡縮する。"""
        px = self._px()
        if not px:
            return
        anchor = self.view_start + timedelta(
            days=int(round((x - NAME_W) / px)))
        new_days = int(round(self.view_days * (0.85 ** steps)))
        new_days = max(14, min(400, new_days))
        if new_days == self.view_days:
            return
        self.view_days = new_days
        px = self._px()
        offset = int(round((x - NAME_W) / px)) if px else 0
        self.view_start = anchor - timedelta(days=max(0, offset))
        self.update()
        self.view_changed.emit()

    def wheelEvent(self, ev):
        dy = ev.angleDelta().y()
        ctrl = ev.modifiers() & Qt.KeyboardModifier.ControlModifier
        if dy and self.projects and ctrl:
            self.zoom_by(dy / 120.0, ev.position().x())
            ev.accept()
            return
        super().wheelEvent(ev)

    # ---------- ツールチップ ----------
    def _task_tip(self, proj, t):
        track = next((tr.name for tr in proj.tracks if tr.id == t.track_id), "")
        if t.milestone:
            return f"{proj.name}｜{t.name}\n{_fmt(t.dstart)}（{track}）"
        days = md.workdays_between(t.dstart, t.dend, t.calendar)
        text = (f"{proj.name}｜{t.name}\n"
                f"{_fmt(t.dstart)}〜{_fmt(t.dend)}（営業日 {days}日）")
        hours = md.task_hours(self.data, t)["合計"]
        if hours:
            text += f"\n作業時間 {md.fmt_hours(hours)}h"
        return text

    def tooltip_at(self, pos) -> str:
        for rect, text in reversed(self._hits):
            if rect.contains(pos):
                return text
        return ""

    def mouseMoveEvent(self, ev):
        pos = ev.position()
        over_lane = any(y0 <= pos.y() <= y1 for y0, y1, _ in self._row_project)
        if (self._add_rect is not None and self._add_rect.contains(pos)) or over_lane:
            self.setCursor(Qt.CursorShape.PointingHandCursor)
        else:
            self.setCursor(Qt.CursorShape.ArrowCursor)
        text = self.tooltip_at(pos)
        if text:
            QToolTip.showText(ev.globalPosition().toPoint(), text, self)
        else:
            QToolTip.hideText()
        super().mouseMoveEvent(ev)

    # ---------- 描画 ----------
    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), DESK)
        self._hits = []
        if not self.data:
            p.end()
            return
        px = self._px()
        rh = self._row_h()
        total_days = self.view_days
        blank = self._blank_count()
        chart_top = HEADER_H + (len(self.projects) + blank) * rh + 26
        from .gantt import WEEKEND as WK, HEADER_DARK, HEADER_LIGHT
        p.fillRect(QRectF(NAME_W, HEADER_H, self.width() - NAME_W, chart_top - HEADER_H),
                   QColor("#ffffff"))
        for i in range(total_days):
            d = self.view_start + timedelta(days=i)
            if d.weekday() in (5, 6):
                p.fillRect(QRectF(NAME_W + i * px, HEADER_H, px, chart_top - HEADER_H), WK)
        draw_time_header(p, NAME_W, px, self.view_start, total_days)
        # コーナーは月の濃色帯を引かず淡色で統一（ボタンの背景、Trial47）
        p.fillRect(QRectF(0, 0, NAME_W, HEADER_H), HEADER_LIGHT)
        # 左上コーナーには表示切替ボタンが重なる（Trial45）
        self._row_project = []
        for i, proj in enumerate(self.projects):
            y = HEADER_H + i * rh + 8
            self._row_project.append((y, y + rh - 16, proj.id))
            fi = self.data.projects.index(proj) if self.data else i
            col = QColor(PALETTE[fi % len(PALETTE)])
            p.setBrush(QBrush(QColor(255, 255, 255, 90)))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawRect(QRectF(0, y - 4, self.width(), rh - 8))
            if proj.id == self.selected_id:
                p.fillRect(QRectF(0, y - 4, self.width(), rh - 8),
                           QColor(46, 74, 102, 28))
            p.setBrush(QBrush(QColor("#ffffff")))
            p.setPen(QPen(QColor("#b3a888"), 1))
            card = QRectF(10, y, NAME_W - 24, rh - 16)
            p.drawRoundedRect(card, 5, 5)
            if proj.id == self.selected_id:
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.setPen(QPen(QColor("#2e4a66"), 2.2))
                p.drawRoundedRect(card, 5, 5)
            p.setBrush(QBrush(col))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawRoundedRect(QRectF(10, y, 6, rh - 16), 3, 3)
            # 3行表記: 1行目プラント、2行目工事名、3行目総作業時間（Trial62）
            inner_w = card.right() - 8 - 24
            p.setPen(QPen(col.darker(115), 1))
            p.setFont(font(9, True))
            fm = p.fontMetrics()
            p.drawText(QRectF(24, y + 5, inner_w, 15),
                       fm.elidedText(proj.plant,
                                     Qt.TextElideMode.ElideRight,
                                     int(inner_w)))
            p.setPen(QPen(INK, 1))
            p.setFont(font(12, True))
            fm = p.fontMetrics()
            p.drawText(QRectF(24, y + 21, inner_w, 22),
                       fm.elidedText(proj.name,
                                     Qt.TextElideMode.ElideRight,
                                     int(inner_w)))
            own = md.project_hours_total(self.data, proj)
            p.setPen(QPen(col.darker(115), 1))
            p.setFont(font(10, True))
            p.drawText(QRectF(24, y + 45, inner_w, 16),
                       f"総作業時間 {md.fmt_hours(own)}h")
            if not proj.tasks:
                continue
            p.save()
            p.setClipRect(QRectF(NAME_W, HEADER_H,
                                 self.width() - NAME_W,
                                 self.height() - HEADER_H))
            if self.mode == "process":
                self._lane_process(p, proj, y, col)
            elif self.mode == "labor":
                self._lane_labor(p, proj, y, col)
            else:
                self._lane_milestone(p, proj, y, col)
            p.restore()
        # 空欄行（画面の余りに、空のレーンを並べておく。先頭は「+追加」）
        self._add_rect = None
        for i in range(blank):
            y = HEADER_H + (len(self.projects) + i) * rh + 8
            p.setBrush(QBrush(QColor(255, 255, 255, 90)))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawRect(QRectF(0, y - 4, self.width(), rh - 8))
            card = QRectF(10, y, NAME_W - 24, rh - 16)
            p.setBrush(QBrush(QColor("#ffffff")))
            p.setPen(QPen(QColor("#b3a888"), 1))
            p.drawRoundedRect(card, 5, 5)
            if i == 0:
                self._add_rect = card
                p.setPen(QPen(QColor("#2e4a66"), 1))
                p.setFont(font(12, True))
                p.drawText(card, Qt.AlignmentFlag.AlignCenter, "+追加")
                self._hits.append((card, "工事を追加"))
                p.setPen(QPen(INK, 1))
        # 今日線
        today = date.today()
        if self.view_start <= today <= self.view_start + timedelta(days=total_days):
            x = self._x(today)
            p.setPen(QPen(RED, 2))
            p.drawLine(QPointF(x, HEADER_H), QPointF(x, chart_top))
        self._chart_top = chart_top
        self._place_chart_btn()
        if self.chart_open:
            self._draw_total_chart(p, chart_top)
        else:
            # 閉じた状態は題名だけの細い帯にする
            p.setBrush(QBrush(QColor("#ffffff")))
            p.setPen(QPen(QColor("#b3a888"), 1))
            p.drawRoundedRect(QRectF(10, chart_top, self.width() - 20, 26), 5, 5)
            p.setPen(QPen(INK, 1))
            p.setFont(font(11, True))
            p.drawText(QRectF(22, chart_top, 500, 26),
                       Qt.AlignmentFlag.AlignVCenter,
                       "全工事の作業時間（月別・営業日按分）")
        p.end()

    def _diamond(self, p, cx, cy, r, fill):
        p.setBrush(QBrush(fill))
        p.setPen(QPen(QColor("#ffffff"), 1.5))
        p.drawPolygon(QPolygonF([QPointF(cx, cy - r), QPointF(cx + r, cy),
                                 QPointF(cx, cy + r), QPointF(cx - r, cy)]))

    def _lane_milestone(self, p, proj, y, col):
        px = self._px()
        s = min(t.dstart for t in proj.tasks)
        e = max(t.dend for t in proj.tasks)
        p.setBrush(QBrush(QColor("#efe9da")))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawRoundedRect(QRectF(NAME_W + 2, y + 17, self.width() - NAME_W - 18, 12), 4, 4)
        bar = QRectF(self._x(s), y + 15, max(4, self._x(e) - self._x(s)), 16)
        p.setBrush(QBrush(col))
        p.setPen(QPen(col.darker(140), 1.2))
        p.drawRoundedRect(bar, 4, 4)
        self._hits.append((bar, f"{proj.name}\n{_fmt(s)}〜{_fmt(e)}"
                                f"（総作業時間 {md.fmt_hours(md.project_hours_total(self.data, proj))}h）"))
        for t in [t for t in proj.tasks if t.milestone]:
            cx = self._x(t.dstart) + px / 2
            cy = y + 44
            r = 7
            self._diamond(p, cx, cy, r, col)
            self._hits.append((QRectF(cx - r - 2, cy - r - 2, 2 * r + 4, 2 * r + 4),
                               self._task_tip(proj, t)))
            p.setPen(QPen(QColor("#57503f"), 1))
            p.setFont(font(8, True))
            p.drawText(QRectF(cx - 70, cy + r + 1, 140, 12),
                       Qt.AlignmentFlag.AlignCenter,
                       f"{t.name} {t.dstart.month}/{t.dstart.day}")

    def _split_row(self, p, proj, tasks, y, h, color_of, today_frame=True):
        """1行に工程を並べ、重なる区間は上下に等分して両方の色で塗る。
        ツールチップの当たりも帯ごとに登録する。名前は単独区間に収まる場合だけ描く。"""
        if not tasks:
            return
        bounds = sorted({t.dstart for t in tasks} |
                        {t.dend + timedelta(days=1) for t in tasks})
        sole = {}
        for a, b in zip(bounds, bounds[1:]):
            active = [t for t in tasks
                      if t.dstart <= a and b - timedelta(days=1) <= t.dend]
            if not active:
                continue
            x1, x2 = self._x(a), self._x(b)
            band = h / len(active)
            for k, t in enumerate(active):
                rect = QRectF(x1, y + k * band, max(1.5, x2 - x1), band)
                c = color_of(t)
                p.setBrush(QBrush(c))
                p.setPen(QPen(c.darker(125), 0.7))
                p.drawRect(rect)
                self._hits.append((rect, self._task_tip(proj, t)))
            if len(active) == 1:
                t = active[0]
                if t.id not in sole or (x2 - x1) > (sole[t.id][1] - sole[t.id][0]):
                    sole[t.id] = (x1, x2)
        p.setFont(font(9, True))
        for t in tasks:
            if t.id in sole:
                x1, x2 = sole[t.id]
                if p.fontMetrics().horizontalAdvance(t.name) < (x2 - x1) - 8:
                    p.setPen(QPen(QColor("#ffffff"), 1))
                    p.drawText(QRectF(x1 + 4, y, x2 - x1 - 8, h),
                               Qt.AlignmentFlag.AlignVCenter, t.name)
        if today_frame:
            today = date.today()
            for t in tasks:
                if t.dstart <= today <= t.dend:
                    x1 = self._x(t.dstart)
                    x2 = self._x(t.dend + timedelta(days=1))
                    p.setBrush(Qt.BrushStyle.NoBrush)
                    p.setPen(QPen(INK, 2.2))
                    p.drawRoundedRect(QRectF(x1, y, max(4, x2 - x1), h), 4, 4)

    def _lane_process(self, p, proj, y, col):
        px = self._px()
        own_all = [t for tr in proj.tracks if tr.kind == "own"
                   for t in proj.tasks_in_track(tr.id)]
        ref_all = [t for tr in proj.tracks if tr.kind == "ref"
                   for t in proj.tasks_in_track(tr.id)]
        own = sorted([t for t in own_all if not t.milestone],
                     key=lambda t: t.dstart)
        ref = sorted([t for t in ref_all if not t.milestone],
                     key=lambda t: t.dstart)
        self._split_row(p, proj, own, y + 10, 20,
                        lambda t: vivid(QColor(t.color)))
        self._split_row(p, proj, ref, y + 38, 9,
                        lambda t: vivid(QColor(t.color)).lighter(160),
                        today_frame=False)
        for t in own_all + ref_all:
            if not t.milestone:
                continue
            cx = self._x(t.dstart) + px / 2
            cy = y + 20 if t in own_all else y + 42
            r = 6
            fill = vivid(QColor(t.color)) if t in own_all else QColor("#8a8272")
            self._diamond(p, cx, cy, r, fill)
            self._hits.append((QRectF(cx - r - 2, cy - r - 2, 2 * r + 4, 2 * r + 4),
                               self._task_tip(proj, t)))
            p.setPen(QPen(QColor("#57503f"), 1))
            p.setFont(font(8, True))
            p.drawText(QRectF(cx - 60, cy + r + 1, 120, 11),
                       Qt.AlignmentFlag.AlignCenter,
                       f"{t.name} {t.dstart.month}/{t.dstart.day}")

    def _lane_labor(self, p, proj, y, col):
        s = min(t.dstart for t in proj.tasks)
        e = max(t.dend for t in proj.tasks)
        bar = QRectF(self._x(s), y + 8, max(4, self._x(e) - self._x(s)), 9)
        p.setBrush(QBrush(col))
        p.setPen(QPen(col.darker(140), 1.0))
        p.drawRoundedRect(bar, 3, 3)
        self._hits.append((bar, f"{proj.name}\n{_fmt(s)}〜{_fmt(e)}"
                                f"（総作業時間 {md.fmt_hours(md.project_hours_total(self.data, proj))}h）"))
        maxv = 1
        for pr in self.projects:
            for v in md.monthly_hours(self.data, pr).values():
                maxv = max(maxv, v)
        base = y + 88
        p.setPen(QPen(QColor("#b3a888"), 1))
        p.drawLine(QPointF(NAME_W, base), QPointF(self.width() - 16, base))
        for (yy, mm), v in sorted(md.monthly_hours(self.data, proj).items()):
            if not v:
                continue
            ms = date(yy, mm, 1)
            me = date(yy + (1 if mm == 12 else 0), 1 if mm == 12 else mm + 1, 1)
            x1, x2 = self._x(ms), self._x(me)
            h = 46 * v / maxv
            rect = QRectF(x1 + 3, base - h, max(3, x2 - x1 - 6), h)
            p.setBrush(QBrush(col))
            p.setPen(QPen(col.darker(120), 0.8))
            p.drawRect(rect)
            self._hits.append((rect, f"{proj.name}｜{yy}年{mm}月\n作業時間 {md.fmt_hours(v)}h"))
            p.setPen(QPen(INK, 1))
            p.setFont(font(8, True))
            p.drawText(QRectF(x1 - 6, base - h - 13, x2 - x1 + 12, 11),
                       Qt.AlignmentFlag.AlignCenter, f"{v}")

    def _draw_total_chart(self, p, chart_top):
        total_days = self.view_days
        p.setBrush(QBrush(QColor("#ffffff")))
        p.setPen(QPen(QColor("#b3a888"), 1))
        p.drawRoundedRect(QRectF(10, chart_top, self.width() - 20, CHART_H + 16), 5, 5)
        p.setPen(QPen(INK, 1))
        p.setFont(font(13, True))
        p.drawText(QRectF(22, chart_top + 6, 500, 20), "全工事の作業時間（月別・営業日按分）")
        months = list(month_iter(self.view_start,
                                 self.view_start + timedelta(days=total_days)))
        per_month = {}
        for proj in self.projects:
            i = self.data.projects.index(proj)
            for k, v in md.monthly_hours(self.data, proj).items():
                per_month.setdefault(k, {})[i] = v
        maxv = max([sum(d.values()) for d in per_month.values()] + [1])
        base = chart_top + CHART_H - 26
        for frac in (0.5, 1.0):
            gy = base - (CHART_H - 70) * frac
            p.setPen(QPen(QColor("#e6ddc9"), 1))
            p.drawLine(QPointF(NAME_W, gy), QPointF(self.width() - 16, gy))
        p.setPen(QPen(QColor("#38332b"), 2))
        p.drawLine(QPointF(NAME_W, base), QPointF(self.width() - 16, base))
        mw = (self.width() - NAME_W - 16) / max(1, len(months))
        for mi, (y_, m_) in enumerate(months):
            vals = per_month.get((y_, m_), {})
            total = sum(vals.values())
            x = NAME_W + mi * mw + 14
            w = mw - 28
            p.setPen(QPen(QColor("#57503f"), 1))
            p.setFont(font(9, True))
            p.drawText(QRectF(x - 8, base + 4, w + 16, 14),
                       Qt.AlignmentFlag.AlignCenter, f"{m_}月")
            if not total:
                continue
            h_total = (CHART_H - 70) * total / maxv
            yy = base
            for pi in sorted(vals):
                h = h_total * vals[pi] / total
                rect = QRectF(x, yy - h, w, h)
                p.setBrush(QBrush(QColor(PALETTE[pi % len(PALETTE)])))
                p.setPen(QPen(QColor("#ffffff"), 1))
                p.drawRect(rect)
                proj = self.data.projects[pi]
                self._hits.append((rect, f"{proj.name}｜{y_}年{m_}月\n作業時間 {md.fmt_hours(vals[pi])}h"))
                yy -= h
            p.setPen(QPen(INK, 1))
            p.setFont(font(11, True))
            p.drawText(QRectF(x - 8, base - h_total - 20, w + 16, 14),
                       Qt.AlignmentFlag.AlignCenter, f"{md.fmt_hours(total)}h")

    def mousePressEvent(self, ev):
        pos = ev.position()
        if (ev.button() == Qt.MouseButton.LeftButton
                and self._add_rect is not None and self._add_rect.contains(pos)):
            self.add_requested.emit()
            return
        y = pos.y()
        for y0, y1, pid in self._row_project:
            if y0 <= y <= y1:
                if ev.button() == Qt.MouseButton.RightButton:
                    self.remove_requested.emit(pid)
                elif ev.button() == Qt.MouseButton.LeftButton:
                    self.selected_id = pid
                    self.update()
                    self.project_selected.emit(pid)
                return
        if ev.button() == Qt.MouseButton.LeftButton and self.selected_id:
            self.selected_id = ""
            self.update()

    def mouseDoubleClickEvent(self, ev):
        y = ev.position().y()
        for y0, y1, pid in self._row_project:
            if y0 <= y <= y1:
                self.selected_id = pid
                self.project_chosen.emit(pid)
                return
        super().mouseDoubleClickEvent(ev)
