# -*- coding: utf-8 -*-
"""日本語が表示できるフォントを選ぶ（Windows=Yu Gothic/Meiryo、Linux=Noto CJK）。"""
from __future__ import annotations

from PySide6.QtGui import (QColor, QFont, QFontDatabase, QIcon, QPainter,
                           QPixmap, QPolygonF)
from PySide6.QtCore import QPointF, Qt

_family = None
_CANDIDATES = ("Yu Gothic UI", "Meiryo UI", "Noto Sans CJK JP",
               "Noto Sans JP", "Hiragino Sans", "sans-serif")


def family() -> str:
    global _family
    if _family is None:
        avail = set(QFontDatabase.families())
        _family = next((c for c in _CANDIDATES if c in avail), "")
    return _family


def font(size: int, bold: bool = False) -> QFont:
    f = QFont(family(), size)
    f.setBold(bold)
    return f


def style_calendar(edit) -> None:
    """QDateEdit のカレンダーの年月表示を見えるように固定する。

    周囲の白背景スタイルが及ぶと、カレンダーのナビゲーションバーは
    白文字のまま背景だけ白くなり、年と月が見えなくなる（実機報告）。
    帯を濃色にして白文字を生かし、年の入力欄は白地に濃い文字にする。
    """
    cal = edit.calendarWidget()
    if cal is None:
        return
    # 前月／次月ボタンは白い三角アイコンで固定する（標準の矢印は
    # 濃い帯の上で黒っぽく描かれ、見づらいため。実機報告 Trial63）
    from PySide6.QtWidgets import QToolButton
    prev = cal.findChild(QToolButton, "qt_calendar_prevmonth")
    nxt = cal.findChild(QToolButton, "qt_calendar_nextmonth")
    if prev is not None:
        prev.setIcon(_triangle_icon(False))
    if nxt is not None:
        nxt.setIcon(_triangle_icon(True))
    cal.setStyleSheet(
        "QWidget#qt_calendar_navigationbar { background: #38332b; }"
        "QCalendarWidget QToolButton { color: #ffffff;"
        " background: transparent; border: none; padding: 2px 6px; }"
        "QCalendarWidget QToolButton:hover { background: #57503f; }"
        "QCalendarWidget QSpinBox { background: #ffffff;"
        " color: #241f18; border: 1px solid #b3a888; }"
        "QCalendarWidget QAbstractItemView { background: #ffffff;"
        " color: #241f18; selection-background-color: #2e4a66;"
        " selection-color: #ffffff; }")


def _triangle_icon(right: bool) -> QIcon:
    """カレンダーの前月／次月ボタン用の白い三角アイコン。"""
    pm = QPixmap(14, 14)
    pm.fill(Qt.GlobalColor.transparent)
    qp = QPainter(pm)
    qp.setRenderHint(QPainter.RenderHint.Antialiasing)
    qp.setBrush(QColor("#ffffff"))
    qp.setPen(Qt.PenStyle.NoPen)
    if right:
        pts = [QPointF(4, 2), QPointF(4, 12), QPointF(11, 7)]
    else:
        pts = [QPointF(10, 2), QPointF(10, 12), QPointF(3, 7)]
    qp.drawPolygon(QPolygonF(pts))
    qp.end()
    return QIcon(pm)
