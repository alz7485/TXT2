# -*- coding: utf-8 -*-
"""工程表ツール モデル層（Qt非依存）。

正本は「項目＋開始・終了日」。期間はカレンダー（営業日）から導出する。
人工は役割ごとに 人数×日数。属性はタスク量で、単位時間から所要時間の目安を出す。
"""
from __future__ import annotations

import json
import base64
import copy
import os
import hashlib
import tempfile
import re
import shutil
import sys
import uuid
from dataclasses import dataclass, field, asdict
from datetime import date, datetime, timedelta
from pathlib import Path

SCHEMA_VERSION = 1

# カレンダー: 休みにする weekday() の集合（月=0 … 土=5, 日=6）
CALENDARS = {
    "standard": {"label": "標準（土日休み）", "off": {5, 6}},
    "saturday": {"label": "土曜出勤", "off": {6}},
    "all": {"label": "暦日（休みなし）", "off": set()},
}

# 2026年の日本の祝日（簡易内蔵。将来は設定で編集可能にする想定）
HOLIDAYS_2026 = {
    "2026-01-01", "2026-01-12", "2026-02-11", "2026-02-23", "2026-03-20",
    "2026-04-29", "2026-05-03", "2026-05-04", "2026-05-05", "2026-05-06",
    "2026-07-20", "2026-08-11", "2026-09-21", "2026-09-22", "2026-09-23",
    "2026-10-12", "2026-11-03", "2026-11-23",
}
HOLIDAYS = {date.fromisoformat(s) for s in HOLIDAYS_2026}

# 外部の祝日ファイル（holidays.txt）があれば、そちらを正とする（Trial24）。
# 置き場所: アプリのフォルダ（main.py と同じ場所）→ カレントフォルダの順。
HOLIDAY_SOURCE = ""
_DATE_RE = re.compile(r"(\d{4})[-/](\d{1,2})[-/](\d{1,2})")


def parse_holidays_text(text: str) -> set:
    """1行に1日。'2026-01-01 元日' のように後ろに名前を付けてもよい。

    '#' で始まる行と空行は無視する。'/' 区切りも可。
    """
    out = set()
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        m = _DATE_RE.search(line)
        if m:
            try:
                out.add(date(int(m[1]), int(m[2]), int(m[3])))
            except ValueError:
                pass
    return out


def app_dir() -> Path:
    """アプリのフォルダ。onedir の EXE 化時は EXE のある場所、
    通常実行時はこのパッケージの親フォルダ（main.py の場所）。"""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def load_holidays() -> int:
    """holidays.txt を探して読み、内蔵祝日と差し替える。読めた日数を返す。"""
    global HOLIDAY_SOURCE
    cands = [app_dir() / "holidays.txt",
             Path.cwd() / "holidays.txt"]
    for cand in cands:
        try:
            if cand.is_file():
                days = parse_holidays_text(cand.read_text(encoding="utf-8"))
                if days:
                    HOLIDAYS.clear()
                    HOLIDAYS.update(days)
                    HOLIDAY_SOURCE = str(cand)
                    return len(days)
        except OSError:
            continue
    HOLIDAY_SOURCE = ""
    return 0


def holiday_status_text() -> str:
    if HOLIDAY_SOURCE:
        years = sorted({d.year for d in HOLIDAYS})
        span = f"{years[0]}〜{years[-1]}年" if years else ""
        return f"祝日：holidays.txt を使用中（{span}・{len(HOLIDAYS)}日）"
    return "祝日：内蔵データ（2026年のみ）。holidays.txt を置くと差し替わります"

PALETTE = ["#2f5da8", "#b26a00", "#26808f", "#3e8a3e", "#7a4fa3",
           "#c0532f", "#35707f", "#5d7d1e", "#b03a5e", "#46648c"]


def suggest_master_color(used) -> str:
    """まだ使われていないバーの色をパレットから提案する（Trial83）。"""
    taken = {str(u).lower() for u in used or []}
    for c in PALETTE:
        if c.lower() not in taken:
            return c
    return PALETTE[0]

# 役割（作成・チェック等）の色分け。よく使う名前は固定色、
# それ以外は名前から決定的にパレットを選ぶ（Trial14）
ROLE_COLORS = {
    "作成": "#2f6db3",
    "チェック": "#d2691e",
    "確認": "#3d8b5f",
    "承認": "#7d4fa6",
    "管理": "#96731a",
}
ROLE_PALETTE = ["#2f6db3", "#d2691e", "#3d8b5f", "#7d4fa6", "#b03a5b",
                "#17807e", "#96731a", "#5b6abf"]


def role_color(name: str) -> str:
    """役割名に対応する色（同じ名前は常に同じ色）。"""
    if name in ROLE_COLORS:
        return ROLE_COLORS[name]
    h = 0
    for ch in name:
        h = (h * 31 + ord(ch)) & 0xFFFFFFFF
    return ROLE_PALETTE[h % len(ROLE_PALETTE)]


def _uid() -> str:
    return uuid.uuid4().hex[:12]


# ---------------- 営業日計算 ----------------

def is_workday(d: date, calendar: str) -> bool:
    cal = CALENDARS.get(calendar, CALENDARS["standard"])
    return d.weekday() not in cal["off"] and (calendar == "all" or d not in HOLIDAYS)


def next_workday(d: date, calendar: str) -> date:
    while not is_workday(d, calendar):
        d += timedelta(days=1)
    return d


def prev_workday(d: date, calendar: str) -> date:
    while not is_workday(d, calendar):
        d -= timedelta(days=1)
    return d


def add_workdays(d: date, n: int, calendar: str) -> date:
    """d の翌営業日から数えて n 営業日進めた日（n=0 なら d を営業日に寄せて返す）。"""
    d = next_workday(d, calendar)
    step = 1 if n >= 0 else -1
    for _ in range(abs(n)):
        d += timedelta(days=step)
        while not is_workday(d, calendar):
            d += timedelta(days=step)
    return d


def workdays_between(a: date, b: date, calendar: str) -> int:
    """a..b 両端含みの営業日数。b<a なら 0。"""
    if b < a:
        return 0
    n, d = 0, a
    while d <= b:
        if is_workday(d, calendar):
            n += 1
        d += timedelta(days=1)
    return n


def end_from_duration(start: date, days_bd: int, calendar: str) -> date:
    """開始日（営業日）から days_bd 営業日目の日付。"""
    if days_bd <= 1:
        return next_workday(start, calendar)
    return add_workdays(start, days_bd - 1, calendar)


def month_workdays(a: date, b: date, calendar: str, year: int, month: int) -> int:
    """a..b のうち year-month に含まれる営業日数。"""
    n, d = 0, a
    while d <= b:
        if (d.year, d.month) == (year, month) and is_workday(d, calendar):
            n += 1
        d += timedelta(days=1)
    return n


# ---------------- データ構造 ----------------

@dataclass
class RoleDef:
    name: str = ""
    headcount: int = 0
    mode: str = "full"      # 旧「終盤」指定の名残（Trial69で廃止、読み込み互換のため残置・不使用）
    days: int = 0           # 同上


@dataclass
class AttrDef:
    name: str = ""
    unit: str = "枚"
    hours: dict = field(default_factory=dict)  # 役割名 -> 1単位あたり時間


@dataclass
class Master:
    """項目マスタ（登録済み項目）。"""
    id: str = field(default_factory=_uid)
    name: str = ""
    kind: str = "own"               # own=自部門 / ref=他部門
    calendar: str = "standard"
    default_days: int = 5           # 標準の期間（営業日）
    color: str = "#406eb4"
    roles: list = field(default_factory=list)    # RoleDef
    attrs: list = field(default_factory=list)    # AttrDef
    milestone: bool = False


@dataclass
class Track:
    id: str = field(default_factory=_uid)
    name: str = ""
    kind: str = "own"               # own=自部門 / ref=他部門


@dataclass
class Task:
    id: str = field(default_factory=_uid)
    master_id: str = ""
    name: str = ""
    track_id: str = ""
    start: str = ""                 # ISO date
    end: str = ""
    calendar: str = "standard"
    kind: str = "own"
    color: str = "#406eb4"
    roles: list = field(default_factory=list)    # RoleDef（インスタンス側）
    attrs: dict = field(default_factory=dict)    # 属性名 -> 数量
    attr_defs: list = field(default_factory=list)  # 作業内容の定義（項目ごとに保持。マスタは初期値）
    pred_id: str = ""               # 先行タスク（表示とプロパティ用。自動伝播はしない）
    milestone: bool = False
    lock_start: bool = False        # 開始日のロック（期限確定）
    lock_end: bool = False          # 終了日のロック

    @property
    def locked_any(self) -> bool:
        return self.lock_start or self.lock_end
    memo: str = ""

    @property
    def dstart(self) -> date:
        return date.fromisoformat(self.start)

    @property
    def dend(self) -> date:
        return date.fromisoformat(self.end)


@dataclass
class Project:
    id: str = field(default_factory=_uid)
    name: str = ""
    plant: str = ""
    tracks: list = field(default_factory=list)   # Track
    tasks: list = field(default_factory=list)    # Task

    def track_of(self, task: Task):
        for t in self.tracks:
            if t.id == task.track_id:
                return t
        return None

    def task_by_id(self, tid: str):
        for t in self.tasks:
            if t.id == tid:
                return t
        return None

    def tasks_in_track(self, track_id: str):
        return sorted((t for t in self.tasks if t.track_id == track_id),
                      key=lambda t: (t.start, t.end))


@dataclass
class PresetEntry:
    master_id: str = ""
    track_name: str = ""
    pred_master: str = ""           # 他系列の先行（マスタ名で指定、任意）


@dataclass
class Preset:
    id: str = field(default_factory=_uid)
    name: str = ""
    tracks: list = field(default_factory=list)   # {"name":..., "kind":...}
    entries: list = field(default_factory=list)  # PresetEntry


@dataclass
class ViewPreset:
    """表示プリセット：並列表示に出す工事の集まり（プラントを跨げる）。"""
    id: str = field(default_factory=_uid)
    name: str = ""
    project_ids: list = field(default_factory=list)


@dataclass
class Settings:
    zoom_on_drag: bool = True       # 調整時に日単位へ拡大表示
    hours_per_day: float = 8.0      # 作業時間換算の1日あたり時間
    hours_per_day_set: bool = False  # 利用者が設定画面で決めたか
    show_jinko: bool = True         # ガントに人数・時間を表示（既定ON、Trial60）
    show_attrs: bool = True         # ガントに作業内容（タスク量）を表示（既定ON）
    parallel_mode: str = "milestone"  # 並列レーンの表示（milestone/process/labor）
    parallel_chart_open: bool = True  # 並列表示の下部グラフを表示するか
    pdf_items: list = field(default_factory=list)  # PDF出力で選んだ項目（空=全て）
    parallel_plants: list = field(default_factory=list)  # 並列に含める他プラント
    view_mode: str = ""          # 前回の表示の選び方（single/preset/plant）
    view_ids: list = field(default_factory=list)   # 前回の表示セット（工事ID）
    view_preset_id: str = ""     # 前回開いた表示プリセット
    view_plant: str = ""         # 前回選んだプラント
    project_list_widths: list = field(default_factory=list)  # 工事一覧の列幅


@dataclass
class AppData:
    version: int = SCHEMA_VERSION
    masters: list = field(default_factory=list)
    presets: list = field(default_factory=list)
    view_presets: list = field(default_factory=list)   # ViewPreset
    projects: list = field(default_factory=list)
    settings: Settings = field(default_factory=Settings)

    def view_preset_by_id(self, vid: str):
        for v in self.view_presets:
            if v.id == vid:
                return v
        return None

    def master_by_id(self, mid: str):
        for m in self.masters:
            if m.id == mid:
                return m
        return None

    def master_by_name(self, name: str):
        for m in self.masters:
            if m.name == name:
                return m
        return None


# ---------------- 計算 ----------------

def task_duration_bd(task: Task) -> int:
    if task.milestone:
        return 0
    return workdays_between(task.dstart, task.dend, task.calendar)


def role_span(task: Task, role: RoleDef):
    """役割が関与する (開始, 終了, 営業日数)。常に対象工程の全期間。

    旧「終盤○日」指定は細分化しすぎのため Trial69 で廃止した。
    """
    dur = task_duration_bd(task)
    if dur == 0:
        return task.dstart, task.dend, 0
    return task.dstart, task.dend, dur


def task_jinko(task: Task) -> dict:
    """役割名 -> 人工。合計は "合計" キー。"""
    out = {}
    total = 0
    for r in task.roles:
        _, _, n = role_span(task, r)
        v = (r.headcount or 0) * n
        out[r.name] = v
        total += v
    out["合計"] = total
    return out


def project_jinko_total(project: Project) -> int:
    """自部門系列の項目だけの総人工。"""
    total = 0
    for t in project.tasks:
        tr = project.track_of(t)
        if tr and tr.kind == "own":
            total += task_jinko(t)["合計"]
    return total


def project_span(project: Project):
    """工事の (開始, 終了)。タスクが無ければ (None, None)。"""
    if not project.tasks:
        return None, None
    return (min(t.dstart for t in project.tasks),
            max(t.dend for t in project.tasks))


def is_current_or_future(project: Project, today=None) -> bool:
    """現在進行中と今後の工事か（終了済みだけを除く）。"""
    today = today or date.today()
    _s, e = project_span(project)
    return e is None or e >= today


def monthly_jinko(project: Project) -> dict:
    """{(年, 月): 人工}。自部門のみ。役割の関与期間を月ごとの営業日で按分。"""
    out = {}
    for t in project.tasks:
        tr = project.track_of(t)
        if not tr or tr.kind != "own":
            continue
        for r in t.roles:
            if not r.headcount:
                continue
            s, e, n = role_span(t, r)
            if n == 0:
                continue
            y, m = s.year, s.month
            while (y, m) <= (e.year, e.month):
                cnt = month_workdays(s, e, t.calendar, y, m)
                if cnt:
                    out[(y, m)] = out.get((y, m), 0) + r.headcount * cnt
                m += 1
                if m == 13:
                    y, m = y + 1, 1
    return out


def estimate_hours(task: Task) -> dict:
    """属性×単位時間から 役割名 -> 所要時間（目安）。

    定義は項目ごとに持つ（Task.attr_defs）。マスタは初期値。
    """
    out = {}
    for a in task.attr_defs:
        qty = task.attrs.get(a.name, 0) or 0
        if not qty:
            continue
        for role_name, h in (a.hours or {}).items():
            out[role_name] = out.get(role_name, 0.0) + qty * float(h)
    return out


def role_shortages(data, task: Task) -> dict:
    """作業内容の所要時間が人員の上限を超える役割 {役割名: (所要, 上限)}。

    対象は、作業内容（属性×単位時間）が設定された自部門の項目だけ。
    上限 = 人数（役割が無ければ0）× 営業日数 × 1日の時間。
    不足していなければ空 dict。
    """
    if not data or task.kind != "own" or task.milestone:
        return {}
    if not any((v or 0) > 0 for v in task.attrs.values()):
        return {}
    est = estimate_hours(task)
    if not est:
        return {}
    dur = task_duration_bd(task)
    per = data.settings.hours_per_day
    heads = {r.name: (r.headcount or 0) for r in task.roles}
    out = {}
    for name, req in est.items():
        cap = heads.get(name, 0) * dur * per
        if req > cap:
            out[name] = (float(req), float(cap))
    return out


def fmt_hours(v: float) -> str:
    """時間の表示（54 → '54'、54.5 → '54.5'）。"""
    return f"{float(v):g}"


def task_hours(data, task: Task) -> dict:
    """役割名 -> 作業時間（時間）。合計は "合計" キー。

    属性×単位時間が設定された役割はその時間を使い、設定の無い
    役割は 人工 × 1日の時間（設定、既定8時間）で換算する。
    """
    est = estimate_hours(task)
    per = data.settings.hours_per_day if data else 8.0
    jinko = task_jinko(task)
    out = {}
    total = 0.0
    for r in task.roles:
        v = float(est.get(r.name, 0.0))
        if v <= 0:
            v = jinko.get(r.name, 0) * per
        out[r.name] = v
        total += v
    for name, v in est.items():
        if name not in out and v > 0:
            out[name] = float(v)
            total += float(v)
    out["合計"] = total
    return out


def project_hours_total(data, project: Project) -> float:
    """自部門系列の項目だけの総作業時間（時間）。"""
    total = 0.0
    for t in project.tasks:
        tr = project.track_of(t)
        if tr and tr.kind == "own":
            total += task_hours(data, t)["合計"]
    return total


def monthly_hours(data, project: Project) -> dict:
    """{(年, 月): 作業時間}。自部門のみ。

    役割ごとの時間を、その役割の関与期間の営業日で月へ按分する
    （営業日が無い期間は暦日で按分）。
    """
    out = {}

    def spread(s, e, cal, value):
        if value <= 0 or s > e:
            return
        months = []
        y, m = s.year, s.month
        while (y, m) <= (e.year, e.month):
            months.append((y, m))
            m += 1
            if m == 13:
                y, m = y + 1, 1
        weights = [month_workdays(s, e, cal, yy, mm) for yy, mm in months]
        if sum(weights) == 0:
            weights = []
            for yy, mm in months:
                first = date(yy, mm, 1)
                nxt = (date(yy + 1, 1, 1) if mm == 12
                       else date(yy, mm + 1, 1))
                lo, hi = max(s, first), min(e, nxt - timedelta(days=1))
                weights.append(max(0, (hi - lo).days + 1))
        tot = sum(weights)
        if tot == 0:
            out[(s.year, s.month)] = out.get((s.year, s.month), 0.0) + value
            return
        for (yy, mm), w in zip(months, weights):
            if w:
                out[(yy, mm)] = out.get((yy, mm), 0.0) + value * w / tot

    for t in project.tasks:
        tr = project.track_of(t)
        if not tr or tr.kind != "own":
            continue
        hours = task_hours(data, t)
        spans = {r.name: role_span(t, r) for r in t.roles}
        for name, v in hours.items():
            if name == "合計" or v <= 0:
                continue
            if name in spans:
                s, e, _n = spans[name]
            else:
                s, e = t.dstart, t.dend
            spread(s, e, t.calendar, v)
    return out


# ---------------- 重なりの解消 ----------------

def next_task_in_track(project: Project, task: Task):
    """同じ系列で、開始日が task の次に来る項目（自分以外）。"""
    cands = [t for t in project.tasks_in_track(task.track_id) if t.id != task.id]
    for t in cands:
        if t.dstart > task.dstart or (t.dstart == task.dstart and t.dend > task.dend):
            return t
    return None


def find_overlap(project: Project, task: Task):
    """task の終了が後続（同系列の次＋系列をまたぐ依存先）に重なれば、その項目を返す。"""
    cands = []
    nxt = next_task_in_track(project, task)
    if nxt:
        cands.append(nxt)
    for t in project.tasks:
        if t.pred_id == task.id and t not in cands:
            cands.append(t)
    hit = [t for t in cands if task.dend >= t.dstart]
    if not hit:
        return None
    return min(hit, key=lambda t: t.start)


def can_shrink(project: Project, task: Task, nxt: Task) -> bool:
    """次の項目だけ縮める、が可能か（縮めても1営業日は残る）。"""
    ns = next_workday(task.dend + timedelta(days=1), nxt.calendar)
    return ns <= nxt.dend


def apply_shrink(task: Task, nxt: Task) -> None:
    nxt.start = next_workday(task.dend + timedelta(days=1), nxt.calendar).isoformat()


def following_tasks(project: Project, task: Task):
    """同じ系列で task より後ろにある項目すべて（開始順）。"""
    out, seen = [], False
    for t in project.tasks_in_track(task.track_id):
        if t.id == task.id:
            seen = True
            continue
        if seen:
            out.append(t)
    return out


def shift_delta_for(task: Task, first: Task) -> int:
    """first の開始を task 終了の翌営業日に合わせるための暦日シフト量。"""
    target = next_workday(task.dend + timedelta(days=1), first.calendar)
    return (target - first.dstart).days


def apply_shift(tasks: list, delta_days: int) -> None:
    for t in tasks:
        t.start = (t.dstart + timedelta(days=delta_days)).isoformat()
        t.end = (t.dend + timedelta(days=delta_days)).isoformat()


# ---------------- プリセット展開 ----------------

def task_from_master(master: Master, track_id: str, start: date) -> Task:
    s = next_workday(start, master.calendar)
    e = s if master.milestone else end_from_duration(s, max(1, master.default_days), master.calendar)
    return Task(
        master_id=master.id, name=master.name, track_id=track_id,
        start=s.isoformat(), end=e.isoformat(), calendar=master.calendar,
        kind=master.kind, color=master.color,
        roles=[RoleDef(r.name, r.headcount) for r in master.roles],
        attrs={a.name: 0 for a in master.attrs},
        attr_defs=[AttrDef(a.name, a.unit, dict(a.hours or {}))
                   for a in master.attrs],
        milestone=master.milestone,
    )


def expand_preset(data: AppData, preset: Preset, project_name: str,
                  base: date) -> Project:
    proj = Project(name=project_name)
    track_by_name = {}
    for td in preset.tracks:
        tr = Track(name=td["name"], kind=td.get("kind", "own"))
        proj.tracks.append(tr)
        track_by_name[tr.name] = tr
    if not proj.tracks:
        tr = Track(name="自部門", kind="own")
        proj.tracks.append(tr)
        track_by_name[tr.name] = tr
    cursor = {}   # track_id -> 次の開始候補
    placed = {}   # master_id -> Task
    last_in_track = {}
    for entry in preset.entries:
        master = data.master_by_id(entry.master_id)
        if not master:
            continue
        tr = track_by_name.get(entry.track_name) or proj.tracks[0]
        start = cursor.get(tr.id, base)
        if entry.pred_master:
            pm = data.master_by_name(entry.pred_master)
            if pm and pm.id in placed:
                after = placed[pm.id].dend + timedelta(days=1)
                if after > start:
                    start = after
        task = task_from_master(master, tr.id, start)
        if tr.id in last_in_track:
            task.pred_id = last_in_track[tr.id].id
        elif entry.pred_master:
            pm = data.master_by_name(entry.pred_master)
            if pm and pm.id in placed:
                task.pred_id = placed[pm.id].id
        proj.tasks.append(task)
        placed[master.id] = task
        last_in_track[tr.id] = task
        cursor[tr.id] = task.dend + timedelta(days=1)
    return proj


def preset_from_project(data: AppData, project: Project, name: str) -> Preset:
    """現在の並びをプリセットとして登録する（項目はマスタ名で引き直す）。"""
    preset = Preset(name=name)
    for tr in project.tracks:
        preset.tracks.append({"name": tr.name, "kind": tr.kind})
    track_name = {t.id: t.name for t in project.tracks}
    for tr in project.tracks:
        for task in project.tasks_in_track(tr.id):
            master = data.master_by_id(task.master_id) or data.master_by_name(task.name)
            if master is None:
                master = Master(name=task.name, kind=task.kind, calendar=task.calendar,
                                color=task.color, milestone=task.milestone)
                data.masters.append(master)
            entry = PresetEntry(master_id=master.id, track_name=track_name[tr.id])
            preset.entries.append(entry)
    return preset


# ---------------- JSON 入出力 ----------------

def _task_to_dict(t: Task) -> dict:
    d = asdict(t)
    return d


def data_to_dict(data: AppData) -> dict:
    return {
        "version": data.version,
        "settings": asdict(data.settings),
        "masters": [asdict(m) for m in data.masters],
        "presets": [{
            "id": p.id, "name": p.name, "tracks": p.tracks,
            "entries": [asdict(e) for e in p.entries],
        } for p in data.presets],
        "view_presets": [asdict(v) for v in data.view_presets],
        "projects": [{
            "id": pr.id, "name": pr.name, "plant": pr.plant,
            "tracks": [asdict(t) for t in pr.tracks],
            "tasks": [_task_to_dict(t) for t in pr.tasks],
        } for pr in data.projects],
    }


def _master_from_dict(d: dict) -> Master:
    m = Master(**{k: d[k] for k in ("id", "name", "kind", "calendar",
                                     "default_days", "color", "milestone") if k in d})
    m.roles = [RoleDef(**r) for r in d.get("roles", [])]
    m.attrs = [AttrDef(name=a.get("name", ""), unit=a.get("unit", "枚"),
                       hours=a.get("hours", {})) for a in d.get("attrs", [])]
    return m


def _task_from_dict(d: dict) -> Task:
    t = Task(**{k: d[k] for k in ("id", "master_id", "name", "track_id", "start",
                                  "end", "calendar", "kind", "color", "pred_id",
                                  "milestone", "memo", "lock_start",
                                  "lock_end") if k in d})
    if d.get("locked"):   # Trial78の単一ロックは両方ロックとして引き継ぐ
        t.lock_start = True
        t.lock_end = True
    t.roles = [RoleDef(**r) for r in d.get("roles", [])]
    t.attrs = d.get("attrs", {}) or {}
    t._needs_attr_migration = "attr_defs" not in d
    t.attr_defs = [AttrDef(name=a.get("name", ""), unit=a.get("unit", "枚"),
                           hours=a.get("hours", {}))
                   for a in d.get("attr_defs", [])]
    return t


def ensure_attr_defs(data: AppData) -> None:
    """定義を持たない項目へ、マスタの定義（初期値）を補う。

    Trial82より前は定義がマスタ側にしか無かったため、旧データの
    読込時にここで項目側へ移す。
    """
    for proj in data.projects:
        for t in proj.tasks:
            if not getattr(t, "_needs_attr_migration", False):
                continue
            t._needs_attr_migration = False
            m = data.master_by_id(t.master_id)
            if m and m.attrs:
                t.attr_defs = [AttrDef(a.name, a.unit, dict(a.hours or {}))
                               for a in m.attrs]


def data_from_dict(d: dict) -> AppData:
    data = AppData(version=d.get("version", SCHEMA_VERSION))
    if "settings" in d:
        data.settings = Settings(**d["settings"])
        if (data.settings.hours_per_day == 7.75
                and not data.settings.hours_per_day_set):
            data.settings.hours_per_day = 8.0
    data.masters = [_master_from_dict(m) for m in d.get("masters", [])]
    for p in d.get("presets", []):
        preset = Preset(id=p.get("id", _uid()), name=p.get("name", ""),
                        tracks=p.get("tracks", []))
        preset.entries = [PresetEntry(**e) for e in p.get("entries", [])]
        data.presets.append(preset)
    data.view_presets = [ViewPreset(**v) for v in d.get("view_presets", [])]
    for pr in d.get("projects", []):
        proj = Project(id=pr.get("id", _uid()), name=pr.get("name", ""),
                       plant=pr.get("plant", ""))
        proj.tracks = [Track(**t) for t in pr.get("tracks", [])]
        proj.tasks = [_task_from_dict(t) for t in pr.get("tasks", [])]
        data.projects.append(proj)
    ensure_attr_defs(data)
    return data


def save_json(data: AppData, path: str) -> None:
    """保存の安全化（Trial24）: 既存ファイルは backup フォルダへ世代保存し、
    書き込みは一時ファイル経由の差し替え（原子化）にする。"""
    p = Path(path)
    text = json.dumps(data_to_dict(data), ensure_ascii=False, indent=1)
    if p.exists():
        try:
            bdir = p.parent / "backup"
            bdir.mkdir(exist_ok=True)
            stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            shutil.copy2(p, bdir / f"{p.stem}_{stamp}{p.suffix}")
            olds = sorted(bdir.glob(f"{p.stem}_*{p.suffix}"))
            for old in olds[:-10]:
                old.unlink()
        except OSError:
            pass  # バックアップに失敗しても保存自体は続ける
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, p)


def load_json(path: str) -> AppData:
    with open(path, encoding="utf-8") as f:
        return data_from_dict(json.load(f))


# ---------------- 置き場（工事ごとのファイル分割、Trial33） ----------------

def _write_with_backup(text: str, path) -> None:
    """一意の一時ファイルを使った同ディレクトリ原子差替＋世代保存。"""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists():
        bdir = p.parent / "backup"
        bdir.mkdir(exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
        shutil.copy2(p, bdir / f"{p.stem}_{stamp}{p.suffix}")
        olds = sorted(bdir.glob(f"{p.stem}_*{p.suffix}"))
        for old in olds[:-10]:
            old.unlink()
    fd, tmpname = tempfile.mkstemp(prefix=f".{p.stem}-", suffix=".tmp", dir=p.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmpname, p)
    finally:
        if os.path.exists(tmpname):
            os.unlink(tmpname)


def workspace_root() -> Path:
    """データの置き場。アプリ（EXE）の隣の data フォルダ。"""
    return app_dir() / "data"


def _safe_filename(name: str) -> str:
    for ch in '\\/:*?"<>|':
        name = name.replace(ch, "＿")
    return (name.strip() or "無題") + ".json"


def common_to_dict(data: AppData) -> dict:
    d = data_to_dict(data)
    d.pop("projects", None)
    d["project_order"] = [pr.id for pr in data.projects]  # 並び順を保持する
    return d


def _common_from_dict(d: dict) -> AppData:
    data = AppData(version=d.get("version", SCHEMA_VERSION))
    if "settings" in d:
        data.settings = Settings(**d["settings"])
        if (data.settings.hours_per_day == 7.75
                and not data.settings.hours_per_day_set):
            data.settings.hours_per_day = 8.0
    data.masters = [_master_from_dict(m) for m in d.get("masters", [])]
    for p in d.get("presets", []):
        preset = Preset(id=p.get("id", _uid()), name=p.get("name", ""),
                        tracks=p.get("tracks", []))
        preset.entries = [PresetEntry(**e) for e in p.get("entries", [])]
        data.presets.append(preset)
    data.view_presets = [ViewPreset(**v) for v in d.get("view_presets", [])]
    return data


def project_to_dict(pr: Project) -> dict:
    return {"version": SCHEMA_VERSION,
            "project": {"id": pr.id, "name": pr.name, "plant": pr.plant,
                        "tracks": [asdict(t) for t in pr.tracks],
                        "tasks": [_task_to_dict(t) for t in pr.tasks]}}


def project_from_dict(d: dict) -> Project:
    pr = d.get("project", d)
    proj = Project(id=pr.get("id", _uid()), name=pr.get("name", ""),
                   plant=pr.get("plant", ""))
    proj.tracks = [Track(**t) for t in pr.get("tracks", [])]
    proj.tasks = [_task_from_dict(t) for t in pr.get("tasks", [])]
    return proj


# 複数PC共有時、個人の表示状態は共通ファイルに書かない。
_PERSONAL_SETTINGS = ("zoom_on_drag", "show_jinko", "show_attrs", "parallel_mode",
                      "parallel_chart_open", "pdf_items", "parallel_plants",
                      "view_mode", "view_ids", "view_preset_id", "view_plant",
                      "project_list_widths")


def _shared_common_to_dict(data: AppData) -> dict:
    d = common_to_dict(data)
    d["settings"] = {"hours_per_day": data.settings.hours_per_day,
                     "hours_per_day_set": data.settings.hours_per_day_set}
    # 同時追加時はセッション側で最新の順番へマージする。
    return d


def _personal_path(root) -> Path:
    base = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / ".local" / "share"))
    key = hashlib.sha256(os.path.normcase(str(Path(root).resolve())).encode("utf-8")).hexdigest()[:20]
    return base / "PhaseFlow" / "view_settings" / f"{key}.json"


def _load_personal(data, root):
    path = _personal_path(root)
    if not path.exists():
        # Trial53 以前の表示設定を読み、次の保存で新しい保存先へ移行する。
        # 旧ファイルは削除しない（ロールバック可能にする）。
        path = path.parent.parent.parent / "Kouteihyo" / "view_settings" / path.name
    if path.exists():
        try:
            values = json.loads(path.read_text(encoding="utf-8"))
            for field_name in _PERSONAL_SETTINGS:
                if field_name in values:
                    setattr(data.settings, field_name, values[field_name])
        except (OSError, ValueError, TypeError):
            pass


def _save_personal(data, root):
    values = {k: getattr(data.settings, k) for k in _PERSONAL_SETTINGS}
    _write_with_backup(json.dumps(values, ensure_ascii=False, indent=1), _personal_path(root))


def _digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _scan_workspace(root: Path) -> dict:
    """ID -> (パス, SHA256)。重複IDや壊れたJSONは黙って上書きしない。"""
    from .concurrency import WorkspaceConflict
    projects = {}
    if not root.exists():
        return projects
    for pdir in root.iterdir():
        if not pdir.is_dir() or pdir.name in {"backup", ".locks"}:
            continue
        for f in pdir.glob("*.json"):
            try:
                raw = f.read_bytes()
                project = project_from_dict(json.loads(raw))
                pid = project.id
                if not pid:
                    raise ValueError("工事IDなし")
            except (OSError, ValueError, KeyError, TypeError) as e:
                raise WorkspaceConflict(f"読み取れない工事ファイルが存在します: {f} ({e})") from e
            if pid in projects:
                raise WorkspaceConflict(f"同一IDの工事ファイルが重複しています: {projects[pid][0]} / {f}")
            projects[pid] = (f, hashlib.sha256(raw).hexdigest())
    return projects


def _project_path(root: Path, pr: Project) -> Path:
    # 名前が同じでもIDが違えば必ず別ファイル。Windowsのファイル名長さにも配慮。
    name = _safe_filename(pr.name)[:-5][:65].rstrip(" .") or "無題"
    pid = re.sub(r"[^a-zA-Z0-9_-]", "_", pr.id)
    plant = _safe_filename(pr.plant or "未分類")[:-5].strip(" .") or "未分類"
    return root / plant / f"{name}__{pid}.json"


class WorkspaceSession:
    """起動時のスナップショットとOSロックを保持する編集セッション。"""
    def __init__(self, root, data: AppData | None = None):
        from .concurrency import WorkspaceLock
        self.root = Path(root)
        self.index_lock = WorkspaceLock(self.root, "_workspace_index")
        self.locks = {}
        if (self.root / _SAVE_JOURNAL).exists():
            if not self.index_lock.acquire():
                raise RuntimeError("保存処理中です。しばらく待って置き場を開き直してください。")
            try:
                _recover_save(self.root)
            finally:
                self.index_lock.release()
        self.baseline_files = _scan_workspace(self.root)
        self.baseline_common = (_digest(self.root / "common.json")
                                if (self.root / "common.json").exists() else None)
        if data is None:
            data, _ = load_workspace(self.root)
        self.baseline_projects = {p.id: project_to_dict(p) for p in data.projects}
        self.baseline_shared = _shared_common_to_dict(data)
        # ロードとセッション開始の間に他PCが保存しても、古いデータを
        # 新しい版として誤認しない。次回 refresh で再読込させる。
        for pid, (path, digest) in list(self.baseline_files.items()):
            loaded = self.baseline_projects.get(pid)
            if loaded is None:
                continue
            disk_project = project_from_dict(json.loads(path.read_text(encoding="utf-8")))
            disk_project.plant = path.parent.name
            if loaded != project_to_dict(disk_project):
                self.baseline_files[pid] = (path, "__stale__")
        common = self.root / "common.json"
        if common.exists():
            latest_common = _shared_common_to_dict(
                _common_from_dict(json.loads(common.read_text(encoding="utf-8"))))
            fields = ("masters", "presets", "view_presets", "settings")
            if any(latest_common.get(k) != self.baseline_shared.get(k) for k in fields):
                self.baseline_common = "__stale__"

    def claim(self, pid) -> tuple[bool, str]:
        from .concurrency import WorkspaceLock
        if pid in self.locks:
            return True, ""
        lock = WorkspaceLock(self.root, "project_" + pid)
        if not lock.acquire():
            return False, lock.owner()
        self.locks[pid] = lock
        return True, ""

    def release(self, pid):
        lock = self.locks.pop(pid, None)
        if lock is not None:
            lock.release()

    def release_clean(self, data, except_id=""):
        now = {p.id: project_to_dict(p) for p in data.projects}
        for pid in list(self.locks):
            if pid != except_id and now.get(pid) == self.baseline_projects.get(pid):
                self.release(pid)

    def close(self):
        for pid in list(self.locks):
            self.release(pid)

    def project_dirty(self, data, pid):
        pr = next((p for p in data.projects if p.id == pid), None)
        return ((project_to_dict(pr) if pr else None)
                != self.baseline_projects.get(pid))

    def _get_new_files(self):
        return _scan_workspace(self.root)

    def refresh(self, data: AppData):
        """ローカル未編集の工事だけ外部の更新と新規追加を反映。"""
        if self.index_lock.file is not None:
            return self._refresh_locked(data)
        if not self.index_lock.acquire():
            return []  # 書込中なら一時的にスキップ。次回再確認する。
        try:
            return self._refresh_locked(data)
        finally:
            self.index_lock.release()

    def _refresh_locked(self, data: AppData):
        files = self._get_new_files()
        ids = {pr.id: i for i, pr in enumerate(data.projects)}
        changes = []
        for pid, (path, revision) in files.items():
            before = self.baseline_files.get(pid)
            if before is not None and before[1] == revision:
                continue
            if pid in self.locks or (pid in ids and self.project_dirty(data, pid)):
                continue
            pr = project_from_dict(json.loads(path.read_text(encoding="utf-8")))
            pr.plant = path.parent.name
            if pid in ids:
                data.projects[ids[pid]] = pr
            else:
                data.projects.append(pr)
            self.baseline_projects[pid] = project_to_dict(pr)
            self.baseline_files[pid] = (path, revision)
            changes.append(pid)
        for pid in list(self.baseline_files):
            if pid in files or pid in self.locks:
                continue
            if not self.project_dirty(data, pid):
                data.projects[:] = [p for p in data.projects if p.id != pid]
                self.baseline_files.pop(pid, None)
                self.baseline_projects.pop(pid, None)
                changes.append(pid)
        common = self.root / "common.json"
        revision = _digest(common) if common.exists() else None
        if revision != self.baseline_common:
            # 共有項目はローカル未編集のときのみ更新する。個人表示設定は保持。
            if all(_shared_common_to_dict(data).get(k) == self.baseline_shared.get(k)
                   for k in ("masters", "presets", "view_presets", "settings")):
                if common.exists():
                    latest = _common_from_dict(json.loads(common.read_text(encoding="utf-8")))
                    data.masters, data.presets, data.view_presets = latest.masters, latest.presets, latest.view_presets
                    data.settings.hours_per_day = latest.settings.hours_per_day
                    data.settings.hours_per_day_set = latest.settings.hours_per_day_set
                self.baseline_shared = _shared_common_to_dict(data)
                self.baseline_common = revision
                changes.append("common")
        return changes

    def save(self, data: AppData, plants):
        from .concurrency import WorkspaceConflict
        if not self.index_lock.acquire():
            raise WorkspaceConflict("他の利用者が保存処理中です。数秒後に保存し直してください。")
        try:
            self._save_locked(data, plants)
        finally:
            self.index_lock.release()

    def _save_locked(self, data: AppData, plants):
        # index lock is held throughout snapshot, commit and rollback.
        _recover_save(self.root)
        state = copy.deepcopy((self.baseline_files, self.baseline_common,
                               self.baseline_projects, self.baseline_shared))
        # Preserve project/task identities held by the GUI on a failed save.
        previous_data = {key: list(value) if isinstance(value, list) else value
                         for key, value in data.__dict__.items()}
        previous_settings = dict(data.settings.__dict__)
        _begin_save(self.root)
        try:
            self._save_changes(data, plants)
            # Removing the journal is the commit point. A crash before this
            # point restores the previous complete workspace on next open.
            (self.root / _SAVE_JOURNAL).unlink()
        except Exception as error:
            try:
                _recover_save(self.root)
            except Exception as recovery_error:
                raise RuntimeError(
                    f"保存と復旧に失敗しました。次回起動時に再復旧します。"
                    f"置き場を変更せず再度開いてください。\n保存: {error}\n復旧: {recovery_error}") from error
            (self.baseline_files, self.baseline_common,
             self.baseline_projects, self.baseline_shared) = state
            data.__dict__.clear()
            data.__dict__.update(previous_data)
            data.settings.__dict__.update(previous_settings)
            raise
        self.release_clean(data)

    def _save_changes(self, data: AppData, plants):
        from .concurrency import WorkspaceConflict
        self.root.mkdir(parents=True, exist_ok=True)
        files = self._get_new_files()
        current = {pr.id: pr for pr in data.projects}
        if len(current) != len(data.projects):
            raise WorkspaceConflict("重複した工事IDがあります。保存せずデータを確認してください。")
        baseline_ids = set(self.baseline_projects)
        # 変更したものだけ保存する。同じIDの工事が他者に更新されていれば中断。
        changed = {pid for pid, pr in current.items()
                   if project_to_dict(pr) != self.baseline_projects.get(pid) or pid not in files}
        deleted = baseline_ids - set(current)
        if (changed | deleted) - set(self.locks):
            raise WorkspaceConflict("編集ロック未取得の工事があります。該当工事を開き直してください。")
        for pid in changed | deleted:
            disk = files.get(pid)
            initial = self.baseline_files.get(pid)
            if (disk[1] if disk else None) != (initial[1] if initial else None):
                raise WorkspaceConflict(f"工事ID {pid} が他のPCで変更されています。保存を中止しました。")
        common = self.root / "common.json"
        disk_common = _digest(common) if common.exists() else None
        local_shared = _shared_common_to_dict(data)
        # 表示順は他の追加工事を消さないように最新順とマージする。
        if common.exists():
            disk_d = json.loads(common.read_text(encoding="utf-8"))
            previous_order = disk_d.get("project_order", [])
        else:
            disk_d = {}
            previous_order = []
        all_ids = (set(files) - deleted) | set(current)
        order = [i for i in previous_order if i in all_ids]
        order.extend(pid for pid in current if pid not in order)
        local_shared["project_order"] = order
        # 工事順は別扱いで、設定の共有フィールドだけ競合検出する。
        def shared_content(d):
            return {k: v for k, v in d.items() if k != "project_order"}
        before_content = shared_content(self.baseline_shared)
        local_content = shared_content(local_shared)
        disk_content = shared_content(disk_d) if disk_d else before_content
        if local_content != before_content and disk_common != self.baseline_common and disk_content != before_content:
            raise WorkspaceConflict("項目マスタ・プリセット・共通設定が他のPCで更新されています。保存を中止しました。")
        # 未変更共有設定を古い内容で上書きしない。
        if local_content == before_content and disk_d:
            common_payload = dict(disk_d)
            # 以前の版で共有保存されていた個人表示設定を移行時に取り除く。
            common_payload["settings"] = {
                "hours_per_day": disk_d.get("settings", {}).get("hours_per_day", 8.0),
                "hours_per_day_set": disk_d.get("settings", {}).get("hours_per_day_set", False)}
            common_payload["project_order"] = order
        else:
            common_payload = local_shared
        # 個人設定の保存失敗を共有データ書換後に起こさない。
        _save_personal(data, self.root)
        # 空プラントも置き場に残す。
        for plant in plants:
            folder = _safe_filename(plant)[:-5].strip(" .") or "未分類"
            (self.root / folder).mkdir(exist_ok=True)
        # 事前検査はここまで。ファイルごとに一時ファイル＋置換でコミット。
        for pid in changed:
            pr = current[pid]
            target = _project_path(self.root, pr)
            old = files.get(pid)
            # 既存の別IDがターゲットを使用するケースは拒否。
            if target.exists() and (old is None or old[0] != target):
                raise WorkspaceConflict(f"保存先ファイルが既に存在します: {target}")
        for pid in changed:
            pr = current[pid]
            target = _project_path(self.root, pr)
            old = files.get(pid)
            if old and old[0] != target and old[0].exists():
                # 先に原子的に移動し、途中停止でも同一IDが二重に残らないようにする。
                target.parent.mkdir(parents=True, exist_ok=True)
                os.replace(old[0], target)
            _write_with_backup(json.dumps(project_to_dict(pr), ensure_ascii=False, indent=1), target)
        for pid in deleted:
            if pid in files and files[pid][0].exists():
                # 削除された工事はバックアップしてから退避させる。
                old = files[pid][0]
                bdir = old.parent / "backup"
                bdir.mkdir(exist_ok=True)
                shutil.copy2(old, bdir / f"{old.stem}_deleted_{datetime.now():%Y%m%d-%H%M%S-%f}.json")
                old.unlink()
        if not common.exists() or common_payload != disk_d:
            _write_with_backup(json.dumps(common_payload, ensure_ascii=False, indent=1), common)
        # 他の利用者の更新は未編集工事に限り取り込む。
        self.refresh(data)
        self.baseline_files = self._get_new_files()
        self.baseline_common = _digest(common)
        self.baseline_projects = {pr.id: project_to_dict(pr) for pr in data.projects}
        self.baseline_shared = _shared_common_to_dict(data)


_SAVE_JOURNAL = ".phaseflow-save-journal.json"


def _workspace_json_files(root):
    files = [root / "common.json"] if (root / "common.json").exists() else []
    for folder in root.iterdir():
        if folder.is_dir() and folder.name not in {"backup", ".locks"}:
            files.extend(folder.glob("*.json"))
    return files


def _atomic_bytes(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".recover-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _begin_save(root):
    root.mkdir(parents=True, exist_ok=True)
    snapshot = {str(path.relative_to(root)): base64.b64encode(path.read_bytes()).decode("ascii")
                for path in _workspace_json_files(root)}
    _atomic_bytes(root / _SAVE_JOURNAL,
                  json.dumps(snapshot, ensure_ascii=False).encode("utf-8"))


def _recover_save(root):
    """Must be called with the workspace index lock held; retries are idempotent."""
    journal = root / _SAVE_JOURNAL
    if not journal.exists():
        return
    snapshot = json.loads(journal.read_text(encoding="utf-8"))
    # Validate the complete journal before touching workspace files.
    restored = {}
    for relative, encoded in snapshot.items():
        path = root / relative
        if (path.resolve().parent != root.resolve() and
                path.resolve().parent.parent != root.resolve()):
            raise ValueError("復旧情報に不正なパスがあります")
        if path.suffix != ".json" or path.name == _SAVE_JOURNAL:
            raise ValueError("復旧情報に不正なファイルがあります")
        restored[path] = base64.b64decode(encoded, validate=True)
    for path, raw in restored.items():
        _atomic_bytes(path, raw)
    for path in _workspace_json_files(root):
        if path not in restored:
            path.unlink()
    journal.unlink()


def load_workspace(root) -> tuple:
    root = Path(root)
    if not root.exists():
        return AppData(), []
    from .concurrency import WorkspaceLock
    lock = WorkspaceLock(root, "_workspace_index")
    if not lock.acquire():
        raise RuntimeError("別の利用者が保存処理中です。しばらく待って置き場を開き直してください。")
    try:
        _recover_save(root)
        return _load_workspace_locked(root)
    finally:
        lock.release()


def _load_workspace_locked(root) -> tuple:
    """置き場を読む。戻り値は (AppData, プラント名リスト)。
    工事ファイルはプラントフォルダ内の *.json を名前順に読む。
    読めないファイルは _load_errors に記録し、GUIで閲覧専用として通知する。"""
    root = Path(root)
    data = AppData()
    data._load_errors = []
    plants = []
    if not root.exists():
        return data, plants
    common = root / "common.json"
    order = []
    if common.exists():
        try:
            with open(common, encoding="utf-8") as f:
                raw = json.load(f)
            data = _common_from_dict(raw)
            data._load_errors = []
            order = raw.get("project_order", [])
        except Exception as error:
            data._load_errors.append(f"{common}: {error}")
    for pdir in sorted((d for d in root.iterdir() if d.is_dir() and d.name != ".locks"),
                       key=lambda d: d.name):
        if pdir.name == "backup":
            continue
        plants.append(pdir.name)
        for f in sorted(pdir.glob("*.json"), key=lambda f: f.name):
            try:
                with open(f, encoding="utf-8") as fh:
                    proj = project_from_dict(json.load(fh))
            except Exception as error:
                data._load_errors.append(f"{f}: {error}")
                continue
            proj.plant = pdir.name  # 置かれているフォルダが正
            data.projects.append(proj)
    if order:
        rank = {pid: i for i, pid in enumerate(order)}
        data.projects.sort(key=lambda pr: rank.get(pr.id, len(rank)))
    _load_personal(data, root)
    ensure_attr_defs(data)
    return data, plants


def save_workspace(data: AppData, root, plants, *, session=None) -> None:
    """置き場へ書く。共通部は common.json、工事はプラントフォルダへ
    1件1ファイル。既存ファイルは ID で突き合わせ、移動・改名・削除に
    追従する（読めなかったファイルには触らない）。"""
    if session is not None:
        session.save(data, plants)
        return
    # 互換API。複数PCでの編集は必ず WorkspaceSession を渡すこと。
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    _write_with_backup(json.dumps(common_to_dict(data),
                                  ensure_ascii=False, indent=1),
                       root / "common.json")
    known = {}   # project id -> 既存ファイル
    for pdir in root.iterdir():
        if not pdir.is_dir() or pdir.name in {"backup", ".locks"}:
            continue
        for f in pdir.glob("*.json"):
            try:
                with open(f, encoding="utf-8") as fh:
                    pid = json.load(fh).get("project", {}).get("id")
                if pid:
                    known[pid] = f
            except Exception:
                continue
    live = set()
    for pr in data.projects:
        plant = pr.plant or "未分類"
        target = _project_path(root, pr)
        _write_with_backup(json.dumps(project_to_dict(pr),
                                      ensure_ascii=False, indent=1), target)
        live.add(pr.id)
        old = known.get(pr.id)
        if old is not None and old != target and old.exists():
            old.unlink()
    for pid, f in known.items():
        if pid not in live and f.exists():
            f.unlink()   # 削除された工事のファイル
    keep = set(plants) | {pr.plant or "未分類" for pr in data.projects}
    for pdir in list(root.iterdir()):
        if pdir.is_dir() and pdir.name not in {"backup", ".locks"} and pdir.name not in keep:
            try:
                pdir.rmdir()   # 空のときだけ消える
            except OSError:
                pass


def migrate_legacy(json_path, root, plant_name: str) -> AppData:
    """旧 data.json を置き場へ移行する。全工事を plant_name のプラントに
    入れ、旧ファイルは .bak に残す。"""
    data = load_json(json_path)
    plant_name = (plant_name or "").strip() or "プラント1"
    for pr in data.projects:
        pr.plant = plant_name
    session = WorkspaceSession(root, data)
    try:
        from .concurrency import WorkspaceConflict
        for pr in data.projects:
            ok, owner = session.claim(pr.id)
            if not ok:
                raise WorkspaceConflict(f"移行先の工事を編集中です: {owner}")
        save_workspace(data, root, [plant_name], session=session)
    finally:
        session.close()
    try:
        os.replace(json_path, str(json_path) + ".bak")
    except OSError:
        pass
    return data
