# -*- coding: utf-8 -*-
"""置き場の排他制御 (Windows/SMB の byte-range lock、Unix は fcntl)。

ロックファイルを消さないこと。削除すると inode/ファイル識別子が変わり、
待機プロセスが異なるファイルを同時ロックできるため危険。
"""
from __future__ import annotations

import getpass
import json
import os
import re
import socket
import threading
from datetime import datetime
from pathlib import Path


_PROCESS_LOCKS = set()
_PROCESS_GUARD = threading.RLock()


class WorkspaceConflict(RuntimeError):
    """他の利用者による変更・編集中で安全に保存できない。"""


class WorkspaceLock:
    def __init__(self, root, name: str):
        self.path = Path(root) / '.locks' / (re.sub(r'[^a-zA-Z0-9_-]', '_', name) + '.lock')
        self.file = None
        self._key = os.path.normcase(str(self.path.resolve()))

    def acquire(self) -> bool:
        with _PROCESS_GUARD:
            return self._acquire_guarded()

    def _acquire_guarded(self) -> bool:
        if self.file is not None:
            return True
        if self._key in _PROCESS_LOCKS:
            return False
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.touch(exist_ok=True)
        fh = open(self.path, 'r+b', buffering=0)
        try:
            # Windows はロック範囲にバイトが必要。常に先頭1バイトを確保する。
            if not self.path.stat().st_size:
                fh.write(b'!')
                fh.flush()
            fh.seek(0)
            if os.name == 'nt':
                import msvcrt
                try:
                    msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
                except OSError:
                    fh.close()
                    return False
            else:
                import fcntl
                try:
                    fcntl.lockf(fh, fcntl.LOCK_EX | fcntl.LOCK_NB, 1)
                except (OSError, BlockingIOError):
                    fh.close()
                    return False
            info = {'user': getpass.getuser(), 'host': socket.gethostname(),
                    'pid': os.getpid(), 'since': datetime.now().isoformat(timespec='seconds')}
            fh.seek(1)
            fh.write(json.dumps(info, ensure_ascii=False).encode('utf-8'))
            fh.truncate()
            fh.flush()
            os.fsync(fh.fileno())
            self.file = fh
            _PROCESS_LOCKS.add(self._key)
            return True
        except Exception:
            fh.close()
            raise

    def owner(self) -> str:
        try:
            with open(self.path, 'rb') as fh:
                fh.seek(1)  # Windows の byte-range lock が先頭1バイトを保護
                raw = fh.read()
            info = json.loads(raw.decode('utf-8'))
            return f"{info.get('user', '?')} @ {info.get('host', '?')}（{info.get('since', '?')} 開始）"
        except (OSError, ValueError, UnicodeDecodeError):
            return '別の利用者'

    def release(self):
        if self.file is None:
            return
        fh = self.file
        self.file = None
        with _PROCESS_GUARD:
            try:
                fh.seek(0)
                if os.name == 'nt':
                    import msvcrt
                    msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.lockf(fh, fcntl.LOCK_UN, 1)
            finally:
                fh.close()
                _PROCESS_LOCKS.discard(self._key)
