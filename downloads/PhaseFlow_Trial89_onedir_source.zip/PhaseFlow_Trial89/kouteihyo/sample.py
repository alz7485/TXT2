# -*- coding: utf-8 -*-
"""初回起動時のサンプルデータ（ユーザーの受け持ち5工程＋他部門の工程）。"""
from __future__ import annotations

from datetime import date

from .model import (AppData, AttrDef, Master, Preset, PresetEntry, RoleDef,
                    expand_preset)


def build_sample_data() -> AppData:
    data = AppData()
    M = {}

    def master(name, **kw):
        m = Master(name=name, **kw)
        data.masters.append(m)
        M[name] = m
        return m

    master("現場調査準備", kind="own", calendar="standard", default_days=3,
           color="#3f6fb5", roles=[RoleDef("担当", 2, "full", 0)])
    master("現場調査", kind="own", calendar="saturday", default_days=7,
           color="#b26a00", roles=[RoleDef("担当", 3, "full", 0)])
    master("現場調査報告書作成", kind="own", calendar="standard", default_days=5,
           color="#26808f", roles=[RoleDef("担当", 2, "full", 0)])
    master("物量集計", kind="own", calendar="standard", default_days=10,
           color="#3e8a3e", roles=[RoleDef("担当", 2, "full", 0)])
    master("図面作成", kind="own", calendar="standard", default_days=20,
           color="#2f5da8",
           roles=[RoleDef("作成", 2), RoleDef("チェック", 3)],
           attrs=[AttrDef("配管図", "枚", {"作成": 3.0, "チェック": 1.0}),
                  AttrDef("サポート図", "枚", {"作成": 2.0, "チェック": 0.5}),
                  AttrDef("その他図面", "枚", {"作成": 2.0, "チェック": 1.0})])
    master("レーザースキャン計測", kind="ref", calendar="standard", default_days=7,
           color="#b0a89e")
    master("点群処理", kind="ref", calendar="standard", default_days=6,
           color="#b0a89e")
    master("データ納品", kind="ref", calendar="standard", default_days=1,
           color="#96918a", milestone=True)
    master("承認", kind="ref", calendar="standard", default_days=15,
           color="#bcb5ac")
    master("製作", kind="ref", calendar="standard", default_days=40,
           color="#bcb5ac")
    master("検査", kind="ref", calendar="standard", default_days=1,
           color="#96918a", milestone=True)

    preset = Preset(name="標準（調査〜図面）")
    preset.tracks = [
        {"name": "自部門", "kind": "own"},
        {"name": "他部門（他課）", "kind": "ref"},
        {"name": "他部門・ベンダー", "kind": "ref"},
    ]

    def entry(master_name, track, pred=""):
        preset.entries.append(PresetEntry(master_id=M[master_name].id,
                                          track_name=track, pred_master=pred))

    entry("レーザースキャン計測", "他部門（他課）")
    entry("点群処理", "他部門（他課）")
    entry("データ納品", "他部門（他課）")
    entry("現場調査準備", "自部門")
    entry("現場調査", "自部門")
    entry("現場調査報告書作成", "自部門")
    entry("物量集計", "自部門", pred="データ納品")
    entry("図面作成", "自部門")
    entry("承認", "他部門・ベンダー", pred="図面作成")
    entry("製作", "他部門・ベンダー")
    entry("検査", "他部門・ベンダー")
    data.presets.append(preset)

    b = expand_preset(data, preset, "B工事 配管更新", date(2026, 4, 1))
    for t in b.tasks:
        if t.name == "図面作成":
            t.attrs = {"配管図": 12, "サポート図": 6, "その他図面": 3}
    data.projects.append(b)
    data.projects.append(expand_preset(data, preset, "A工事 ポンプ基礎", date(2026, 4, 1)))
    data.projects.append(expand_preset(data, preset, "C工事 タンク設置", date(2026, 5, 7)))
    data.projects.append(expand_preset(data, preset, "D工事 計装工事", date(2026, 6, 1)))
    # サンプルは2プラントに分ける（Trial33: プラント切替の見本）
    for _pr in data.projects:
        _pr.plant = "プラントA"
    data.projects[-1].plant = "プラントB"
    return data
