# -*- coding: utf-8 -*-
"""右側パネル：日付表タブとプロパティタブ。"""
from __future__ import annotations

from datetime import date

from PySide6.QtCore import QDate, QEvent, QPoint, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFontMetrics, QPen, QPixmap
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDateEdit,
                               QDoubleSpinBox, QFormLayout,
                               QHBoxLayout,
                               QHeaderView,
                               QLabel, QLineEdit, QPushButton, QSpinBox,
                               QStyledItemDelegate, QTableWidget,
                               QTableWidgetItem, QVBoxLayout, QWidget)

from . import model as md
from .fontutil import font, style_calendar
from .icons import icon_pixmap

WD = "月火水木金土日"


def fmt_d(d: date) -> str:
    return f"{d.year % 100:02d}/{d.month}/{d.day}（{WD[d.weekday()]}）"


def _date_width(edit) -> int:
    """日付欄の最小幅：表示文字列の実測＋プルダウン＋余白（下限100）。
    フォント幅は環境で違うため固定値にしない（Trial43）。"""
    text = edit.fontMetrics().horizontalAdvance("26/12/31")
    return max(100, text + 40)


class _RowFrameDelegate(QStyledItemDelegate):
    """不足している行の外周に赤枠を描く（Trial70）。"""

    def __init__(self, parent, rows_fn):
        super().__init__(parent)
        self._rows_fn = rows_fn

    def paint(self, painter, option, index):
        super().paint(painter, option, index)
        if index.row() not in self._rows_fn():
            return
        painter.save()
        painter.setPen(QPen(QColor("#d43a2f"), 2))
        r = option.rect
        painter.drawLine(r.left(), r.top() + 1, r.right(), r.top() + 1)
        painter.drawLine(r.left(), r.bottom() - 1, r.right(), r.bottom() - 1)
        if index.column() == 0:
            painter.drawLine(r.left() + 1, r.top(), r.left() + 1, r.bottom())
        if index.column() == index.model().columnCount() - 1:
            painter.drawLine(r.right() - 1, r.top(), r.right() - 1, r.bottom())
        painter.restore()


class _LockHeaderView(QHeaderView):
    """開始・終了の見出しに、セルのチェックボックスの真上の位置へ
    鍵アイコンを描くヘッダ（Trial82）。"""

    def __init__(self, parent=None):
        super().__init__(Qt.Orientation.Horizontal, parent)
        self.lock_icon = None     # QPixmap
        self.lock_offset = 0      # 列の左端からチェック中心までのpx

    def paintSection(self, painter, rect, logicalIndex):
        super().paintSection(painter, rect, logicalIndex)
        if logicalIndex in (1, 2) and self.lock_icon is not None:
            x = rect.left() + self.lock_offset - 7
            y = rect.center().y() - 7
            painter.drawPixmap(int(x), int(y), self.lock_icon)


class DateTable(QWidget):
    task_chosen = Signal(str)
    dates_edited = Signal(object)   # Task
    lock_changed = Signal(object)   # Task（日付ロックの切替）

    def __init__(self, parent=None):
        super().__init__(parent)
        self.project = None
        self.data = None
        self._loading = False
        self.table = QTableWidget(0, 5)
        # 日付欄の幅は、表示形式の実寸＋付属ボタン分から決める。
        # sizeHint 任せだと環境により日付が欄の中で見切れる（Trial85）
        self._edit_w = (QFontMetrics(font(10)).horizontalAdvance("00/00/00")
                        + 34)
        self.table.setHorizontalHeaderLabels(["工程", "開始", "終了", "期間", "作業時間"])
        # 鍵マークは見出しに置き、セルのチェックボックスの真上に
        # 来るよう位置を合わせる（Trial81/82）。位置は日付欄と
        # チェックの実寸から求める
        hdr = _LockHeaderView(self.table)
        self.table.setHorizontalHeader(hdr)
        hdr.lock_offset = (self._edit_w + 2
                           + QCheckBox().sizeHint().width() // 2)
        hdr.lock_icon = icon_pixmap("lock", "#f0e9d8").scaled(
            14, 14, Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation)
        # 列幅: 工程だけ伸縮、他は固定（作業時間が間延びしないように）
        # 開始・終了は「日付欄＋チェック＋余白」がちょうど入る幅（Trial85）
        hdr.setStretchLastSection(False)
        hdr.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        _date_col_w = self._edit_w + 2 + 22 + 4
        for _col, _w in ((1, _date_col_w), (2, _date_col_w), (3, 62), (4, 62)):
            hdr.setSectionResizeMode(_col, QHeaderView.ResizeMode.Fixed)
            self.table.setColumnWidth(_col, _w)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(26)
        self.table.setAlternatingRowColors(True)
        self.table.setStyleSheet(
            "QTableWidget { background: #ffffff; alternate-background-color: #f6f2e7;"
            " gridline-color: #c7b995; selection-background-color: #fdeed3;"
            " selection-color: #241f18; }"
            "QHeaderView::section { background: #38332b; color: #ffffff;"
            " font-weight: bold; padding: 5px; border: none; }")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        # 項目の追加はガント左上のボタンに集約（Trial74で表のボタンは廃止）
        lay.addWidget(self.table)
        self._short_rows = set()
        self._edit_rows = {}   # 日付ドロップダウン欄 -> (行, task_id)
        self.table.setItemDelegate(
            _RowFrameDelegate(self.table, lambda: self._short_rows))
        self.table.currentCellChanged.connect(self._on_current)
        self.table.itemChanged.connect(self._on_item_changed)

    def set_project(self, project):
        self.project = project
        self.refresh()

    def refresh(self, select_id: str = ""):
        self._loading = True
        _first_wrap = None
        self.table.setRowCount(0)
        self._short_rows = set()
        self._edit_rows = {}
        if not self.project:
            self._loading = False
            return
        row = 0
        for tr in self.project.tracks:
            for t in self.project.tasks_in_track(tr.id):
                self.table.insertRow(row)
                vals = [t.name,
                        t.start[2:].replace("-", "/"),
                        t.end[2:].replace("-", "/"),
                        "―" if t.milestone else f"{md.task_duration_bd(t)}日",
                        "―" if tr.kind == "ref" else
                        md.fmt_hours(md.task_hours(self.data, t)["合計"])]
                short = bool(md.role_shortages(self.data, t))
                for c, v in enumerate(vals):
                    if c in (1, 2):
                        continue   # 日付列はドロップダウン欄を置く
                    item = QTableWidgetItem(v)
                    item.setData(Qt.ItemDataRole.UserRole, t.id)
                    item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                    if tr.kind == "ref":
                        item.setForeground(QColor("#9a927e"))
                    elif c == 0 or c == 4:
                        item.setFont(font(10, True))
                    self.table.setItem(row, c, item)
                for c, iso in ((1, t.start), (2, t.end)):
                    edit = self._make_date_edit(iso, t.id, row, c,
                                                tr.kind == "ref", short)
                    lk = t.lock_start if c == 1 else t.lock_end
                    if t.milestone and t.locked_any:
                        lk = True   # 節目は開始＝終了なので片方でも両方止める
                    if lk:
                        edit.setEnabled(False)
                    # 日付の横に鍵チェックボックスを置く（Trial79/80）
                    _wrap = self._wrap_date_edit(
                        edit, t, "start" if c == 1 else "end")
                    self.table.setCellWidget(row, c, _wrap)
                    if _first_wrap is None:
                        _first_wrap = (_wrap, c)
                if short:
                    self._short_rows.add(row)
                if t.id == select_id:
                    self.table.setCurrentCell(row, 0)
                row += 1
        # 見出しの鍵アイコンがチェックボックスの真上に来るよう実測で合わせる
        if _first_wrap is not None and self.table.isVisible():
            _wrap, _col = _first_wrap
            _cb = _wrap.findChild(QCheckBox)
            if _cb is not None and _cb.width() > 0:
                _hdr = self.table.horizontalHeader()
                _cx = _cb.mapTo(self.table.viewport(),
                                QPoint(_cb.width() // 2, 0)).x()
                _new = _cx - _hdr.sectionViewportPosition(_col)
                if abs(_new - _hdr.lock_offset) > 1:
                    _hdr.lock_offset = _new
                    _hdr.update()
        self._loading = False

    def _make_date_edit(self, iso, tid, row, col, is_ref, short):
        """開始／終了セルに置く、カレンダーが開く日付ドロップダウン。"""
        edit = QDateEdit()
        edit.setCalendarPopup(True)
        edit.setDisplayFormat("yy/MM/dd")
        d = date.fromisoformat(iso)
        edit.setDate(QDate(d.year, d.month, d.day))
        edit.setFont(font(10))
        border = "1px solid #d43a2f" if short else "none"
        color = "#9a927e" if is_ref else "#241f18"
        edit.setStyleSheet(
            f"QDateEdit {{ background: transparent; border: {border};"
            f" color: {color}; }}"
            # drop-down は幅だけ指定し、矢印は標準スタイルに描かせる
            "QDateEdit::drop-down { width: 16px; }")
        style_calendar(edit)
        edit.editingFinished.connect(
            lambda e=edit, t=tid, c=col: self._commit_date_edit(e, t, c))
        cal = edit.calendarWidget()
        if cal is not None:
            # ポップアップが閉じてから反映する（開いている欄を壊さない）
            cal.clicked.connect(
                lambda _d, e=edit, t=tid, c=col: QTimer.singleShot(
                    0, lambda: self._commit_date_edit(e, t, c)))
        edit.installEventFilter(self)
        self._edit_rows[edit] = (row, tid)
        return edit

    def _wrap_date_edit(self, edit, task, which):
        w = QWidget()
        box = QHBoxLayout(w)
        box.setContentsMargins(0, 0, 0, 0)
        box.setSpacing(2)
        edit.setFixedWidth(self._edit_w)
        box.addWidget(edit)
        cb = QCheckBox()
        cb.setToolTip("開始日をロックする" if which == "start"
                      else "終了日をロックする")
        cb.setChecked(bool(task.lock_start if which == "start"
                           else task.lock_end))
        cb.toggled.connect(
            lambda on, tid=task.id, wh=which:
                self._on_lock_box(tid, wh, on))
        box.addWidget(cb)
        box.addStretch(1)
        return w

    def _on_lock_box(self, tid, which, on):
        if self._loading or not self.project:
            return
        task = self.project.task_by_id(tid)
        if not task:
            return
        if task.milestone:
            if task.lock_start != bool(on) or task.lock_end != bool(on):
                task.lock_start = task.lock_end = bool(on)
                self.lock_changed.emit(task)
            return
        cur = task.lock_start if which == "start" else task.lock_end
        if cur != bool(on):
            if which == "start":
                task.lock_start = bool(on)
            else:
                task.lock_end = bool(on)
            self.lock_changed.emit(task)

    def _commit_date_edit(self, edit, tid, col):
        if self._loading or not self.project:
            return
        task = self.project.task_by_id(tid)
        if not task:
            return
        try:
            qd = edit.date()
        except RuntimeError:
            return
        iso = date(qd.year(), qd.month(), qd.day()).isoformat()
        if col == 1:
            if task.start == iso:
                return
            task.start = iso
            if task.dstart > task.dend:
                task.end = task.start
        else:
            if task.end == iso:
                return
            task.end = iso
            if task.dend < task.dstart:
                task.start = task.end
        if task.milestone:
            task.end = task.start
        self.dates_edited.emit(task)

    def eventFilter(self, obj, ev):
        # 日付欄にフォーカスが入ったら、その行を選択状態にする
        if ev.type() == QEvent.Type.FocusIn and obj in self._edit_rows:
            row, _tid = self._edit_rows[obj]
            if self.table.currentRow() != row:
                self.table.setCurrentCell(row, 1)
        return super().eventFilter(obj, ev)

    def _on_current(self, row, _c, _pr, _pc):
        if self._loading or row < 0:
            return
        item = self.table.item(row, 0)
        if item:
            self.task_chosen.emit(item.data(Qt.ItemDataRole.UserRole))

    def _on_item_changed(self, item):
        if self._loading or not self.project:
            return
        if item.column() not in (1, 2):
            return
        tid = self.table.item(item.row(), 0).data(Qt.ItemDataRole.UserRole)
        task = self.project.task_by_id(tid)
        if not task:
            return
        txt = item.text().strip().replace("/", "-")
        parts = txt.split("-")
        if len(parts) == 3 and len(parts[0]) == 2:
            txt = "20" + txt
        try:
            d = date.fromisoformat(txt)
        except ValueError:
            self.refresh(select_id=tid)
            return
        if item.column() == 1:
            task.start = d.isoformat()
            if task.dstart > task.dend:
                task.end = task.start
        else:
            task.end = d.isoformat()
            if task.dend < task.dstart:
                task.start = task.end
        if task.milestone:
            task.end = task.start
        self.dates_edited.emit(task)


class PropertyPanel(QWidget):
    edited = Signal(object)         # Task（日付が変わった）
    changed = Signal()              # 日付以外の変更（再描画・集計更新）

    def __init__(self, parent=None):
        super().__init__(parent)
        self.data = None
        self.project = None
        self.task = None
        self._loading = False
        # 入力欄の高さ（Trial4で詰めた後、Trial8で少しだけ戻した）
        # 付属ボタン幅はこのパネル側にも明示する（ウィンドウ側の指定が
        # サブコントロールまで届かない環境があるため。Trial43）
        self.setStyleSheet(
            "QDateEdit, QComboBox, QSpinBox, QDoubleSpinBox, QLineEdit {"
            " min-height: 24px; max-height: 24px; padding: 0 3px; }"
            "QSpinBox::up-button, QSpinBox::down-button { width: 14px; }"
            "QDoubleSpinBox::up-button, QDoubleSpinBox::down-button"
            " { width: 14px; }"
            "QDateEdit::drop-down { width: 16px; }"
            "QComboBox::drop-down { width: 16px; }"
            "QComboBox QAbstractItemView { background: #fdfbf5;"
            " color: #241f18; selection-background-color: #fdeed3;"
            " selection-color: #241f18; }"
            "QSpinBox, QDoubleSpinBox { background: #ffffff;"
            " border: 1px solid #b3a888; border-radius: 3px; }")

        # 内容が縦に溢れても行が潰れないようスクロールに入れる
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        from PySide6.QtWidgets import QScrollArea
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        inner = QWidget()
        inner.setObjectName("propInner")
        # セレクタ無しの指定だと子孫のスタイルシート（カードの枠など）が
        # 効かなくなるため、必ず対象を限定する（Trial70）
        inner.setStyleSheet("QWidget#propInner { background: #ffffff; }")
        scroll.setWidget(inner)
        outer.addWidget(scroll)
        root = QVBoxLayout(inner)
        root.setContentsMargins(10, 8, 10, 8)
        root.setSpacing(5)
        self._inner = inner
        self._root_lay = root
        # 見出し: 色チップと項目名は別ラベルにする
        # （旧実装は同一ラベルに pixmap と text を両方設定し、名前が出なかった）
        head_box = QHBoxLayout()
        head_box.setContentsMargins(0, 0, 0, 0)
        head_box.setSpacing(6)
        self.header_chip = QLabel()
        head_box.addWidget(self.header_chip)
        self.header = QLabel("項目を選択してください")
        self.header.setStyleSheet("font-size: 15px; font-weight: bold; color: #241f18;")
        head_box.addWidget(self.header)
        head_box.addStretch(1)
        head_w = QWidget()
        head_w.setLayout(head_box)
        root.addWidget(head_w)
        self.track_label = QLabel("")
        root.addWidget(self.track_label)

        def section(text):
            # Trial9: セクションごとに枠どりのカードにする
            # Trial12: 最初の行（見出し）に薄い色の帯を付ける
            card = QWidget()
            card.setObjectName("propCard")
            card.setStyleSheet(
                "QWidget#propCard { background: #ffffff;"
                " border: 1px solid #cfc4a6; border-radius: 6px; }")
            lay = QVBoxLayout(card)
            lay.setContentsMargins(0, 0, 0, 0)
            lay.setSpacing(0)
            head = QWidget()
            head.setStyleSheet(
                "background: #f0e9d8; border-top-left-radius: 6px;"
                " border-top-right-radius: 6px;")
            head_lay = QHBoxLayout(head)
            head_lay.setContentsMargins(10, 5, 10, 5)
            lab = QLabel(text)
            lab.setStyleSheet(
                "font-size: 12px; font-weight: bold; color: #2e4a66;"
                " background: transparent;")
            head_lay.addWidget(lab)
            head_lay.addStretch(1)
            lay.addWidget(head)
            body = QWidget()
            # background を付けない（transparent 指定がプルダウンの
            # 背景色計算に漏れて黒くなるため。地はカードの白で足りる）
            body_lay = QVBoxLayout(body)
            body_lay.setContentsMargins(10, 8, 10, 8)
            body_lay.setSpacing(6)
            lay.addWidget(body)
            root.addWidget(card)
            body_lay.card = card
            return body_lay

        self._section = section

        # Trial8: 全セクション共通のグリッドで、項目名と値の開始位置を揃える
        # 列: [アイコン 18][項目名 98][値（伸縮）]
        from PySide6.QtWidgets import QGridLayout
        LABEL_W = 98

        def make_grid(parent_lay):
            g = QGridLayout()
            g.setContentsMargins(0, 0, 0, 0)
            g.setHorizontalSpacing(6)
            g.setVerticalSpacing(6)
            g.setColumnMinimumWidth(0, 18)
            g.setColumnMinimumWidth(1, LABEL_W)
            g.setColumnStretch(2, 1)
            parent_lay.addLayout(g)
            return g

        def icon_label(kind, color="#786e64"):
            lab = QLabel()
            lab.setPixmap(icon_pixmap(kind, color).scaled(
                18, 18, Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation))
            lab.setFixedSize(18, 18)
            lab.setAlignment(Qt.AlignmentFlag.AlignCenter)
            return lab

        def grow(grid, r, kind, text, widget, color="#786e64"):
            if kind:
                grid.addWidget(icon_label(kind, color), r, 0)
            lab = QLabel(text)
            grid.addWidget(lab, r, 1)
            grid.addWidget(widget, r, 2)
            return widget

        date_lay = section("日程")
        date_grid = make_grid(date_lay)
        # 開始／終了は1行にまとめる（Trial4）
        self.start_edit = QDateEdit()
        self.start_edit.setDisplayFormat("yy/MM/dd")
        self.start_edit.setCalendarPopup(True)
        style_calendar(self.start_edit)
        self.start_edit.setMinimumWidth(_date_width(self.start_edit))
        self.end_edit = QDateEdit()
        self.end_edit.setDisplayFormat("yy/MM/dd")
        self.end_edit.setCalendarPopup(True)
        style_calendar(self.end_edit)
        self.end_edit.setMinimumWidth(_date_width(self.end_edit))
        period_box = QHBoxLayout()
        period_box.setContentsMargins(0, 0, 0, 0)
        period_box.setSpacing(4)
        def lock_box(tooltip):
            w = QWidget()
            hb = QHBoxLayout(w)
            hb.setContentsMargins(0, 0, 0, 0)
            hb.setSpacing(3)
            cb = QCheckBox()
            cb.setToolTip(tooltip)
            ic = QLabel()
            ic.setPixmap(icon_pixmap("lock", "#786e64").scaled(
                16, 16, Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation))
            ic.setToolTip(tooltip)
            hb.addWidget(cb)
            hb.addWidget(ic)
            return w, cb

        period_box.addWidget(self.start_edit)
        _lw, self.lock_start_check = lock_box("開始日をロックする")
        self.lock_start_check.toggled.connect(
            lambda on: self._on_lock_toggled("start", on))
        period_box.addWidget(_lw)
        period_box.addWidget(QLabel("〜"))
        period_box.addWidget(self.end_edit)
        _lw, self.lock_end_check = lock_box("終了日をロックする")
        self.lock_end_check.toggled.connect(
            lambda on: self._on_lock_toggled("end", on))
        period_box.addWidget(_lw)
        period_box.addStretch(1)
        period_w = QWidget()
        period_w.setLayout(period_box)
        grow(date_grid, 0, "start", "開始／終了", period_w)
        self.span_label = QLabel("")
        self.span_label.setStyleSheet("font-weight: bold; color: #241f18;")
        grow(date_grid, 1, "span", "期間", self.span_label)
        self.cal_combo = QComboBox()
        for key, v in md.CALENDARS.items():
            self.cal_combo.addItem(v["label"], key)
        self.cal_combo.setMaximumWidth(190)
        grow(date_grid, 2, "calendar", "カレンダー", self.cal_combo)
        self.pred_label = QLabel("")
        grow(date_grid, 3, "link", "先行 / 後続", self.pred_label)


        jinko_lay = section("作業時間")
        self._jinko_card = jinko_lay.card
        self._shortages = {}
        self.roles_grid = make_grid(jinko_lay)
        self.role_add_btn = QPushButton("人員を追加")
        self.role_add_btn.clicked.connect(self._add_role)
        jinko_lay.addWidget(self.role_add_btn,
                            alignment=Qt.AlignmentFlag.AlignLeft)
        jinko_grid = make_grid(jinko_lay)
        self.jinko_label = QLabel("")
        self.jinko_label.setStyleSheet(
            "font-size: 13px; font-weight: bold; color: #c65c14;")
        grow(jinko_grid, 0, "clock", "作業時間 合計", self.jinko_label, "#c65c14")

        attr_lay = section("作業内容")
        self._attr_card = attr_lay.card
        self.attrs_grid = make_grid(attr_lay)
        self.attr_add_btn = QPushButton("作業内容を追加")
        self.attr_add_btn.clicked.connect(self._add_attr)
        attr_lay.addWidget(self.attr_add_btn,
                           alignment=Qt.AlignmentFlag.AlignLeft)
        tail_grid = make_grid(attr_lay)
        self.est_label = QLabel("")
        grow(tail_grid, 0, "clock", "作業内容の時間", self.est_label)
        self.memo_edit = QLineEdit()
        grow(tail_grid, 1, "memo", "メモ", self.memo_edit)

        # 項目の削除はガント左上の削除ボタンに集約（Trial74で廃止）
        root.addStretch(1)

        self.start_edit.dateChanged.connect(lambda qd: self._date_changed("start", qd))
        self.end_edit.dateChanged.connect(lambda qd: self._date_changed("end", qd))
        self.cal_combo.currentIndexChanged.connect(self._cal_changed)
        self.memo_edit.editingFinished.connect(self._memo_changed)
        self.setEnabled(False)

    # ---------- 表示 ----------
    def _on_lock_toggled(self, which, checked):
        if self._loading or not self.task:
            return
        if self.task.milestone:
            # 節目は開始＝終了なので連動させる
            self.task.lock_start = bool(checked)
            self.task.lock_end = bool(checked)
        elif which == "start":
            self.task.lock_start = bool(checked)
        else:
            self.task.lock_end = bool(checked)
        self._apply_lock_state()
        self.changed.emit()

    def _apply_lock_state(self):
        t = self.task
        ls = bool(t and t.lock_start)
        le = bool(t and t.lock_end)
        if t and t.milestone and (ls or le):
            ls = le = True
        self.start_edit.setEnabled(not ls)
        self.end_edit.setEnabled(not le)

    def show_task(self, data, project, task):
        self.data, self.project, self.task = data, project, task
        self._shortages = md.role_shortages(data, task) if task else {}
        self._jinko_card.setStyleSheet(
            "QWidget#propCard { background: #ffffff;"
            " border: 2px solid #d43a2f; border-radius: 6px; }"
            if self._shortages else
            "QWidget#propCard { background: #ffffff;"
            " border: 1px solid #cfc4a6; border-radius: 6px; }")
        self._loading = True
        self.setEnabled(task is not None)
        if not task:
            self._jinko_card.setVisible(True)
            self._attr_card.setVisible(True)
            self.header.setText("項目を選択してください")
            self.header_chip.clear()
            self.track_label.setText("")
            self.track_label.setStyleSheet("")
            self._loading = False
            return
        chip = QPixmap(16, 16)
        chip.fill(QColor(task.color))
        self.header_chip.setPixmap(chip)
        self.header.setText(task.name)
        tr = project.track_of(task)
        own = task.kind == "own"
        # 節目・他部門では意味のないカードを出さない（Trial75）
        self._jinko_card.setVisible(own and not task.milestone)
        self._attr_card.setVisible(not task.milestone)
        self.track_label.setText(
            f"系列：{tr.name if tr else ''}")
        self.track_label.setStyleSheet(
            "background: #2e4a66; color: #ffffff; font-weight: bold;"
            " padding: 3px 8px; border-radius: 3px;" if own else
            "background: #d9d3c3; color: #57503f; font-weight: bold;"
            " padding: 3px 8px; border-radius: 3px;")
        from PySide6.QtCore import QDate
        self.start_edit.setDate(QDate(task.dstart.year, task.dstart.month, task.dstart.day))
        self.end_edit.setDate(QDate(task.dend.year, task.dend.month, task.dend.day))
        self.lock_start_check.setChecked(bool(task.lock_start))
        self.lock_end_check.setChecked(bool(task.lock_end))
        self._apply_lock_state()
        idx = self.cal_combo.findData(task.calendar)
        self.cal_combo.setCurrentIndex(max(0, idx))
        pred = project.task_by_id(task.pred_id) if task.pred_id else None
        succ = [t.name for t in project.tasks if t.pred_id == task.id]
        self.pred_label.setText(
            f"{pred.name}（{pred.dend.month}/{pred.dend.day} 終了）" if pred else "なし"
        )
        if succ:
            self.pred_label.setText(self.pred_label.text() + " ／ 後続：" + "、".join(succ))
        self.memo_edit.setText(task.memo or "")
        self._rebuild_roles()
        self._rebuild_attrs()
        # 行を組み直した直後はレイアウトの寸法が古いまま残り、作業内容の
        # 行が潰れることがあるため、再配置を明示する（Trial79）
        self._relayout()
        self._refresh_derived()
        self._loading = False

    def _refresh_derived(self):
        if not self.task:
            return
        t = self.task
        self.span_label.setText("節目" if t.milestone
                                else f"{md.task_duration_bd(t)}日（営業日）")
        h = md.task_hours(self.data, t)
        parts = [f"<span style='color:{md.role_color(k)}'>{k} {md.fmt_hours(v)}h</span>"
                 for k, v in h.items() if k != "合計"]
        self.jinko_label.setText(
            f"{md.fmt_hours(h['合計'])} 時間"
            + (f"（{' ・ '.join(parts)}）" if parts else ""))
        est = md.estimate_hours(t)
        if est:
            txt = " ・ ".join(
                f"<span style='color:{md.role_color(k)}'>{k} {v:g}h</span>"
                for k, v in est.items())
            self.est_label.setText(
                f"{txt}（合計 {md.fmt_hours(sum(est.values()))}h）")
        else:
            self.est_label.setText("（作業内容の時間設定なし）")

    # ---------- 役割・属性の動的行 ----------
    def _relayout(self):
        self._jinko_card.updateGeometry()
        self._attr_card.updateGeometry()
        self._root_lay.invalidate()
        self._root_lay.activate()

    def showEvent(self, ev):
        super().showEvent(ev)
        # 非表示の間に組み直された行も、表示された時点で配置し直す
        if getattr(self, "_root_lay", None) is not None:
            self._relayout()

    def _clear(self, layout):
        while layout.count():
            item = layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
            elif item.layout():
                self._clear(item.layout())

    def _rebuild_roles(self):
        self._clear(self.roles_grid)
        if not self.task:
            return
        hours_map = md.task_hours(self.data, self.task)
        for i, r in enumerate(self.task.roles):
            box = QHBoxLayout()
            box.setContentsMargins(0, 0, 0, 0)
            box.setSpacing(4)
            spin = QSpinBox()
            spin.setRange(0, 99)
            spin.setValue(r.headcount or 0)
            spin.setSuffix(" 人")
            spin.setMaximumWidth(74)
            spin.valueChanged.connect(lambda v, idx=i: self._role_changed(idx, "headcount", v))
            box.addWidget(spin)
            jlab = QLabel(f"＝ {md.fmt_hours(hours_map.get(r.name, 0))}h")
            jlab.setObjectName(f"jinko_{i}")
            if r.name in self._shortages:
                jlab.setStyleSheet("color: #d43a2f; font-weight: bold;")
            box.addWidget(jlab)
            box.addStretch(1)
            w = QWidget()
            w.setLayout(box)
            rcol = md.role_color(r.name)
            icon = QLabel()
            icon.setPixmap(icon_pixmap("people", rcol).scaled(
                18, 18, Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation))
            icon.setFixedSize(18, 18)
            icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.roles_grid.addWidget(icon, i, 0, Qt.AlignmentFlag.AlignVCenter)
            combo = QComboBox()
            combo.setEditable(True)
            combo.addItems(self._role_candidates())
            combo.setCurrentText(r.name)
            combo.setFixedWidth(84)
            combo.setStyleSheet(
                f"color: {rcol}; font-weight: bold;"
                + (" border: 1.5px solid #d43a2f;"
                   if r.name in self._shortages else ""))
            combo.lineEdit().setStyleSheet(
                f"color: {rcol}; font-weight: bold;")
            combo.lineEdit().editingFinished.connect(
                lambda c=combo, idx=i: self._role_renamed(idx, c))
            combo.currentIndexChanged.connect(
                lambda _ix, c=combo, idx=i: self._role_renamed(idx, c))
            self.roles_grid.addWidget(combo, i, 1, Qt.AlignmentFlag.AlignVCenter)
            self.roles_grid.addWidget(w, i, 2, Qt.AlignmentFlag.AlignVCenter)

    def _rebuild_attrs(self):
        self._clear(self.attrs_grid)
        if not self.task or not self.data:
            self.attr_add_btn.setEnabled(False)
            return
        self.attr_add_btn.setEnabled(True)
        defs = self.task.attr_defs
        if not defs:
            return
        for i, a in enumerate(defs):
            box = QHBoxLayout()
            box.setContentsMargins(0, 0, 0, 0)
            box.setSpacing(5)
            spin = QSpinBox()
            spin.setRange(0, 99999)
            spin.setMaximumWidth(80)
            spin.setValue(int(self.task.attrs.get(a.name, 0) or 0))
            spin.setSuffix(f" {a.unit}")
            spin.valueChanged.connect(lambda v, name=a.name: self._attr_changed(name, v))
            box.addWidget(spin)
            # 単位時間はこの項目の分をその場で編集できる（Trial82）
            for role_name, hv in (a.hours or {}).items():
                rlab = QLabel(role_name)
                rlab.setStyleSheet(
                    f"color: {md.role_color(role_name)};"
                    " font-weight: bold;")
                box.addWidget(rlab)
                hspin = QDoubleSpinBox()
                hspin.setRange(0, 9999)
                hspin.setDecimals(1)
                hspin.setSingleStep(0.5)
                hspin.setSuffix("h")
                hspin.setValue(float(hv))
                hspin.setFixedWidth(64)
                hspin.valueChanged.connect(
                    lambda v, name=a.name, role=role_name:
                        self._attr_hours_changed(name, role, v))
                box.addWidget(hspin)
            box.addStretch(1)
            w2 = QWidget()
            w2.setLayout(box)
            combo = QComboBox()
            combo.setEditable(True)
            combo.addItems(self._attr_candidates())
            combo.setCurrentText(a.name)
            combo.setFixedWidth(96)
            combo.setStyleSheet("font-weight: bold;")
            combo.lineEdit().editingFinished.connect(
                lambda c=combo, idx=i: self._attr_renamed(idx, c))
            combo.currentIndexChanged.connect(
                lambda _ix, c=combo, idx=i: self._attr_renamed(idx, c))
            self.attrs_grid.addWidget(combo, i, 1, Qt.AlignmentFlag.AlignVCenter)
            self.attrs_grid.addWidget(w2, i, 2, Qt.AlignmentFlag.AlignVCenter)

    # ---------- 名前のプルダウン候補と改名（Trial15） ----------
    def _role_candidates(self):
        names = []
        if self.data:
            for m in self.data.masters:
                for r in m.roles:
                    if r.name not in names:
                        names.append(r.name)
            for p in self.data.projects:
                for t in p.tasks:
                    for r in t.roles:
                        if r.name not in names:
                            names.append(r.name)
        return names

    def _attr_candidates(self):
        names = []
        if self.data:
            for m in self.data.masters:
                for a in m.attrs:
                    if a.name not in names:
                        names.append(a.name)
            for p in self.data.projects:
                for t in p.tasks:
                    for a in t.attr_defs:
                        if a.name not in names:
                            names.append(a.name)
        return names

    def _role_renamed(self, idx, combo):
        """役割名の変更はこの項目の役割だけに効く（マスタは変えない）。"""
        if not self.task or idx >= len(self.task.roles):
            return
        role = self.task.roles[idx]
        new = combo.currentText().strip()
        if not new or new == role.name:
            combo.setCurrentText(role.name)
            return
        if any(r.name == new for r in self.task.roles):
            combo.setCurrentText(role.name)
            return
        role.name = new
        self._refresh_derived()
        self._rebuild_roles()
        self.changed.emit()

    def _attr_renamed(self, idx, combo):
        """作業内容の定義は項目ごとに持つので、この項目だけ付け替える。"""
        if not self.task or not self.data:
            return
        if idx >= len(self.task.attr_defs):
            return
        d = self.task.attr_defs[idx]
        new = combo.currentText().strip()
        if not new or new == d.name:
            combo.setCurrentText(d.name)
            return
        if any(x.name == new for x in self.task.attr_defs):
            combo.setCurrentText(d.name)
            return
        old = d.name
        d.name = new
        if old in self.task.attrs:
            self.task.attrs[new] = self.task.attrs.pop(old)
        self._refresh_derived()
        self._rebuild_attrs()
        self.changed.emit()

    def _attr_hours_changed(self, name, role, value):
        if self._loading or not self.task:
            return
        for a in self.task.attr_defs:
            if a.name == name:
                a.hours[role] = float(value)
                break
        self._refresh_derived()
        self.changed.emit()

    # ---------- 編集 ----------
    def _date_changed(self, which, qd):
        if self._loading or not self.task:
            return
        d = date(qd.year(), qd.month(), qd.day())
        t = self.task
        if which == "start":
            t.start = d.isoformat()
            if t.dstart > t.dend:
                t.end = t.start
        else:
            t.end = d.isoformat()
            if t.dend < t.dstart:
                t.start = t.end
        if t.milestone:
            t.end = t.start
        self._refresh_derived()
        self.edited.emit(t)

    def _cal_changed(self, _idx):
        if self._loading or not self.task:
            return
        # カレンダーを変えても日付そのものは動かさない
        self.task.calendar = self.cal_combo.currentData()
        self._refresh_derived()
        self.edited.emit(self.task)

    def _memo_changed(self):
        if self._loading or not self.task:
            return
        self.task.memo = self.memo_edit.text()
        self.changed.emit()

    def _add_role(self):
        if not self.task:
            return
        used = {r.name for r in self.task.roles}
        name = next((c for c in self._role_candidates() if c not in used),
                    "")
        if not name:
            name = "役割"
            n = 2
            while name in used:
                name = f"役割{n}"
                n += 1
        self.task.roles.append(md.RoleDef(name=name, headcount=1))
        self._refresh_derived()
        self._rebuild_roles()
        self.changed.emit()

    def _add_attr(self):
        if not self.task or not self.data:
            return
        used = {a.name for a in self.task.attr_defs}
        name = next((c for c in self._attr_candidates() if c not in used),
                    "")
        if not name:
            name = "作業内容"
            n = 2
            while name in used:
                name = f"作業内容{n}"
                n += 1
        self.task.attr_defs.append(md.AttrDef(name=name))
        self.task.attrs.setdefault(name, 0)
        self._refresh_derived()
        self._rebuild_attrs()
        self.changed.emit()

    def _role_changed(self, idx, field_name, value):
        if self._loading or not self.task:
            return
        r = self.task.roles[idx]
        setattr(r, field_name, value)
        self._refresh_derived()
        self._rebuild_roles()
        self.changed.emit()

    def _attr_changed(self, name, value):
        if self._loading or not self.task:
            return
        self.task.attrs[name] = value
        self._refresh_derived()
        self.changed.emit()
