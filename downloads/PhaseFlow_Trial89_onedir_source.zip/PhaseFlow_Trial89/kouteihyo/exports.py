# -*- coding: utf-8 -*-
"""Excel / PDF 出力（Qt非依存）。JSON が正本で、こちらは一方向の出力。"""
from __future__ import annotations

from datetime import date, timedelta

from . import model as md


def export_excel(data: md.AppData, project: md.Project, path: str) -> None:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter

    FONT = "Yu Gothic"
    DARK = PatternFill("solid", fgColor="38332B")
    BAND = PatternFill("solid", fgColor="F6F2E7")
    TOTAL = PatternFill("solid", fgColor="F0E9D8")
    thin = Side(style="thin", color="B3A888")
    BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)
    GRID = Border(left=Side(style="thin", color="DDD3BF"),
                  right=Side(style="thin", color="DDD3BF"),
                  top=Side(style="thin", color="DDD3BF"),
                  bottom=Side(style="thin", color="DDD3BF"))
    head_font = Font(name=FONT, size=11, bold=True, color="FFFFFF")
    body_font = Font(name=FONT, size=10.5)
    grey_font = Font(name=FONT, size=10.5, color="9A927E")
    bold_font = Font(name=FONT, size=10.5, bold=True)
    CENTER = Alignment(horizontal="center", vertical="center")
    LEFT = Alignment(horizontal="left", vertical="center")
    RIGHT = Alignment(horizontal="right", vertical="center")
    LEFT_WRAP = Alignment(horizontal="left", vertical="center", wrap_text=True)

    def style_header(ws, row, ncols):
        ws.row_dimensions[row].height = 21
        for c in range(1, ncols + 1):
            cell = ws.cell(row=row, column=c)
            cell.fill = DARK
            cell.font = head_font
            cell.alignment = CENTER
            cell.border = BORDER

    def print_setup(ws, freeze):
        ws.page_setup.orientation = "landscape"
        ws.page_setup.paperSize = ws.PAPERSIZE_A4
        ws.sheet_properties.pageSetUpPr.fitToPage = True
        ws.page_setup.fitToWidth = 1
        ws.page_setup.fitToHeight = 0
        ws.freeze_panes = freeze

    wb = Workbook()
    # ---- 日付表 ----
    ws = wb.active
    ws.title = "日付表"
    ws.append([project.name])
    ws["A1"].font = Font(name=FONT, size=14, bold=True)
    ws.row_dimensions[1].height = 24
    headers = ["工程", "開始", "終了", "期間（営業日）", "作業時間",
               "作業内容", "カレンダー"]
    ws.append(headers)
    style_header(ws, 2, len(headers))
    r = 3
    for ti, tr in enumerate(project.tracks):
        for t in project.tasks_in_track(tr.id):
            attrs = "、".join(f"{k} {v}" for k, v in t.attrs.items() if v)
            vals = [t.name,
                    t.start[2:].replace("-", "/"),
                    t.end[2:].replace("-", "/"),
                    "" if t.milestone else md.task_duration_bd(t),
                    "" if tr.kind == "ref" else
                    md.task_hours(data, t)["合計"],
                    attrs, md.CALENDARS[t.calendar]["label"]]
            ws.append(vals)
            for c, v in enumerate(vals, start=1):
                cell = ws.cell(row=r, column=c)
                cell.border = BORDER
                cell.font = grey_font if tr.kind == "ref" else body_font
                if ti % 2 == 1:
                    cell.fill = BAND
                cell.alignment = (LEFT if c == 1 else
                                  LEFT_WRAP if c == 6 else CENTER)
            r += 1
    for col, w in zip("ABCDEFG", (24, 11, 11, 13, 8, 34, 13)):
        ws.column_dimensions[col].width = w
    print_setup(ws, "A3")

    # ---- 月別作業時間（全工事） ----
    ws2 = wb.create_sheet("月別作業時間（全工事）")
    months = sorted({k for pr in data.projects for k in md.monthly_hours(data, pr)})
    ws2.append(["工事"] + [f"{y}/{m}" for y, m in months] + ["合計"])
    style_header(ws2, 1, len(months) + 2)
    for pi, pr in enumerate(data.projects):
        mj = md.monthly_hours(data, pr)
        ws2.append([pr.name] + [mj.get(k, 0) for k in months]
                   + [sum(mj.values())])
        for c in range(1, len(months) + 3):
            cell = ws2.cell(row=pi + 2, column=c)
            cell.border = BORDER
            cell.font = body_font
            if pi % 2 == 1:
                cell.fill = BAND
            cell.alignment = LEFT if c == 1 else RIGHT
    ws2.append(["全工事"] + [sum(md.monthly_hours(data, pr).get(k, 0)
                                  for pr in data.projects) for k in months]
               + [sum(md.project_hours_total(data, pr)
                        for pr in data.projects)])
    for c in range(1, len(months) + 3):
        cell = ws2.cell(row=len(data.projects) + 2, column=c)
        cell.border = BORDER
        cell.fill = TOTAL
        cell.font = bold_font
        cell.alignment = LEFT if c == 1 else RIGHT
    ws2.column_dimensions["A"].width = 26
    for i in range(len(months) + 1):
        ws2.column_dimensions[get_column_letter(2 + i)].width = 10
    print_setup(ws2, "B2")

    # ---- ガント（週単位のセル塗り） ----
    ws3 = wb.create_sheet("ガント")
    if project.tasks:
        s = min(t.dstart for t in project.tasks)
        s = s - timedelta(days=s.weekday())
        e = max(t.dend for t in project.tasks)
        weeks = []
        d = s
        while d <= e:
            weeks.append(d)
            d += timedelta(days=7)
        ws3.append([project.name])
        ws3["A1"].font = Font(name=FONT, size=14, bold=True)
        ws3.row_dimensions[1].height = 24
        # 月の行（同じ月の週を結合）と週の行の2段見出し
        ws3.append(["系列", "工程"] + [""] * len(weeks))
        ws3.append(["", ""] + [f"{w.month}/{w.day}" for w in weeks])
        i = 0
        while i < len(weeks):
            j = i
            while (j + 1 < len(weeks)
                   and (weeks[j + 1].year, weeks[j + 1].month)
                   == (weeks[i].year, weeks[i].month)):
                j += 1
            c1 = get_column_letter(3 + i)
            if j > i:
                ws3.merge_cells(f"{c1}2:{get_column_letter(3 + j)}2")
            ws3.cell(row=2, column=3 + i).value = f"{weeks[i].month}月"
            i = j + 1
        style_header(ws3, 2, len(weeks) + 2)
        style_header(ws3, 3, len(weeks) + 2)
        r = 4
        for ti, tr in enumerate(project.tracks):
            for t in project.tasks_in_track(tr.id):
                ws3.append([tr.name, t.name] + [""] * len(weeks))
                fill = PatternFill("solid", fgColor=t.color.replace("#", ""))
                for wi, w in enumerate(weeks):
                    cell = ws3.cell(row=r, column=3 + wi)
                    cell.border = GRID
                    cell.alignment = CENTER
                    wend = w + timedelta(days=6)
                    if not (t.dend < w or t.dstart > wend):
                        cell.fill = fill
                        if t.milestone:
                            cell.value = "◆"
                            cell.font = Font(name=FONT, size=10,
                                             color="FFFFFF")
                for c in (1, 2):
                    cell = ws3.cell(row=r, column=c)
                    cell.border = BORDER
                    cell.font = grey_font if tr.kind == "ref" else body_font
                    if ti % 2 == 1:
                        cell.fill = BAND
                    cell.alignment = LEFT
                r += 1
        ws3.column_dimensions["A"].width = 15
        ws3.column_dimensions["B"].width = 24
        for wi in range(len(weeks)):
            ws3.column_dimensions[get_column_letter(3 + wi)].width = 4.2
        print_setup(ws3, "C4")
    wb.save(path)


PDF_ITEMS = [("gantt", "詳細ガント"), ("dates", "日付表"),
             ("parallel", "並列表示"), ("jinko", "月別作業時間")]

_PDF_FONT = None


def _pdf_font():
    """PDF用フォント名。同梱の日本語TTFを埋め込み、無ければCIDに落とす。"""
    global _PDF_FONT
    if _PDF_FONT:
        return _PDF_FONT
    from pathlib import Path

    from reportlab.pdfbase import pdfmetrics
    ttf = Path(__file__).parent / "assets" / "ipagp.ttf"
    if ttf.exists():
        from reportlab.pdfbase.ttfonts import TTFont
        try:
            pdfmetrics.registerFont(TTFont("KouteihyoJP", str(ttf)))
            _PDF_FONT = "KouteihyoJP"
            return _PDF_FONT
        except Exception:
            pass
    from reportlab.pdfbase.cidfonts import UnicodeCIDFont
    pdfmetrics.registerFont(UnicodeCIDFont("HeiseiKakuGo-W5"))
    _PDF_FONT = "HeiseiKakuGo-W5"
    return _PDF_FONT


def _rgb(hexcolor):
    h = hexcolor.lstrip("#")
    return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))


def _fit(c, text, font_name, size, max_w):
    """幅に収まるよう末尾を…で切る。"""
    from reportlab.pdfbase.pdfmetrics import stringWidth
    if stringWidth(text, font_name, size) <= max_w:
        return text
    while text and stringWidth(text + "…", font_name, size) > max_w:
        text = text[:-1]
    return text + "…"


def export_pdf(data: md.AppData, project: md.Project, path: str) -> None:
    export_pdf_multi(data, project, path, ["gantt"])


def export_pdf_multi(data: md.AppData, project: md.Project, path: str,
                     items) -> int:
    """選ばれた項目を複数ページのPDFにする。戻り値はページ数。"""
    from reportlab.pdfgen import canvas
    F = _pdf_font()
    c = canvas.Canvas(path)
    pages = 0
    for key, _label in PDF_ITEMS:
        if key not in items:
            continue
        if key == "gantt":
            pages += _page_gantt(c, data, project, F)
        elif key == "dates":
            pages += _page_dates(c, data, project, F)
        elif key == "parallel":
            pages += _page_parallel(c, data, F)
        elif key == "jinko":
            pages += _page_jinko(c, data, F)
    c.save()
    return pages


def _page_gantt(c, data, project, F):
    from reportlab.lib.pagesizes import A3, landscape
    W, H = landscape(A3)
    c.setPageSize((W, H))
    c.setFont(F, 16)
    c.drawString(36, H - 40, f"工程表：{project.name}")
    if not project.tasks:
        c.showPage()
        return 1
    s = min(t.dstart for t in project.tasks)
    s = date(s.year, s.month, 1)
    e = max(t.dend for t in project.tasks)
    total = max(30, (e - s).days + 10)
    x0, x1 = 150.0, W - 36
    px = (x1 - x0) / total

    def X(d):
        return x0 + (d - s).days * px

    top = H - 70
    c.setFont(F, 9)
    y, m = s.year, s.month
    while (y, m) <= (e.year, e.month):
        ms = date(y, m, 1)
        me = date(y + (1 if m == 12 else 0), 1 if m == 12 else m + 1, 1)
        c.drawCentredString((X(max(ms, s)) + X(min(me, e))) / 2, top, f"{m}月")
        m += 1
        if m == 13:
            y, m = y + 1, 1
    ycur = top - 24
    for tr in project.tracks:
        if tr.kind == "own":
            c.setFillColorRGB(0.35, 0.31, 0.27)
        else:
            c.setFillColorRGB(0.54, 0.51, 0.47)
        c.rect(36, ycur - 14, W - 72, 16, stroke=0, fill=1)
        c.setFillColorRGB(1, 1, 1)
        c.setFont(F, 10)
        c.drawString(42, ycur - 10, tr.name)
        c.setFillColorRGB(0, 0, 0)
        ycur -= 18
        for t in project.tasks_in_track(tr.id):
            c.setFont(F, 9)
            c.drawRightString(x0 - 8, ycur - 4,
                              _fit(c, t.name, F, 9, x0 - 50))
            if t.milestone:
                cx = X(t.dstart) + px / 2
                c.setFillColorRGB(0.6, 0.57, 0.54)
                pth = c.beginPath()
                pth.moveTo(cx, ycur + 3)
                pth.lineTo(cx + 6, ycur - 4)
                pth.lineTo(cx, ycur - 11)
                pth.lineTo(cx - 6, ycur - 4)
                pth.close()
                c.drawPath(pth, stroke=0, fill=1)
                c.setFillColorRGB(0, 0, 0)
                c.drawCentredString(cx, ycur - 22,
                                    f"{t.dstart.month}/{t.dstart.day}")
            else:
                r, g, b = _rgb(t.color)
                if tr.kind == "ref":
                    r, g, b = 0.71, 0.68, 0.64
                c.setFillColorRGB(r, g, b)
                c.roundRect(X(t.dstart), ycur - 11,
                            max(3, X(t.dend + timedelta(days=1)) - X(t.dstart)),
                            13, 3, stroke=0, fill=1)
                if X(t.dstart) < x0 + 44:
                    c.setFillColorRGB(1, 1, 1)
                    c.drawString(X(t.dstart) + 3, ycur - 8,
                                 f"{t.dstart.month}/{t.dstart.day}")
                else:
                    c.setFillColorRGB(0.3, 0.3, 0.3)
                    c.drawRightString(X(t.dstart) - 3, ycur - 8,
                                      f"{t.dstart.month}/{t.dstart.day}")
                c.setFillColorRGB(0.3, 0.3, 0.3)
                c.drawString(X(t.dend + timedelta(days=1)) + 3, ycur - 8,
                             f"{t.dend.month}/{t.dend.day}")
                c.setFillColorRGB(0, 0, 0)
            ycur -= 22
    c.setFont(F, 9)
    total_j = md.project_hours_total(data, project)
    c.drawString(36, 30, f"総作業時間（自部門）：{md.fmt_hours(total_j)} 時間")
    c.showPage()
    return 1


def _table_header(c, F, title, cols, W, H):
    """表ページ共通：タイトルと濃色見出し。cols=[(見出し, x, 幅, 寄せ)]。
    戻り値は最初の行の y（上端）。"""
    c.setFillColorRGB(0, 0, 0)
    c.setFont(F, 14)
    c.drawString(36, H - 38, title)
    y = H - 66
    band_w = max(x + w for _l, x, w, _a in cols) - 36
    c.setFillColorRGB(0.22, 0.20, 0.17)
    c.rect(36, y - 4, band_w, 18, stroke=0, fill=1)
    c.setFillColorRGB(1, 1, 1)
    c.setFont(F, 9.5)
    for label, x, w, align in cols:
        if align == "l":
            c.drawString(x + 4, y, label)
        elif align == "r":
            c.drawRightString(x + w - 4, y, label)
        else:
            c.drawCentredString(x + w / 2, y, label)
    c.setFillColorRGB(0, 0, 0)
    return y - 18


def _page_dates(c, data, project, F):
    from reportlab.lib.pagesizes import A4, landscape
    W, H = landscape(A4)
    c.setPageSize((W, H))
    cols = [("工程", 36, 226, "l"),
            ("開始", 262, 58, "c"), ("終了", 320, 58, "c"),
            ("期間", 378, 56, "c"), ("作業時間", 434, 44, "c"),
            ("作業内容", 478, 252, "l"), ("カレンダー", 730, 76, "c")]
    pages = 0
    y = _table_header(c, F, f"日付表：{project.name}", cols, W, H)
    pages += 1
    ROW = 16
    for ti, tr in enumerate(project.tracks):
        for t in project.tasks_in_track(tr.id):
            if y < 54:
                c.showPage()
                c.setPageSize((W, H))
                y = _table_header(c, F, f"日付表：{project.name}（続き）",
                                  cols, W, H)
                pages += 1
            if ti % 2 == 1:
                c.setFillColorRGB(0.965, 0.95, 0.905)
                c.rect(36, y - 3, W - 72, ROW, stroke=0, fill=1)
            if tr.kind == "ref":
                c.setFillColorRGB(0.60, 0.57, 0.50)
            else:
                c.setFillColorRGB(0, 0, 0)
            c.setFont(F, 9)
            attrs = "、".join(f"{k} {v}" for k, v in t.attrs.items() if v)
            vals = [t.name, t.start[2:].replace("-", "/"),
                    t.end[2:].replace("-", "/"),
                    "" if t.milestone else str(md.task_duration_bd(t)),
                    "" if tr.kind == "ref" else
                    md.fmt_hours(md.task_hours(data, t)["合計"]),
                    attrs, md.CALENDARS[t.calendar]["label"]]
            for (label, x, w, align), v in zip(cols, vals):
                v = _fit(c, v, F, 9, w - 8)
                if align == "l":
                    c.drawString(x + 4, y, v)
                elif align == "r":
                    c.drawRightString(x + w - 4, y, v)
                else:
                    c.drawCentredString(x + w / 2, y, v)
            c.setStrokeColorRGB(0.85, 0.82, 0.75)
            c.line(36, y - 3, W - 36, y - 3)
            c.setFillColorRGB(0, 0, 0)
            y -= ROW
    c.setFont(F, 9)
    c.drawString(36, 30, f"総作業時間（自部門）：{md.fmt_hours(md.project_hours_total(data, project))} 時間")
    c.showPage()
    return pages


def _page_parallel(c, data, F):
    from reportlab.lib.pagesizes import A3, landscape
    W, H = landscape(A3)
    c.setPageSize((W, H))
    projects = [pr for pr in data.projects if pr.tasks]
    c.setFont(F, 14)
    c.drawString(36, H - 40, "並列表示（全工事）")
    if not projects:
        c.showPage()
        return 1
    s = min(t.dstart for pr in projects for t in pr.tasks)
    s = date(s.year, s.month, 1)
    e = max(t.dend for pr in projects for t in pr.tasks)
    e = date(e.year + (1 if e.month == 12 else 0),
             1 if e.month == 12 else e.month + 1, 1)
    total = max(30, (e - s).days)
    x0, x1 = 196.0, W - 36
    px = (x1 - x0) / total

    def X(d):
        return x0 + (d - s).days * px

    # 月ヘッダーと縦罫
    top = H - 64
    c.setFont(F, 9)
    y, m = s.year, s.month
    while (y, m) < (e.year, e.month):
        ms = date(y, m, 1)
        me = date(y + (1 if m == 12 else 0), 1 if m == 12 else m + 1, 1)
        c.drawCentredString((X(ms) + X(me)) / 2, top, f"{m}月")
        c.setStrokeColorRGB(0.88, 0.85, 0.79)
        c.line(X(ms), top - 6, X(ms), 190)
        m += 1
        if m == 13:
            y, m = y + 1, 1
    # レーン（色は画面と同じく工事の並び順パレット）
    PALETTE = ["#2f5da8", "#3e8a3e", "#26808f", "#7a4fa3", "#b26a00", "#c0532f"]
    ROW = 52
    ycur = top - 20
    for pi, pr in enumerate(projects):
        ps = min(t.dstart for t in pr.tasks)
        pe = max(t.dend for t in pr.tasks)
        col = _rgb(PALETTE[pi % len(PALETTE)])
        c.setStrokeColorRGB(0.70, 0.66, 0.55)
        c.setFillColorRGB(1, 1, 1)
        c.roundRect(36, ycur - 34, 142, 40, 4, stroke=1, fill=1)
        c.setFillColorRGB(*col)
        c.rect(36, ycur - 34, 5, 40, stroke=0, fill=1)
        c.setFillColorRGB(0, 0, 0)
        c.setFont(F, 10)
        c.drawString(48, ycur - 12, _fit(c, pr.name, F, 10, 124))
        c.setFont(F, 8.5)
        c.setFillColorRGB(0.30, 0.42, 0.62)
        c.drawString(48, ycur - 27,
                     f"総作業時間 {md.fmt_hours(md.project_hours_total(data, pr))}h")
        c.setFillColorRGB(0.93, 0.90, 0.83)
        c.roundRect(X(ps), ycur - 20, max(4, X(pe + timedelta(days=1)) - X(ps)),
                    13, 3, stroke=0, fill=1)
        c.setFillColorRGB(0, 0, 0)
        for t in pr.tasks:
            if not t.milestone:
                continue
            cx = X(t.dstart) + px / 2
            c.setFillColorRGB(*_rgb(t.color))
            pth = c.beginPath()
            pth.moveTo(cx, ycur - 1)
            pth.lineTo(cx + 6, ycur - 8)
            pth.lineTo(cx, ycur - 15)
            pth.lineTo(cx - 6, ycur - 8)
            pth.close()
            c.drawPath(pth, stroke=0, fill=1)
            c.setFillColorRGB(0.25, 0.25, 0.25)
            c.setFont(F, 8)
            c.drawCentredString(cx, ycur - 27,
                                _fit(c, f"{t.name} {t.dstart.month}/{t.dstart.day}",
                                     F, 8, 110))
            c.setFillColorRGB(0, 0, 0)
        ycur -= ROW
    # 下部：全工事の作業時間（月別・積み上げ）
    chart_top = 176
    c.setFont(F, 11)
    c.drawString(36, chart_top + 22, "全工事の作業時間（月別・営業日按分）")
    months = []
    y, m = s.year, s.month
    while (y, m) < (e.year, e.month):
        months.append((y, m))
        m += 1
        if m == 13:
            y, m = y + 1, 1
    per_month = []
    for k in months:
        per_month.append([md.monthly_hours(data, pr).get(k, 0) for pr in projects])
    vmax = max([sum(v) for v in per_month] + [1])
    base = 52
    chart_h = chart_top - base
    bw = (x1 - x0) / max(1, len(months))
    for i, k in enumerate(months):
        bx = x0 + i * bw
        acc = 0.0
        for pi, pr in enumerate(projects):
            v = per_month[i][pi]
            if not v:
                continue
            bh = chart_h * v / vmax
            c.setFillColorRGB(*_rgb(PALETTE[pi % len(PALETTE)]))
            c.rect(bx + 2, base + acc, bw - 4, bh, stroke=0, fill=1)
            acc += bh
        c.setFillColorRGB(0, 0, 0)
        c.setFont(F, 8)
        c.drawCentredString(bx + bw / 2, base - 12, f"{k[1]}月")
        if sum(per_month[i]):
            c.drawCentredString(bx + bw / 2, base + acc + 4,
                                str(sum(per_month[i])))
    c.setStrokeColorRGB(0.6, 0.57, 0.5)
    c.line(x0, base, x1, base)
    c.showPage()
    return 1


def _page_jinko(c, data, F):
    from reportlab.lib.pagesizes import A4, landscape
    W, H = landscape(A4)
    c.setPageSize((W, H))
    months = sorted({k for pr in data.projects for k in md.monthly_hours(data, pr)})
    name_w, total_w = 170, 60
    mw = min(58, (W - 72 - name_w - total_w) / max(1, len(months)))
    cols = [("工事", 36, name_w, "l")]
    x = 36 + name_w
    for (yy, mm) in months:
        cols.append((f"{yy}/{mm}", x, mw, "r"))
        x += mw
    cols.append(("合計", x, total_w, "r"))
    y = _table_header(c, F, "月別作業時間（全工事）", cols, W, H)
    ROW = 17
    for pr in data.projects:
        mj = md.monthly_hours(data, pr)
        vals = [pr.name] + [str(mj.get(k, 0)) for k in months] \
            + [str(sum(mj.values()))]
        c.setFont(F, 9.5)
        c.setFillColorRGB(0, 0, 0)
        for (label, cx, w, align), v in zip(cols, vals):
            if align == "l":
                c.drawString(cx + 4, y, _fit(c, v, F, 9.5, w - 8))
            else:
                c.drawRightString(cx + w - 4, y, v)
        c.setStrokeColorRGB(0.85, 0.82, 0.75)
        c.line(36, y - 4, 36 + name_w + mw * len(months) + total_w, y - 4)
        y -= ROW
    c.setFillColorRGB(0.94, 0.91, 0.85)
    c.rect(36, y - 4, name_w + mw * len(months) + total_w, ROW,
           stroke=0, fill=1)
    c.setFillColorRGB(0, 0, 0)
    vals = ["全工事"] + [str(sum(md.monthly_hours(data, pr).get(k, 0)
                                  for pr in data.projects)) for k in months] \
        + [md.fmt_hours(sum(md.project_hours_total(data, pr)
                             for pr in data.projects))]
    c.setFont(F, 9.5)
    for (label, cx, w, align), v in zip(cols, vals):
        if align == "l":
            c.drawString(cx + 4, y, v)
        else:
            c.drawRightString(cx + w - 4, y, v)
    c.showPage()
    return 1
