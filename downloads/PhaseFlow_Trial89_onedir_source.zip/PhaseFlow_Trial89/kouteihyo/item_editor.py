"""Shared browsing components for item presets and item masters."""
from __future__ import annotations

import copy
from PySide6.QtCore import Qt, QSize, Signal
from PySide6.QtGui import QColor, QIcon, QPainter, QPixmap
from PySide6.QtWidgets import (QAbstractItemView, QComboBox, QFrame, QHBoxLayout,
                              QLabel, QLineEdit, QDoubleSpinBox, QListWidget, QListWidgetItem,
                              QMessageBox, QPushButton, QSplitter, QTableWidget,
                              QTableWidgetItem, QHeaderView, QVBoxLayout, QWidget)
from . import model as md
from .ui import action_icon, install_ui

EDITOR_STYLE = """
QWidget#itemEditor { background: #f5f3ed; color: #332c24; }
QLabel[editorTitle="true"] { color: #243e57; font-size: 18px; font-weight: bold; }
QLabel[editorHint="true"] { color: #736d63; }
QFrame[editorCard="true"] { background: white; border: 1px solid #d9d2c3; border-radius: 8px; }
QLineEdit { background: white; border: 1px solid #c4bba6; border-radius: 5px; padding: 7px 9px; }
QLineEdit:focus { border-color: #5687b4; }
QListWidget { background: white; border: 1px solid #d9d2c3; border-radius: 6px; outline: none; }
QListWidget::item { padding: 9px 10px; border-bottom: 1px solid #f0ede7; }
QListWidget::item:selected { background: #e5edf5; color: #203d59; }
QListWidget::item:selected:!active { background: #e5edf5; color: #203d59; }
QTableWidget { background: white; alternate-background-color: #f8f7f3; gridline-color: #e8e3d9; border: 1px solid #ded8cc; }
QHeaderView::section { background: #eeeae0; color: #4f4b43; padding: 7px; border: none; border-right: 1px solid #ded8cc; font-weight: bold; }
QTabWidget::pane { border: none; background: #f5f3ed; }
QTabBar::tab { padding: 10px 18px; background: #e9e4d8; color: #736d63; border: none; }
QTabBar::tab:selected { background: #ffffff; color: #243e57; border-bottom: 3px solid #2e4a66; font-weight: bold; }
"""


def label(text, title=False, hint=False):
    result = QLabel(text)
    result.setTextFormat(Qt.TextFormat.PlainText)
    result.setWordWrap(True)
    result.setProperty('editorTitle', title)
    result.setProperty('editorHint', hint)
    return result


def card():
    widget = QFrame()
    widget.setProperty('editorCard', True)
    layout = QVBoxLayout(widget)
    layout.setContentsMargins(16, 14, 16, 14)
    layout.setSpacing(10)
    return widget, layout


def button(text, kind, slot, primary=False):
    result = QPushButton(text)
    result.setProperty('pfIcon', kind)
    result.setProperty('pfPrimary', primary)
    result.setIcon(action_icon(kind, '#ffffff' if primary else '#b03a2e' if kind == 'trash' else '#475569'))
    result.setIconSize(QSize(18, 18))
    result.setAutoDefault(False)
    result.clicked.connect(slot)
    return result


def table(headers):
    result = QTableWidget(0, len(headers))
    result.setHorizontalHeaderLabels(headers)
    result.setAlternatingRowColors(True)
    result.verticalHeader().hide()
    result.verticalHeader().setDefaultSectionSize(36)
    result.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    result.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
    result.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
    result.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
    return result


def swatch(color):
    pixmap = QPixmap(20, 20)
    pixmap.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    ink = QColor(color)
    painter.setBrush(ink if ink.isValid() else QColor('#64748b'))
    painter.setPen(Qt.PenStyle.NoPen)
    painter.drawRoundedRect(2, 2, 16, 16, 4, 4)
    painter.end()
    return QIcon(pixmap)


def kind_text(master):
    return '節目' if master.milestone else '自部門' if master.kind == 'own' else '他部門'


class MasterLibrary(QWidget):
    changed = Signal()

    def __init__(self, data, parent=None):
        super().__init__(parent)
        install_ui()
        self.data = data
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 12, 0, 0)
        root.setSpacing(12)
        root.addWidget(label('マスタは、新しく配置する項目の初期値です。配置済みの項目は変更されません。', hint=True))
        search_row = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText('項目名で検索…')
        self.search.setClearButtonEnabled(True)
        self.search.setAccessibleName('項目マスタを検索')
        search_row.addWidget(self.search, 1)
        self.filter = QComboBox()
        for text, value in [('すべての種別', ''), ('自部門', 'own'), ('他部門', 'ref'), ('節目', 'milestone')]:
            self.filter.addItem(text, value)
        self.filter.setAccessibleName('項目マスタの種別で絞り込む')
        search_row.addWidget(self.filter)
        root.addLayout(search_row)
        split = QSplitter()
        split.setChildrenCollapsible(False)
        self.list = QListWidget()
        self.list.setMinimumWidth(210)
        self.list.setAccessibleName('項目マスタ一覧')
        split.addWidget(self.list)
        detail, detail_layout = card()
        self.name = label('項目を選択してください', title=True)
        self.summary = label('', hint=True)
        self.roles = label('')
        detail_layout.addWidget(self.name)
        detail_layout.addWidget(self.summary)
        detail_layout.addWidget(label('人員の初期値'))
        detail_layout.addWidget(self.roles)
        detail_layout.addWidget(label('作業内容・単位時間'))
        self.attrs = table(['作業名', '単位', '1単位あたりの時間'])
        detail_layout.addWidget(self.attrs, 1)
        self.empty = label('', hint=True)
        detail_layout.addWidget(self.empty)
        split.addWidget(detail)
        split.setSizes([270, 550])
        root.addWidget(split, 1)
        row = QHBoxLayout()
        self.add_btn = button('新規登録', 'plus', self._new, primary=True)
        self.edit_btn = button('編集', 'pencil', self._edit)
        self.copy_btn = button('複製して編集', 'copy', self._duplicate)
        self.delete_btn = button('削除', 'trash', self._delete)
        for widget in (self.add_btn, self.edit_btn, self.copy_btn):
            row.addWidget(widget)
        row.addStretch(1)
        row.addWidget(self.delete_btn)
        root.addLayout(row)
        self.count = label('', hint=True)
        root.addWidget(self.count)
        self.search.textChanged.connect(self.refresh)
        self.filter.currentIndexChanged.connect(self.refresh)
        self.list.currentItemChanged.connect(self._preview)
        self.list.itemDoubleClicked.connect(lambda *_: self._edit())
        self.refresh()

    def current(self):
        item = self.list.currentItem()
        return self.data.master_by_id(item.data(Qt.ItemDataRole.UserRole)) if item else None

    def refresh(self, *_args, select_id=None):
        selected = select_id or (self.current().id if self.current() else '')
        query = self.search.text().strip().casefold()
        kind = self.filter.currentData()
        self.list.blockSignals(True)
        self.list.clear()
        for master in self.data.masters:
            if query and query not in master.name.casefold():
                continue
            if kind == 'milestone' and not master.milestone:
                continue
            if kind in ('own', 'ref') and (master.kind != kind or master.milestone):
                continue
            duration = '日付のみ' if master.milestone else f'{master.default_days}営業日'
            item = QListWidgetItem(swatch(master.color), f'{master.name}\n{kind_text(master)} · {duration}')
            item.setData(Qt.ItemDataRole.UserRole, master.id)
            item.setToolTip(master.name)
            self.list.addItem(item)
        row = next((i for i in range(self.list.count())
                    if self.list.item(i).data(Qt.ItemDataRole.UserRole) == selected), 0)
        self.list.setCurrentRow(row if self.list.count() else -1)
        self.list.blockSignals(False)
        self.count.setText(f'{self.list.count()} / {len(self.data.masters)} 件のマスタ')
        self._preview()

    def _preview(self, *_args):
        master = self.current()
        for widget in (self.edit_btn, self.copy_btn, self.delete_btn):
            widget.setEnabled(master is not None)
        self.attrs.setRowCount(0)
        if not master:
            self.name.setText('該当する項目がありません')
            self.summary.setText('検索条件を変えるか、新規登録してください。')
            self.roles.setText('—')
            self.empty.setText('')
            return
        self.name.setText(master.name)
        calendar = md.CALENDARS.get(master.calendar, {}).get('label', master.calendar)
        duration = '日付のみ' if master.milestone else f'標準 {master.default_days}営業日'
        self.summary.setText(f'{kind_text(master)}  /  {calendar}  /  {duration}')
        self.roles.setText('  ·  '.join(f'{r.name} {r.headcount}人' for r in master.roles) or '人員の設定はありません')
        for attr in master.attrs:
            row = self.attrs.rowCount()
            self.attrs.insertRow(row)
            values = [attr.name, attr.unit, ' / '.join(f'{r} {h:g}h' for r, h in (attr.hours or {}).items()) or '未設定']
            for col, value in enumerate(values):
                item = QTableWidgetItem(value)
                item.setToolTip(value)
                self.attrs.setItem(row, col, item)
        self.empty.setText('作業内容は登録されていません。' if not master.attrs else '単位時間は1単位あたりの時間です。')

    def _edit_dialog(self, master=None, duplicate=False):
        from .dialogs import MasterDialog
        dialog = MasterDialog(master, self, used_colors=[m.color for m in self.data.masters])
        if dialog.exec():
            result = dialog.result_master()
            if master is None or duplicate:
                self.data.masters.append(result)
            # A new item may fall outside the previous search/filter.
            self.search.blockSignals(True)
            self.filter.blockSignals(True)
            self.search.clear()
            self.filter.setCurrentIndex(0)
            self.search.blockSignals(False)
            self.filter.blockSignals(False)
            self.refresh(select_id=result.id)
            self.changed.emit()

    def _new(self):
        self._edit_dialog()

    def _edit(self):
        if self.current():
            self._edit_dialog(self.current())

    def _duplicate(self):
        if self.current():
            master = copy.deepcopy(self.current())
            master.id = md.Master().id
            master.name += ' のコピー'
            self._edit_dialog(master, duplicate=True)

    def _delete(self):
        master = self.current()
        if not master:
            return
        uses = [p.name for p in self.data.presets if any(e.master_id == master.id for e in p.entries)]
        text = f'項目マスタ「{master.name}」を削除しますか？\n配置済みの項目は残ります。'
        if uses:
            text += '\n\n使用中のプリセット: ' + '、'.join(uses) + '\n削除後、この項目を含むプリセットは適用できません。'
        if QMessageBox.question(self, '項目マスタを削除', text) != QMessageBox.StandardButton.Yes:
            return
        self.data.masters.remove(master)
        self.refresh()
        self.changed.emit()


class HoursSpinBox(QDoubleSpinBox):
    """Show 3 h instead of 3.0000 h without reducing input precision."""
    def textFromValue(self, value):
        text = super().textFromValue(value)
        decimal = self.locale().decimalPoint()
        return text.rstrip('0').rstrip(decimal) if decimal in text else text
