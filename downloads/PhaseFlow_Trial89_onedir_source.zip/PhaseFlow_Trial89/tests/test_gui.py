# -*- coding: utf-8 -*-
"""オフスクリーンでのGUIスモークテスト＋画面キャプチャ。"""
import os
import sys

sys.path.insert(0, __file__.rsplit("/tests/", 1)[0])
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication

from kouteihyo import exports, model as md
from kouteihyo.main_window import MainWindow
from kouteihyo.sample import build_sample_data


def main():
    app = QApplication(sys.argv)
    from kouteihyo.fontutil import font as _f
    app.setFont(_f(10))
    data = build_sample_data()
    win = MainWindow(data)
    win.show()
    app.processEvents()
    p = win.project()
    assert p is not None and len(p.tasks) == 11, len(p.tasks)
    # 日付表の行数
    assert win.table.table.rowCount() == 11, win.table.table.rowCount()
    # 図面作成を選択 → プロパティに目安が出る
    drawing = next(t for t in p.tasks if t.name == "図面作成")
    win._on_selection(drawing.id)
    app.processEvents()
    assert "54" in win.prop.est_label.text(), win.prop.est_label.text()
    assert "72 時間" in win.prop.jinko_label.text(), win.prop.jinko_label.text()
    # プロパティが縦スクロールなしで収まること（Trial4の圧縮の回帰防止）
    from PySide6.QtWidgets import QScrollArea
    pscroll = win.prop.findChild(QScrollArea)
    assert pscroll.verticalScrollBar().maximum() == 0, \
        pscroll.verticalScrollBar().maximum()
    # 項目と情報のインデントが全行で揃っていること（Trial8）
    inner = pscroll.widget()
    xs = {w.mapTo(inner, w.rect().topLeft()).x() for w in
          (win.prop.start_edit, win.prop.span_label, win.prop.cal_combo,
           win.prop.pred_label, win.prop.jinko_label, win.prop.est_label,
           win.prop.memo_edit)}
    assert len(xs) == 1, xs
    assert win.detail_btn.isChecked()
    # 右パネルの開閉（Trial5）: ▶で閉じ、◀で同じ幅に開き直す
    w_before = win.tabs.width()
    # 開閉ボタンは境界（パネルの左端）・縦中央にある（Trial6）
    app.processEvents()
    btn = win.right_toggle
    seam_x = win.tabs.mapTo(win._detail_page, win.tabs.rect().topLeft()).x()
    assert abs((btn.x() + btn.width() / 2) - seam_x) <= 2, (btn.x(), seam_x)
    sp_cy = win.splitter.y() + win.splitter.height() / 2
    assert abs((btn.y() + btn.height() / 2) - sp_cy) <= 2, (btn.y(), sp_cy)
    gw_open = win.gantt.width()
    win._toggle_right_panel()
    app.processEvents()
    assert not win.tabs.isVisible() and win.right_toggle.accessibleName() == "右パネルを開く"
    # 閉じたらガントが表示幅いっぱいに広がる（Trial6）
    assert win.gantt.width() == win.scroll.viewport().width(), \
        (win.gantt.width(), win.scroll.viewport().width())
    assert win.gantt.width() > gw_open
    win._toggle_right_panel()
    app.processEvents()
    assert win.tabs.isVisible() and win.right_toggle.accessibleName() == "右パネルを閉じる"
    assert abs(win.tabs.width() - w_before) <= 2, (win.tabs.width(), w_before)
    # 集計サマリ
    assert "528 時間" in win.summary.text(), win.summary.text()
    # ガント描画キャプチャ
    win.grab().save("/tmp/kouteihyo_detail.png")
    # 並列表示
    win._switch_view(1)
    app.processEvents()
    win.grab().save("/tmp/kouteihyo_parallel.png")
    win._switch_view(0)
    # 項目追加（モデル経由の経路を模擬）
    master = data.master_by_name("物量集計")
    track = p.tracks[0]
    t = md.task_from_master(master, track.id, drawing.dstart)
    p.tasks.append(t)
    win._refresh_all(select_id=t.id)
    assert win.table.table.rowCount() == 12
    p.tasks.remove(t)
    # 出力
    exports.export_excel(data, p, "/tmp/kouteihyo_test.xlsx")
    exports.export_pdf(data, p, "/tmp/kouteihyo_test.pdf")
    assert os.path.getsize("/tmp/kouteihyo_test.xlsx") > 0
    assert os.path.getsize("/tmp/kouteihyo_test.pdf") > 0
    # 重なり解消の下準備（shrink経路）
    approval = next(x for x in p.tasks if x.name == "承認")
    drawing.end = approval.start
    assert md.find_overlap(p, drawing) is approval
    assert md.can_shrink(p, drawing, approval)
    # 人数／作業内容の表示オプション: 既定はON（Trial60）。行高の増減を見る
    assert win.gantt._people_count(drawing) == 5  # 作成2＋チェック3
    assert win.gantt.show_jinko and win.gantt.show_attrs
    h1 = win.gantt.content_height()
    # 作業時間・属性は合体ボタン1つで切り替える（Trial45）
    win.strips_btn.click()
    app.processEvents()
    assert not data.settings.show_jinko and not win.gantt.show_jinko
    assert not data.settings.show_attrs and not win.gantt.show_attrs
    h0 = win.gantt.content_height()
    assert h0 < h1, (h0, h1)
    win.strips_btn.click()
    app.processEvents()
    assert win.gantt.content_height() == h1
    # 設定ダイアログ側にも同じ項目があり、往復で保持される
    from kouteihyo.dialogs import SettingsDialog
    sdlg = SettingsDialog(data.settings)
    assert sdlg.strips_check.isChecked()
    sdlg.strips_check.setChecked(False)
    sdlg.apply_to(data.settings)
    assert not data.settings.show_jinko and not data.settings.show_attrs
    data.settings.show_jinko = False
    data.settings.show_attrs = True
    # 役割名・属性名の手入力プルダウン（Trial15）
    from PySide6.QtWidgets import QComboBox
    win._on_selection(drawing.id)
    app.processEvents()
    rc = win.prop.roles_grid.itemAtPosition(0, 1).widget()
    assert isinstance(rc, QComboBox) and rc.isEditable()
    assert rc.currentText() == "作成"
    assert "チェック" in [rc.itemText(i) for i in range(rc.count())]
    rc.setCurrentText("作図")
    rc.lineEdit().editingFinished.emit()
    app.processEvents()
    assert drawing.roles[0].name == "作図"
    rc2 = win.prop.roles_grid.itemAtPosition(0, 1).widget()
    rc2.setCurrentText("チェック")  # 同じ項目内の重複は不可
    rc2.lineEdit().editingFinished.emit()
    app.processEvents()
    assert drawing.roles[0].name == "作図"
    rc3 = win.prop.roles_grid.itemAtPosition(0, 1).widget()
    rc3.setCurrentText("作成")
    rc3.lineEdit().editingFinished.emit()
    app.processEvents()
    assert drawing.roles[0].name == "作成"
    ac = win.prop.attrs_grid.itemAtPosition(0, 1).widget()
    assert isinstance(ac, QComboBox) and ac.isEditable()
    assert ac.currentText() == "配管図"
    ac.setCurrentText("配管図面")
    ac.lineEdit().editingFinished.emit()
    app.processEvents()
    master = data.master_by_id(drawing.master_id)
    # Trial82: 定義は項目ごとに持つ。改名はこの項目だけで、マスタは不変
    assert drawing.attr_defs[0].name == "配管図面"
    assert master.attrs[0].name == "配管図"
    assert drawing.attrs.get("配管図面") == 12 and "配管図" not in drawing.attrs
    ac2 = win.prop.attrs_grid.itemAtPosition(0, 1).widget()
    ac2.setCurrentText("配管図")
    ac2.lineEdit().editingFinished.emit()
    app.processEvents()
    assert drawing.attr_defs[0].name == "配管図" and drawing.attrs.get("配管図") == 12
    # 系列の呼び名と名称変更（Trial16）
    assert [t.name for t in p.tracks] == ["自部門", "他部門（他課）", "他部門・ベンダー"]
    assert win._set_track_name(p.tracks[1].id, "他部門（計測）")
    assert p.tracks[1].name == "他部門（計測）"
    assert not win._set_track_name(p.tracks[1].id, "  ")
    assert p.tracks[1].name == "他部門（計測）"
    assert win._set_track_name(p.tracks[1].id, "他部門（他課）")
    from PySide6.QtCore import QPoint, Qt
    from PySide6.QtTest import QTest
    from kouteihyo.gantt import HEADER_H, TRACK_H
    got = []
    win.gantt.track_rename_requested.disconnect(win._rename_track)
    win.gantt.track_rename_requested.connect(got.append)
    win._switch_view(0)
    win.show()
    app.processEvents()
    QTest.mouseDClick(win.gantt, Qt.MouseButton.LeftButton,
                      pos=QPoint(60, HEADER_H + TRACK_H // 2))
    app.processEvents()
    assert got == [p.tracks[0].id], got
    # 作成の流れ: ステップ判定は残るが、案内バーは廃止（Trial63）
    assert len(win.step_btns) == 0
    win._on_selection(drawing.id)
    app.processEvents()
    assert win._current_step() == 4
    win._on_selection("")
    app.processEvents()
    assert win._current_step() == 3
    empty = md.Project(name="空の工事")
    empty.tracks.append(md.Track(name="自部門", kind="own"))
    data.projects.append(empty)
    win.current_project_id = empty.id
    win.selected_task_id = ""
    win._refresh_all()
    app.processEvents()
    assert win._current_step() == 2
    assert "次の手順" in win.summary.text()
    win.current_project_id = p.id
    win.selected_task_id = ""
    win._refresh_all()
    win._goto_step(4)
    app.processEvents()
    expected_first = p.tasks_in_track(p.tracks[0].id)[0].id
    assert win.selected_task_id == expected_first
    assert win._current_step() == 4
    data.projects.remove(empty)
    # 日付設定の専用UI（Trial18）: 期間→終了の連動とキャンセル復元
    from kouteihyo.dialogs import CreationWizard, DateSettingsDialog
    dlg = DateSettingsDialog(p)
    row = dlg.panel._rows[drawing.id]
    old_start, old_end = drawing.start, drawing.end
    row["period"].setValue(10)
    app.processEvents()
    assert md.task_duration_bd(drawing) == 10
    row["start"].setDate(row["start"].date().addDays(7))
    app.processEvents()
    assert md.task_duration_bd(drawing) == 10  # 期間を保って両端が動く
    dlg.reject()
    assert (drawing.start, drawing.end) == (old_start, old_end)
    # 作成ウィザード（Trial18）: 4ページで工事ができる
    wiz = CreationWizard(data)
    wiz.name_edit.setText("ウィザード工事")
    wiz._next()
    assert wiz.stack.currentIndex() == 1
    assert wiz.preview.count() > 3  # プリセットの項目プレビュー
    wiz._next()
    assert wiz.stack.currentIndex() == 2
    assert wiz.temp_project is not None
    assert len(wiz.temp_project.tasks) == 11
    wiz._next()
    assert wiz.stack.currentIndex() == 3
    wiz._next()  # 完了
    proj = wiz.result_project()
    assert proj is not None and proj.name == "ウィザード工事"
    assert len(proj.tasks) == 11
    print("ALL GUI SMOKE TESTS PASSED")


def test_trial45_preset_dialog_and_toggle():
    """Trial45: プリセットUIはステップ2のダイアログへ。切替はガント左上に重なる。"""
    from kouteihyo.dialogs import ItemPresetDialog
    app = QApplication.instance()
    data = build_sample_data()
    win = MainWindow(data)
    win.resize(1400, 900)
    win.show()
    app.processEvents()
    # 詳細ツール行にプリセットのコンボは無い
    assert not hasattr(win, "preset_combo")
    dlg = ItemPresetDialog(data, win,
                           on_save=win._save_preset,
                           on_manage=win._manage_masters)
    assert dlg.list.count() == len(data.presets)
    assert "項目" in dlg.list.item(0).text()
    dlg.list.setCurrentRow(0)
    dlg._apply()
    assert dlg.apply_id == data.presets[0].id
    dlg.close()
    # Trial72: 切替はツールバー側へ移り、ガント左上には追加・削除が重なる
    from PySide6.QtCore import QPoint
    corner = win.gantt.mapTo(win, QPoint(0, 0))
    seg = win.corner_seg
    # Trial85: 見出しセルにちょうど重なり、ボタン群は中央寄せ
    assert abs(seg.x() - corner.x()) <= 2, (seg.x(), corner.x())
    assert abs(seg.y() - corner.y()) <= 2, (seg.y(), corner.y())
    assert seg.height() == 44 and seg.width() == 176
    _lm = win.add_item_btn.geometry().x()
    _rm = seg.width() - win.del_item_btn.geometry().right() - 1
    assert abs(_lm - _rm) <= 1, (_lm, _rm)
    assert win.add_item_btn.parent() is seg
    assert win.del_item_btn.parent() is seg
    assert hasattr(win, "strips_btn") and not hasattr(win, "jinko_btn")
    assert win.gantt.data is data  # 帯の時間が属性と一致する根拠（Trial48）
    win._switch_view(1)
    app.processEvents()
    assert not seg.isVisible()  # 並列表示では追加・削除は隠れる
    win._switch_view(0)
    win.close()
    print("trial45 preset dialog + toggle overlay ok")




if __name__ == "__main__":
    main()


def test_trial19_date_format():
    from PySide6.QtWidgets import QDateEdit
    from kouteihyo.dialogs import CreationWizard, DateSettingsPanel
    data = build_sample_data()
    wiz = CreationWizard(data)
    assert wiz.base_edit.displayFormat() == "yy/MM/dd", wiz.base_edit.displayFormat()
    panel = DateSettingsPanel(data.projects[0])
    edits = panel.findChildren(QDateEdit)
    assert edits and all(e.displayFormat() == "yy/MM/dd" for e in edits)
    win = MainWindow(data)
    win.table.dates_edited.disconnect()   # 重なりダイアログ（モーダル）を切り離す
    assert win.prop.start_edit.displayFormat() == "yy/MM/dd"
    assert win.prop.end_edit.displayFormat() == "yy/MM/dd"
    # 日付表はスラッシュ表示
    win.table.set_project(data.projects[0])
    from PySide6.QtWidgets import QDateEdit as _QDE19
    texts = [win.table.table.cellWidget(r, 1).findChild(_QDE19).text()
             for r in range(win.table.table.rowCount())]
    assert texts and all("/" in x and "-" not in x for x in texts), texts[:3]
    # ドロップダウンで編集できる（行のタスクは UserRole の ID で引く）
    from PySide6.QtCore import QDate, Qt as _Qt
    _tid = win.table.table.item(0, 0).data(_Qt.ItemDataRole.UserRole)
    task = data.projects[0].task_by_id(_tid)
    edit = win.table.table.cellWidget(0, 1).findChild(_QDE19)
    edit.setDate(QDate(2026, 5, 7))
    edit.editingFinished.emit()
    assert task.start == "2026-05-07", task.start
    # 年2桁の表示（Trial22）。行は開始日順に並ぶので ID で引き直す
    win.table.refresh()
    row = next(r for r in range(win.table.table.rowCount())
               if win.table.table.item(r, 0).data(_Qt.ItemDataRole.UserRole) == task.id)
    txt = win.table.table.cellWidget(row, 1).findChild(_QDE19).text()
    assert txt.startswith("26/"), txt
    edit = win.table.table.cellWidget(row, 1).findChild(_QDE19)
    edit.setDate(QDate(2026, 6, 3))
    edit.editingFinished.emit()
    assert task.start == "2026-06-03", task.start
    print("test_trial19_date_format ok")


def test_trial19_people_attrs_editable():
    from PySide6.QtWidgets import QComboBox
    from kouteihyo.dialogs import PeopleAttrsPanel
    data = build_sample_data()
    proj = data.projects[0]
    task = next(t for t in proj.tasks if t.name == "図面作成")
    master = data.master_by_id(task.master_id)
    panel = PeopleAttrsPanel(data, proj)
    combos = panel.findChildren(QComboBox)
    assert combos and all(c.isEditable() for c in combos)
    # 役割の名前変更（このタスクだけ）
    combo = QComboBox(); combo.setEditable(True); combo.setCurrentText("作図")
    panel._role_renamed(task, 0, combo)
    assert task.roles[0].name == "作図"
    assert master.roles[0].name == "作成"   # マスタは変わらない
    # 役割の追加と削除
    n0 = len(task.roles)
    panel._add_role(task)
    assert len(task.roles) == n0 + 1
    panel._del_role(task, len(task.roles) - 1)
    assert len(task.roles) == n0
    # 属性の名前変更（Trial82: 項目ごとの定義＋その項目の数量キーだけ移行）
    task.attrs["配管図"] = 12
    idx = next(i for i, a in enumerate(task.attr_defs) if a.name == "配管図")
    combo2 = QComboBox(); combo2.setEditable(True); combo2.setCurrentText("配管図面")
    panel._attr_renamed(task, idx, combo2)
    assert task.attr_defs[idx].name == "配管図面"
    assert master.attrs[0].name == "配管図"   # マスタは変わらない
    assert task.attrs["配管図面"] == 12 and "配管図" not in task.attrs
    # 属性の追加と削除
    m0 = len(task.attr_defs)
    panel._add_attr(task)
    assert len(task.attr_defs) == m0 + 1
    panel._del_attr(task, len(task.attr_defs) - 1)
    assert len(task.attr_defs) == m0
    print("test_trial19_people_attrs_editable ok")


def test_trial20_people_attrs_grouped():
    from PySide6.QtWidgets import QGroupBox
    from kouteihyo.dialogs import PeopleAttrsPanel
    data = build_sample_data()
    panel = PeopleAttrsPanel(data, data.projects[0])
    titles = [w.title() for w in panel.findChildren(QGroupBox)]
    assert "人員" in titles and "作業内容" in titles, titles[:8]
    # 項目ごとに人員グループ、属性はマスタのある項目に出る
    assert titles.count("人員") >= 5 and titles.count("作業内容") >= 1
    print("test_trial20_people_attrs_grouped ok")


def test_trial23_date_preview():
    from kouteihyo.dialogs import DateSettingsPanel, MiniGanttPreview
    data = build_sample_data()
    proj = data.projects[0]
    panel = DateSettingsPanel(proj)
    assert isinstance(panel.preview, MiniGanttPreview)
    assert panel.preview.height() > 100, panel.preview.height()
    panel.preview.resize(640, panel.preview.height())
    pm = panel.preview.grab()
    assert not pm.isNull()
    # 日付を変えるとプレビューも追随する（例外なく再描画できる）
    task = next(t for t in proj.tasks if t.name == "図面作成")
    before = task.end
    panel._on_period(task.id, 30)
    assert task.end != before
    pm = panel.preview.grab()
    assert not pm.isNull()
    print("test_trial23_date_preview ok")


def test_trial24_undo_redo():
    data = build_sample_data()
    win = MainWindow(data)
    proj = data.projects[0]
    task = next(t for t in proj.tasks if t.name == "図面作成")
    orig_end = task.end
    assert not win.undo_btn.isEnabled()
    task.end = "2026-07-01"
    win._after_edit(task.id)
    assert win.undo_btn.isEnabled()
    win._undo()
    t2 = win.project().task_by_id(task.id)
    assert t2.end == orig_end, t2.end
    assert win.redo_btn.isEnabled()
    win._redo()
    t3 = win.project().task_by_id(task.id)
    assert t3.end == "2026-07-01", t3.end
    print("test_trial24_undo_redo ok")


def test_trial26_parallel_modes():
    data = build_sample_data()
    win = MainWindow(data)
    win.show()
    win._switch_view(1)
    # 工程モードへ
    win.pmode_btns["process"].click()
    assert win.parallel.mode == "process"
    assert win.data.settings.parallel_mode == "process"
    win.parallel.grab()   # paint を走らせて当たり判定を作る
    texts = [t for _r, t in win.parallel._hits]
    # 狭くて名前が描けない工程も、ツールチップ側には名前がある
    assert any("現場調査準備" in t for t in texts), texts[:3]
    seg = next(r for r, t in win.parallel._hits if "図面作成" in t)
    tip = win.parallel.tooltip_at(seg.center())
    assert "図面作成" in tip and "〜" in tip and "営業日" in tip, tip
    # 人工モード: 月別バーのツールチップ
    win.pmode_btns["labor"].click()
    win.parallel.grab()
    texts = [t for _r, t in win.parallel._hits]
    assert any("作業時間" in t and "年" in t and "月" in t for t in texts)
    # マイルストーンに戻せる
    win.pmode_btns["milestone"].click()
    assert win.parallel.mode == "milestone"
    win.parallel.grab()
    assert any("検査" in t for _r, t in win.parallel._hits)
    print("test_trial26_parallel_modes ok")


def test_trial26_overlap_split():
    # 重なる工程は上下に分かれ、帯ごとにツールチップが返る
    from datetime import date as _date
    from kouteihyo.parallel import ParallelWidget
    data = build_sample_data()
    proj = data.projects[0]
    own_track = next(tr for tr in proj.tracks if tr.kind == "own")
    base = next(t for t in proj.tasks if t.name == "図面作成")
    over = md.Task(name="並行作業", track_id=own_track.id,
                   start="2026-05-20", end="2026-06-20",
                   color="#c0532f")
    proj.tasks.append(over)
    w = ParallelWidget()
    w.resize(1280, 900)
    w.set_data(data)
    w.set_mode("process")
    w.show()
    w.grab()
    # 重なり区間では同じ x 範囲で上下2つの帯ができる（上=先に始まった工程）
    hits = [(r, t) for r, t in w._hits
            if "B工事" in t and ("図面作成" in t or "並行作業" in t)]
    pair = None
    for r1, t1 in hits:
        for r2, t2 in hits:
            if (r1 is not r2 and abs(r1.x() - r2.x()) < 1
                    and abs(r1.width() - r2.width()) < 1 and r1.y() < r2.y()):
                pair = (r1, t1, r2, t2)
    assert pair, "split bands not found"
    r1, t1, r2, t2 = pair
    assert "図面作成" in t1 and "並行作業" in t2, (t1, t2)
    assert "図面作成" in w.tooltip_at(r1.center())
    assert "並行作業" in w.tooltip_at(r2.center())
    print("test_trial26_overlap_split ok")



def test_trial28_chart_toggle():
    data = build_sample_data()
    win = MainWindow(data)
    win.show()
    win._switch_view(1)
    assert win.parallel.chart_open
    win.parallel.grab()
    # 開いているときは合計グラフの積み上げにもツールチップがある
    assert any("年" in t and "月" in t for _r, t in win.parallel._hits)
    win.parallel.chart_btn.click()
    assert not win.parallel.chart_open
    assert win.data.settings.parallel_chart_open is False
    assert win.parallel.chart_btn.accessibleName() == "下のグラフを表示する"
    win.parallel.grab()
    # 閉じたら合計グラフの当たりは消える（節目モードのレーンには年月チップが無い）
    assert not any("年" in t and "月" in t for _r, t in win.parallel._hits)
    win.parallel.chart_btn.click()
    assert win.parallel.chart_open
    assert win.data.settings.parallel_chart_open is True
    assert win.parallel.chart_btn.accessibleName() == "下のグラフを隠す"
    print("test_trial28_chart_toggle ok")




def test_trial30_scroll_compact():
    # 行高は固定（広がらない）。案件が多いときはスクロールで全レーンに届く
    import copy
    from kouteihyo.parallel import ROW_H
    data = build_sample_data()
    i = 0
    while len(data.projects) < 12:
        src = data.projects[i % 4]
        clone = copy.deepcopy(src)
        clone.id = f"{src.id}-c{i}"
        clone.name = src.name + "（複製）"
        data.projects.append(clone)
        i += 1
    win = MainWindow(data)
    win.show()
    win._switch_view(1)
    assert win.parallel._row_h() == ROW_H["milestone"]
    assert win.parallel_scroll.widget() is win.parallel
    open_h = win.parallel.minimumHeight()
    win.parallel.chart_btn.click()
    closed_h = win.parallel.minimumHeight()
    assert open_h - closed_h == (190 + 16) - 26, (open_h, closed_h)
    assert win.parallel._row_h() == ROW_H["milestone"]  # 閉じても行は広がらない
    print("test_trial30_scroll_compact ok")


def test_trial30_blank_rows():
    # 画面に余りがあれば空欄行が出て、収まる画面では出ない
    from kouteihyo.parallel import ParallelWidget
    data = build_sample_data()
    w = ParallelWidget()
    w.set_data(data)
    w.resize(1280, 900)
    w.show()
    assert w._blank_count() > 0, w._blank_count()
    w.set_chart_open(False)
    open_blank = w._blank_count()
    w.set_chart_open(True)
    assert w._blank_count() < open_blank  # グラフを開くと空欄は減る
    w.resize(1280, 480)
    assert w._blank_count() == 0
    print("test_trial30_blank_rows ok")

# ※ テスト関数はこのブロックより前に追加すること（後ろだと実行されない）

def test_trial32_pdf_dialog():
    from kouteihyo.dialogs import PdfExportDialog
    dlg = PdfExportDialog("B工事 配管更新", [], None)
    assert dlg.items() == ["gantt", "dates", "parallel", "jinko"]  # 既定は全て
    assert dlg.ok_btn.isEnabled()
    for cb in dlg.checks.values():
        cb.setChecked(False)
    assert not dlg.ok_btn.isEnabled()      # 0件では出力できない
    dlg.checks["jinko"].setChecked(True)
    assert dlg.ok_btn.isEnabled()
    assert dlg.items() == ["jinko"]
    dlg2 = PdfExportDialog("B工事 配管更新", ["dates"], None)
    assert dlg2.items() == ["dates"]       # 前回の選択を復元
    print("test_trial32_pdf_dialog ok")


def test_trial34_view_set():
    data = build_sample_data()
    win = MainWindow(data)
    # 既定の表示セットは全工事
    assert len(win.parallel.projects) == 4
    # 詳細で別プラントの工事を開いても並列の表示セットは変わらない
    win._open_project_from_parallel(data.projects[-1].id)
    assert len(win.parallel.projects) == 4
    # 単体で開く
    b_id = data.projects[0].id
    win.apply_view_choice("single", b_id)
    assert win.view_ids == [b_id]
    assert len(win.parallel.projects) == 1
    # プラント（進行中・今後）：D工事を未来にずらすと入り、過去の工事は外れる
    d = data.projects[-1]
    for t in d.tasks:
        t.start = str(int(t.start[:4]) + 30) + t.start[4:]
        t.end = str(int(t.end[:4]) + 30) + t.end[4:]
    win.apply_view_choice("plant", "プラントB")
    assert win.view_ids == [d.id]
    win.apply_view_choice("plant", "プラントA")
    assert win.view_ids == []  # サンプルは全て終了済み（実日付基準）
    # 表示プリセット
    vp = md.ViewPreset(name="確認用", project_ids=[b_id, d.id])
    data.view_presets.append(vp)
    win.apply_view_choice("preset", vp.id)
    assert win.view_ids == [b_id, d.id]
    assert win._active_preset_id == vp.id
    # 表示から外す
    win._remove_from_view(b_id)
    assert win.view_ids == [d.id]
    # 起動時案内：前回（view_ids あり）が選べて、単体も選べる
    from kouteihyo.dialogs import ProjectPickerDialog, StartupGuideDialog
    dlg = StartupGuideDialog(data, win.plant_names, None)
    assert dlg.rb_last.isEnabled()
    assert dlg.choice() == ("last", None)
    dlg.radios["single"].setChecked(True)
    mode, val = dlg.choice()
    assert mode == "single" and val == data.projects[0].id
    # 追加ダイアログ：表示中は候補から外れる
    pick = ProjectPickerDialog(data, {d.id}, None)
    names = [pick.list.item(i).text() for i in range(pick.list.count())]
    assert len(names) == 3 and all("D工事" not in n for n in names)
    print("test_trial34_view_set ok")


def test_trial34_switch_keeps_set():
    data = build_sample_data()
    win = MainWindow(data)
    win.apply_view_choice("single", data.projects[0].id)
    win._switch_view(1)
    assert len(win.parallel.projects) == 1
    print("test_trial34_switch_keeps_set ok")


def test_trial35_no_combos():
    from kouteihyo.dialogs import CreationWizard
    data = build_sample_data()
    win = MainWindow(data)
    # 左上のプラント／工事プルダウンは無い
    assert not hasattr(win, "plant_combo")
    assert not hasattr(win, "project_combo")
    # タイトルに開いている工事とプラントが出る
    assert "B工事 配管更新" in win.windowTitle()
    assert "プラントA" in win.windowTitle()
    win._open_project_from_parallel(data.projects[-1].id)
    assert "D工事 計装工事" in win.windowTitle()
    assert "プラントB" in win.windowTitle()
    # プラント操作は工事一覧ダイアログへ移った
    assert not hasattr(win, "_plant_menu")
    # ウィザードで所属プラントを選べる（新規名も入力可）
    wiz = CreationWizard(data, None, plants=["プラントA", "プラントB"],
                         default_plant="プラントB")
    assert wiz.chosen_plant() == "プラントB"
    wiz.plant_combo.setCurrentText("プラントC")
    assert wiz.chosen_plant() == "プラントC"
    print("test_trial35_no_combos ok")


def test_trial35_lane_select():
    from PySide6.QtCore import QPoint, Qt
    from PySide6.QtTest import QTest
    app = QApplication.instance()
    data = build_sample_data()
    win = MainWindow(data)
    win.resize(1280, 900)
    win.show()
    app.processEvents()
    win._switch_view(1)
    app.processEvents()
    p0, p1, p2 = (data.projects[i].id for i in range(3))
    # クリック＝選択だけ（詳細へは行かない）
    QTest.mouseClick(win.parallel, Qt.MouseButton.LeftButton,
                     pos=QPoint(100, 46 + 78 + 39))
    assert win.parallel.selected_id == p1
    assert win.stack.currentIndex() == 1
    assert win.current_project_id == p0
    # 詳細ボタンで選択中の工事の詳細へ
    win._goto_detail()
    assert win.current_project_id == p1
    assert win.stack.currentIndex() == 0
    # 並列に戻ると現在の工事が選択されている
    win._switch_view(1)
    app.processEvents()
    assert win.parallel.selected_id == p1
    # ダブルクリック＝そのまま詳細へ
    QTest.mouseDClick(win.parallel, Qt.MouseButton.LeftButton,
                      pos=QPoint(100, 46 + 156 + 39))
    assert win.current_project_id == p2
    assert win.stack.currentIndex() == 0
    print("test_trial35_lane_select ok")


def test_trial36_bars_and_list():
    from kouteihyo.dialogs import ProjectListDialog
    from PySide6.QtPrintSupport import QPrinter
    data = build_sample_data()
    win = MainWindow(data)
    # 2行目：詳細／並列で道具が入れ替わる
    assert not hasattr(win, "detail_tools")  # Trial45で詳細側ツールは廃止
    win._switch_view(1)
    assert win.parallel_tools.isVisibleTo(win)
    win._switch_view(0)
    # 工事一覧：ツリーに2プラント・4工事、コールバックが効く
    calls = []
    cb = {"open_single": lambda pid: calls.append(("single", pid)),
          "add_projects": lambda ids: calls.append(("add", tuple(ids))),
          "open_plant": lambda n: calls.append(("open_plant", n)),
          "add_plant": lambda n: calls.append(("add_plant", n))}
    dlg = ProjectListDialog(data, ["プラントA", "プラントB"], cb, None)
    tops = [dlg.tree.topLevelItem(i) for i in range(dlg.tree.topLevelItemCount())]
    assert len(tops) == 2
    assert sum(t.childCount() for t in tops) == 4
    proj_item = tops[0].child(0)
    dlg.tree.setCurrentItem(proj_item)
    dlg._add_selected()
    assert calls[-1] == ("add", (data.projects[0].id,))
    dlg._open_single()
    assert calls[-1] == ("single", data.projects[0].id)
    dlg.tree.setCurrentItem(tops[1])
    dlg._open_plant()
    assert calls[-1] == ("open_plant", "プラントB")
    # プラントを開く＝そのプラントの全工事（終了済みも含む）
    win._list_open_plant("プラントA")
    assert len(win.view_ids) == 3
    assert win.stack.currentIndex() == 1
    # 表示プリセットのメニュー
    data.view_presets.append(md.ViewPreset(name="確認用",
                                           project_ids=[data.projects[0].id]))
    win._build_vp_menu()
    texts = [a.text() for a in win._vp_menu.actions()]
    assert "確認用" in texts
    # 印刷：今の画面をPDFプリンタへ描ける
    import os
    import tempfile
    printer = QPrinter(QPrinter.PrinterMode.HighResolution)
    out = os.path.join(tempfile.mkdtemp(), "print.pdf")
    printer.setOutputFormat(QPrinter.OutputFormat.PdfFormat)
    printer.setOutputFileName(out)
    win._do_print(printer)
    assert os.path.getsize(out) > 1000
    print("test_trial36_bars_and_list ok")


def test_trial37_date_table_columns():
    data = build_sample_data()
    win = MainWindow(data)
    win.table.set_project(data.projects[0])
    headers = [win.table.table.horizontalHeaderItem(c).text()
               for c in range(win.table.table.columnCount())]
    assert headers == ["工程", "開始", "終了", "期間", "作業時間"]
    print("test_trial37_date_table_columns ok")


def test_trial39_weekend_dates():
    from PySide6.QtCore import QDate, Qt
    data = build_sample_data()
    win = MainWindow(data)
    proj = data.projects[0]
    task = next(t for t in proj.tasks if t.name == "図面作成")
    # 日付表：土曜（26/05/02）を開始にそのまま設定できる
    win.table.dates_edited.disconnect()
    win.table.set_project(proj)
    row = next(r for r in range(win.table.table.rowCount())
               if win.table.table.item(r, 0).data(Qt.ItemDataRole.UserRole)
               == task.id)
    from PySide6.QtWidgets import QDateEdit as _QDE39
    _edit = win.table.table.cellWidget(row, 1).findChild(_QDE39)
    _edit.setDate(QDate(2026, 5, 2))
    _edit.editingFinished.emit()
    assert task.start == "2026-05-02", task.start   # 土曜に寄せ直されない
    # プロパティ：祝日（26/05/04）もそのまま
    task.start, task.end = "2026-05-11", "2026-06-05"
    win._on_selection(task.id)
    win.prop.start_edit.setDate(QDate(2026, 5, 4))
    assert task.start == "2026-05-04", task.start   # 祝日に寄せ直されない
    print("test_trial39_weekend_dates ok")


def test_trial40_icon_spin_combo():
    from kouteihyo.icons import icon_pixmap
    pm = icon_pixmap("people", "#2e4a66")
    assert not pm.isNull()
    data = build_sample_data()
    win = MainWindow(data)
    ss = win.styleSheet()
    assert "QSpinBox::up-button" in ss and "selection-background-color: #fdeed3" in ss
    proj = data.projects[0]
    task = next(t for t in proj.tasks if t.name == "図面作成")
    win._on_selection(task.id)
    assert win.prop.start_edit.minimumWidth() >= 100
    assert win.prop.end_edit.minimumWidth() >= 100
    print("test_trial40_icon_spin_combo ok")


def test_trial41_close_dialog_japanese():
    from PySide6.QtCore import QTimer
    from PySide6.QtWidgets import QMessageBox
    data = build_sample_data()
    win = MainWindow(data)
    win.show()
    win.dirty = True
    seen = {}

    def interact():
        for w in QApplication.topLevelWidgets():
            if isinstance(w, QMessageBox) and w.isVisible():
                texts = [b.text() for b in w.buttons()]
                seen["texts"] = texts
                for b in w.buttons():
                    if b.text() == "キャンセル":
                        b.click()
                        return
    QTimer.singleShot(300, interact)
    win.close()   # キャンセルされるので閉じない
    assert sorted(seen.get("texts", [])) == sorted(
        ["保存して続ける", "保存せず続ける", "キャンセル"]), seen
    assert win.isVisible()

    def interact2():
        for w in QApplication.topLevelWidgets():
            if isinstance(w, QMessageBox) and w.isVisible():
                for b in w.buttons():
                    if b.text() == "保存せず続ける":
                        b.click()
                        return
    QTimer.singleShot(300, interact2)
    win.close()
    assert not win.isVisible()
    print("test_trial41_close_dialog_japanese ok")


def test_trial55_project_list_current_view():
    # 工事一覧に「現在の表示」が出て、追加すると即反映される（Trial55）
    from PySide6.QtCore import Qt
    from kouteihyo.dialogs import ProjectListDialog
    app = QApplication.instance()
    data = build_sample_data()
    view = [data.projects[0].id]
    added = []
    cb = {"lock_projects": lambda ids: None,
          "open_single": lambda pid: None,
          "add_projects": lambda ids: added.extend(ids),
          "open_plant": lambda name: None,
          "add_plant": lambda name: None}
    # add_projects が実際に表示セットへ反映する疑似本体
    def apply_add(ids):
        added.extend(ids)
        for i in ids:
            if i not in view:
                view.append(i)
    cb["add_projects"] = apply_add
    cb["remove_projects"] = lambda ids: [view.remove(i) for i in ids
                                          if i in view]
    dlg = ProjectListDialog(data, ["プラントA", "プラントB"], cb, None,
                            view_provider=lambda: list(view))
    dlg.show()
    app.processEvents()
    assert dlg.view_label.text() == "現在の表示（1件）", dlg.view_label.text()
    assert dlg.view_list.count() == 1
    # 表示外の工事を選んで追加 → 一覧とマークとボタンが即変わる
    target = None
    for i in range(dlg.tree.topLevelItemCount()):
        top = dlg.tree.topLevelItem(i)
        for j in range(top.childCount()):
            item = top.child(j)
            kind, val = item.data(0, Qt.ItemDataRole.UserRole)
            if kind == "project" and val not in view:
                target = (item, val)
    assert target is not None
    item, pid = target
    dlg.tree.setCurrentItem(item)
    app.processEvents()
    assert dlg.btn_arrow.isEnabled()
    dlg._add_selected()
    app.processEvents()
    assert dlg.view_label.text() == "現在の表示（2件）", dlg.view_label.text()
    assert dlg.view_list.count() == 2
    assert dlg.view_list.currentRow() == 1     # 追加した行が選ばれる
    assert "（表示中）" in item.text(0), item.text(0)
    assert not dlg.btn_arrow.isEnabled()        # 表示中は追加できない
    # Trial87: 狭い画面でも右側の列へ移動できる。
    assert dlg.tree.horizontalScrollBarPolicy() == \
        Qt.ScrollBarPolicy.ScrollBarAsNeeded
    # ▶で外す: 左リストで追加した行が選ばれているので、そのまま外せる
    assert dlg.btn_arrow_r.isEnabled()
    dlg._remove_arrow()
    app.processEvents()
    assert dlg.view_label.text() == "現在の表示（1件）", dlg.view_label.text()
    assert dlg.view_list.count() == 1
    assert "（表示中）" not in item.text(0), item.text(0)
    dlg.tree.setCurrentItem(item)
    app.processEvents()
    assert dlg.btn_arrow.isEnabled()            # 外したので追加し直せる
    dlg.close()
    print("test_trial55_project_list_current_view ok")


def test_trial60_defaults_scroll_clip():
    """Trial60: 人・時間表示は既定ON、横スクロールでパン、窓は大きめ。"""
    from PySide6.QtGui import QFontMetrics
    from kouteihyo import model as md
    from kouteihyo.fontutil import font
    from kouteihyo.parallel import NAME_W as PAR_NAME_W
    app = QApplication.instance()
    st = md.Settings()
    assert st.show_jinko and st.show_attrs          # 既定でON
    win = MainWindow(build_sample_data())
    # Trial87: 画面の実寸を考慮し、小さい画面に固定1420pxを強制しない。
    available = win.screen().availableGeometry()
    assert win.width() == min(1720, max(1000, available.width() - 40))
    assert win.height() == min(1040, max(640, available.height() - 64))
    # ガント: 拡大すると横スクロールが効き、バーでパンできる
    span = win.gantt.span()
    assert span is not None
    win.gantt.zoom_by(4, 800)
    app.processEvents()
    assert win.gantt_hbar.isEnabled() and win.gantt_hbar.maximum() > 0
    win.gantt_hbar.setValue(5)
    app.processEvents()
    assert (win.gantt.view_start - span[0]).days == 5
    # 並列: 同じくパンできる
    pspan = win.parallel.span()
    assert pspan is not None
    win.parallel.zoom_by(4, 800)
    app.processEvents()
    assert win.parallel_hbar.isEnabled() and win.parallel_hbar.maximum() > 0
    win.parallel_hbar.setValue(3)
    app.processEvents()
    assert (win.parallel.view_start - pspan[0]).days == 3
    # カード下段: 時間の文字列がカード枠（右端-8）を超えない
    fm = QFontMetrics(font(10, True))
    sub_w = PAR_NAME_W - 46   # カード内側の文字幅（Trial62の3行表記）
    for proj in win.data.projects:
        hours_txt = f"総作業時間 {md.fmt_hours(md.project_hours_total(win.data, proj))}h"
        assert fm.horizontalAdvance(hours_txt) <= sub_w, hours_txt
    win.close()
    print("test_trial60_defaults_scroll_clip ok")


def test_trial61_calendar_style():
    """Trial61: カレンダーの年月が見えるよう、専用スタイルが付いている。"""
    app = QApplication.instance()
    win = MainWindow(build_sample_data())
    for edit in (win.prop.start_edit, win.prop.end_edit):
        cal = edit.calendarWidget()
        sheet = cal.styleSheet()
        assert "qt_calendar_navigationbar" in sheet, sheet
        # 前月／次月ボタンは白い三角アイコン（Trial63）
        from PySide6.QtWidgets import QToolButton
        for name in ("qt_calendar_prevmonth", "qt_calendar_nextmonth"):
            btn = cal.findChild(QToolButton, name)
            assert btn is not None and not btn.icon().isNull(), name
    win.close()
    print("test_trial61_calendar_style ok")


def test_trial64_table_columns():
    """Trial64: 日付表の作業時間列は固定幅、右パネルは少し広く。"""
    app = QApplication.instance()
    win = MainWindow(build_sample_data())
    t = win.table.table
    assert t.columnWidth(4) == 62, t.columnWidth(4)   # 作業時間
    # 開始・終了列は「日付欄（形式の実寸＋34）＋チェック＋余白」の幅（Trial85）
    from PySide6.QtGui import QFontMetrics
    from kouteihyo.fontutil import font as _kf
    _ew = QFontMetrics(_kf(10)).horizontalAdvance("00/00/00") + 34
    assert t.columnWidth(1) == _ew + 28 and t.columnWidth(2) == _ew + 28
    assert t.columnWidth(3) == 62                     # 期間
    assert not t.horizontalHeader().stretchLastSection()
    win.close()
    print("test_trial64_table_columns ok")


def test_trial68_wide_names_and_add_buttons():
    """Trial68: 工事一覧は名前列が広く期間に年入り。表とプロパティから追加できる。"""
    app = QApplication.instance()
    win = MainWindow(build_sample_data())
    win.show()
    app.processEvents()
    # Trial74: 日付表の追加ボタンは廃止（ガント左上に集約）
    assert not hasattr(win.table, "add_btn")
    # プロパティから人員を追加
    p = win.project()
    task = next(t for t in p.tasks if t.name == "図面作成")
    win._on_selection(task.id)
    app.processEvents()
    n_roles = len(task.roles)
    win.prop._add_role()
    app.processEvents()
    assert len(task.roles) == n_roles + 1
    assert task.roles[-1].headcount == 1
    # プロパティから作業内容を追加（Trial82: この項目の定義が増える）
    master = win.data.master_by_id(task.master_id)
    n_attrs, n_master = len(task.attr_defs), len(master.attrs)
    win.prop._add_attr()
    app.processEvents()
    assert len(task.attr_defs) == n_attrs + 1
    assert len(master.attrs) == n_master   # マスタは変わらない
    assert task.attr_defs[-1].name in task.attrs
    # 工事一覧: 名前列が広く、期間に年が入る
    from kouteihyo.dialogs import ProjectListDialog
    cb = {"open_single": lambda pid: None,
          "open_plant": lambda plant: None,
          "add_projects": win._add_ids_to_view,
          "remove_projects": lambda ids: None,
          "new_project": lambda: None,
          "add_plant": lambda name: None,
          "rename_plant": lambda old, new: None,
          "delete_plant": lambda name: None,
          "open_folder": lambda: None}
    dlg = ProjectListDialog(win.data, win.plant_names, cb, win,
                            view_provider=lambda: list(win.view_ids))
    dlg.show()
    app.processEvents()
    dlg.grab()   # 描画してヘッダーの伸縮を確定させる
    app.processEvents()
    # Trial75: 名前列は狭めの既定幅、全列ドラッグ変更可、幅は個人設定に保存
    from PySide6.QtWidgets import QHeaderView
    assert dlg.tree.columnWidth(0) == 420, dlg.tree.columnWidth(0)
    hdr = dlg.tree.header()
    assert all(hdr.sectionResizeMode(c) == QHeaderView.ResizeMode.Interactive
               for c in range(3))
    dlg.tree.setColumnWidth(0, 500)
    assert win.data.settings.project_list_widths[0] == 500
    top = dlg.tree.topLevelItem(0)
    child = top.child(0)
    assert "/4/1" in child.text(1) and child.text(1)[0:2].isdigit(), \
        child.text(1)
    dlg.close()
    win.dirty = False   # 編集で dirty になるため、閉じる前の確認モーダルを回避
    win.close()
    print("test_trial68_wide_names_and_add_buttons ok")


def test_trial70_shortage_frames():
    """Trial70: 作業内容の所要が人員の上限を超えると不足として伝わる。"""
    app = QApplication.instance()
    data = build_sample_data()
    win = MainWindow(data)
    win.show()
    app.processEvents()
    p = win.project()
    draw = next(t for t in p.tasks if t.name == "図面作成")
    # 標準サンプル（20営業日）では不足なし
    assert md.role_shortages(data, draw) == {}
    # 期間を2営業日に縮める: 作成 所要54h > 上限 2人×2日×8h=32h で不足
    draw.start, draw.end = "2026-05-11", "2026-05-12"
    short = md.role_shortages(data, draw)
    assert "作成" in short and "チェック" not in short, short
    assert short["作成"] == (54.0, 32.0), short
    # 日付表: 不足行が1行だけ立つ
    win.table.refresh()
    assert len(win.table._short_rows) == 1, win.table._short_rows
    # プロパティ: 不足が伝わり、作業時間カードが赤枠になる
    win._on_selection(draw.id)
    app.processEvents()
    assert "作成" in win.prop._shortages
    assert "#d43a2f" in win.prop._jinko_card.styleSheet()
    # 実際に赤枠が描かれていること（スタイルシート文字列だけでは不十分）
    from PySide6.QtGui import QColor
    img = win.prop._jinko_card.grab().toImage()
    reds = sum(1 for x in range(0, img.width(), 2)
               for y in range(0, img.height(), 2)
               if QColor(img.pixel(x, y)).name() == "#d43a2f")
    assert reds > 20, reds
    win.dirty = False
    win.close()
    print("test_trial70_shortage_frames ok")


def test_trial71_toolbar_consolidated():
    """Trial71: 新規作成・工事を開く・プリセット2ボタンを外し、項目編集に集約。"""
    app = QApplication.instance()
    win = MainWindow(build_sample_data())
    win.show()
    app.processEvents()
    from PySide6.QtWidgets import QPushButton
    texts = [b.text() for b in win.findChildren(QPushButton)]
    for gone in ("新規作成", "工事を開く", "プリセットを開く", "現在をプリセット登録"):
        assert gone not in texts, (gone, texts)
    assert "項目編集" in texts
    assert "工事一覧" in texts and "保存" in texts
    win.dirty = False
    win.close()
    print("test_trial71_toolbar_consolidated ok")


def test_trial72_toggle_in_toolbar_corner_add_delete():
    """Trial72: 切替はツールバー中央、ガント左上に項目追加・削除。"""
    app = QApplication.instance()
    win = MainWindow(build_sample_data())
    win.show()
    app.processEvents()
    # 切替セグメントはツールバーの中（ガントより上）にある
    seg = win.view_seg
    assert seg.y() < win.gantt.mapTo(win, seg.pos()).y() or seg.y() < 60, seg.y()
    # 削除ボタンは未選択では無効、選択すると有効になる
    assert not win.del_item_btn.isEnabled()
    p = win.project()
    win._on_selection(p.tasks[0].id)
    app.processEvents()
    assert win.del_item_btn.isEnabled()
    win._on_selection("")
    app.processEvents()
    assert not win.del_item_btn.isEnabled()
    win.dirty = False
    win.close()
    print("test_trial72_toggle_in_toolbar_corner_add_delete ok")


def test_trial73_lock_label_and_toggle_position():
    """Trial73: 編集状態は保存の右、表示切替は広めで左寄せ。"""
    app = QApplication.instance()
    win = MainWindow(build_sample_data())
    win.show()
    app.processEvents()
    from PySide6.QtWidgets import QPushButton
    from PySide6.QtCore import QPoint
    save = next(b for b in win.findChildren(QPushButton) if b.text() == "保存")
    save_r = save.mapTo(win, QPoint(0, 0)).x() + save.width()
    lbl = win.lock_status
    assert lbl.y() < 60, lbl.y()  # 1行目の中にある
    assert lbl.mapTo(win, QPoint(0, 0)).x() >= save_r  # 保存の右
    seg = win.view_seg
    assert seg.x() + seg.width() // 2 < win.width() // 2  # 左寄せ
    assert win.detail_btn.width() >= 100
    assert win.parallel_btn.width() >= 100
    win.dirty = False
    win.close()
    print("test_trial73_lock_label_and_toggle_position ok")


def test_trial74_operation_cleanup():
    """Trial74: Ctrl+S/Deleteキー、重複ボタンの廃止、プリセット管理、工事削除。"""
    app = QApplication.instance()
    from PySide6.QtWidgets import QMessageBox, QInputDialog
    from PySide6.QtCore import Qt
    from PySide6.QtTest import QTest
    orig_q = QMessageBox.question
    QMessageBox.question = staticmethod(
        lambda *a, **k: QMessageBox.StandardButton.Yes)
    try:
        win = MainWindow(build_sample_data())
        win.show()
        app.processEvents()
        # Ctrl+S のショートカットがある
        from PySide6.QtGui import QShortcut, QKeySequence
        seqs = [sc.key().toString() for sc in win.findChildren(QShortcut)]
        assert QKeySequence(QKeySequence.StandardKey.Save).toString() in seqs, seqs
        # プロパティに削除ボタンは無い（角に集約）
        assert not hasattr(win.prop, "del_btn")
        # 並列表示では帯ボタンが隠れる
        win._switch_view(1)
        app.processEvents()
        assert not win.strips_btn.isVisible()
        win._switch_view(0)
        app.processEvents()
        assert win.strips_btn.isVisible()
        # Delete キーで選択中の項目が消える
        p = win.project()
        task = next(t for t in p.tasks if t.name == "図面作成")
        win._on_selection(task.id)
        app.processEvents()
        n0 = len(p.tasks)
        QTest.keyClick(win.gantt, Qt.Key.Key_Delete)
        app.processEvents()
        assert len(p.tasks) == n0 - 1
        assert p.task_by_id(task.id) is None
        # 項目プリセットの削除
        from kouteihyo.dialogs import ItemPresetDialog, StartupGuideDialog
        data = win.data
        n_pre = len(data.presets)
        dlg = ItemPresetDialog(data, win, on_save=win._save_preset,
                               on_manage=win._manage_masters)
        dlg.list.setCurrentRow(0)
        dlg._delete()
        assert len(data.presets) == n_pre - 1 and dlg.changed
        dlg.close()
        # 表示プリセットの登録・削除（ガイド内）
        orig_t = QInputDialog.getText
        QInputDialog.getText = staticmethod(lambda *a, **k: ("確認用表示", True))
        try:
            g = StartupGuideDialog(data, win.plant_names, win,
                                   current_ids=[data.projects[0].id])
            n_vp = len(data.view_presets)
            g._save_view_preset()
            assert len(data.view_presets) == n_vp + 1 and g.presets_changed
            idx = g.combos["preset"].findData(data.view_presets[-1].id)
            g.combos["preset"].setCurrentIndex(idx)
            g._delete_view_preset()
            assert len(data.view_presets) == n_vp
            g.close()
        finally:
            QInputDialog.getText = orig_t
        # 工事の削除（本体・メモリ上）
        victim = data.projects[-1]
        n_pr = len(data.projects)
        assert win._delete_project(victim.id) is True
        assert len(data.projects) == n_pr - 1
        assert all(x.id != victim.id for x in data.projects)
        win.dirty = False
        win.close()
    finally:
        QMessageBox.question = orig_q
    print("test_trial74_operation_cleanup ok")


def test_trial75_columns_cards_keys_menu():
    """Trial75: 列幅・縦罫線、カード出し分け、追加集約、矢印移動、右クリック。"""
    app = QApplication.instance()
    from PySide6.QtCore import QPoint, Qt
    from PySide6.QtWidgets import QMenu, QPushButton
    from PySide6.QtTest import QTest
    win = MainWindow(build_sample_data())
    win.show()
    app.processEvents()
    p = win.project()
    # C1: 種別でカードを出し分ける
    ms = next(t for t in p.tasks if t.milestone)
    win._on_selection(ms.id)
    app.processEvents()
    assert not win.prop._jinko_card.isVisible()
    assert not win.prop._attr_card.isVisible()
    ref = next(t for t in p.tasks if t.kind == "ref" and not t.milestone)
    win._on_selection(ref.id)
    app.processEvents()
    assert not win.prop._jinko_card.isVisible()
    assert win.prop._attr_card.isVisible()
    own = next(t for t in p.tasks if t.name == "図面作成")
    win._on_selection(own.id)
    app.processEvents()
    assert win.prop._jinko_card.isVisible()
    assert win.prop._attr_card.isVisible()
    # C2: 並列ツールに＋追加ボタンは無い（カードに集約）
    texts = [b.text() for b in win.parallel_tools.findChildren(QPushButton)]
    assert "+追加" not in texts, texts
    # D2: 矢印キーでバーが前後に動く（Shiftで7日）。まずバーをクリックして
    # ガントにフォーカスを移す（実際の操作と同じ流れ）
    click_pos = None
    for y in range(40, win.gantt.height(), 4):
        for x in range(180, win.gantt.width(), 16):
            if win.gantt.task_at(QPoint(x, y)) is own:
                click_pos = QPoint(x, y)
                break
        if click_pos:
            break
    assert click_pos is not None
    QTest.mouseClick(win.gantt, Qt.MouseButton.LeftButton, pos=click_pos)
    app.processEvents()
    assert QApplication.focusWidget() is win.gantt
    s0, e0 = own.dstart, own.dend
    QTest.keyClick(win.gantt, Qt.Key.Key_Right)
    app.processEvents()
    assert (own.dstart - s0).days == 1 and (own.dend - e0).days == 1
    QTest.keyClick(win.gantt, Qt.Key.Key_Right)
    app.processEvents()
    assert (own.dstart - s0).days == 2
    QTest.keyClick(win.gantt, Qt.Key.Key_Left)
    app.processEvents()
    assert (own.dstart - s0).days == 1
    # Shift+矢印は7日（後続に余裕のある節目で確認）
    ms2 = next(t for t in p.tasks if t.name == "データ納品")
    win._on_selection(ms2.id)
    app.processEvents()
    m0 = ms2.dstart
    QTest.keyClick(win.gantt, Qt.Key.Key_Right,
                   Qt.KeyboardModifier.ShiftModifier)
    app.processEvents()
    assert (ms2.dstart - m0).days == 7
    # D1: 右クリックメニューの中身（exec を差し替えて確認）
    pos = None
    for y in range(40, win.gantt.height(), 4):
        for x in range(180, win.gantt.width(), 16):
            if win.gantt.task_at(QPoint(x, y)) is own:
                pos = QPoint(x, y)
                break
        if pos:
            break
    assert pos is not None
    menu = win._build_gantt_menu(pos)
    seen = [act.text() for act in menu.actions()]
    assert "項目を追加…" in seen and "この項目を削除" in seen, seen
    assert "日付を設定…" in seen, seen
    # C3: プラント操作はメニューの中
    from kouteihyo.dialogs import ProjectListDialog
    cb = {"lock_projects": win._claim_projects,
          "open_single": win._list_open_single,
          "add_projects": win._add_ids_to_view,
          "remove_projects": lambda ids: None,
          "open_plant": win._list_open_plant,
          "add_plant": win._list_add_plant,
          "delete_project": win._delete_project}
    dlg = ProjectListDialog(win.data, win.plant_names, cb, win,
                            view_provider=lambda: list(win.view_ids))
    dlg.show()
    app.processEvents()
    assert dlg.act_add_p.text() == "プラントを追加…"
    top = dlg.tree.topLevelItem(0)
    dlg.tree.setCurrentItem(top.child(0))   # 工事を選択
    app.processEvents()
    assert not dlg.act_ren_p.isEnabled()    # 名称変更はプラント選択時のみ
    assert dlg.btn_del_pr.isEnabled()
    dlg.close()
    win.dirty = False
    win.close()
    print("test_trial75_columns_cards_keys_menu ok")


def test_trial77_table_stays_and_date_dropdown():
    """Trial77: 日付表クリックでプロパティへ移らない／日付はドロップダウン。"""
    app = QApplication.instance()
    from PySide6.QtCore import QDate, Qt
    from PySide6.QtWidgets import QDateEdit
    win = MainWindow(build_sample_data())
    win.show()
    app.processEvents()
    p = win.project()
    task = next(t for t in p.tasks if t.name == "図面作成")
    row = next(r for r in range(win.table.table.rowCount())
               if win.table.table.item(r, 0).data(
                   Qt.ItemDataRole.UserRole) == task.id)
    # 日付表タブを表示して行をクリックしても、タブは日付表のまま
    win.tabs.setCurrentWidget(win.table)
    win.table.table.setCurrentCell(row, 0)
    app.processEvents()
    assert win.selected_task_id == task.id
    assert win.tabs.currentWidget() is win.table
    # 開始・終了セルはカレンダー付きドロップダウン
    e_start = win.table.table.cellWidget(row, 1).findChild(QDateEdit)
    e_end = win.table.table.cellWidget(row, 2).findChild(QDateEdit)
    assert isinstance(e_start, QDateEdit) and e_start.calendarPopup()
    assert isinstance(e_end, QDateEdit) and e_end.calendarPopup()
    assert e_start.text() == "26/05/11", e_start.text()
    # 日付を変えて確定するとタスクへ反映され、タブも移らない
    e_start.setDate(QDate(2026, 5, 13))
    e_start.editingFinished.emit()
    app.processEvents()
    assert task.start == "2026-05-13", task.start
    assert win.tabs.currentWidget() is win.table
    # ガント側の選択では従来どおりプロパティが開く
    win._on_selection(task.id)
    app.processEvents()
    assert win.tabs.currentWidget() is win.prop
    win.dirty = False
    win.close()
    print("test_trial77_table_stays_and_date_dropdown ok")


def test_trial78_date_lock():
    """Trial78: 日付ロック（プロパティ切替・各編集経路の拒否・鍵表示）。"""
    app = QApplication.instance()
    from PySide6.QtCore import QPoint, Qt
    from PySide6.QtTest import QTest
    from kouteihyo.dialogs import DateSettingsDialog, ShiftDialog
    win = MainWindow(build_sample_data())
    win.show()
    app.processEvents()
    p = win.project()
    task = next(t for t in p.tasks if t.name == "図面作成")
    assert task.lock_start is False and task.lock_end is False
    win._on_selection(task.id)
    app.processEvents()
    # プロパティで両方ロックする
    win.prop.lock_start_check.setChecked(True)
    win.prop.lock_end_check.setChecked(True)
    app.processEvents()
    assert task.lock_start is True and task.lock_end is True
    assert not win.prop.start_edit.isEnabled()
    assert not win.prop.end_edit.isEnabled()
    # 日付表: 両方の鍵チェックが入り、日付欄が無効になる
    row = next(r for r in range(win.table.table.rowCount())
               if win.table.table.item(r, 0).data(
                   Qt.ItemDataRole.UserRole) == task.id)
    from PySide6.QtWidgets import QCheckBox as _QCB, QDateEdit as _QDE
    _lcb = win.table.table.cellWidget(row, 2).findChild(_QCB)
    assert _lcb is not None and _lcb.isChecked()
    assert not win.table.table.cellWidget(row, 1).findChild(_QDE).isEnabled()
    # 矢印キー移動は効かない
    s0, e0 = task.start, task.end
    win._nudge_selected(1)
    assert (task.start, task.end) == (s0, e0)
    # ガントのドラッグは始まらない
    pos = None
    for y in range(40, win.gantt.height(), 4):
        for x in range(180, win.gantt.width(), 16):
            if win.gantt.task_at(QPoint(x, y)) is task:
                pos = QPoint(x, y)
                break
        if pos:
            break
    assert pos is not None
    QTest.mousePress(win.gantt, Qt.MouseButton.LeftButton, pos=pos)
    app.processEvents()
    assert win.gantt._pending is None and win.gantt._drag is None
    QTest.mouseRelease(win.gantt, Qt.MouseButton.LeftButton, pos=pos)
    # 水平移動ダイアログ: ロック中は選べない
    other = next(t for t in p.tasks if t.name == "物量集計")
    dlg = ShiftDialog([task, other], win)
    by_id = {cb.property("task_id"): cb for cb in dlg.checks}
    assert not by_id[task.id].isEnabled() and not by_id[task.id].isChecked()
    assert by_id[other.id].isChecked()   # 最初の未ロックが既定チェック
    dlg.close()
    # 日付の設定: ロック中の行は無効
    dsd = DateSettingsDialog(p, win)
    assert not dsd.panel._rows[task.id]["start"].isEnabled()
    assert not dsd.panel._rows[task.id]["end"].isEnabled()
    dsd.close()
    # 解除すると編集できる
    win.prop.lock_start_check.setChecked(False)
    win.prop.lock_end_check.setChecked(False)
    app.processEvents()
    assert task.lock_start is False and task.lock_end is False
    assert win.prop.start_edit.isEnabled()
    win.dirty = False
    win.close()
    print("test_trial78_date_lock ok")


def test_trial79_layout_and_lock_ui():
    """Trial79: 作業内容の行潰れ修正／🔐チェックボックス／一括ロック。"""
    app = QApplication.instance()
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QCheckBox, QMessageBox
    win = MainWindow(build_sample_data())
    win.show()
    app.processEvents()
    p = win.project()
    task = next(t for t in p.tasks if t.name == "図面作成")
    win._on_selection(task.id)
    app.processEvents()
    # 作業内容の行が潰れていない（行の高さ・間隔・カードの高さ）
    g = win.prop.attrs_grid
    ys = sorted({g.itemAt(i).widget().geometry().y()
                 for i in range(g.count())
                 if g.itemAt(i).widget() and g.getItemPosition(i)[1] == 1})
    assert len(ys) == 3 and ys[1] - ys[0] >= 30 and ys[2] - ys[1] >= 30, ys
    assert win.prop._attr_card.height() >= 200, win.prop._attr_card.height()
    # プロパティの鍵チェックは開始／終了と同じ行の箱に入っている
    assert win.prop.lock_start_check.parent().parent() \
        is win.prop.start_edit.parent()
    assert win.prop.lock_end_check.parent().parent() \
        is win.prop.end_edit.parent()
    # 日付表の🔐チェックでロックできる
    row = next(r for r in range(win.table.table.rowCount())
               if win.table.table.item(r, 0).data(
                   Qt.ItemDataRole.UserRole) == task.id)
    cb = win.table.table.cellWidget(row, 2).findChild(QCheckBox)
    assert cb is not None and not cb.isChecked()
    cb.setChecked(True)
    app.processEvents()
    assert task.lock_end is True and task.lock_start is False
    assert win.prop.lock_end_check.isChecked()   # プロパティ側にも同期する
    cb2 = win.table.table.cellWidget(row, 2).findChild(QCheckBox)
    cb2.setChecked(False)
    app.processEvents()
    assert task.lock_end is False
    # 工事単位で一括ロック／全解除
    orig_q = QMessageBox.question
    QMessageBox.question = staticmethod(
        lambda *a, **k: QMessageBox.StandardButton.Yes)
    try:
        win._set_all_locks(True)
        assert all(t.lock_start and t.lock_end for t in p.tasks)
        win._set_all_locks(False)
        assert not any(t.locked_any for t in p.tasks)
    finally:
        QMessageBox.question = orig_q
    win.dirty = False
    win.close()
    print("test_trial79_layout_and_lock_ui ok")


def test_trial80_separate_locks():
    """Trial80: 開始／終了の分離ロック・専用アイコン・旧データ移行。"""
    app = QApplication.instance()
    from PySide6.QtCore import QPoint, Qt
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QCheckBox, QDateEdit
    from kouteihyo.gantt import GanttWidget
    from kouteihyo.icons import icon_pixmap
    # 専用アイコンが描けている（南京錠の本体あたりに不透明画素がある）
    pm = icon_pixmap("lock", "#786e64")
    assert not pm.isNull() and pm.width() == 40
    img = pm.toImage()
    assert any(img.pixelColor(x, 24).alpha() > 0 for x in range(12, 29))
    # 旧データ移行: Trial78の locked=true は両方ロックになる
    old = md._task_from_dict({"id": "x1", "name": "旧項目",
                              "start": "2026-01-05", "end": "2026-01-06",
                              "locked": True})
    assert old.lock_start is True and old.lock_end is True
    # 開始だけロック: プロパティと日付表で開始だけ止まる
    win = MainWindow(build_sample_data())
    win.show()
    app.processEvents()
    p = win.project()
    task = next(t for t in p.tasks if t.name == "図面作成")
    win._on_selection(task.id)
    app.processEvents()
    win.prop.lock_start_check.setChecked(True)
    app.processEvents()
    assert task.lock_start is True and task.lock_end is False
    assert not win.prop.start_edit.isEnabled()
    assert win.prop.end_edit.isEnabled()
    row = next(r for r in range(win.table.table.rowCount())
               if win.table.table.item(r, 0).data(
                   Qt.ItemDataRole.UserRole) == task.id)
    assert not win.table.table.cellWidget(row, 1).findChild(QDateEdit).isEnabled()
    assert win.table.table.cellWidget(row, 2).findChild(QDateEdit).isEnabled()
    # ガント: 左端は掴めないが右端は掴める（開始ロックのみ）
    g = GanttWidget()
    g.resize(1176, 640)
    g.set_project(p)
    g.view_days = 100
    g._layout()
    grow = next(r for r in g._rows if r[0] == "task" and r[2].id == task.id)
    rect = g._bar_rect(task, grow[3])
    cy = int(rect.center().y())
    QTest.mousePress(g, Qt.MouseButton.LeftButton,
                     pos=QPoint(int(rect.left()) + 3, cy))
    app.processEvents()
    assert g._pending is None
    QTest.mouseRelease(g, Qt.MouseButton.LeftButton,
                       pos=QPoint(int(rect.left()) + 3, cy))
    QTest.mousePress(g, Qt.MouseButton.LeftButton,
                     pos=QPoint(int(rect.right()) - 3, cy))
    app.processEvents()
    assert g._pending and g._pending["mode"] == "resize_r", g._pending
    QTest.mouseRelease(g, Qt.MouseButton.LeftButton,
                       pos=QPoint(int(rect.right()) - 3, cy))
    g.close()
    # 縮める可否: 終了ロックだけなら可、開始ロックなら不可
    hit = next(t for t in p.tasks if t.name == "承認")
    hit.lock_start, hit.lock_end = False, True
    menu, _w, shrink, _s = win._build_overlap_menu(task, hit)
    assert shrink.isEnabled()
    hit.lock_start, hit.lock_end = True, False
    menu, _w, shrink, _s = win._build_overlap_menu(task, hit)
    assert not shrink.isEnabled()
    hit.lock_start = hit.lock_end = False
    # 節目: 片方のチェックで両方ロックされる
    ms = next(t for t in p.tasks if t.name == "データ納品")
    mrow = next(r for r in range(win.table.table.rowCount())
                if win.table.table.item(r, 0).data(
                    Qt.ItemDataRole.UserRole) == ms.id)
    mcb = win.table.table.cellWidget(mrow, 1).findChild(QCheckBox)
    mcb.setChecked(True)
    app.processEvents()
    assert ms.lock_start is True and ms.lock_end is True
    win.dirty = False
    win.close()
    print("test_trial80_separate_locks ok")


def test_trial81_tree_selection_readable():
    """Trial81: 工事一覧ツリーの選択行の文字が見える（選択色を明示）。"""
    app = QApplication.instance()
    from kouteihyo.dialogs import ProjectListDialog
    data = build_sample_data()
    cb = {"open_project": lambda pid: None}
    dlg = ProjectListDialog(data, ["プラントA", "プラントB"], cb, None,
                            view_provider=lambda: [])
    dlg.resize(1280, 600)
    dlg.show()
    app.processEvents()
    ss = dlg.tree.styleSheet()
    assert "item:selected" in ss and "#2e4a66" in ss
    top = dlg.tree.topLevelItem(0)
    item = top.child(0) if top.childCount() else top
    dlg.tree.setCurrentItem(item)
    dlg.tree.setFocus()
    app.processEvents()
    rect = dlg.tree.visualItemRect(item)
    img = dlg.tree.viewport().grab().toImage()
    # 選択行の文字ピクセル（背景と対照的な色）があること
    found = 0
    for x in range(rect.left() + 20, rect.right() - 4, 2):
        for y in range(rect.top() + 2, rect.bottom() - 1, 2):
            c = img.pixelColor(x, y)
            if (c.red() > 235 and c.green() > 235 and c.blue() > 235) or \
               (c.red() < 70 and c.green() < 65 and c.blue() < 55):
                found += 1
    assert found > 25, found
    dlg.close()
    print("test_trial81_tree_selection_readable ok")


def test_trial82_per_task_attrs():
    """Trial82: 作業内容は項目ごとに保持／単位時間をプロパティで編集。"""
    app = QApplication.instance()
    from PySide6.QtCore import QPoint
    from PySide6.QtWidgets import QCheckBox, QDoubleSpinBox
    # 旧データの移行: attr_defs 無しでもマスタ定義が補われる
    raw = md.data_to_dict(build_sample_data())
    for pr in raw["projects"]:
        for t in pr["tasks"]:
            t.pop("attr_defs", None)
    data2 = md.data_from_dict(raw)
    dt = next(t for pr in data2.projects for t in pr.tasks
              if t.name == "図面作成")
    assert [a.name for a in dt.attr_defs] == ["配管図", "サポート図", "その他図面"]
    # 2つの同マスタ項目で独立していること
    win = MainWindow(build_sample_data())
    win.show()
    app.processEvents()
    p0, p1 = win.data.projects[0], win.data.projects[1]
    t0 = next(t for t in p0.tasks if t.name == "図面作成")
    t1 = next(t for t in p1.tasks if t.name == "図面作成")
    t0.attrs["配管図"] = 10
    t1.attrs["配管図"] = 10
    h0 = md.task_hours(win.data, t0)["作成"]
    win._on_selection(t0.id)
    win.project = lambda: p0   # 選択中プロジェクトに合わせる
    app.processEvents()
    # プロパティで t0 の配管図の「作成」単位時間を 3→5 に変える
    spins = win.prop.findChildren(QDoubleSpinBox)
    assert spins, "単位時間の編集欄が出ていない"
    target = None
    for sp in spins:
        if abs(sp.value() - 3.0) < 1e-9:
            target = sp
            break
    assert target is not None
    target.setValue(5.0)
    app.processEvents()
    d0 = next(a for a in t0.attr_defs if a.name == "配管図")
    d1 = next(a for a in t1.attr_defs if a.name == "配管図")
    assert d0.hours["作成"] == 5.0
    assert d1.hours["作成"] == 3.0   # もう一方の項目は変わらない
    assert md.task_hours(win.data, t0)["作成"] > h0
    assert md.estimate_hours(t1)["作成"] == 30.0   # 10枚×3h のまま
    # マスタ（初期値）も変わらない
    mst = win.data.master_by_id(t0.master_id)
    assert next(a for a in mst.attrs if a.name == "配管図").hours["作成"] == 3.0
    # 見出しの鍵アイコン位置がチェック中心と合っている（実測補正）
    win.tabs.setCurrentWidget(win.table)
    win.table.refresh()
    app.processEvents()
    tbl = win.table.table
    wrap = tbl.cellWidget(0, 1)
    cb = wrap.findChild(QCheckBox)
    hdr = tbl.horizontalHeader()
    cx = cb.mapTo(tbl.viewport(), QPoint(cb.width() // 2, 0)).x()
    icon_cx = hdr.sectionViewportPosition(1) + hdr.lock_offset
    assert abs(cx - icon_cx) <= 3, (cx, icon_cx)
    win.dirty = False
    win.close()
    print("test_trial82_per_task_attrs ok")


def test_trial83_new_master_color_and_label():
    """Trial83: 新規登録の初期色は未使用色／「属性名」→「作業名」。"""
    app = QApplication.instance()
    from kouteihyo.dialogs import MasterDialog
    win = MainWindow(build_sample_data())
    win.show()
    app.processEvents()
    used = [md.PALETTE[0], md.PALETTE[1], md.PALETTE[2]]
    dlg = MasterDialog(None, win, used_colors=used)
    assert dlg._color == md.PALETTE[3], dlg._color
    assert dlg.master.color == md.PALETTE[3]
    # 全部使われていたら先頭に戻る
    dlg2 = MasterDialog(None, win, used_colors=list(md.PALETTE))
    assert dlg2._color == md.PALETTE[0]
    # 編集時はその項目の色のまま
    m = md.Master(name="x", color="#123456")
    dlg3 = MasterDialog(m, win, used_colors=used)
    assert dlg3._color == "#123456"
    # 見出しは「作業名」
    assert dlg.attrs_table.horizontalHeaderItem(0).text() == "作業名"
    for d in (dlg, dlg2, dlg3):
        d.close()
        d.deleteLater()
    app.processEvents()
    win.dirty = False
    win.close()
    print("test_trial83_new_master_color_and_label ok")


if __name__ == "__main__":
    for _name, _fn in sorted(globals().items()):
        if _name.startswith("test_trial"):
            _fn()









