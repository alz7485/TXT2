import copy
import pytest
from PySide6.QtWidgets import QInputDialog, QMessageBox
from kouteihyo.dialogs import ItemPresetDialog
from kouteihyo.sample import build_sample_data
from kouteihyo import model as md


def test_rename_preserves_contents_selection_and_saved_name(monkeypatch):
    data = build_sample_data()
    dialog = ItemPresetDialog(data)
    original = copy.deepcopy(data.presets[0])
    monkeypatch.setattr(QInputDialog, 'getText', lambda *a, **k: ('  新しい工程セット  ', True))
    try:
        dialog.search.setText(original.name)
        dialog._rename()
        selected = dialog._selected()
        assert selected.id == original.id
        assert selected.name == '新しい工程セット'
        assert selected.entries == original.entries and selected.tracks == original.tracks
        assert dialog.changed and dialog.search.text() == ''
        assert dialog.preview_title.text() == selected.name
        assert md.data_from_dict(md.data_to_dict(data)).presets[0].name == selected.name
    finally:
        dialog.close()


@pytest.mark.parametrize('answer', [(' ', True), ('別名', False), ('標準（調査〜図面）', True)])
def test_invalid_cancelled_or_unchanged_rename_does_not_change_data(monkeypatch, answer):
    data = build_sample_data()
    dialog = ItemPresetDialog(data)
    before = copy.deepcopy(data.presets)
    if answer[0] == '標準（調査〜図面）':
        answer = (data.presets[0].name, True)
    monkeypatch.setattr(QInputDialog, 'getText', lambda *a, **k: answer)
    monkeypatch.setattr(QMessageBox, 'warning', lambda *a: None)
    try:
        dialog._rename()
        assert data.presets == before and not dialog.changed
        dialog.search.setText('一致しない検索')
        assert not dialog.rename_btn.isEnabled()
    finally:
        dialog.close()


def test_duplicate_name_is_rejected(monkeypatch):
    data = build_sample_data()
    data.presets.append(md.Preset(name='既存名'))
    dialog = ItemPresetDialog(data)
    before = copy.deepcopy(data.presets)
    notices = []
    monkeypatch.setattr(QInputDialog, 'getText', lambda *a, **k: ('既存名', True))
    monkeypatch.setattr(QMessageBox, 'warning', lambda *a: notices.append(a[2]))
    try:
        dialog._rename()
        assert data.presets == before and not dialog.changed and notices
    finally:
        dialog.close()
