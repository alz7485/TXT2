"""Trial87: action discoverability, responsive layout and dynamic dialogs."""
import pytest
from PySide6.QtCore import QPoint
from PySide6.QtWidgets import QApplication, QPushButton
from kouteihyo.main_window import MainWindow
from kouteihyo.sample import build_sample_data
from kouteihyo.dialogs import ProjectListDialog
from kouteihyo.fontutil import font
from kouteihyo.ui import action_icon, install_ui


def position(widget, ancestor):
    return widget.mapTo(ancestor, QPoint(0, 0))


@pytest.mark.parametrize('width', [1024, 1366, 1600])
def test_main_actions_fit_and_view_controls_have_own_row(width):
    app = QApplication.instance()
    previous_font = app.font()
    app.setFont(font(10))
    window = MainWindow(build_sample_data())
    try:
        window.resize(width, 800)
        window.show()
        app.processEvents()
        assert window.width() == width
        save = next(b for b in window.findChildren(QPushButton) if b.text() == '保存')
        assert position(window.view_seg, window).y() >= position(save, window).y() + save.height()
        for button in (window.add_item_btn, window.del_item_btn,
                       window.detail_btn, window.parallel_btn, save):
            assert not button.icon().isNull()
            assert button.width() >= button.sizeHint().width()
        buttons = [b for b in window.centralWidget().findChildren(QPushButton)
                   if b.isVisible() and position(b, window).y() < position(window.view_seg, window).y()]
        buttons.sort(key=lambda b: position(b, window).x())
        for left, right in zip(buttons, buttons[1:]):
            assert position(left, window).x() + left.width() <= position(right, window).x()
        assert position(buttons[-1], window).x() + buttons[-1].width() <= window.width()
        assert window.add_item_btn.x() + window.add_item_btn.width() <= window.del_item_btn.x()
        assert window.del_item_btn.x() + window.del_item_btn.width() <= window.corner_seg.width()
        assert window.add_item_btn.text() == '項目追加'
        from PySide6.QtWidgets import QScrollArea
        drawing = next(t for t in window.project().tasks if t.name == '図面作成')
        window._on_selection(drawing.id)
        app.processEvents()
        panel_scroll = window.prop.findChild(QScrollArea)
        assert panel_scroll.horizontalScrollBar().maximum() == 0
        assert window.tabs.width() <= 510
    finally:
        window.dirty = False
        window.close()
        app.setFont(previous_font)


def test_project_list_actions_are_grouped_and_accessible():
    app = QApplication.instance()
    install_ui()
    window = MainWindow(build_sample_data())
    dialog = ProjectListDialog(window.data, ['プラントA', 'プラントB'], {}, window)
    try:
        dialog.show()
        app.processEvents()
        actions = [b for b in dialog.findChildren(QPushButton) if b.isVisible()]
        for button in actions:
            assert not button.icon().isNull(), button.text()
            assert button.accessibleName()
            assert button.width() >= button.sizeHint().width(), button.text()
        workspace = next(b for b in actions if b.text() == '置き場を開く…')
        assert position(workspace, dialog).y() > position(dialog.btn_new, dialog).y()
        assert dialog.btn_arrow.text() == '' and dialog.btn_arrow.toolTip()
    finally:
        dialog.close()
        window.dirty = False
        window.close()


def test_icons_have_disabled_and_checked_variants():
    from PySide6.QtGui import QIcon
    icon = action_icon('detail')
    assert len(icon.availableSizes()) >= 6
    normal = icon.pixmap(24, QIcon.Mode.Normal, QIcon.State.Off).toImage()
    disabled = icon.pixmap(24, QIcon.Mode.Disabled, QIcon.State.Off).toImage()
    checked = icon.pixmap(24, QIcon.Mode.Normal, QIcon.State.On).toImage()
    assert normal != disabled
    assert normal != checked
