"""Qtアプリをテスト全体で保持して既存GUIテストも実行する。"""
import os
import sys
from pathlib import Path

if sys.platform.startswith('linux'):
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(root))
from PySide6.QtWidgets import QApplication
import pytest

if __name__ == '__main__':
    app = QApplication.instance() or QApplication([])
    status = pytest.main(['-q', *(sys.argv[1:] or [str(root / 'tests')])])
    # Dispose test windows before Qt tears down its application and icon cache.
    from PySide6.QtCore import QCoreApplication, QEvent
    from kouteihyo import ui, icons
    if hasattr(app, '_phaseflow_ui_polisher'):
        app.removeEventFilter(app._phaseflow_ui_polisher)
    for widget in app.topLevelWidgets():
        if hasattr(widget, 'dirty'):
            widget.dirty = False
        widget.close()
        widget.deleteLater()
    QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
    app.processEvents()
    ui._CACHE.clear()
    icons._cache.clear()
    raise SystemExit(status)
