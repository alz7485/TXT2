# -*- coding: utf-8 -*-
import sys
from datetime import date

sys.path.insert(0, __file__.rsplit("/tests/", 1)[0])

from kouteihyo import model as md
from kouteihyo.sample import build_sample_data


def test_workdays():
    # 2026-04-01 は水曜。標準: 4/1,2,3 が営業日、4/4(土)4/5(日)休み
    assert md.workdays_between(date(2026, 4, 1), date(2026, 4, 3), "standard") == 3
    assert md.workdays_between(date(2026, 4, 1), date(2026, 4, 5), "standard") == 3
    # 土曜出勤: 4/4(土)も営業日
    assert md.workdays_between(date(2026, 4, 1), date(2026, 4, 5), "saturday") == 4
    # 終了日の導出: 4/1 から 3 営業日 = 4/3
    assert md.end_from_duration(date(2026, 4, 1), 3, "standard") == date(2026, 4, 3)
    # 翌営業日: 4/3(金) の次は 4/6(月)
    assert md.next_workday(date(2026, 4, 4), "standard") == date(2026, 4, 6)
    print("workdays ok")


def test_sample_and_jinko():
    data = build_sample_data()
    b = data.projects[0]
    names = [t.name for t in b.tasks]
    assert "図面作成" in names and "データ納品" in names
    drawing = next(t for t in b.tasks if t.name == "図面作成")
    j = md.task_jinko(drawing)
    assert j["作成"] == 40 and j["チェック"] == 60 and j["合計"] == 100, j
    # 物量集計は他課のデータ納品を待ってから始まる
    survey = next(t for t in b.tasks if t.name == "物量集計")
    delivery = next(t for t in b.tasks if t.name == "データ納品")
    assert survey.dstart > delivery.dend, (survey.start, delivery.end)
    # 属性の目安: 作成 12*3+6*2+3*2=54, チェック 12*1+6*0.5+3*1=18
    est = md.estimate_hours(drawing)
    assert est["作成"] == 54.0 and est["チェック"] == 18.0, est
    # 総人工は自部門のみ
    total = md.project_jinko_total(b)
    expect = sum(md.task_jinko(t)["合計"] for t in b.tasks
                 if b.track_of(t).kind == "own")
    assert total == expect and total > 0
    monthly = md.monthly_jinko(b)
    assert sum(monthly.values()) == total, (monthly, total)
    print("sample/jinko ok, total =", total, "monthly =", monthly)


def test_overlap_ops():
    data = build_sample_data()
    b = data.projects[0]
    drawing = next(t for t in b.tasks if t.name == "図面作成")
    approval = next(t for t in b.tasks if t.name == "承認")
    # 図面作成の終了を承認の期間内まで伸ばす → 重なり検出
    drawing.end = approval.start
    assert md.find_overlap(b, drawing) is approval
    assert md.can_shrink(b, drawing, approval)
    md.apply_shrink(drawing, approval)
    assert approval.dstart > drawing.dend
    # 水平移動: delta は承認開始を図面終了の翌営業日に合わせる
    drawing.end = approval.end
    followers = md.following_tasks(b, approval)
    assert followers and followers[0].name == "製作"
    print("overlap ok")


def test_json_roundtrip():
    import json
    data = build_sample_data()
    d = md.data_to_dict(data)
    data2 = md.data_from_dict(json.loads(json.dumps(d)))
    assert len(data2.projects) == len(data.projects)
    assert len(data2.masters) == len(data.masters)
    b2 = data2.projects[0]
    assert md.project_jinko_total(b2) == md.project_jinko_total(data.projects[0])
    print("json roundtrip ok")


def test_preset_from_project():
    data = build_sample_data()
    b = data.projects[0]
    p = md.preset_from_project(data, b, "B工事の並び")
    assert p.entries and len(p.tracks) == 3
    proj2 = md.expand_preset(data, p, "E工事", date(2026, 9, 1))
    assert len(proj2.tasks) == len(b.tasks)
    print("preset roundtrip ok")


def test_trial24_holidays_and_save():
    # 祝日テキストのパース（名前付き・'/'区切り・コメント・不正行）
    days = md.parse_holidays_text(
        "2027-03-21 春分の日\n# コメント\n2027/03/22 振替休日\n\n"
        "ただの文字列\n2027-13-40 あり得ない日\n")
    assert days == {date(2027, 3, 21), date(2027, 3, 22)}, days
    # 同梱 holidays.txt（アプリのフォルダ）の読み込み: 2026年18日+2027年17日
    n = md.load_holidays()
    assert n == 35, n
    assert not md.is_workday(date(2027, 3, 22), "standard")   # 月曜だが振替休日
    assert md.is_workday(date(2027, 3, 23), "standard")
    assert not md.is_workday(date(2026, 9, 22), "standard")   # 国民の休日
    # 保存: 世代バックアップ＋原子書き込み
    import os
    import tempfile
    from pathlib import Path
    data = build_sample_data()
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "data.json")
        md.save_json(data, path)
        first_name = data.projects[0].name
        data.projects[0].name = "変更後"
        md.save_json(data, path)
        backs = list((Path(td) / "backup").glob("data_*.json"))
        assert len(backs) == 1, backs
        assert md.load_json(str(backs[0])).projects[0].name == first_name
        assert md.load_json(path).projects[0].name == "変更後"
        assert not os.path.exists(path + ".tmp")
    print("test_trial24_holidays_and_save ok")


def test_trial25_app_dir_frozen():
    # onedir(EXE化)を模擬: sys.frozen + sys.executable を差し替えると
    # EXE の隣の holidays.txt が読まれること
    import os
    import sys as _sys
    import tempfile
    from pathlib import Path
    old_frozen = getattr(_sys, "frozen", False)
    old_exe = _sys.executable
    with tempfile.TemporaryDirectory() as td:
        fake_exe = os.path.join(td, "PhaseFlow.exe")
        Path(fake_exe).write_text("", encoding="utf-8")
        (Path(td) / "holidays.txt").write_text(
            "2030-01-01 テスト休日\n", encoding="utf-8")
        _sys.frozen = True
        _sys.executable = fake_exe
        try:
            assert md.app_dir() == Path(td), md.app_dir()
            n = md.load_holidays()
            assert n == 1 and date(2030, 1, 1) in md.HOLIDAYS
        finally:
            _sys.frozen = old_frozen
            _sys.executable = old_exe
            md.load_holidays()   # 同梱ファイルの状態に戻す
    print("test_trial25_app_dir_frozen ok")


def test_trial31_excel_style():
    import os
    import tempfile
    from openpyxl import load_workbook
    from kouteihyo.exports import export_excel
    from kouteihyo.sample import build_sample_data
    data = build_sample_data()
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "out.xlsx")
        export_excel(data, data.projects[0], path)
        wb = load_workbook(path)
    assert wb.sheetnames == ["日付表", "月別作業時間（全工事）", "ガント"]
    ws = wb["日付表"]
    assert ws["A2"].fill.fgColor.rgb.endswith("38332B")   # 見出しは濃色
    assert ws.freeze_panes == "A3"
    assert ws.sheet_properties.pageSetUpPr.fitToPage
    ws2 = wb["月別作業時間（全工事）"]
    assert ws2.column_dimensions["A"].width >= 20        # 工事名が切れない幅
    ws3 = wb["ガント"]
    assert ws3.merged_cells.ranges, "月の結合見出しがある"
    assert ws3.freeze_panes == "C4"
    print("test_trial31_excel_style ok")


def test_trial32_pdf_multi():
    import os
    import tempfile
    from kouteihyo.exports import _pdf_font, export_pdf_multi
    from kouteihyo.sample import build_sample_data

    def pages_of(path):
        raw = open(path, "rb").read()
        return raw.count(b"/Type /Page") - raw.count(b"/Type /Pages")

    data = build_sample_data()
    assert _pdf_font() in {"KouteihyoJP", "HeiseiKakuGo-W5"}  # 日本語PDF出力のフォールバック
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "multi.pdf")
        n = export_pdf_multi(data, data.projects[0], path,
                             ["gantt", "dates", "parallel", "jinko"])
        assert n == 4 and pages_of(path) == 4, (n, pages_of(path))
        n = export_pdf_multi(data, data.projects[0], path, ["jinko"])
        assert n == 1 and pages_of(path) == 1
    print("test_trial32_pdf_multi ok")


def test_trial33_workspace():
    import os
    import tempfile
    root_td = tempfile.TemporaryDirectory()
    td = root_td.name
    data = build_sample_data()
    root = os.path.join(td, "data")
    md.save_workspace(data, root, ["プラントA", "プラントB"])
    assert os.path.exists(os.path.join(root, "common.json"))
    assert len(list((__import__("pathlib").Path(root) / "プラントA").glob("B工事 配管更新__*.json"))) == 1
    assert len(list((__import__("pathlib").Path(root) / "プラントB").glob("D工事 計装工事__*.json"))) == 1
    data2, plants = md.load_workspace(root)
    assert plants == ["プラントA", "プラントB"]
    # 並び順が保存前と同じ（レーンの色が入れ替わらない）
    assert [p.name for p in data2.projects] == [p.name for p in data.projects]
    assert data2.projects[-1].plant == "プラントB"
    assert len(data2.masters) == len(data.masters)
    # 改名・削除にファイルが追従する
    data2.projects[0].name = "B工事 改名"
    md.save_workspace(data2, root, plants)
    assert len(list((__import__("pathlib").Path(root) / "プラントA").glob("B工事 改名__*.json"))) == 1
    assert not list((__import__("pathlib").Path(root) / "プラントA").glob("B工事 配管更新__*.json"))
    data2.projects.pop(0)
    md.save_workspace(data2, root, plants)
    assert not list((__import__("pathlib").Path(root) / "プラントA").glob("B工事 改名__*.json"))
    # 旧 data.json の移行
    legacy = os.path.join(td, "data.json")
    md.save_json(build_sample_data(), legacy)
    mig = md.migrate_legacy(legacy, os.path.join(td, "ws2"), "本社プラント")
    assert all(p.plant == "本社プラント" for p in mig.projects)
    assert os.path.exists(legacy + ".bak") and not os.path.exists(legacy)
    print("test_trial33_workspace ok")


def test_trial34_view_presets():
    import os
    import tempfile
    from datetime import date as _date
    data = build_sample_data()
    # 進行中・今後の判定（今日を渡して決定的に）
    b = data.projects[0]
    assert not md.is_current_or_future(b, _date(2027, 1, 1))   # 終了済み
    assert md.is_current_or_future(b, _date(2026, 5, 1))       # 進行中
    empty = md.Project(name="空")
    assert md.is_current_or_future(empty, _date(2027, 1, 1))   # タスク無しは対象
    # 表示プリセットが置き場の common.json に残る
    data.view_presets.append(md.ViewPreset(
        name="横断", project_ids=[data.projects[0].id, data.projects[-1].id]))
    with tempfile.TemporaryDirectory() as td:
        root = os.path.join(td, "data")
        md.save_workspace(data, root, ["プラントA", "プラントB"])
        data2, _plants = md.load_workspace(root)
    assert len(data2.view_presets) == 1
    assert data2.view_presets[0].project_ids == data.view_presets[0].project_ids
    print("test_trial34_view_presets ok")


def test_trial38_excel_columns():
    import os
    import tempfile
    from openpyxl import load_workbook
    from kouteihyo.exports import export_excel
    from kouteihyo.sample import build_sample_data
    data = build_sample_data()
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "out.xlsx")
        export_excel(data, data.projects[0], path)
        wb = load_workbook(path)
    ws = wb["日付表"]
    headers = [c.value for c in ws[2]]
    assert headers == ["工程", "開始", "終了", "期間（営業日）", "作業時間",
                       "作業内容", "カレンダー"], headers
    assert ws["A3"].value == "現場調査準備"   # 先頭列は工程名になった
    print("test_trial38_excel_columns ok")


def test_trial44_task_hours():
    """Trial44: 作業時間 = 属性の時間 or 人工×8h。"""
    from datetime import date
    data = build_sample_data()
    proj = data.projects[0]
    draw = next(t for t in proj.tasks if t.name == "図面作成")
    h = md.task_hours(data, draw)
    # 属性に時間設定がある役割はその時間（作成54・チェック18）
    assert h["作成"] == 54 and h["チェック"] == 18, h
    assert h["合計"] == 72, h
    # 属性の無い項目は 人工×8h（既定）
    prep = next(t for t in proj.tasks if t.name == "現場調査準備")
    j = md.task_jinko(prep)
    h2 = md.task_hours(data, prep)
    assert h2["合計"] == j["合計"] * 8.0, (h2, j)
    # 工事合計と月別の整合
    total = md.project_hours_total(data, proj)
    monthly = md.monthly_hours(data, proj)
    assert abs(sum(monthly.values()) - total) < 0.01, (monthly, total)
    # 既定は8時間、旧既定値7.75は読み込み時に移行する
    assert md.Settings().hours_per_day == 8.0
    d = md.data_to_dict(data)
    d["settings"]["hours_per_day"] = 7.75
    d["settings"].pop("hours_per_day_set", None)
    data2 = md.data_from_dict(d)
    assert data2.settings.hours_per_day == 8.0, data2.settings
    # 利用者が明示設定した7.75は移行しない
    d["settings"]["hours_per_day_set"] = True
    data3 = md.data_from_dict(d)
    assert data3.settings.hours_per_day == 7.75, data3.settings
    print("trial44 task hours ok")


if __name__ == "__main__":
    test_workdays()
    test_sample_and_jinko()
    test_overlap_ops()
    test_json_roundtrip()
    test_preset_from_project()
    test_trial24_holidays_and_save()
    test_trial25_app_dir_frozen()
    test_trial31_excel_style()
    test_trial32_pdf_multi()
    test_trial33_workspace()
    test_trial34_view_presets()
    test_trial38_excel_columns()
    test_trial44_task_hours()
    # 役割の色分け（Trial14）: 固定色と決定的な割り当て
    assert md.role_color("作成") == "#2f6db3"
    assert md.role_color("チェック") == "#d2691e"
    assert md.role_color("作成") != md.role_color("チェック")
    assert md.role_color("積算") == md.role_color("積算")
    assert md.role_color("積算") in md.ROLE_PALETTE
    print("ALL MODEL TESTS PASSED")







