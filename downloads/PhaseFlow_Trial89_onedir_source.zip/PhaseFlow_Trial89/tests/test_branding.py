# -*- coding: utf-8 -*-
"""PhaseFlow branding and old view-settings compatibility tests."""
import json
from pathlib import Path
from kouteihyo import model as md
from kouteihyo.sample import build_sample_data


def test_personal_settings_migrate_from_old_appname(tmp_path, monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA', str(tmp_path / 'local'))
    root = tmp_path / 'shared' / 'data'
    path = md._personal_path(root)
    assert 'PhaseFlow' in path.parts
    legacy = path.parent.parent.parent / 'Kouteihyo' / 'view_settings' / path.name
    legacy.parent.mkdir(parents=True)
    legacy.write_text(json.dumps({'show_jinko': False}), encoding='utf-8')
    data = build_sample_data()
    data.settings.show_jinko = True
    md._load_personal(data, root)
    assert not data.settings.show_jinko
    md._save_personal(data, root)
    assert path.exists() and legacy.exists()
    newer = build_sample_data()
    newer.settings.show_jinko = True
    md._load_personal(newer, root)
    assert not newer.settings.show_jinko


def test_release_icon_exists_and_is_multisize():
    from PIL import Image
    from pathlib import Path
    assets = Path(__file__).resolve().parents[1] / 'kouteihyo' / 'assets'
    assert (assets / 'icon.png').is_file()
    with Image.open(assets / 'icon.ico') as im:
        sizes = im.ico.sizes()
        for size in [16, 32, 48, 256]:
            assert (size,size) in sizes
