# -*- coding: utf-8 -*-
"""ガントのドラッグ模擬テスト：移動／左端リサイズ／右端リサイズ／ホバー／拡大ON。

実機報告「端をつまんでも移動になってしまう」の回帰テスト。
- 端の判定幅は14px（旧7px）: 右端-10px地点でも resize_r になること
- 短いバーは幅の1/3が端になること
- 拡大ON時は掴んだ端がマウスの真下に残る（アンカー）こと
"""
import os
import sys
from datetime import timedelta

sys.path.insert(0, __file__.rsplit("/tests/", 1)[0])
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import QEvent, QPointF, Qt
from PySide6.QtGui import QMouseEvent
from PySide6.QtWidgets import QApplication

from kouteihyo import model as md
from kouteihyo.gantt import GanttWidget
from kouteihyo.sample import build_sample_data


def mouse(kind, x, y):
    btn = Qt.MouseButton.LeftButton
    return QMouseEvent(kind, QPointF(x, y), btn, btn,
                       Qt.KeyboardModifier.NoModifier)


def press(w, x, y):
    w.mousePressEvent(mouse(QEvent.Type.MouseButtonPress, x, y))


def move(w, x, y):
    w.mouseMoveEvent(mouse(QEvent.Type.MouseMove, x, y))


def release(w, x, y):
    w.mouseReleaseEvent(mouse(QEvent.Type.MouseButtonRelease, x, y))


def fresh_widget():
    data = build_sample_data()
    proj = data.projects[0]
    w = GanttWidget()
    w.resize(1176, 640)
    w.set_project(proj)
    w.view_days = 100          # px = (1176-176)/100 = 10.0 ちょうど
    w._layout()
    task = next(t for t in proj.tasks if t.name == "図面作成")
    row = next(r for r in w._rows if r[0] == "task" and r[2].id == task.id)
    return w, proj, task, row[3]


def bar(w, task, y):
    return w._bar_rect(task, y)


def main():
    app = QApplication(sys.argv)

    # --- 1) 右端-10px（旧7px幅では移動になっていた地点）が resize_r になる ---
    w, proj, task, y = fresh_widget()
    rect = bar(w, task, y)
    cy = y + 17
    t_hit, mode = w._hit(QPointF(rect.right() - 10, cy))
    assert t_hit is task and mode == "resize_r", mode
    t_hit, mode = w._hit(QPointF(rect.x() + 10, cy))
    assert t_hit is task and mode == "resize_l", mode
    t_hit, mode = w._hit(QPointF(rect.center().x(), cy))
    assert t_hit is task and mode == "move", mode
    # バーの上下余白（行内）でも端判定される
    t_hit, mode = w._hit(QPointF(rect.right() - 5, y + 2))
    assert mode == "resize_r", mode
    print("hit ok")

    # --- 2) ホバーで端カーソル（↔）になる ---
    w, proj, task, y = fresh_widget()
    rect = bar(w, task, y)
    move(w, rect.right() - 5, y + 17)
    assert w._hover_mode == "resize_r", w._hover_mode
    assert w.cursor().shape() == Qt.CursorShape.SizeHorCursor, w.cursor().shape()
    move(w, rect.center().x(), y + 17)
    assert w._hover_mode == "move", w._hover_mode
    print("hover ok")

    # --- 3) 右端ドラッグで開始は不変・終了だけ伸びる（+7日） ---
    w, proj, task, y = fresh_widget()
    rect = bar(w, task, y)
    s0, e0 = task.dstart, task.dend
    press(w, rect.right() - 3, y + 17)
    assert w._pending and w._pending["mode"] == "resize_r", w._pending
    move(w, rect.right() - 3 + 70, y + 17)   # px=10 → +7日
    assert w._drag and w._drag["mode"] == "resize_r", w._drag
    release(w, rect.right() - 3 + 70, y + 17)
    assert task.dstart == s0, (task.dstart, s0)
    assert task.dend == e0 + timedelta(days=7), (task.dend, e0)
    print("resize_r ok", s0, e0, "->", task.dend)

    # --- 4) 左端ドラッグで終了は不変・開始だけ前へ（-7日） ---
    w, proj, task, y = fresh_widget()
    rect = bar(w, task, y)
    s0, e0 = task.dstart, task.dend
    press(w, rect.x() + 3, y + 17)
    assert w._pending and w._pending["mode"] == "resize_l", w._pending
    move(w, rect.x() + 3 - 70, y + 17)
    release(w, rect.x() + 3 - 70, y + 17)
    assert task.dend == e0, (task.dend, e0)
    # 土日祝日にもそのまま置ける（Trial39）：5/4（祝日）に開始が来る
    expect = s0 - timedelta(days=7)
    assert task.dstart == expect, (task.dstart, expect)
    print("resize_l ok", s0, "->", task.dstart, e0)

    # --- 5) 中央ドラッグは移動（期間＝営業日数は不変、+7日） ---
    w, proj, task, y = fresh_widget()
    rect = bar(w, task, y)
    s0, e0 = task.dstart, task.dend
    dur0 = md.workdays_between(s0, e0, task.calendar)
    press(w, rect.center().x(), y + 17)
    assert w._pending and w._pending["mode"] == "move", w._pending
    move(w, rect.center().x() + 70, y + 17)
    release(w, rect.center().x() + 70, y + 17)
    assert task.dstart == s0 + timedelta(days=7), (task.dstart, s0)
    assert task.dend == e0 + timedelta(days=7), (task.dend, e0)
    assert md.workdays_between(task.dstart, task.dend, task.calendar) == dur0
    print("move ok", s0, e0, "->", task.dstart, task.dend)

    # --- 6) ドラッグでは拡大しない／ホイールで拡大縮小（Trial55） ---
    w, proj, task, y = fresh_widget()
    saved = (w.view_start, w.view_days)
    rect = bar(w, task, y)
    s0, e0 = task.dstart, task.dend
    press_x = rect.right() - 3
    press(w, press_x, y + 17)
    assert w._drag is None and w._pending is not None
    move(w, press_x + 10, y + 17)   # しきい値（7px）を超えたら開始
    assert w._drag and w._drag["mode"] == "resize_r", w._drag
    assert (w.view_start, w.view_days) == saved, "ドラッグで表示が変わった"
    move(w, press_x + 70, y + 17)    # px=10 → +7日
    release(w, press_x + 70, y + 17)
    assert task.dstart == s0 and task.dend == e0 + timedelta(days=7)
    assert (w.view_start, w.view_days) == saved
    # ホイール: カーソル下の日を基点に拡縮する
    anchor_x = rect.center().x()
    anchor_date = w.date_at(anchor_x)
    w.zoom_by(1.0, anchor_x)
    assert w.view_days == 85, w.view_days
    assert abs((w.date_at(anchor_x) - anchor_date).days) <= 1
    w.zoom_by(30.0, anchor_x)
    assert w.view_days == 14, w.view_days     # 下限クランプ
    w.zoom_by(-60.0, anchor_x)
    assert w.view_days == 400, w.view_days    # 上限クランプ
    # ホイールは Ctrl 併用のときだけ拡縮し、単独では受け付けない（Trial56）
    from PySide6.QtCore import QPoint
    from PySide6.QtGui import QWheelEvent

    def wheel(mods):
        ev = QWheelEvent(QPointF(anchor_x, y + 17), QPointF(anchor_x, y + 17),
                         QPoint(0, 0), QPoint(0, 120),
                         Qt.MouseButton.NoButton, mods,
                         Qt.ScrollPhase.NoScrollPhase, False)
        w.wheelEvent(ev)
        return ev.isAccepted()
    days0 = w.view_days
    assert not wheel(Qt.KeyboardModifier.NoModifier)
    assert w.view_days == days0
    assert wheel(Qt.KeyboardModifier.ControlModifier)
    assert w.view_days < days0
    print("wheel zoom ok")

    # --- 7) 短いクリックではドラッグしない（Trial50→55で継続） ---
    w, proj, task, y = fresh_widget()
    saved = (w.view_start, w.view_days)
    rect = bar(w, task, y)
    s0, e0 = task.dstart, task.dend
    press(w, rect.right() - 3, y + 17)
    move(w, rect.right() - 1, y + 18)        # 2pxだけ（しきい値未満）
    release(w, rect.right() - 1, y + 18)
    assert w._drag is None and w._pending is None
    assert (w.view_start, w.view_days) == saved
    assert task.dstart == s0 and task.dend == e0
    print("short click ok")

    print("ALL GANTT DRAG TESTS PASSED")


if __name__ == "__main__":
    main()
