# -*- coding: utf-8 -*-
"""複数編集セッションと保存の整合性に対する回帰テスト (Qt不要)。"""
import copy
import json
import os
from datetime import date
from pathlib import Path

import pytest

from kouteihyo import model as md
from kouteihyo.concurrency import WorkspaceConflict, WorkspaceLock


def create_workspace(tmp_path, monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA', str(tmp_path / 'localsettings'))
    root = tmp_path / 'shared'
    data = md.AppData(projects=[
        md.Project(id='aaa', name='同名', plant='P'),
        md.Project(id='bbb', name='同名', plant='P')])
    md.save_workspace(data, root, ['P'])
    return root


def open_client(root):
    data, plants = md.load_workspace(root)
    return data, plants, md.WorkspaceSession(root, data)


def test_same_name_id_produces_distinct_files(tmp_path, monkeypatch):
    root = create_workspace(tmp_path, monkeypatch)
    files = sorted((root / 'P').glob('*.json'))
    assert len(files) == 2
    assert len(md.load_workspace(root)[0].projects) == 2
    assert files[0].name != files[1].name


def test_lock_and_owner(tmp_path):
    a = WorkspaceLock(tmp_path, 'project_same')
    b = WorkspaceLock(tmp_path, 'project_same')
    try:
        assert a.acquire()
        assert not b.acquire()
        assert ' @ ' in b.owner()
    finally:
        a.release()
    assert b.acquire()
    b.release()


def test_parallel_different_projects_do_not_overwrite(tmp_path, monkeypatch):
    root = create_workspace(tmp_path, monkeypatch)
    a, plants, session_a = open_client(root)
    b, plants_b, session_b = open_client(root)
    try:
        assert session_a.claim('aaa')[0]
        assert not session_b.claim('aaa')[0]
        assert session_b.claim('bbb')[0]
        a.projects[0].name = '作業者Aの変更'
        b.projects[1].name = '作業者Bの変更'
        session_a.save(a, plants)
        session_b.save(b, plants_b)
        result, _ = md.load_workspace(root)
        assert {p.name for p in result.projects} == {'作業者Aの変更', '作業者Bの変更'}
        assert len(list((root / 'P').glob('*.json'))) == 2
    finally:
        session_a.close()
        session_b.close()


def test_stale_save_is_rejected_even_after_lock_release(tmp_path, monkeypatch):
    root = create_workspace(tmp_path, monkeypatch)
    a, plants, session_a = open_client(root)
    b, plants_b, session_b = open_client(root)
    try:
        assert session_a.claim('aaa')[0]
        a.projects[0].name = '先に保存'
        session_a.save(a, plants)
        assert session_b.claim('aaa')[0]
        b.projects[0].name = '遅れて保存'
        with pytest.raises(WorkspaceConflict):
            session_b.save(b, plants_b)
        assert next(p.name for p in md.load_workspace(root)[0].projects if p.id == 'aaa') == '先に保存'
    finally:
        session_a.close()
        session_b.close()


def test_unlocked_modified_project_cannot_be_saved(tmp_path, monkeypatch):
    root = create_workspace(tmp_path, monkeypatch)
    data, plants, s = open_client(root)
    data.projects[0].name = 'ロックなし変更'
    with pytest.raises(WorkspaceConflict):
        s.save(data, plants)
    s.close()
    assert next(p.name for p in md.load_workspace(root)[0].projects if p.id == 'aaa') == '同名'


def test_concurrent_additions_merge_orders(tmp_path, monkeypatch):
    root = create_workspace(tmp_path, monkeypatch)
    a, plants, sa = open_client(root)
    b, plants_b, sb = open_client(root)
    try:
        a.projects.append(md.Project(id='ccc', name='追加A', plant='P'))
        b.projects.append(md.Project(id='ddd', name='追加B', plant='P'))
        assert sa.claim('ccc')[0]
        assert sb.claim('ddd')[0]
        sa.save(a, plants)
        sb.save(b, plants_b)
        result, _ = md.load_workspace(root)
        assert len(result.projects) == 4
        assert {p.id for p in result.projects} == {'aaa', 'bbb', 'ccc', 'ddd'}
        assert len(json.loads((root / 'common.json').read_text())['project_order']) == 4
    finally:
        sa.close()
        sb.close()


def test_common_conflicting_edit_rejected(tmp_path, monkeypatch):
    root = create_workspace(tmp_path, monkeypatch)
    a, plants, sa = open_client(root)
    b, plants_b, sb = open_client(root)
    try:
        a.masters.append(md.Master(id='m1', name='A'))
        b.masters.append(md.Master(id='m2', name='B'))
        sa.save(a, plants)
        with pytest.raises(WorkspaceConflict):
            sb.save(b, plants_b)
        assert [m.name for m in md.load_workspace(root)[0].masters] == ['A']
    finally:
        sa.close()
        sb.close()


def test_read_only_refresh_uses_remote_update(tmp_path, monkeypatch):
    root = create_workspace(tmp_path, monkeypatch)
    a, plants, sa = open_client(root)
    b, plants_b, sb = open_client(root)
    try:
        assert sa.claim('aaa')[0]
        assert not sb.claim('aaa')[0]
        a.projects[0].name = '最新の内容'
        sa.save(a, plants)
        assert 'aaa' in sb.refresh(b)
        assert next(p.name for p in b.projects if p.id == 'aaa') == '最新の内容'
    finally:
        sa.close()
        sb.close()


def test_calendar_all_includes_holiday_and_role_span_is_full():
    assert md.is_workday(date(2026, 1, 1), 'all')
    assert not md.is_workday(date(2026, 1, 1), 'standard')
    task = md.Task(start='2026-05-04', end='2026-05-10', calendar='standard')
    # Trial69: 「終盤」指定は廃止。旧データに mode='last' が残っていても全期間になる
    role = md.RoleDef(name='作成', headcount=1, mode='last', days=1)
    s, e, n = md.role_span(task, role)
    assert (s, e) == (task.dstart, task.dend)
    assert n == md.task_duration_bd(task)


def test_other_process_cannot_acquire_lock(tmp_path):
    import subprocess
    import sys
    first = WorkspaceLock(tmp_path, 'cross_process')
    child_code = (
        "from kouteihyo.concurrency import WorkspaceLock; import sys; "
        "lock=WorkspaceLock(sys.argv[1], 'cross_process'); print(lock.acquire()); lock.release()"
    )
    cwd = str(Path(__file__).resolve().parents[1])
    try:
        assert first.acquire()
        result = subprocess.run([sys.executable, '-c', child_code, str(tmp_path)],
                                cwd=cwd, capture_output=True, text=True, check=True)
        assert result.stdout.strip() == 'False'
    finally:
        first.release()
    result = subprocess.run([sys.executable, '-c', child_code, str(tmp_path)],
                            cwd=cwd, capture_output=True, text=True, check=True)
    assert result.stdout.strip() == 'True'


def test_only_modified_file_is_rewritten(tmp_path, monkeypatch):
    root = create_workspace(tmp_path, monkeypatch)
    data, plants, session = open_client(root)
    untouched = next(p for p in (root / 'P').glob('*.json') if '__bbb.' in p.name)
    raw = untouched.read_bytes()
    before_mtime = untouched.stat().st_mtime_ns
    try:
        assert session.claim('aaa')[0]
        data.projects[0].name = '変更した工事'
        session.save(data, plants)
        assert untouched.read_bytes() == raw
        assert untouched.stat().st_mtime_ns == before_mtime
    finally:
        session.close()


def test_local_view_settings_are_not_saved_to_common(tmp_path, monkeypatch):
    root = create_workspace(tmp_path, monkeypatch)
    data, plants, session = open_client(root)
    data.settings.view_mode = 'preset'
    data.settings.show_jinko = True
    try:
        session.save(data, plants)
    finally:
        session.close()
    shared = json.loads((root / 'common.json').read_text(encoding='utf-8'))
    assert 'view_mode' not in shared['settings']
    assert 'show_jinko' not in shared['settings']
    loaded, _ = md.load_workspace(root)
    assert loaded.settings.view_mode == 'preset'
    assert loaded.settings.show_jinko is True
