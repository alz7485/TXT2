import json
import pytest
from kouteihyo import model as md


def test_empty_definitions_stay_empty_and_legacy_migrates():
    master = md.Master(id='m', attrs=[md.AttrDef(name='作業A')])
    task = md.Task(master_id='m', attr_defs=[])
    data = md.AppData(masters=[master], projects=[md.Project(tasks=[task])])
    raw = md.data_to_dict(data)
    assert md.data_from_dict(raw).projects[0].tasks[0].attr_defs == []
    del raw['projects'][0]['tasks'][0]['attr_defs']
    migrated = md.data_from_dict(raw)
    assert migrated.projects[0].tasks[0].attr_defs[0].name == '作業A'
    migrated.projects[0].tasks[0].attr_defs.clear()
    md.ensure_attr_defs(migrated)
    assert migrated.projects[0].tasks[0].attr_defs == []


def workspace(tmp_path, monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA', str(tmp_path / 'local'))
    root = tmp_path / 'shared'
    data = md.AppData(projects=[md.Project(id='a',name='A',plant='P'),
                                md.Project(id='b',name='B',plant='P')])
    md.save_workspace(data, root, ['P'])
    return root


def snapshot(root):
    return {str(p.relative_to(root)): p.read_bytes() for p in md._workspace_json_files(root)}


@pytest.mark.parametrize("failure_number", [1, 2, 3])
def test_partial_save_rolls_back_and_can_retry(tmp_path, monkeypatch, failure_number):
    root = workspace(tmp_path, monkeypatch)
    before = snapshot(root)
    data, plants = md.load_workspace(root)
    session = md.WorkspaceSession(root, data)
    for project in data.projects:
        assert session.claim(project.id)[0]
        project.name += ' edited'
    data.masters.append(md.Master(name="new master"))
    original_projects = list(data.projects)
    original = md._write_with_backup
    count = 0
    def failing(text, path):
        nonlocal count
        if str(path).startswith(str(root)):
            count += 1
            if count == failure_number:
                raise OSError('simulated disk failure')
        original(text, path)
    try:
        with monkeypatch.context() as patch:
            patch.setattr(md, '_write_with_backup', failing)
            with pytest.raises(OSError):
                session.save(data, plants)
        assert snapshot(root) == before
        assert all(p is original for p, original in zip(data.projects, original_projects))
        assert all(p.name.endswith(' edited') for p in data.projects)
        session.save(data, plants)
        assert all(p.name.endswith(' edited') for p in md.load_workspace(root)[0].projects)
    finally:
        session.close()


def test_interrupted_save_restores_on_open(tmp_path, monkeypatch):
    root = workspace(tmp_path, monkeypatch)
    before = snapshot(root)
    md._begin_save(root)
    (root / 'common.json').write_text('{}')
    next((root / 'P').glob('*.json')).unlink()
    (root / 'P' / 'new.json').write_text('{}')
    md.load_workspace(root)
    assert snapshot(root) == before
    assert not (root / md._SAVE_JOURNAL).exists()


def test_corrupt_files_reported(tmp_path, monkeypatch):
    root = workspace(tmp_path, monkeypatch)
    (root / 'common.json').write_text('{broken')
    (root / 'P' / 'broken.json').write_text('{broken')
    data, _ = md.load_workspace(root)
    assert len(data.projects) == 2
    assert len(data._load_errors) == 2
    assert any('common.json' in error for error in data._load_errors)


def test_invalid_journal_does_not_touch_files(tmp_path, monkeypatch):
    root = workspace(tmp_path, monkeypatch)
    before = snapshot(root)
    (root / md._SAVE_JOURNAL).write_text(json.dumps({'../../outside.json':'e30='}))
    with pytest.raises(ValueError):
        md.load_workspace(root)
    assert snapshot(root) == before


def test_failed_recovery_keeps_journal_for_next_open(tmp_path, monkeypatch):
    root = workspace(tmp_path, monkeypatch)
    before = snapshot(root)
    data, plants = md.load_workspace(root)
    session = md.WorkspaceSession(root, data)
    assert session.claim('a')[0]
    data.projects[0].name = 'changed'
    original = md._atomic_bytes
    def fail_restore(path, raw):
        if path.name != md._SAVE_JOURNAL:
            raise OSError('temporary recovery failure')
        return original(path, raw)
    def fail_write(*args):
        raise OSError('disk failure')
    try:
        with monkeypatch.context() as patch:
            patch.setattr(md, '_write_with_backup', fail_write)
            patch.setattr(md, '_atomic_bytes', fail_restore)
            with pytest.raises(RuntimeError, match='次回起動時'):
                session.save(data, plants)
        assert (root / md._SAVE_JOURNAL).exists()
    finally:
        session.close()
    md.load_workspace(root)
    assert snapshot(root) == before


def test_real_process_exit_recovers(tmp_path, monkeypatch):
    import os
    import subprocess
    import sys
    root = workspace(tmp_path, monkeypatch)
    before = snapshot(root)
    script = '''
import os, sys
from kouteihyo import model as md
root = md.Path(sys.argv[1])
data, plants = md.load_workspace(root)
session = md.WorkspaceSession(root, data)
for project in data.projects:
    assert session.claim(project.id)[0]
    project.name += " changed"
original = md._write_with_backup
count = 0
def interrupted(text, path):
    global count
    original(text, path)
    if str(path).startswith(str(root)):
        count += 1
        if count == 1:
            os._exit(23)
md._write_with_backup = interrupted
session.save(data, plants)
'''
    result = subprocess.run([sys.executable, '-c', script, str(root)],
                            env=os.environ.copy(), timeout=30)
    assert result.returncode == 23
    assert (root / md._SAVE_JOURNAL).exists()
    md.load_workspace(root)
    assert snapshot(root) == before


def test_gui_reports_corrupt_common_and_disables_save(tmp_path, monkeypatch):
    from PySide6.QtWidgets import QApplication, QMessageBox
    from kouteihyo.main_window import MainWindow
    app = QApplication.instance() or QApplication([])
    root = workspace(tmp_path, monkeypatch)
    (root / 'common.json').write_text('{broken')
    data, plants = md.load_workspace(root)
    messages = []
    monkeypatch.setattr(QMessageBox, 'warning', lambda *args: messages.append(args[2]))
    window = MainWindow(data, str(root), plants)
    try:
        app.processEvents()
        assert 'common.json' in window.workspace_error
        assert 'backup' in window.workspace_error
        assert window.edit_session is None
        assert window._save() is False
        assert messages and 'common.json' in messages[0]
        assert (root / 'common.json').read_text() == '{broken'
    finally:
        window.dirty = False
        window.close()
