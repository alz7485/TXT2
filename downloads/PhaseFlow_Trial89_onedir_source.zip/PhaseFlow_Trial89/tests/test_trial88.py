"""Item editing: searchable selection, draft isolation and numeric unit hours."""
import copy
import pytest
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QDialog, QMessageBox
from kouteihyo import model as md
from kouteihyo.dialogs import ItemPresetDialog, MasterDialog
from kouteihyo.item_editor import MasterLibrary
from kouteihyo.sample import build_sample_data


@pytest.fixture
def sample():
    return build_sample_data()


def test_preset_search_preview_and_correct_id(sample):
    extra = copy.deepcopy(sample.presets[0])
    extra.id = 'second'
    extra.name = '検査専用'
    sample.presets.append(extra)
    dialog = ItemPresetDialog(sample)
    try:
        dialog.search.setText('検査')
        assert dialog.list.count() == 1
        assert dialog.preview_title.text() == '検査専用'
        assert dialog.preview_table.rowCount() == len(extra.entries)
        dialog._apply()
        assert dialog.apply_id == 'second'
    finally:
        dialog.close()


def test_no_matches_and_missing_master_cannot_apply(sample):
    dialog = ItemPresetDialog(sample)
    try:
        dialog.search.setText('not-a-preset')
        assert dialog.list.count() == 0
        assert not dialog.apply_btn.isEnabled() and not dialog.del_btn.isEnabled()
        dialog._apply()
        assert not dialog.apply_id
        dialog.search.clear()
        sample.masters.remove(sample.master_by_id(sample.presets[0].entries[0].master_id))
        dialog._preview()
        assert not dialog.apply_btn.isEnabled()
        assert '未登録' in dialog.preview_hint.text()
    finally:
        dialog.close()


def test_search_enter_does_not_apply_or_save(sample):
    called = []
    dialog = ItemPresetDialog(sample, on_save=lambda: called.append(True))
    try:
        dialog.show()
        dialog.search.setFocus()
        QTest.keyClick(dialog.search, Qt.Key.Key_Return)
        QApplication.processEvents()
        assert dialog.isVisible() and not dialog.apply_id and not called
    finally:
        dialog.close()


def test_saved_preset_selected_even_after_search(sample):
    def save():
        sample.presets.append(md.Preset(id='new', name='新しい並び'))
    dialog = ItemPresetDialog(sample, on_save=save)
    try:
        dialog.search.setText('検索結果なし')
        dialog._save()
        assert dialog.search.text() == ''
        assert dialog._selected().id == 'new'
        assert dialog.changed
    finally:
        dialog.close()


def test_library_search_uses_id_not_original_row(sample, monkeypatch):
    library = MasterLibrary(sample)
    try:
        library.search.setText('図面作成')
        assert library.list.count() == 1
        selected = library.current()
        assert selected.name == '図面作成'
        assert library.attrs.rowCount() == len(selected.attrs)
        monkeypatch.setattr(QMessageBox, 'question', lambda *a: QMessageBox.StandardButton.Yes)
        library._delete()
        assert sample.master_by_id(selected.id) is None
        assert library.list.count() == 0
        assert not library.edit_btn.isEnabled()
        assert len(sample.masters) == 10
    finally:
        library.close()


def test_duplicate_master_is_independent_and_new_id(sample, monkeypatch):
    library = MasterLibrary(sample)
    original = sample.master_by_name('図面作成')
    library.refresh(select_id=original.id)
    monkeypatch.setattr(MasterDialog, 'exec', lambda self: QDialog.DialogCode.Accepted)
    try:
        library._duplicate()
        duplicate = library.current()
        assert duplicate.id != original.id
        assert duplicate.name == '図面作成 のコピー'
        duplicate.attrs[0].hours['作成'] = 999
        assert original.attrs[0].hours['作成'] == 3
    finally:
        library.close()


def test_master_cancel_does_not_mutate_original(sample):
    master = sample.master_by_name('図面作成')
    before = copy.deepcopy(master)
    dialog = MasterDialog(master)
    try:
        dialog.name_edit.setText('キャンセルする編集')
        dialog.roles_table.item(0, 0).setText('別の役割')
        dialog.attrs_table.cellWidget(0, 2).setValue(88)
        dialog.reject()
        assert master == before
    finally:
        dialog.close()


def test_numeric_rates_rename_and_unknown_roles_survive(sample):
    master = sample.master_by_name('図面作成')
    master.attrs[0].hours['旧役割'] = .123456789
    dialog = MasterDialog(master)
    try:
        dialog.attrs_table.cellWidget(0, 2).setValue(4.5)
        dialog.roles_table.item(0, 0).setText('作図')
        result = dialog.result_master()
        assert result.roles[0].name == '作図'
        assert result.attrs[0].hours['作図'] == 4.5
        assert '作成' not in result.attrs[0].hours
        assert result.attrs[0].hours['旧役割'] == .123456789
    finally:
        dialog.close()


def test_duplicate_role_then_correction_does_not_move_other_rates(sample):
    dialog = MasterDialog(sample.master_by_name('図面作成'))
    try:
        dialog.roles_table.item(0, 0).setText('チェック')
        dialog.accept()
        assert dialog.result() != QDialog.DialogCode.Accepted
        assert '重複' in dialog.error_label.text()
        dialog.roles_table.item(0, 0).setText('作図')
        result = dialog.result_master()
        assert result.attrs[0].hours == {'作図': 3, 'チェック': 1}
    finally:
        dialog.close()


def test_delete_role_retains_legacy_rates_and_empty_attributes_stay_empty(sample):
    dialog = MasterDialog(sample.master_by_name('図面作成'))
    try:
        dialog.roles_table.setCurrentCell(0, 0)
        dialog._del_row(dialog.roles_table)
        assert any('未登録' in dialog.attrs_table.horizontalHeaderItem(col).text()
                   for col in range(dialog.attrs_table.columnCount()))
        assert dialog.result_master().attrs[0].hours['作成'] == 3
        while dialog.attrs_table.rowCount():
            dialog.attrs_table.setCurrentCell(0, 0)
            dialog._del_row(dialog.attrs_table)
        assert dialog.result_master().attrs == []
    finally:
        dialog.close()


def test_master_requires_name_and_shows_milestone_preview():
    dialog = MasterDialog()
    try:
        dialog.accept()
        assert dialog.result() != QDialog.DialogCode.Accepted
        assert '項目名' in dialog.error_label.text()
        dialog.name_edit.setText('<節目>')
        dialog.mile_check.setChecked(True)
        assert not dialog.days_spin.isEnabled()
        assert '<節目>' in dialog.bar_preview.text()
        dialog.accept()
        assert dialog.result() == QDialog.DialogCode.Accepted
    finally:
        dialog.close()


def test_read_only_project_cannot_apply(sample):
    from kouteihyo.main_window import MainWindow
    window = MainWindow(sample)
    window._read_only = True
    dialog = ItemPresetDialog(sample, window)
    try:
        assert not dialog.apply_btn.isEnabled()
        dialog._apply()
        assert not dialog.apply_id
        assert '閲覧専用' in dialog.notice.text()
    finally:
        dialog.close()
        window.dirty = False
        window.close()


@pytest.mark.parametrize('width', [752, 960])
def test_editor_layout_at_compact_and_regular_widths(sample, width):
    from kouteihyo.fontutil import font
    app = QApplication.instance()
    previous = app.font()
    app.setFont(font(10))
    hub = ItemPresetDialog(sample, on_save=lambda: None)
    editor = MasterDialog(sample.master_by_name('図面作成'))
    try:
        for dialog in (hub, editor):
            dialog.show()
            app.processEvents()
            dialog.resize(width, 700)
            app.processEvents()
            assert dialog.width() == width
        for page in (0, 1):
            hub.tabs.setCurrentIndex(page)
            editor.editor_tabs.setCurrentIndex(page)
            app.processEvents()
            actions = [hub.close_btn, hub.apply_btn] if page == 0 else [hub.library.add_btn, hub.library.copy_btn]
            for btn in actions:
                assert btn.width() >= btn.sizeHint().width()
                assert not btn.icon().isNull()
        assert editor.attrs_table.horizontalScrollBar().maximum() == 0
        for row in range(editor.attrs_table.rowCount()):
            for col in range(2, editor.attrs_table.columnCount()):
                spin = editor.attrs_table.cellWidget(row, col)
                assert not spin.text().startswith('3.0000')
        assert editor.add_attr_btn.width() >= editor.add_attr_btn.sizeHint().width()
    finally:
        hub.close()
        editor.reject()
        app.setFont(previous)


def test_master_filter_and_add_role_then_rate(sample):
    library = MasterLibrary(sample)
    editor = MasterDialog()
    try:
        library.filter.setCurrentIndex(library.filter.findData('milestone'))
        assert library.list.count() > 0
        for row in range(library.list.count()):
            assert sample.master_by_id(library.list.item(row).data(Qt.ItemDataRole.UserRole)).milestone
        assert '役割を追加' in editor.hours_hint.text()
        editor._add_role_row(md.RoleDef('担当', 2))
        editor._add_attr_row(md.AttrDef('新規作業', '件', {}))
        editor.attrs_table.cellWidget(0, 2).setValue(.75)
        result = editor.result_master()
        assert result.attrs[0].hours == {'担当': .75}
        assert result.roles[0].headcount == 2
    finally:
        library.close()
        editor.reject()
