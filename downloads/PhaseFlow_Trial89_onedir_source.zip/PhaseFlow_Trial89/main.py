# -*- coding: utf-8 -*-
"""PhaseFlow — 起動入口。

データはアプリ（EXE）の隣の data フォルダ（置き場）に、
common.json ＋ プラントごとのフォルダ ＋ 工事ごとの JSON で持つ。
旧 data.json があれば、プラント名を聞いて置き場へ移行する。
どちらも無ければサンプルデータで起動する。
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication, QInputDialog, QMessageBox

from kouteihyo import model as md
from kouteihyo.main_window import MainWindow
from kouteihyo.sample import build_sample_data


def main():
    app = QApplication(sys.argv)
    from kouteihyo.ui import install_ui
    install_ui()
    app.setApplicationName("PhaseFlow")
    app.setApplicationDisplayName("PhaseFlow")
    from kouteihyo.fontutil import font
    app.setFont(font(10))
    # Qt標準ボタンを日本語にする（同梱の公式訳を読む。失敗しても続行）
    from PySide6.QtCore import QLibraryInfo, QTranslator
    app._translators = []
    for name in ("qtbase_ja", "qt_ja"):
        tr = QTranslator(app)
        if tr.load(name, QLibraryInfo.path(
                QLibraryInfo.LibraryPath.TranslationsPath)):
            app.installTranslator(tr)
            app._translators.append(tr)
    from kouteihyo.icons import app_icon
    app.setWindowIcon(app_icon())
    root = md.workspace_root()
    legacy = md.app_dir() / "data.json"
    if root.exists():
        try:
            data, plants = md.load_workspace(root)
        except Exception as error:
            QMessageBox.critical(None, "置き場を開けません", str(error))
            return
        win = MainWindow(data, str(root), plants)
    elif legacy.exists():
        name, ok = QInputDialog.getText(
            None, "データの移行",
            "これまでの data.json を置き場の形式へ移行します。\n"
            "既存の工事を入れるプラント名を入力してください。",
            text="プラント1")
        data = md.migrate_legacy(str(legacy), root,
                                 name if ok and name.strip() else "プラント1")
        win = MainWindow(data, str(root),
                         sorted({p.plant for p in data.projects}))
    else:
        win = MainWindow(build_sample_data(), str(root))
    win.show()
    if win.data.projects:
        QTimer.singleShot(0, win.show_startup_guide)
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
