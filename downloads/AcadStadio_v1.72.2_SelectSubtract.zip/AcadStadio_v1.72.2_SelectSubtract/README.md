# 選択の除外と最大・最小XYの点参照化

プレビューで＋／−選択後、表示される最大最小XYを確認して「選択図形の最大・最小XYを点参照にする」を実行できます。詳細はdocs/SELECT.md参照。

# ドロップ直後のクラッシュ対策版

Windowsのファイル受け渡し処理を修正。DXF／DWGのドロップ時にネイティブ受信処理からTkを直接呼ばず、読み込みを画面側のタイマーへ移します。Windows実機での確認は未実施です。

# SELECTプレビュー選択の改良版

直前にSELECTがない操作の作成案内と、範囲を点参照の最小窓へ変換する機能を追加しました。操作は[docs/SELECT.md](docs/SELECT.md)を参照してください。

# AcadStadio 1.72.2-beta107（整理版）

Excel / CSVの入力表とブロック・コマンドから、AutoCAD用SCRを生成するPythonデスクトップアプリです。

## 起動

Python 3.11を推奨します。Tkinterが必要です。

```sh
python -m pip install -r requirements.txt
python src/main.py
```

Windowsでは `AcadStadio.pyw` からも起動できます。EXEは未ビルドです。
基本操作は [クイックスタート](docs/QUICK_START.txt) を参照してください。

## 現在の状態

- プレビューはモデル → 各レイアウト → ＋の順。ブロック一覧の列見出しは「名前」。
- フォルダの表示位置はブロックの実行順に追従。「順」欄に親フォルダ名と番号を表示。
- 読込図形の範囲選択によるフォルダ化、明示的な属性整理、フォルダ解放に対応。
- 同じブロック内の設定参照と、参照先への移動・使用箇所の強調に対応。
- 作図、入力表、点参照、DWG／DXF読込、Undo／Redoなどの既存機能は保持。

## 資料

- 開発引き継ぎ： [START_HERE_FOR_CODEX.md](START_HERE_FOR_CODEX.md)
- 機能別資料の一覧： [docs/INDEX.md](docs/INDEX.md)
- 検証状況： [docs/VALIDATION.md](docs/VALIDATION.md)
- 整理内容： [docs/CLEANUP.md](docs/CLEANUP.md)

元の長いREADME・変更履歴・引き継ぎ・検証ログは別添のHistoryArchive ZIPに保管しています。
Windows／AutoCAD実機、SCR実行、EXEビルドは未確認です。
