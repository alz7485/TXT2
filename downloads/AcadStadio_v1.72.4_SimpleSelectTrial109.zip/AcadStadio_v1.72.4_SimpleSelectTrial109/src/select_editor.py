"""Preview-only SELECT interaction; references are generated behind the scenes."""
import copy
import tkinter as tk
from tkinter import ttk,messagebox
from selection_sets import resolve,select_queries

class SelectionEditor:
    def __init__(self,win,get_data,apply_data,get_canvas,refresh,identity=None):
        self.win=win;self.get_data=get_data;self.apply_data=apply_data;self.get_canvas=get_canvas;self.refresh=refresh
        self.capturing=False;self.updating=False;self.identity=identity
        self.simple=False;self.simple_count=tk.StringVar(master=win,value='0 図形を選択')
        self.context=None;self.number=None

    def build_simple(self,host):
        self.simple=True
        for child in host.winfo_children():child.destroy()
        bar=ttk.Frame(host);bar.pack(fill='x')
        ttk.Label(bar,text='図形を選択',style='Section.TLabel').pack(side='left')
        ttk.Label(bar,textvariable=self.simple_count).pack(side='left',padx=18)
        ttk.Button(bar,text='元に戻す',command=self.win.undo_draft).pack(side='right',padx=6)
        ttk.Button(bar,text='すべて解除',command=self.clear).pack(side='right')
        ttk.Label(host,text='クリックで選択・解除。ドラッグで囲んで選択。Shift＋ドラッグでまとめて解除。',style='Muted.TLabel').pack(anchor='w',pady=(6,0))

    def simple_point(self,position,source):
        self.simple_sources([source],position,None)

    def simple_rectangle(self,a,b,remove=False):
        from range_selection import select_range
        mode='window' if b[0]>=a[0] else 'crossing'
        box=(min(a[0],b[0]),min(a[1],b[1]),max(a[0],b[0]),max(a[1],b[1]))
        self.simple_sources(select_range(self.get_canvas().items,box,mode),a,remove)

    def simple_sources(self,sources,position,remove):
        if not sources:return
        from selection_pick_reference import exclusion_reference
        try:
            if self.context is None:raise ValueError('プレビューの計算完了をお待ちください。')
            canvas=self.get_canvas();data=self.get_data()
            tolerance=float(self.number(data.get('pick_tolerance','0.01'),self.context))
            current=select_queries(canvas.items,resolve(data,self.context,self.number),tolerance) if data.get('selections') else []
            queries=copy.deepcopy(data.get('selections',[]))
            staged=[]
            for source in sources:
                selected=any(item is source for item in current)
                subtract=selected if remove is None else remove
                if remove is not None and selected==(not remove):continue
                # Verify every figure before registering IDs or changing the draft.
                exclusion_reference(source,canvas.items,position,tolerance,lambda item:'p_'+'0'*32)
                staged.append((source,subtract))
            if len(queries)+len(staged)>100:
                raise ValueError('選択操作の上限です。すべて解除してから、対象を選び直してください。')
            for source,subtract in staged:
                query=exclusion_reference(source,canvas.items,position,tolerance,self.identity or (lambda item:item.get('point_id')))
                query['operation']='subtract' if subtract else 'add'
                # A figure selected again must not stay excluded by its earlier query.
                key=(self.identity(source) if self.identity else source.get('point_id'))
                if key:
                    queries=[q for q in queries if q.get('simple_source')!=key and not (q.get('mode')=='point' and repr(key) in str(q.get('x1','')))]
                    query['simple_source']=key
                queries.append(query)
            data['selections']=queries
            self.change(data)
        except ValueError as exc:messagebox.showinfo('図形の選択',str(exc),parent=self.win)

    def change(self,data):
        self.updating=True
        try:self.apply_data(data)
        finally:self.updating=False

    def clear(self):
        data=self.get_data();data['selections']=[];self.change(data)

    def stop(self):
        self.capturing=False
        canvas=self.get_canvas()
        if canvas is not None:canvas.cancel_range()

    def start(self,force=False):
        canvas=self.get_canvas()
        if canvas is None:return
        if self.capturing and not force:self.stop();self.refresh();return
        self.capturing=True
        canvas.begin_object_selection(self.simple_point,self.simple_rectangle)

    def overlays(self,context,number):
        self.context=context;self.number=number
        canvas=self.get_canvas()
        if canvas is None:return
        try:queries=resolve(self.get_data(),context,number)
        except (ValueError,KeyError):queries=[]
        canvas.selection_rectangles=[(q['box'],q['mode']) for q in queries if q['mode']!='point']
        canvas.selection_points=[]
        canvas.reference_bounds=[p for q in queries for p in ([q['point']] if q['mode']=='point' else [q['box'][:2],q['box'][2:]])]
        try:members=select_queries(canvas.items,queries,float(number(self.get_data().get('pick_tolerance','0.01'),context))) if queries else []
        except (ValueError,KeyError):members=[]
        canvas.selection_count=len(members)
        self.simple_count.set(f'{len(members)} 図形を選択')
        canvas.selected_entity_ids={id(s) for s in members if s.get('entity_parent') is None}
        canvas.selected_segments=[s['coords'] for s in members if s.get('entity_parent') is not None]
        canvas.selection_active=True
        canvas.fit(preserve=True,preserve_camera=True)
        if self.simple:self.start(force=True)

