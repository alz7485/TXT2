# 1.72.4-beta109の検証

- コア522件成功。
- Linux／Tk 8.6／Xorgで関連GUI26件成功。
  - test_gui_simple_select：実ドラッグ、Shift囲み解除、クリックトグル、確定後コンパイル、フォーム非表示。
  - test_gui_select_command：複数選択、全解除とUndo、COPYからのSELECT作成、追加順。
  - test_gui_safe_exclusion：安全な点参照と選択保存。
  - test_gui_range_selection：ズーム状態でのドラッグ、カメラ保持、旧条件の編集・Undo。
  - test_gui_point_continuation／test_gui_inline_point_reference：前版のX→Y→次点XYと各確定経路。
- スモークテスト成功。
- Tk 8.6で実画面を撮影し、全幅プレビューと簡素な操作バーを確認。

全GUI一括、Windows/AutoCAD実機、SCR実行、Windows EXEビルドは未実施。内部の最大100条件制限、安全な点参照を作れない図形の拒否は継続します。
