# 1.72.4-beta109：SELECTをプレビュー操作へ集約

最新の実装はこのフォルダ。まずREADME.md、docs/SELECT.md、docs/VALIDATION.mdを読むこと。

- macro_editor.py：SELECTのみ汎用フォームとヘッダーを隠し、プレビューを全幅にする。選択名・許容差は内部初期値を使用。0件での確定を拒否。非SELECTの点参照フローを保持。
- select_editor.py：簡素な選択バー。クリックでトグル、囲みで追加、Shift囲みで解除。各図形の安全な点参照を自動生成して保存。simple_sourceで再追加時の古い解除条件を整理。
- point_preview_ui.py：begin_object_selectionでクリックと囲みを自動判別。既存の点参照パネル・旧begin_point_selectionの動作も維持。
- selection_pick_reference.py：他図形と重ならない参照点候補の探索。曖昧さは拒否。
- selection_sets.py：既存保存形式で追加／除外を評価し、SCRへ出力。

維持する仕様：保存モデル版11、blocks配列が実行順、ID参照・表参照式・Undo／Redo・原子的保存を保持。設定参照・フォルダ処理はそのまま。file_drop.pyのWindowsドロップ対策、AcadStadio.specのQt除外を保持。

点参照はX→同じ点Y→次点XY、XY→次点XY。GUI試験は表示環境が必要。Windows/AutoCAD実機を検証済みと主張しないこと。
