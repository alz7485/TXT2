# 1.73.0-beta113の検証

- コア539件成功。
- 実Tk 8.6／Xorgで関連GUI13件成功。
  - test_gui_polyline_edit：操作選択、結合許容差の段階表示、線分と円弧の結合プレビュー、確定と保存、SELECTなしの追加拒否。
  - test_gui_simple_select、test_gui_select_command：SELECTと100件超選択の回帰確認。
  - test_gui_space_tabs：モデル／レイアウトの独立視点の回帰確認。
- スモーク成功。
- 線分＋円弧の結合・閉じる、曲率bulgeの保持、経路反転、未接続・分岐の拒否、後続COPY・EXPLODE、曲線の正確な中点、円弧を含む表示範囲、JSON再読込をコア検証。
- 生成LISPの構文を検査。PEDITACCEPTの退避・復元と、失敗時のUNDO処理を出力することを検証。
- Tk実画面で、円弧を保持した閉じた経路と操作画面を撮影。

## 未実施

Windows／AutoCAD実機、実際のPEDITコマンドの応答、UNDOによる実CADでのロールバック、EXEビルドは未確認です。生成コードの検証は実機での成功を意味しません。結合許容差による微小な端点調整は、プレビューとCADの結果に差が出る場合があります。
