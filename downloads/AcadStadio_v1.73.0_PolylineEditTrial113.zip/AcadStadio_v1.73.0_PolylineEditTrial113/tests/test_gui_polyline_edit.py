import sys,os,unittest,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from macro_editor import edit_command,CommandList
from test_polyline_edit import outline,selector,SID
from engine import compile_project
@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI display unavailable')
class PolylineEditGui(unittest.TestCase):
 setUp=gui.Gui.setUp
 tearDown=gui.Gui.tearDown
 def test_operation_picker_arc_preview_and_save(self):
  prior=outline()+[selector()]
  def inspect():
   w=gui.top(self.root,'コマンドの設定')
   try:
    self.assertNotIn('x1',w.command_entries);self.assertNotIn('join_tolerance',w.command_entries)
    picker=w.command_entries['polyline_action']
    self.assertEqual(len(picker.cget('values')),4)
    picker.set('結合して閉じる');picker.event_generate('<<ComboboxSelected>>');self.root.update()
    self.assertIn('join_tolerance',w.command_entries)
    w.refresh_command_preview();self.root.update()
    visible=[x for x in w.command_preview.canvas.items if not x.get('operation_deleted') and x.get('display_type')=='POLYLINE']
    self.assertEqual(len(visible),1);self.assertTrue(visible[0]['closed']);self.assertTrue(any(visible[0]['bulges']))
    gui.button(w,'コマンドを反映').invoke()
   except Exception as exc:self.errors.append(exc);w.destroy()
  self.root.after(200,inspect)
  result=edit_command(self.root,dict(type='PEDIT',selection_ref=SID),self.app.data['blocks'],self.app.data,point_sources=prior,creating=True)
  self.assertIsNotNone(result);self.assertEqual(result['polyline_action'],'結合して閉じる')
  p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=prior+[result])]
  self.assertIn('"_.PEDIT"',compile_project(p,[0])[0])
 def test_missing_select_blocks_creation(self):
  listing=CommandList(self.root,[],self.app.data['blocks'],project=self.app.data)
  self.assertFalse(listing.can_add_kind('PEDIT'))
  listing.add('PEDIT');self.assertEqual(listing.commands,[])
