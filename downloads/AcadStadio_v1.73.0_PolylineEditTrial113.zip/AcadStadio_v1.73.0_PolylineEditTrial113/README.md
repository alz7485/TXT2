# AcadStadio 1.73.0-beta113

「編集・複写」へ **PEDIT · ポリライン編集** を追加しました。

1. SELECTで線分・円弧・ポリラインを選択。
2. 直後に「ポリライン編集」を追加。
3. 「ポリライン化」「結合」「閉じる」「結合して閉じる」から選んで確定。

円弧の曲率を保持し、SCRではAutoCADのPEDITを使用します。プレビューも曲線として表示します。接続していない図形、分岐、結合時の属性差は事前検査で拒否します。

操作の詳細と制約は[docs/POLYLINE_EDIT.md](docs/POLYLINE_EDIT.md)。サンプルはexamples/polyline_edit_arc_project.json。

## 起動

Python 3.11以上、Tkinterが必要です。

```sh
python -m pip install -r requirements.txt
python src/main.py
```

EXEのビルド手順はEXE_BUILD_ONEDIR.md。Windows/AutoCAD実機・実SCR実行・EXEビルドは未確認です。

以前のSELECT簡素化・100件超対応、空間ごとの視点、レイアウト作成フロー、点参照入力、ドロップ対策、Qtビルド設定を保持しています。
