from selection_sets import OPERATORS as SELECTION_OPERATORS, descriptors as selection_descriptors
from advanced_commands import FIELDS as ADVANCED_FIELDS
from range_selection import MODES as SELECTION_MODES, RANGE_TYPES
from extended_commands import VERTEX_TYPES
from workbench_style import paint_card, SegmentedChoice
from point_reference_window import PointReferenceWindow, PointReferenceCoordinates
from coordinate_values import CoordinateValue, compose_coordinate, split_coordinate
from arc_modes import MODES as ARC_MODES
from vertex_points import read_vertices, points_text, vertex_id, MAX_VERTICES
from guide_blocks import copy_to_guide, forward_links, confirm_reference_order
from point_preview_ui import PointReferencePreview
from command_points import read_point_reference, POINTS, new_id, reference, clone_commands, rewrite_references
from table_grid import GridTreeview
from command_icons import command_icon
"""Transactional preset/block editors and nested IF/REPEAT command forms."""

from project_data import get_rows
import copy
import tkinter as tk
from tkinter import ttk, messagebox, font
from engine import compile_project, parse_expression, MacroError, polyline_expressions
from command_types import DRAWING_TYPES, DIMENSION_TYPES, COMMAND_GROUPS, GUIDE_TYPES
from project_model import validate_project, validate_sequential_project, walk_commands, valid_name
from preview import DrawingCanvas
from theme import fit_window
from cad_setup import STYLE_FIELDS, names as resource_names
from expression_sample import sample_value
from block_model import index_of, replace_collection
from input_assist import reference_groups, show_condition_builder, show_table_reference_picker
from cad_colors import ColorPicker, entity_color_code, entity_color_label, swatch
from ui_icons import icons_for, ICONS, layout_icon_toolbar
from entry_hints import add_entry_hint
from reference_colors import add_reference_color

def field_label(parent, **kwargs):
    width=kwargs.get('width')
    if width and 'wraplength' not in kwargs:
        kwargs['wraplength']=max(40,font.nametofont('TkDefaultFont').measure('0')*width-4)
    return ttk.Label(parent,**kwargs)


FIELDS = {
    "APPEARANCE": [(key, "") for key in ("layer", "color", "linetype", "linetype_scale", "text_style", "dim_style")],
    "LINE": [
        ("layer", ""),
        ("x1", "@X"),
        ("y1", "@Y"),
        ("x2", "@X + 100"),
        ("y2", "@Y"),
    ],
    "CIRCLE": [("layer", ""), ("x", "@X"), ("y", "@Y"), ("r", "@OD / 2")],
    "RECTANGLE": [
        ("layer", ""),
        ("x1", "@X"),
        ("y1", "@Y"),
        ("x2", "@X + 100"),
        ("y2", "@Y + 50"),
    ],
    "TEXT": [
        ("layer", ""),
        ("x", "@X"),
        ("y", "@Y"),
        ("height", "settings.TEXT_HEIGHT"),
        ("angle", "0"),
        ("text", "@TYPE"),
    ],
    "DIMLINEAR": [
        ("layer", ""),
        ("x1", "@X"),
        ("y1", "@Y"),
        ("x2", "@X + 100"),
        ("y2", "@Y"),
        ("x3", "@X + 50"),
        ("y3", "@Y + 30"),
    ],
    "SET": [("name", "VALUE"), ("value", "0")],
    "IF": [("condition", '@TYPE == "A"')],
    "REPEAT": [("count", "3")],
    "SYSVAR": [
        ("name", "OSMODE"),
        ("value_kind", "number"),
        ("value", "0"),
        ("execution", "per_row"),
    ],
    "CUSTOM": [],
}
FIELDS.update(
    POLYLINE=[("layer", ""), ("points", "@X,@Y; @X+100,@Y"), ("closed", "0")],
    ARC=[("layer", ""), ("x", "@X"), ("y", "@Y"), ("r", "25"), ("start_angle", "0"), ("end_angle", "90")],
    ELLIPSE=[("layer", ""), ("x", "@X"), ("y", "@Y"), ("rx", "40"), ("ry", "20"), ("angle", "0")],
    POINT=[("layer", ""), ("x", "@X"), ("y", "@Y")],
    DIMALIGNED=list(FIELDS["DIMLINEAR"]),
    DIMRADIUS=[("layer", ""), ("x", "@X"), ("y", "@Y"), ("r", "25"), ("x3", "@X+40"), ("y3", "@Y+30")],
    DIMDIAMETER=[("layer", ""), ("x", "@X"), ("y", "@Y"), ("r", "25"), ("x3", "@X+40"), ("y3", "@Y+30")],
)
FIELDS.update(
    HATCH=[('layer',''),('points','@X,@Y; @X+100,@Y; @X+100,@Y+60; @X,@Y+60'),('pattern','ANSI31'),('scale','1'),('angle','0')],
    SPLINE=[('layer',''),('points','@X,@Y; @X+50,@Y+40; @X+100,@Y')],
    INSERT=[('layer',''),('block_name',''),('x','@X'),('y','@Y'),('scale_x','1'),('scale_y','1'),('angle','0')],
    LEADER=[('layer',''),('points','@X,@Y; @X+30,@Y+30; @X+60,@Y+30'),('text','注記'),('height','settings.TEXT_HEIGHT')],
    OFFSET=[('layer',''),('x1','@X+50'),('y1','@Y'),('x2','@X+50'),('y2','@Y+10'),('distance','10'),('pick_tolerance','0.01')],
    EXTEND=[('layer',''),('x1','@X+100'),('y1','@Y+20'),('x2','@X+40'),('y2','@Y'),('pick_tolerance','0.01')],
    COPY=[('layer',''),('x1','@X+50'),('y1','@Y'),('x2','@X'),('y2','@Y'),('x3','@X+100'),('y3','@Y'),('pick_tolerance','0.01')],
    MIRROR=[('layer',''),('x1','@X+50'),('y1','@Y'),('x2','@X'),('y2','@Y'),('x3','@X'),('y3','@Y+100'),('erase_source','0'),('pick_tolerance','0.01')],
    TRIM=[('layer',''),('x1','@X+50'),('y1','@Y'),('x2','@X+100'),('y2','@Y+10'),('pick_tolerance','0.01')],
)
from layout_commands import FIELDS as LAYOUT_FIELDS, CHOICES as LAYOUT_CHOICES, LABELS as LAYOUT_LABELS, TITLES as LAYOUT_TITLES, visible_fields
from layer_change import FIELDS as LAYER_FIELDS, LABELS as LAYER_LABELS, CHOICES as LAYER_CHOICES
FIELDS.update(LAYEREDIT=LAYER_FIELDS,REGEN=[("regen_scope","現在のビュー"),("execution","per_row")])
FIELDS.update(LAYOUT_FIELDS)
FIELDS.update(ADVANCED_FIELDS)
from edge_treatment import FIELDS as EDGE_FIELDS
FIELDS.update(EDGE_FIELDS)
from polyline_edit import FIELDS as POLYLINE_EDIT_FIELDS, ACTIONS as POLYLINE_EDIT_ACTIONS
FIELDS["PEDIT"]=POLYLINE_EDIT_FIELDS
FIELDS["SELECT"]=[("selection_name","選択1"),("x1","@X"),("y1","@Y"),("pick_tolerance","0.01")]
TYPE_LABELS = {
    "SETTINGREF": "SETTINGREF · 設定を参照",
    "CHAMFER": "CHAMFER · 面取り",
    "FILLET": "FILLET · 角丸め",
    "SELECT": "SELECT · 図形選択",
    "PEDIT": "PEDIT · ポリライン編集",
    "ROTATE": "ROTATE · 回転",
    "ROTATECOPY": "ROTATECOPY · 回転複写",
    "ARRAYRECT": "ARRAYRECT · 並べて複写",
    "EXPLODE": "EXPLODE · 分解",
    "CADBLOCK": "CADBLOCK · CADブロック化",
    "SCALE": "SCALE · 尺度変更",
    "MTEXT": "MTEXT · マルチテキスト",
    "HATCH": "HATCH · ハッチング",
    "SPLINE": "SPLINE · スプライン",
    "INSERT": "INSERT · CADブロック挿入",
    "LEADER": "LEADER · 引出線",
    "OFFSET": "OFFSET · オフセット",
    "TRIM": "TRIM · トリム",
    "EXTEND": "EXTEND · 延長",
    "COPY": "COPY · コピー",
    "MIRROR": "MIRROR · ミラー",
    "LINE": "LINE · 線分",
    "POLYLINE": "POLYLINE · ポリライン",
    "ARC": "ARC · 円弧",
    "ELLIPSE": "ELLIPSE · 楕円",
    "POINT": "POINT · 点",
    "DIMALIGNED": "DIMALIGNED · 平行寸法",
    "DIMRADIUS": "DIMRADIUS · 半径寸法",
    "DIMDIAMETER": "DIMDIAMETER · 直径寸法",
    "CIRCLE": "CIRCLE · 円",
    "RECTANGLE": "RECTANGLE · 長方形",
    "TEXT": "TEXT · 単一行文字",
    "DIMLINEAR": "DIMLINEAR · 長さ寸法",
    "SET": "SET · 旧形式の変数代入",
    "IF": "IF / ELSE · 条件分岐",
    "REPEAT": "REPEAT · 繰り返し",
    "APPEARANCE": "APPEARANCE · 作図属性を設定",
    "SYSVAR": "SYSVAR · システム変数変更",
    "CUSTOM": "登録済みコマンド",
}
LABELS = {
    "distance1": "面取り距離1",
    "distance2": "面取り距離2",
    "radius": "丸め半径",
    "selection_name": "選択名",
    "selection_ref": "使用するSELECT",
    "polyline_action":"操作", "join_tolerance":"結合許容差",
    "copy_count": "追加する個数",
    "columns": "列数（元を含む）",
    "rows": "行数（元を含む）",
    "column_spacing": "列の間隔（X）",
    "row_spacing": "行の間隔（Y）",
    "factor": "尺度の倍率",
    "width": "文字枠の幅",
    "erase_source": "元の図形を削除（0/1）",
    "block_name": "CAD内のブロック名",
    "pattern": "パターン名",
    "scale": "パターン尺度",
    "scale_x": "X尺度",
    "scale_y": "Y尺度",
    "distance": "オフセット距離",
    "pick_tolerance": "選択許容差",
    "diameter": "直径",
    "text_style": "文字スタイル",
    "dim_style": "寸法スタイル",
    "linetype": "線種",
    "color": "色（ACI）",
    "linetype_scale": "線種尺度（個別）",
    "points": "頂点（X,Y; X,Y; …）",
    "closed": "閉じる（0/1）",
    "rx": "長軸半径",
    "ry": "短軸半径",
    "start_angle": "開始角度（°）",
    "end_angle": "終了角度（°）",
    "layer": "レイヤー",
    "x": "中心 / 挿入 X",
    "y": "中心 / 挿入 Y",
    "x1": "始点 X",
    "y1": "始点 Y",
    "x2": "終点 X",
    "y2": "終点 Y",
    "x3": "寸法位置 X",
    "y3": "寸法位置 Y",
    "r": "半径",
    "height": "文字高さ",
    "angle": "回転角度（°）",
    "text": "文字列",
    "name": "名前",
    "value": "代入する式",
    "condition": "実行条件（式）",
    "count": "反復回数（式）",
    "value_kind": "値の種類",
    "execution": "実行回数",
}


LABELS.update(lineweight='線の太さ', attachment='文字配置', dimension_axis='寸法方向', dimension_text='寸法文字',
              text_halign='文字の水平配置',text_valign='文字の垂直配置',text_width='文字幅係数',text_oblique='文字傾斜',text_generation='文字反転',text_align_x='合わせ位置 X',text_align_y='合わせ位置 Y')

def command_summary(cmd):
    typ = cmd.get("type", "?").upper()
    if typ == "SETTINGREF":return "設定を参照"
    if typ == "SELECT":return f"{cmd.get('selection_name','選択')} / 点・矩形 {len(cmd.get('selections',[]))}条件"
    if typ == "IF":
        return f"{cmd.get('condition', '')}  → {len(cmd.get('commands', []))}件 / ELSE {len(cmd.get('else', []))}件"
    if typ == "REPEAT":
        return f"{cmd.get('count', '')} 回 × {len(cmd.get('commands', []))}件"
    hidden = {"type", "commands", "else", "point_id", "guide_origin", "vertices", "selection_ref", "import_source", "setting_id"}
    prefix = ""
    if "selection_ref" in cmd:prefix = "SELECT: " + ("直前" if cmd["selection_ref"]=="@previous" else str(cmd["selection_ref"]))
    if typ in VERTEX_TYPES and "vertices" in cmd:
        points = read_vertices(cmd)
        start, end = points[0], points[-1]
        prefix = f"{len(points)}点: ({start['x']}, {start['y']}) → ({end['x']}, {end['y']})"
        hidden.update(("x1", "y1", "x2", "y2", "points"))
    detail = ", ".join(
        f"{LABELS.get(k, k)}: {v}"
        for k, v in cmd.items()
        if k not in hidden
    )
    return ", ".join(part for part in (prefix, detail) if part)


TYPE_LABELS.update(LAYOUT_TITLES)
TYPE_LABELS.update(LAYEREDIT="LAYEREDIT · レイヤーを変更",REGEN="REGEN · 再作図")
LABELS.update(LAYER_LABELS,regen_scope="対象")
LAYOUT_CHOICES.update(LAYER_CHOICES,regen_scope=("現在のビュー","全ビュー"))
LABELS.update(LAYOUT_LABELS)

def edit_command(
    parent, current, blocks, project=None, local_names=(), *, sample_locals=None,
    folder_id="", point_sources=(), previous_blocks=(), owner_block_id=None, allow_continue=False, repeat_counts=(), initial_row=0, creating=False, owner_space=None,
):
    if current.get("type", "LINE").upper() not in FIELDS:
        messagebox.showerror("コマンドの確認", "このコマンドは追加・編集できません", parent=parent)
        return None
    from space_command_rules import block_space,creation_reason
    creation_space=owner_space or block_space(blocks,owner_block_id,project)
    if creating and creation_reason(current.get('type'),creation_space):
        messagebox.showinfo('作図先の確認',creation_reason(current.get('type'),creation_space),parent=parent);return None
    win = tk.Toplevel(parent)
    win.title("コマンドの設定")
    fit_window(win, 1320, 860, 980, 620)
    win.transient(parent.winfo_toplevel())
    win.grab_set()
    working = copy.deepcopy(current)
    result = []
    queued = []
    prepended = []
    point_sources = list(point_sources)
    if working.get('type')=='SELECT':
        working.setdefault('point_id',new_id());working.setdefault('selections',[])
    if working.get('type') in SELECTION_OPERATORS and 'selection_ref' not in working:
        if 'x1' in working and 'y1' in working:
            mode=working.get('selection_mode','point');keys=('x1','y1') if mode=='point' else ('x1','y1','x4','y4')
            selector=dict(type='SELECT',point_id=new_id(),selection_name='選択',pick_tolerance=working.get('pick_tolerance','0.01'),selections=[dict(mode=mode,**{k:working.get(k,'0') for k in keys})])
            prepended.append(selector);point_sources.append(selector);working['selection_ref']=selector['point_id']
        else:working['selection_ref']='@previous'
    select_controller=[None]
    live = [None]
    selecting = [None]
    refresh_job = [None]
    redrawing = [True]
    batching = [False]
    undo_stack, redo_stack = [], []
    history_current = [None]
    mode_drafts = {}
    pending_point_ids = {}
    external_point_ids = {}
    point_labels = {cmd['point_id']: f"コマンド{i+1}" for i,cmd in enumerate(point_sources) if cmd.get('point_id')}
    if isinstance(blocks,list):
        for block in blocks:
            for ci,command in enumerate(block.get("commands",[])):
                if command.get("point_id"):
                    point_labels[block["id"]+"/"+command["point_id"]]=f"{block['name']} / コマンド{ci+1}"
    source_defs = []
    for bi, block in enumerate(previous_blocks):
        for ci, command in enumerate(block.get("commands", [])):
            if command.get("type") in POINTS and not (command.get("type") in ("COPY","MIRROR","ROTATECOPY","ARRAYRECT","EXPLODE") and (command.get("selection_mode","point")!="point" or command.get("type") in ("ROTATECOPY","ARRAYRECT","EXPLODE"))):
                descriptor=dict(command=command,block_index=bi,command_index=ci,block_id=block["id"],local=False,
                                label=f"{block['name']} / コマンド{ci+1}")
                source_defs.append(descriptor)
                if command.get("point_id"):
                    point_labels[block["id"]+"/"+command["point_id"]]=descriptor["label"]
    for ci, command in enumerate(point_sources):
        if command.get("type") in POINTS and not (command.get("type") in ("COPY","MIRROR","ROTATECOPY","ARRAYRECT","EXPLODE") and (command.get("selection_mode","point")!="point" or command.get("type") in ("ROTATECOPY","ARRAYRECT","EXPLODE"))):
            source_defs.append(dict(command=command,block_index=len(previous_blocks),command_index=ci,block_id="",local=True,label=f"コマンド{ci+1}"))
    entries = {}
    win.command_entries = entries
    variables = {}
    coordinate_values = {}
    movement_entries = {}
    win.coordinate_values = coordinate_values
    win.movement_entries = movement_entries
    argument_vars = {}
    selected_custom = [current.get("name", "")]
    focused = [None]
    old_type = current.get("type", "LINE").upper()
    drafts = {old_type: copy.deepcopy(working)}
    choice = tk.StringVar(value=TYPE_LABELS.get(old_type, TYPE_LABELS["LINE"]))
    guide_owner=isinstance(blocks,list) and any(b.get('id')==owner_block_id and b.get('guide') for b in blocks)
    kind_groups=tuple((label,tuple(k for k in kinds if not guide_owner or k in GUIDE_TYPES)) for label,kinds in COMMAND_GROUPS if not guide_owner or any(k in GUIDE_TYPES for k in kinds))
    header = ttk.Frame(win, padding=(12, 8))
    header.pack(fill="x")
    picker = ttk.Combobox(
        header,
        textvariable=choice,
        values=[TYPE_LABELS[kind] for _, kinds in kind_groups for kind in kinds],
        state="readonly",
        width=20,
    )
    picker.pack(side="left")
    win.command_picker = picker
    mode_host = ttk.Frame(header)
    mode_host.pack(side="left", padx=(12, 0))
    coordinate_toolbar = ttk.Frame(win, padding=(12, 0, 12, 8))
    target_choice = tk.StringVar()
    ttk.Label(coordinate_toolbar, text="入力先").pack(side="left", padx=(0, 6))
    target_picker = ttk.Combobox(coordinate_toolbar, textvariable=target_choice,
                                state="readonly", width=24)
    target_picker.pack(side="left", padx=(0, 8))
    coordinate_tools = {}
    target_keys = {}
    win.coordinate_toolbar = coordinate_toolbar
    win.coordinate_target_picker = target_picker
    used_values_picker=ttk.Combobox(coordinate_toolbar,state='readonly',width=22)
    used_values_tokens=[]
    win.used_reference_picker=used_values_picker
    def select_coordinate_target(event=None):
        key = target_keys.get(target_choice.get())
        if key in entries:
            focused[0] = entries[key]
            entries[key].focus_set()
            focus_marker()
    target_picker.bind("<<ComboboxSelected>>", select_coordinate_target)
    body = ttk.Frame(win, padding=(12, 0))
    body.pack(fill="both", expand=True)
    body.columnconfigure(0, weight=5, minsize=390)
    body.columnconfigure(1, weight=7)
    body.rowconfigure(0, weight=1)
    simple_select_host=ttk.Frame(win,padding=(12,8))
    left = ttk.Frame(body)
    left.pack_propagate(False)
    left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
    viewport = tk.Canvas(left, highlightthickness=0, bg="#f3f5f9")
    scroll = ttk.Scrollbar(left, command=viewport.yview)
    viewport.pack(side="left", fill="both", expand=True)

    def update_scroll(first, last):
        scroll.set(first, last)
        bounds=viewport.bbox('all')
        fits=bounds is not None and bounds[3]-bounds[1]<=viewport.winfo_height()
        if fits or (float(first) <= 0 and float(last) >= 1):
            if fits and float(first)>0:viewport.yview_moveto(0)
            if scroll.winfo_manager():
                scroll.pack_forget()
        elif not scroll.winfo_manager():
            scroll.pack(side="right", fill="y", before=viewport)

    viewport.configure(yscrollcommand=update_scroll)
    win.command_scrollbar, win.command_viewport = scroll, viewport
    form = ttk.Frame(viewport)
    form_window = viewport.create_window(0, 0, window=form, anchor="nw")
    viewport.bind(
        "<Configure>", lambda e: viewport.itemconfigure(form_window, width=e.width)
    )
    def form_changed(event=None):
        viewport.configure(scrollregion=viewport.bbox('all'))
        update_scroll(*viewport.yview())
    form.bind('<Configure>',form_changed)


    refs = ttk.LabelFrame(win, text="参照一覧・式の試算", padding=10)
    refs.columnconfigure(0, weight=1)
    refs.rowconfigure(2, weight=1)
    ttk.Label(
        refs,
        text="入力欄を選び、候補をダブルクリック",
        style="Muted.TLabel",
        wraplength=250,
    ).grid(row=0, column=0, sticky="w")
    query = tk.StringVar()
    ttk.Entry(refs, textvariable=query).grid(row=1, column=0, sticky="ew", pady=7)
    listing = tk.Listbox(
        refs,
        exportselection=False,
        relief="flat",
        bg="white",
        activestyle="none",
        height=10,
    )
    listing.grid(row=2, column=0, sticky="nsew")
    project = project or {}
    sample_frame = ttk.LabelFrame(refs, text="選択した入力欄の試算", padding=8)
    sample_frame.grid(row=5, column=0, sticky="ew", pady=(6, 0))
    sample_row = tk.StringVar(value=str(initial_row+1))
    sample_picker = ttk.Combobox(
        sample_frame,
        textvariable=sample_row,
        values=[str(i + 1) for i in range(len(get_rows(project)))],
        state="readonly",
        width=8,
    )
    ttk.Label(sample_frame, text="試算する行:").pack(side="left")
    sample_picker.pack(side="left", padx=5)
    sample_result = tk.StringVar(value="数値・条件の入力欄を選択してください")
    ttk.Label(refs, textvariable=sample_result, wraplength=250).grid(
        row=6, column=0, sticky="ew", pady=6
    )
    # Expose state for keyboard/accessibility tooling and real-widget regression tests.
    win.sample_result, win.sample_row = sample_result, sample_row

    def update_sample(*_):
        key = next((k for k, widget in entries.items() if widget is focused[0]), None)
        var = coordinate_values[key[5:]].movement if key and key.startswith("move:") else variables.get(key)
        if key and key.startswith("arg:"):
            var = argument_vars.get(key[4:])
            kind = next(
                (
                    p["kind"]
                    for p in project.get("custom_commands", {})
                    .get(selected_custom[0], {})
                    .get("parameters", [])
                    if p["name"] == key[4:]
                ),
                "text",
            )
            if kind != "number":
                sample_result.set("文字引数です。数値欄を選ぶと試算できます。")
                return
        if key in STYLE_FIELDS:
            sample_result.set(
                "空欄は直前の設定を引き継ぎます。先頭ではCADの現在の設定を使います。"
            )
            return
        if key in ("name", "text", "execution", "value_kind") or var is None:
            sample_result.set("数値・条件の入力欄を選択してください")
            return
        text = var.get().strip()
        if "点(" in text or "点位置(" in text:
            sample_result.set("点参照の値はブロックのプレビューで確認できます")
            return
        if key in ("color","layer_color"):
            text = entity_color_code(text)
        if key in ("color", "linetype_scale") and not text:
            sample_result.set("空欄は直前の設定を引き継ぎます。先頭ではCADの現在値を使います。")
            return
        if not text and key == "condition":
            sample_result.set("条件なし: 常に実行")
            return
        if (
            key == "value"
            and active[0] == "SYSVAR"
            and variables.get("value_kind").get() == "text"
        ):
            sample_result.set("文字列の値です")
            return
        try:
            if key == "points":
                points = polyline_expressions(text)
                shown = [tuple(sample_value(project, expression, max(0, int(sample_row.get())-1), sample_locals,repeat_counts=repeat_counts) for expression in point) for point in points[:3]]
                sample_result.set(f"{len(points)}頂点: {shown}" + (" …" if len(points) > 3 else ""))
                return
            value = sample_value(
                project, text, max(0, int(sample_row.get()) - 1), sample_locals,repeat_counts=repeat_counts
            )
            rendered = f"{value:.12g}" if type(value) in (int, float) else str(value)
            sample_result.set(
                f"{sample_row.get()}行目 → {rendered}\n繰り返しの値は実行時に確定します。"
            )
        except (MacroError, ValueError, IndexError) as exc:
            sample_result.set("試算できません: " + str(exc))

    def focus_sample(event):
        focused[0] = event.widget
        update_sample()
        focus_marker()

    sample_row.trace_add("write", update_sample)
    sample_row.trace_add("write", lambda *_: schedule_preview())
    ref_groups = reference_groups(project, local_names)
    candidates = [ref for _, group in ref_groups for ref in group]

    def filter_refs(*_):
        listing.delete(0, "end")
        for ref in dict.fromkeys(candidates):
            if query.get().lower() in ref.lower():
                listing.insert("end", ref)

    query.trace_add("write", filter_refs)
    filter_refs()

    def scene_blocks():
        earlier=list(copy.deepcopy(previous_blocks))
        for (bi,ci),identity in external_point_ids.items():earlier[bi]['commands'][ci]['point_id']=identity
        prefix=copy.deepcopy(point_sources)
        for index,identity in pending_point_ids.items():
            if index<len(prefix):prefix[index]['point_id']=identity
        owner=next((b for b in blocks if b.get('id')==owner_block_id),{}) if isinstance(blocks,list) else {}
        return earlier+[dict(id=owner_block_id or 'command_preview',name='編集中ブロック',commands=prefix+[gather()],guide=owner.get('guide',False),**({'drawing_space':owner['drawing_space']} if owner.get('drawing_space') else {}))]

    def capture_state():
        return copy.deepcopy((gather(),pending_point_ids,external_point_ids,point_labels))

    def record_edit(*_):
        if redrawing[0] or batching[0]:return
        state=capture_state()
        if history_current[0] is not None and state!=history_current[0]:
            undo_stack.append(history_current[0]);del undo_stack[:-100];redo_stack.clear()
        history_current[0]=state
        schedule_preview()

    def restore_state(state):
        working.clear();working.update(copy.deepcopy(state[0]));active[0]=working['type'];choice.set(TYPE_LABELS[active[0]])
        for target,data in zip((pending_point_ids,external_point_ids,point_labels),state[1:]):target.clear();target.update(copy.deepcopy(data))
        redraw(False);history_current[0]=capture_state();schedule_preview()

    def undo_draft(event=None):
        if selecting[0] is not None:return 'break'
        if undo_stack:
            redo_stack.append(capture_state());restore_state(undo_stack.pop())
        return 'break'

    def redo_draft(event=None):
        if selecting[0] is not None:return 'break'
        if redo_stack:
            undo_stack.append(capture_state());restore_state(redo_stack.pop())
        return 'break'
    win.undo_draft=undo_draft;win.redo_draft=redo_draft
    win.bind('<Control-z>',undo_draft);win.bind('<Control-y>',redo_draft)

    def schedule_preview(*_):
        if redrawing[0] or selecting[0] is not None:return
        if refresh_job[0]:win.after_cancel(refresh_job[0])
        refresh_job[0]=win.after(130,refresh_preview)

    def refresh_preview():
        if refresh_job[0]:win.after_cancel(refresh_job[0])
        refresh_job[0]=None
        if live[0] is None or not win.winfo_exists() or selecting[0] is not None:return
        visual=live[0]
        visual.canvas.selection_active=active[0]=='SELECT'
        if active[0]!='SELECT':
            visual.canvas.selection_rectangles=None;visual.canvas.selection_points=[];visual.canvas.selected_segments=[];visual.canvas.reference_bounds=[]
        visual.preview_blocks=scene_blocks
        visual.source_refs=source_defs+[dict(label='編集中',block_index=len(previous_blocks),command_index=len(point_sources))]
        visual.canvas.on_source=begin_point_reference
        visual.canvas.on_reference_error=visual.status.set
        visual.canvas.on_reference_candidate=begin_direct_reference
        visual.canvas.reference_candidate_indices=set(range(len(source_defs)))
        visual.on_pick=focus_point;visual.canvas.on_pick=focus_point
        if active[0]!='PEDIT':visual.canvas.related_source_indices=set()
        visual.row.set(sample_row.get());visual.load(len(source_defs))
        visual.status.set(visual.warning if visual.warning else 'このコマンドは図形を作成しません' if active[0] in ('SYSVAR','SYSVARS','APPEARANCE','LAYEREDIT','REGEN','SPACE','LAYOUT') else '設定はSCRに出力します。プレビューには反映しません。' if active[0] == 'CUSTOM' else '')
        update_field_results()
        refresh_inheritance_hints()
        canvas=visual.canvas
        if active[0]=='PEDIT':
            canvas.related_source_indices={canvas.item_source_index(i) for i in canvas.items if i.get('polyline_edit_result')}
            canvas.recolor()
        if active[0]=='SELECT' and select_controller[0] is not None:
            from command_workbench import evaluated_fields
            from engine import number
            try:context=evaluated_fields(project,scene_blocks(),canvas.items,int(sample_row.get())-1,sample_locals,repeat_counts=repeat_counts);select_controller[0].overlays(context,number)
            except (MacroError,ValueError,KeyError):pass
            visual.status.set(f"{getattr(canvas,'selection_count',0)} 図形を選択")
        elif active[0] in RANGE_TYPES and 'selection_ref' not in working and working.get('selection_mode','point')!='point':
            try:
                from command_workbench import evaluated_fields
                from engine import evaluate
                context=evaluated_fields(project,scene_blocks(),canvas.items,int(sample_row.get())-1,sample_locals,repeat_counts=repeat_counts)
                coords=[float(evaluate(rewrite_references(variables[k].get(),{v:k for k,v in point_labels.items()}),context)) for k in ('x1','y1','x4','y4')]
                canvas.range_box=tuple(coords);canvas.range_mode=working['selection_mode']
            except (MacroError,ValueError,KeyError,TypeError):canvas.range_box=None
        else:canvas.range_box=None
        canvas.draw_range()
        focus_marker()

    def start_range():
        if active[0]=='SELECT' and select_controller[0] is not None:
            select_controller[0].start();return
        if live[0] is None or working.get('selection_mode','point')=='point':return
        canvas=live[0].canvas
        if not hasattr(canvas,'_base_offset'):
            messagebox.showinfo('範囲選択','プレビューに図形がない場合は、範囲の座標を直接入力してください。',parent=win);return
        def selected(a,b):
            batching[0]=True
            try:
                for key,value in zip(('x1','y1','x4','y4'),(*a,*b)):variables[key].set(format(value,'.12g'))
            finally:batching[0]=False
            record_edit();refresh_preview()
        canvas.begin_range(selected,working.get('selection_mode','window'))
        live[0].status.set('プレビュー上でドラッグして範囲を指定します。Escで範囲指定を中止。')
    win.start_range=start_range

    def focus_point(name):
        key=next((k for k,title in point_titles.items() if title==name),None)
        if key and key in entries:entries[key].focus_set();focused[0]=entries[key];focus_marker()

    def focus_marker():
        if live[0] is None or selecting[0] is not None:return
        key=next((k for k,e in entries.items() if e is focused[0]),'')
        is_movement=key.startswith('move:')
        key=key.removeprefix('move:')
        name=point_titles.get('x'+key[1:],'')
        if name and key in entries and key[:1] in ('x','y'):
            target_choice.set(name+(' 移動' if is_movement else ' ')+key[0].upper())
            for suffix,tools in coordinate_tools.items():
                tools.pack_forget()
                if suffix == key[1:]:tools.pack(side='left')
        for suffix,card in coordinate_cards.items():
            paint_card(card,False)
            for component in ('x','y'):
                frame=coordinate_axis_frames.get(component+suffix)
                if frame is not None:
                    frame._card_focused=None
                    paint_card(frame,bool(name and component+suffix==key))
        if name:
            point_buttons[key[1:]][1].configure(state='disabled' if is_movement else 'normal')
        refresh_used_values()
        visual=live[0];visual.canvas.selected_point=name;visual.canvas.shifted_point=None;visual.canvas.draw_markers()

    def refresh_used_values(*_):
        used_values_picker.pack_forget();used_values_tokens.clear()
        key=next((k[5:] for k,e in entries.items() if k.startswith('move:') and e is focused[0]),None)
        if key is None or key not in coordinate_values or selecting[0] is not None:return
        from reference_tokens import command_references
        from derived_points import read_relation_reference
        base=coordinate_values[key].base.get()
        tokens=command_references({'value':base})
        point_ref=read_point_reference(base);relation=read_relation_reference(base)
        identities=[point_ref['identity']] if point_ref else [relation['primary'],relation['secondary']] if relation else []
        for descriptor in source_defs:
            cmd=descriptor['command'];ci=descriptor['command_index'];bi=descriptor['block_index']
            identity=cmd.get('point_id') or (pending_point_ids.get(ci) if descriptor['local'] else external_point_ids.get((bi,ci)))
            if identity and not descriptor['local']:identity=descriptor['block_id']+'/'+identity
            if any(name in (identity,descriptor['label']) or point_labels.get(name)==descriptor['label'] for name in identities):
                tokens.extend(command_references(cmd))
        tokens=list(dict.fromkeys(tokens))
        if not tokens:return
        from engine import row_values,evaluate
        try:context=row_values(project,max(0,int(sample_row.get())-1))
        except (MacroError,ValueError,IndexError):context={}
        labels=[]
        for token in tokens:
            try:labels.append(f'{token} = {evaluate(token,context)}')
            except (MacroError,ValueError,TypeError,KeyError):labels.append(token)
        used_values_tokens.extend(tokens);used_values_picker.configure(values=labels)
        used_values_picker.set('参照元の使用値を挿入')
        used_values_picker.pack(side='left',padx=(5,0))
    def insert_used_value(event=None):
        i=used_values_picker.current()
        if not 0<=i<len(used_values_tokens):return
        entry=focused[0]
        if entry not in movement_entries.values():return
        key=next(k for k,e in movement_entries.items() if e is entry)
        place_ref(entry,'move:'+key,used_values_tokens[i],replace=entry.get().strip() in ('','0'))
    used_values_picker.bind('<<ComboboxSelected>>',insert_used_value)
    sample_row.trace_add('write',refresh_used_values)

    def update_field_results():
        from command_workbench import evaluated_fields
        try:values=evaluated_fields(project,scene_blocks(),live[0].canvas.items,int(sample_row.get())-1,sample_locals,repeat_counts=repeat_counts)
        except (MacroError,ValueError,KeyError,TypeError):values={}
        vertex_contexts={};previous={}
        if active[0] in VERTEX_TYPES:
            from engine import number
            for index in range(1,vertex_count[0]+1):
                context=dict(values,__前点__=previous);vertex_contexts[index]=context
                try:
                    expressions=[rewrite_references(variables[a+str(index)].get(),{v:k for k,v in point_labels.items()}) for a in ('x','y')]
                    x,y=[float(number(expression,context)) for expression in expressions]
                    previous={'X':x,'Y':y}
                except (MacroError,ValueError,KeyError,TypeError):break
        for key,label in field_results.items():
            value_var = argument_vars[key[4:]] if key.startswith("arg:") else variables[key]
            text=value_var.get().strip()
            try:
                float(text);shown=''
            except ValueError:
                try:
                    raw=rewrite_references(text,{v:k for k,v in point_labels.items()})
                    from engine import evaluate
                    context=vertex_contexts.get(int(key[1:]),dict(values,__前点__={})) if key[:1] in ('x','y') and key[1:].isdigit() and active[0] in VERTEX_TYPES else values
                    value=evaluate(raw,context)
                    shown='= '+(f'{value:.12g}' if type(value) in (int,float) else str(value))
                except (MacroError,ValueError,KeyError,TypeError):shown='入力を確認' if text else ''
            label.configure(text=shown)
            if shown:label.pack(anchor='w',padx=(16,0),pady=(2,0))
            else:label.pack_forget()
        for suffix,label in reference_summaries.items():
            refs=[]
            for axis in ('x','y'):
                parsed=read_point_reference(coordinate_values[axis+suffix].base.get())
                if parsed:refs.append((axis.upper(),point_labels.get(parsed['identity'],parsed['identity'])+' / '+parsed['point']))
            label.configure(text=('↗ '+refs[0][1]+' · XY  ✎') if len(refs)==2 and refs[0][1]==refs[1][1] else '   '.join(axis+': '+name for axis,name in refs))
            from coordinate_formulas import read_formulas,MODES
            recipe=read_formulas(variables['x'+suffix].get(),variables['y'+suffix].get()) if not refs else None
            if recipe:
                mode,parameters=recipe
                detail=('間隔 '+parameters['pitch']) if mode in MODES[2:4] else (parameters.get('size_mode','半径')+' '+parameters['radius']) if mode==MODES[4] else 'X・Yを設定'
                label.configure(text=mode+'：'+detail+'  ✎')
            if (refs or recipe) and suffix not in collapsed_points:label.pack(fill='x',pady=(3,0))
            else:label.pack_forget()
        markers={}
        if any(item.get('block_index',item.get('preset_index',0))==len(previous_blocks) and item.get('command_index')==len(point_sources) for item in live[0].canvas.items):
            for key,title in point_titles.items():
                try:
                    from engine import evaluate
                    raw=[rewrite_references(variables[axis+key[1:]].get(),{v:k for k,v in point_labels.items()}) for axis in ('x','y')]
                    markers[title]=tuple(float(evaluate(expression,values)) for expression in raw)
                except (MacroError,ValueError,KeyError,TypeError):pass
            live[0].canvas.snap_points=markers

    def place_ref(entry, key, value, replace=False):
        if entry is None or not entry.winfo_exists():
            return
        batching[0]=True
        if replace:
            entry.delete(0, "end")
        param_kind = next(
            (
                p["kind"]
                for p in project.get("custom_commands", {})
                .get(selected_custom[0], {})
                .get("parameters", [])
                if "arg:" + p["name"] == key
            ),
            None,
        )
        is_sysvar_text = (
            key == "value"
            and active[0] == "SYSVAR"
            and variables.get("value_kind") is not None
            and variables["value_kind"].get() == "text"
        )
        if (
            key in ("text", "layer") or param_kind == "text" or is_sysvar_text
        ) and not entry.get():
            if key == "text" and value.startswith("@"):
                pass
            else:
                entry.insert(0, "=")
        if entry.selection_present():
            entry.delete(tk.SEL_FIRST, tk.SEL_LAST)
        entry.insert(tk.INSERT, value)
        entry.focus_set()
        batching[0]=False;record_edit()

    def begin_point_reference(index):
        if active[0]=='SELECT' or not 0<=index<len(source_defs):return
        key=next((k for k,e in entries.items() if e is focused[0]),'')
        if key.startswith('move:'):
            live[0].status.set('参照点の欄を選ぶと、コマンドの点を指定できます。');return
        if not (key.startswith('arg:') or (coordinate_key(key) and 'x'+key[1:] in variables)):
            key=target_keys.get(target_choice.get(),next(iter(target_keys.values()),''))
        if key.startswith('arg:') or (coordinate_key(key) and 'x'+key[1:] in variables):
            choose_command_point(key,both=not key.startswith('arg:'),source_index=index)

    def begin_direct_reference(candidate):
        begin_point_reference(candidate['primary'])
        panel=getattr(win,'point_panel',None)
        if panel is not None and panel.winfo_exists():apply_direct_reference(panel,candidate)

    def apply_direct_reference(panel,candidate):
        relation=panel.relation_controls
        choices=relation.candidates
        primary=next((j for j,(index,d) in enumerate(choices) if index==candidate['primary']),None)
        if primary is None:return
        panel.source_picker.current(primary)
        panel.point_angle.set('0')
        relation.mode.set('交点' if candidate['kind']=='intersection' else '基準点')
        if candidate['kind']=='intersection':
            secondary=next((j for j,(index,d) in enumerate(choices) if index==candidate['secondary']),None)
            if secondary is None:return
            relation.second.current(secondary)
            panel.show_relation_details()
        relation.sync()
        panel.source_picker.event_generate('<<ComboboxSelected>>')
        panel.point_picker.set(candidate['point'])
        panel.point_picker.event_generate('<<ComboboxSelected>>')

    def choose_command_point(key, both=False, source_index=None, *, continuation=False, selected_point=None, selection_state=None):
        if live[0] is not None:live[0].canvas.cancel_range()
        is_argument = key.startswith("arg:")
        param = next((p for p in project.get("custom_commands", {}).get(selected_custom[0], {}).get("parameters", []) if "arg:"+p["name"] == key), {})
        suffix = key[1:]
        xkey, ykey = "x"+suffix, "y"+suffix
        if not is_argument and (xkey not in variables or ykey not in variables):
            return
        candidates=list(enumerate(source_defs))
        if not candidates:
            messagebox.showinfo("コマンドの点", "前の作図ブロック、または同じリストで、このコマンドより前に線・円などを追加してください。", parent=win)
            return
        if selecting[0] is not None:
            selecting[0].source_picker.focus_set();return
        target_name=point_titles.get(xkey,field_caption(key)) if not is_argument else param.get('label',key)
        dialog=PointReferenceWindow(win,live[0].canvas,target_name)
        reference_baseline=copy.deepcopy((pending_point_ids,external_point_ids,point_labels))
        selecting[0]=dialog
        frozen=[]
        def freeze(widget):
            if widget.winfo_class() in ('TEntry','TCombobox','TButton','TCheckbutton','TRadiobutton','TSpinbox','TMenubutton','Text','Entry','Listbox'):
                frozen.append((widget,str(widget.cget('state'))));widget.configure(state='disabled')
            for child in widget.winfo_children():freeze(child)
        freeze(form);freeze(picker);freeze(mode_host);freeze(normal_bar);freeze(coordinate_toolbar)
        for widget in (*win.coordinate_formula_buttons.values(),*win.previous_point_buttons.values()):freeze(widget)
        target_picker.configure(state='disabled')
        area=dialog.content
        win.point_panel=dialog
        dialog.is_continuation=continuation
        dialog.target_key=key
        visual=None
        heading=ttk.Frame(area);heading.pack(fill='x')
        ttk.Label(heading,text=target_name+"の点参照",style="Section.TLabel",wraplength=150).pack(side='left')
        axis_row=heading
        source_card=ttk.Frame(area);source_card.pack(fill='x')
        source_row=ttk.Frame(source_card);source_row.pack(fill='x',pady=1)
        ttk.Label(source_row,text='参照',width=4).pack(side='left')
        source=ttk.Combobox(source_row,state="readonly",width=1,values=[d['label']+' · '+TYPE_LABELS[d['command']['type']].split(' · ')[-1] for i,d in candidates])
        source.pack(side='left',fill='x',expand=True);source.current(0)
        def identity_for_source(index):
            descriptor=source_defs[index];cmd=descriptor['command'];ci=descriptor['command_index']
            if descriptor['local']:
                identity=cmd.get('point_id') or pending_point_ids.setdefault(ci,new_id())
            else:
                identity=descriptor['block_id']+'/'+(cmd.get('point_id') or external_point_ids.setdefault((descriptor['block_index'],ci),new_id()))
            point_labels[identity]=descriptor['label']
            return identity
        from relation_point_ui import RelationPointControls
        relation=RelationPointControls(source_card,candidates,lambda:sync(),identity_for_source,compact=True)
        dialog.relation_controls=relation
        point=ttk.Combobox(source_row,state="readonly",width=8)
        point.pack(side='left',padx=(3,0))
        detail_open=[False]
        def toggle_point_details():
            detail_open[0]=True
            relation.pack(fill='x',pady=3)
        dialog.show_relation_details=toggle_point_details
        def sync(*_):
            point.configure(values=POINTS[candidates[source.current()][1]['command']['type']]);point.current(0)
            if visual is not None:
                visual.load(candidates[source.current()][0]);update_visual()
        source.bind("<<ComboboxSelected>>",sync);sync()
        combined = is_argument and param.get("kind") == "text"
        axis = None
        axis_segments = None
        coordinate_card=ttk.Frame(area);coordinate_card.pack(fill='x',pady=1)
        if not combined:

            axis=ttk.Combobox(axis_row,state='readonly',width=5,values=('X','Y') if is_argument else ('XY','X','Y'))
            axis.set('X' if is_argument else 'XY' if both else key[0].upper())
            dialog.axis_picker=axis
            axis_segments=SegmentedChoice(axis_row,axis,compact=True)
            axis_segments.pack(side='right');dialog.axis_segments=axis_segments
        angle_value=tk.StringVar(value='0')
        angle_host=ttk.Frame(coordinate_card)
        angle_head=ttk.Frame(angle_host);angle_head.pack(side='left')
        angle_caption=ttk.Label(angle_head,text='角度',width=7);angle_caption.pack(side='left')
        angle_entry=ttk.Entry(angle_host,textvariable=angle_value,width=1)
        angle_entry.pack(side='left',fill='x',expand=True)
        def restore_preview_access():
            if win.winfo_exists() and dialog.winfo_exists():
                win.grab_set();dialog.lift()
        def choose_angle(kind):
            if kind=='table':
                show_table_reference_picker(dialog,project,on_select=lambda text:angle_value.set(text),on_replace=lambda text:angle_value.set(text))
            else:
                from command_workbench import show_reference_list
                show_reference_list(dialog,[(label,refs) for label,refs in reference_groups(project) if '変数' in label or '設定' in label],angle_value.set)
            restore_preview_access()
        dialog.choose_angle=choose_angle
        def uses_angle():
            return visual is not None and point.get() in ('上','下','左','右','角度指定点') and point.get() in visual.points and '中心' in visual.points
        for caption,icon,kind in (('表','table','table'),('変数','variables','variable')):
            ttk.Button(angle_host,text=caption,image=icons_for(win).get(icon),compound='none',style='WorkbenchRef.TButton',width=2,command=lambda k=kind:choose_angle(k)).pack(side='left',padx=(3,0))
        extra_tools=None
        def update_visual(*_):
            chosen=axis.get() if axis else 'XY'
            if axis_segments is not None:axis_segments.sync()
            if visual is not None and relation.active:
                try:
                    visual.points=relation.preview(candidates[source.current()][0],visual.canvas)
                    if not point.get().startswith('候補') and visual.points:point.set(next(iter(visual.points)))
                    if point.get() not in visual.points:visual.status.set('選択した候補が成立しません。参照元・候補を確認してください')
                except (ValueError,KeyError,TypeError) as exc:
                    visual.points={};visual.status.set(str(exc))
                visual.canvas.snap_points=visual.points
                point.configure(values=tuple(visual.points))
            elif visual is not None and visual.points:
                base=POINTS[candidates[source.current()][1]['command']['type']]
                available=[name for name in base if name in visual.points]+[name for name in visual.points if name not in base]
                point.configure(values=available)
            if visual is not None:
                related={candidates[relation.second.current()][0]} if relation.active else set()
                if related!=getattr(visual.canvas,'related_source_indices',set()):
                    visual.canvas.related_source_indices=related;visual.canvas.recolor()
            if not is_argument:
                for component in ('x','y'):
                    frame=coordinate_axis_frames.get(component+suffix)
                    if frame is not None:
                        frame._card_focused=None
                        paint_card(frame,chosen in ('XY',component.upper()))
            if visual is not None:
                if uses_angle():angle_host.pack(fill='x',pady=3)
                else:angle_host.pack_forget()
                angle_caption.configure(text='角度°' if point.get()=='角度指定点' else '回転°')
                visual.update_selection(point.get(),None if chosen=='XY' else chosen,{},angle_value.get() if uses_angle() else None)
        def pick_visual(name):
            point.set(name);update_visual()
        def pick_source(index):
            selected=next((j for j,(i,cmd) in enumerate(candidates) if i==index),None)
            if selected is not None:
                source.current(selected);sync()
        visual=live[0]
        visual.status_visible=False
        old_marker_label=getattr(visual.canvas,'shifted_label','移動後')
        visual.canvas.shifted_label='参照点'
        buttons=dialog.footer;dialog.action_bar=buttons
        visual.source_refs=source_defs
        visual.on_pick=pick_visual;visual.canvas.on_pick=pick_visual;visual.canvas.on_source=pick_source
        visual.canvas.on_reference_candidate=lambda candidate:apply_direct_reference(dialog,candidate)
        visual.canvas.reference_candidate_indices={index for index,d in candidates}
        dialog.source_picker=source
        dialog.point_preview=visual
        original_reference=(argument_vars[key[4:]] if is_argument else coordinate_values[key].base).get()
        existing=read_point_reference(original_reference)
        from derived_points import read_relation_reference
        existing_relation=read_relation_reference(original_reference)
        if existing_relation:
            def find_source(identity):
                return next((j for j,(index,d) in enumerate(candidates) if identity in (identity_for_source(index),d['label'])),None)
            primary=find_source(existing_relation['primary']);secondary=find_source(existing_relation['secondary'])
            if primary is not None and secondary is not None:
                source.current(primary);relation.mode.set(existing_relation['mode']);relation.second.current(secondary)
                relation.external.set(existing_relation['external']);relation.sync();sync();point.set(existing_relation['branch'])
                if axis is not None:
                    axis.set(existing_relation['axis'])
                    if not is_argument:
                        other=read_relation_reference(coordinate_values[ykey if key==xkey else xkey].base.get())
                        if other and all(other[k]==existing_relation[k] for k in ('mode','primary','secondary','external','branch')) and other['axis']!=existing_relation['axis']:
                            axis.set('XY')
        if existing:
            for candidate_index,(_,descriptor) in enumerate(candidates):
                cmd=descriptor['command'];ci=descriptor['command_index']
                identity=cmd.get('point_id') or (pending_point_ids.get(ci) if descriptor['local'] else external_point_ids.get((descriptor['block_index'],ci)))
                if not descriptor['local'] and identity:identity=descriptor['block_id']+'/'+identity
                if existing['identity'] not in (identity,descriptor['label']):continue
                source.current(candidate_index);sync()
                if existing['point'] not in POINTS[cmd['type']] and existing['point'] not in visual.points:continue
                point.set(existing['point'])
                angle_value.set(existing.get('angle','0'))
                if axis is not None and existing['axis']:
                    axis.set(existing['axis'])
                    if not is_argument:
                        other=read_point_reference(coordinate_values[ykey if key==xkey else xkey].base.get())
                        if other and other['identity']==existing['identity'] and other['point']==existing['point'] and other.get('angle','0')==existing.get('angle','0') and existing['axis']==key[0].upper() and other['axis']==('Y' if key[0]=='x' else 'X'):
                            axis.set('XY')
                break
        if relation.active and not detail_open[0]:toggle_point_details()
        dialog.point_picker=point
        dialog.point_angle=angle_value;dialog.angle_entry=angle_entry
        if source_index is not None:
            source.current(next(j for j,(index,d) in enumerate(candidates) if index==source_index));sync()
        if continuation and selection_state:
            relation.mode.set(selection_state['mode']);relation.second.current(selection_state['second'])
            relation.external.set(selection_state['external']);relation.sync()
            angle_value.set(selection_state['angle'])
            if relation.active and not detail_open[0]:toggle_point_details()
        if continuation and axis is not None:axis.set(selection_state.get('axis',key[0].upper()) if selection_state else key[0].upper())
        visual.load(candidates[source.current()][0])
        if selected_point in visual.points or (selection_state and selection_state['mode']!='基準点'):point.set(selected_point)
        update_visual()
        point.bind("<<ComboboxSelected>>",update_visual)
        if axis:axis.bind("<<ComboboxSelected>>",update_visual)
        angle_value.trace_add('write',update_visual)
        row_job=[None]
        def refresh_row():
            row_job[0]=None
            if dialog.winfo_exists():update_visual()
        def queue_row(*_):
            if row_job[0]:win.after_cancel(row_job[0])
            row_job[0]=win.after_idle(refresh_row)
        row_trace=visual.row.trace_add('write',queue_row)
        point_bindings=[]
        focus_job=[None]
        point_menu=tk.Menu(visual.canvas,tearoff=False)
        cleaned=[False]
        def cleanup(commit=False):
            if cleaned[0]:return
            cleaned[0]=True
            if focus_job[0]:dialog.after_cancel(focus_job[0]);focus_job[0]=None
            visual.row.trace_remove('write',row_trace)
            if row_job[0]:win.after_cancel(row_job[0]);row_job[0]=None
            for widget,sequence,binding in point_bindings:
                if widget.winfo_exists():widget.unbind(sequence,binding)
            point_menu.destroy()
            selecting[0]=None
            if not commit:
                for mapping,baseline in zip((pending_point_ids,external_point_ids,point_labels),reference_baseline):
                    mapping.clear();mapping.update(baseline)
            visual.on_pick=focus_point;visual.canvas.on_pick=focus_point;visual.canvas.on_source=begin_point_reference
            visual.canvas.on_reference_candidate=begin_direct_reference
            visual.canvas.reference_candidate_indices=set(range(len(source_defs)))
            if extra_tools is not None:
                if extra_tools.winfo_exists():extra_tools.destroy()
                if coordinate_toolbar.winfo_exists():coordinate_toolbar.pack_forget()
                target_choice.set('')
            for widget,state in frozen:
                if widget.winfo_exists():widget.configure(state=state)
            if target_picker.winfo_exists():target_picker.configure(state='readonly')
            visual.status_visible=True
            visual.canvas.shifted_label=old_marker_label
        def destroyed(event):
            if event.widget is dialog:cleanup()
        dialog.bind('<Destroy>',destroyed,add='+')
        def close(commit=False):
            if cleaned[0]:return
            cleanup(commit)
            dialog.destroy()
            if win.winfo_exists():
                win.grab_set();win.focus_force();refresh_preview()
                if key in entries:entries[key].focus_set()
        dialog.protocol('WM_DELETE_WINDOW',close)

        def apply():
            i,descriptor=candidates[source.current()]
            cmd=descriptor["command"];ci=descriptor["command_index"]
            if descriptor["local"]:
                identity=cmd.get("point_id") or pending_point_ids.setdefault(ci,new_id())
            else:
                identity=descriptor["block_id"]+"/"+(cmd.get("point_id") or external_point_ids.setdefault((descriptor["block_index"],ci),new_id()))
            point_labels[identity] = descriptor["label"]
            angle=(angle_value.get().strip() or '0') if uses_angle() else None
            try:
                if point.get() not in visual.points:raise MacroError('参照する点がこの確認行にありません。参照元・点・確認行を確認してください')
                if visual.canvas.shifted_point is None:raise MacroError(visual.status.get() or '移動量・角度を確認してください')
                if angle is not None:parse_expression(angle)
            except MacroError as exc:
                messagebox.showerror("移動量の確認",str(exc),parent=dialog);return
            batching[0]=True
            if combined:
                old_offsets=existing['offsets'] if existing and existing['axis'] is None else existing_relation['offsets'] if existing_relation and existing_relation['axis']=='XY' else ['0','0']
                if relation.active:
                    argument_vars[key[4:]].set('='+relation.expression(point.get(),'XY',*old_offsets))
                else:
                    extra=f', {angle}' if angle is not None else ''
                    argument_vars[key[4:]].set(f"=点位置({identity!r}, {point.get()!r}, {old_offsets[0]}, {old_offsets[1]}{extra})")
            elif axis.get()=="XY":
                for coordinate,target in (("X",xkey),("Y",ykey)):
                    expression=relation.expression(point.get(),coordinate) if relation.active else reference(identity,point.get(),coordinate,angle)
                    coordinate_values[target].base.set(rewrite_references(expression,point_labels))
            else:
                expression=relation.expression(point.get(),axis.get()) if relation.active else reference(identity,point.get(),axis.get(),angle)
                if is_argument:
                    argument_vars[key[4:]].set(compose_coordinate(expression,split_coordinate(original_reference)[1]))
                else:
                    target=axis.get().lower()+suffix
                    coordinate_values[target].base.set(rewrite_references(expression,point_labels))
            if is_argument:
                var=argument_vars[key[4:]]
            else:
                var=variables[key]
            var.set(rewrite_references(var.get(),point_labels))
            batching[0]=False;record_edit()
            next_key=None
            if not is_argument:
                xs=[k for k in entries if coordinate_key(k) and k.startswith('x')]
                current=xkey if xkey in xs else key
                if axis.get()=='X':next_key=ykey
                elif current in xs and xs.index(current)+1<len(xs):next_key=xs[xs.index(current)+1]
            point_name=point.get()
            next_state=dict(mode=relation.mode.get(),second=relation.second.current(),external=relation.external.get(),angle=angle_value.get(),axis='Y' if axis is not None and axis.get()=='X' else 'XY')
            close(commit=True)
            if next_key is not None:
                if next_key[1:] in collapsed_points:
                    coordinate_cards[next_key[1:]].point_header.set_expanded(True)
                    win.update_idletasks();form_changed()
                entries[next_key].focus_set();focused[0]=entries[next_key];focus_marker()
                choose_command_point(next_key,source_index=i,continuation=True,selected_point=point_name,selection_state=next_state)
        def accept_point(event=None):
            if selecting[0] is dialog:
                if point.get() in visual.points:apply()
                return 'break'
        def point_context(event):
            if selecting[0] is dialog and point.get() in visual.points:
                point_menu.tk_popup(event.x_root,event.y_root)
                return 'break'
        point_menu.add_command(label='この点を使用',command=accept_point)
        point_menu.add_command(label='交点・接点の設定',command=toggle_point_details)
        def source_context(event):
            point_menu.tk_popup(event.x_root,event.y_root)
            return 'break'
        for widget in (source,point):widget.bind('<Button-3>',source_context)
        for widget,sequence,callback in ((win,'<Return>',accept_point),(win,'<KP_Enter>',accept_point),(dialog,'<Return>',accept_point),(dialog,'<KP_Enter>',accept_point),(dialog,'<Escape>',lambda e:(close(),'break')[-1]),(visual.canvas,'<Button-3>',point_context)):
            point_bindings.append((widget,sequence,widget.bind(sequence,callback,add='+')))
        ttk.Button(buttons,text="キャンセル",command=close).pack(side="left")
        ttk.Button(buttons,text="この点を使用",style="WorkbenchPrimary.TButton",command=apply).pack(side="right")
        win.close_point_panel=close
        dialog.apply_reference=apply

        paint_card(area,True)
        update_visual()
        win.update_idletasks();dialog.queue_arrange()
        focus_job[0]=dialog.after_idle(source.focus_set)

    win.choose_command_point = choose_command_point

    def add_reference_menu(row, entry, key):
        """Let every applicable field use a table picker or the old quick menu."""
        if coordinate_key(key):return
        menu_button = ttk.Menubutton(row, text="表・変数 ▾", width=2, style="MainIcon.TMenubutton")
        menu_button.icon_button_style = "MainIcon.TMenubutton"
        entry.reference_button = menu_button
        menu = tk.Menu(menu_button, tearoff=0)
        menu.add_command(
            label="表の列・セルから選ぶ…",
            command=lambda e=entry, k=key: show_table_reference_picker(
                win, project,
                lambda ref: place_ref(e, k, ref),
                on_replace=lambda ref: place_ref(e, k, ref, replace=True),
            ),
        )
        if coordinate_key(key) or key.startswith("arg:"):
            menu.add_command(label="別コマンドの始点・中点・終点から選ぶ…", command=lambda k=key: choose_command_point(k))
        menu.add_separator()
        for group_title, group_refs in ref_groups:
            group_menu = tk.Menu(menu, tearoff=0)
            for ref in group_refs:
                group_menu.add_command(
                    label=ref,
                    command=lambda e=entry, k=key, r=ref: place_ref(e, k, r),
                )
            menu.add_cascade(label=group_title, menu=group_menu)
        menu_button.configure(menu=menu)
        menu_button.pack(side="left", padx=(3, 0))

    def insert_ref(*_):
        selected = listing.curselection()
        if not selected:
            return
        entry = focused[0]
        key = next((k for k, e in entries.items() if e is entry), "")
        place_ref(entry, key, listing.get(selected[0]))

    listing.bind("<Double-1>", insert_ref)
    ttk.Button(
        refs, text="選択した参照を挿入", command=insert_ref, style="Compact.TButton"
    ).grid(row=3, column=0, sticky="ew", pady=(6, 0))
    ttk.Label(
        refs,
        text="loop.index: 0始まり / number: 1始まり\nloop.count: 反復回数（繰り返し内のみ）",
        style="Muted.TLabel",
        wraplength=250,
    ).grid(row=4, column=0, sticky="w", pady=(6, 0))
    def toggle_refs():
        from command_workbench import show_reference_list
        show_reference_list(win, ref_groups, lambda value: place_ref(focused[0], next((k for k,e in entries.items() if e is focused[0]), ''), value))

    ref_button = ttk.Button(header, text='列・変数の一覧', command=toggle_refs, style='Compact.TButton')
    ref_button.pack(side='right', padx=(8,0))
    active = [old_type]
    point_titles = {}
    field_results = {}
    collapsed_points=set()
    coordinate_axis_frames={}
    win.coordinate_axis_frames=coordinate_axis_frames
    coordinate_cards = {}
    win.field_results=field_results
    win.coordinate_cards=coordinate_cards
    point_buttons = {}
    reference_summaries = {}
    win.reference_summaries=reference_summaries
    vertex_count = [0]
    vertex_ids = []

    def coordinate_key(key):
        return key in ("x","y") or (key[:1] in ("x","y") and key[1:].isdigit())

    def field_caption(key):
        if active[0] in VERTEX_TYPES and coordinate_key(key) and key[1:].isdigit():
            i=int(key[1:]);name="始点" if i==1 else "終点" if i==vertex_count[0] else f"中間点{i-1}"
            return name+" "+key[0].upper()
        if coordinate_key(key) and "x"+key[1:] in point_titles:return point_titles["x"+key[1:]]+" "+key[0].upper()
        return LABELS.get(key,key)

    def gather():
        data = {
            "type": active[0],
            **working,
            **{k: v.get() for k, v in variables.items()},
        }
        if active[0] in VERTEX_TYPES and vertex_count[0]:
            vertices=[dict(id=vertex_ids[i],x=variables[f"x{i+1}"].get(),y=variables[f"y{i+1}"].get()) for i in range(vertex_count[0])]
            for key in list(data):
                if coordinate_key(key) and key[1:].isdigit():data.pop(key,None)
            if "vertices" in working or any("前点." in p[a] for p in vertices for a in ("x","y")):data["vertices"]=vertices
            if active[0]=="LINE":
                data.update(x1=vertices[0]["x"],y1=vertices[0]["y"],x2=vertices[-1]["x"],y2=vertices[-1]["y"])
            else:
                old=read_vertices(working)
                unchanged=[(p['x'],p['y']) for p in old]==[(p['x'],p['y']) for p in vertices]
                data['points']=working.get('points',points_text(vertices)) if unchanged else points_text(vertices)
        if active[0]=="CIRCLE":data.setdefault("r","@OD / 2")
        if active[0]=="ARC":
            for k,v in FIELDS["ARC"]:data.setdefault(k,v)
        for color_key in ("color","layer_color"):
            if color_key in data:data[color_key]=entity_color_code(data[color_key])
        if "layer_weight" in data:
            from layer_change import weight_value
            data["layer_weight"]=weight_value(data["layer_weight"])
        if active[0] == "CUSTOM":
            data.update(
                name=selected_custom[0],
                arguments={k: v.get() for k, v in argument_vars.items()},
            )
        if active[0] in SELECTION_OPERATORS and 'selection_ref' in data:
            for key in ('x1','y1','x4','y4','selection_mode','pick_tolerance'):data.pop(key,None)
        return rewrite_references(data, {label: identity for identity,label in point_labels.items()})

    def switch_input_mode(field,new_mode):
        before=gather();typ=active[0]
        old_mode=before.get(field,'radius' if typ=='CIRCLE' else 'center_angles')
        mode_drafts[(typ,old_mode)]=copy.deepcopy(before)
        geometry={'x','y','x1','y1','x2','y2','x3','y3','r','diameter','start_angle','end_angle'}
        saved=mode_drafts.get((typ,new_mode),{})
        data={k:v for k,v in before.items() if k not in geometry}
        data.update({k:v for k,v in saved.items() if k in geometry});data[field]=new_mode
        working.clear();working.update(data);redraw(False);record_edit()

    def inherited_hint(key):
        from inherited_appearance import inheritance_hint
        return inheritance_hint(key,getattr(live[0],'appearance_state',{}) if live[0] is not None else {})

    def refresh_inheritance_hints():
        for entry in entries.values():
            if hasattr(entry,'refresh_hint'):entry.refresh_hint()

    def make_coordinate_formula(suffix):
        if selecting[0] is not None:return
        from coordinate_formula_ui import show_coordinate_formulas
        from command_workbench import evaluated_fields
        def context():
            values=evaluated_fields(project,scene_blocks(),live[0].canvas.items,int(sample_row.get())-1,sample_locals)
            if repeat_counts:
                from coordinate_formulas import repeat_context
                values['__loop__']=repeat_context(values,repeat_counts,allow_zero=True)
            for identity,label in point_labels.items():
                key='__all_command_points__' if '/' in identity else '__command_points__'
                if identity in values[key]:values[key][label]=values[key][identity]
            if active[0] in VERTEX_TYPES and suffix.isdigit() and int(suffix)>1:
                from vertex_points import evaluate_chain
                from engine import number
                points=evaluate_chain([(variables['x'+str(i)].get(),variables['y'+str(i)].get()) for i in range(1,int(suffix))],values,number)
                values['__前点__']=dict(zip(('X','Y'),points[-1]))
            return values
        movement_mode=focused[0] in movement_entries.values()
        sources=[coordinate_values[a+suffix].movement if movement_mode else variables[a+suffix] for a in ('x','y')]
        result=show_coordinate_formulas(win,project,tuple(v.get() for v in sources),context,repeat_counts)
        if result is not None:
            batching[0]=True
            for variable,expression in zip(sources,result):variable.set(expression)
            batching[0]=False;record_edit();refresh_preview()
    win.make_coordinate_formula=make_coordinate_formula
    def open_coordinate_summary(suffix):
        if any(read_point_reference(coordinate_values[axis+suffix].base.get()) for axis in ('x','y')):
            choose_command_point('x'+suffix,both=True)
        else:make_coordinate_formula(suffix)

    def add_point_actions(head,suffix):
        tools=ttk.Frame(coordinate_toolbar);coordinate_tools[suffix]=tools
        def target_key():
            focused_key=next((k for k,e in entries.items() if e is focused[0]),None)
            focused_key=(focused_key or '').removeprefix('move:')
            return focused_key if focused_key in ('x'+suffix,'y'+suffix) else 'x'+suffix
        def target_entry(key):
            return movement_entries[key] if focused[0] in movement_entries.values() else entries[key]
        def table():
            if selecting[0] is not None:return
            movement=focused[0] in movement_entries.values()
            axis=tk.StringVar(value=target_key()[0].upper())
            def apply(ref):
                key=axis.get().lower()+suffix
                place_ref(movement_entries[key] if movement else entries[key],key,ref,replace=True)
            show_table_reference_picker(win,project,apply,on_replace=apply,target_axis=axis)
        def variable():
            if selecting[0] is not None:return
            movement=focused[0] in movement_entries.values()
            dialog=tk.Toplevel(win);dialog.title('変数を選択');dialog.transient(win);dialog.grab_set()
            fit_window(dialog,460,430,360,300)
            axis=tk.StringVar(value=target_key()[0].upper())
            bar=ttk.Frame(dialog,padding=12);bar.pack(fill='x')
            ttk.Label(bar,text='入力先').pack(side='left')
            ttk.Combobox(bar,textvariable=axis,values=('X','Y'),state='readonly',width=6).pack(side='left',padx=8)
            choices=tk.Listbox(dialog,exportselection=False,activestyle='dotbox');choices.pack(fill='both',expand=True,padx=12)
            values=[r for title,refs_ in ref_groups if title in ('変数','共通設定','繰り返し') for r in refs_]
            for value in values:choices.insert('end',value)
            current=target_entry(target_key()).get()
            if current in values:choices.selection_set(values.index(current));choices.see(values.index(current))
            def close_variable():
                dialog.destroy()
                if win.winfo_exists():win.grab_set()
            def apply(*_):
                if not choices.curselection():return
                key=axis.get().lower()+suffix;place_ref(movement_entries[key] if movement else entries[key],key,values[choices.curselection()[0]],replace=True)
                close_variable()
            choices.bind('<Double-1>',apply)
            footer=ttk.Frame(dialog,padding=12);footer.pack(fill='x')
            ttk.Button(footer,text='キャンセル',command=close_variable).pack(side='left')
            ttk.Button(footer,text='この変数を使用',command=apply,style='Primary.TButton').pack(side='right')
            dialog.protocol('WM_DELETE_WINDOW',close_variable)
            dialog.bind('<Escape>',lambda event:(close_variable(),'break')[-1])
            win.wait_window(dialog)
            if win.winfo_exists():win.grab_set()
        buttons=[]
        for label,icon,action in (('表','table',table),('コマンド','tree',lambda:choose_command_point(target_key(),both=True)),('変数','variables',variable)):
            button=ttk.Button(tools,text=label,image=icons_for(win).get(icon),compound='left',style='WorkbenchRef.TButton',width=0,command=action)
            button.icon_only=False
            button.pack(side='left',padx=(3,0));button.tooltip_text=label+'から選択';buttons.append(button)
        head.reference_buttons=buttons
        formula_button=ttk.Button(tools,text='計算',style='WorkbenchRef.TButton',command=lambda:make_coordinate_formula(suffix))
        formula_button.pack(side='left',padx=(3,0));formula_button.tooltip_text='移動量・距離と角度・繰り返し配置からX/Yの式を作る'
        if not hasattr(win,'coordinate_formula_buttons'):win.coordinate_formula_buttons={}
        win.coordinate_formula_buttons[suffix]=formula_button
        if active[0] in VERTEX_TYPES and suffix.isdigit() and int(suffix)>1:
            def use_previous():
                key=target_key();entry=target_entry(key)
                try:float(entry.get());replace=not entry.selection_present()
                except ValueError:replace=False
                place_ref(entry,key,'前点.'+key[0].upper(),replace=replace)
            previous_button=ttk.Button(tools,text='前点',style='WorkbenchRef.TButton',command=use_previous)
            previous_button.pack(side='left',padx=(3,0))
            previous_button.tooltip_text='入力中のX/Yへ前点を挿入（数値だけの欄は置換）'
            head.previous_point_button=previous_button
            if not hasattr(win,'previous_point_buttons'):win.previous_point_buttons={}
            win.previous_point_buttons[suffix]=previous_button
        point_buttons[suffix]=buttons

    def connect_point_buttons(suffix,buttons):
        if not buttons[0].winfo_exists():return
        for key in ('x'+suffix,'y'+suffix):
            if key in entries:
                entries[key].reference_buttons=buttons;entries[key].reference_button=buttons[0]
                if key in movement_entries:
                    movement_entries[key].reference_buttons=[buttons[0],buttons[2]]
                    movement_entries[key].reference_button=buttons[0]

    def change_vertex(remove=None):
        limit = 500 if active[0] == "HATCH" else MAX_VERTICES
        minimum = 3 if active[0] == "HATCH" else 2
        if remove is None and vertex_count[0]>=limit:
            return messagebox.showinfo("点数の上限", f"1コマンドは{limit}点までです", parent=win)
        if remove is not None and vertex_count[0]<=minimum:return
        if remove is None and active[0] in ('LINE','POLYLINE'):collapsed_points.update(str(i+1) for i in range(vertex_count[0]))
        data=gather()
        vertices=[dict(id=vertex_ids[i],x=variables[f"x{i+1}"].get(),y=variables[f"y{i+1}"].get()) for i in range(vertex_count[0])]
        vertices=rewrite_references(vertices,{label:identity for identity,label in point_labels.items()})
        if remove is None:vertices.append(dict(id=vertex_id(),x="",y=""))
        else:vertices.pop(remove)
        data['vertices']=vertices
        if active[0]=='POLYLINE':
            if len(vertices)<3:data['closed']='0'
            elif vertex_count[0]<3:data['closed']='1'
        working.clear();working.update(data)
        redraw(False);record_edit()
        if remove is None:
            entry=entries[f"x{len(vertices)}"]
            win.after_idle(lambda: (viewport.yview_moveto(min(1, max(0, (entry.winfo_rooty()-form.winfo_rooty()-40)/max(1,form.winfo_height())))),entry.focus_set()) if entry.winfo_exists() else None)
    win.add_vertex=lambda:change_vertex()
    win.remove_vertex=lambda index:change_vertex(index)

    def branch(key):
        working.update({k: v.get() for k, v in variables.items()})
        staged = copy.deepcopy(working.get(key, []))
        before_blocks = copy.deepcopy(blocks)
        sub = tk.Toplevel(win)
        sub.title(
            "IF: 実行する側"
            if key == "commands" and active[0] == "IF"
            else "ELSE: 条件に合わない側"
            if key == "else"
            else "繰り返すコマンド"
        )
        sub.geometry("880x540")
        sub.transient(win)
        sub.grab_set()
        ttk.Label(
            sub, text="ここに追加したコマンドを、上から順番に実行します。", padding=12
        ).pack(anchor="w")
        editor = CommandList(
            sub,
            staged,
            blocks,
            project=project,
            local_names=sample_locals or local_names,
            folder_id=folder_id,
            previous_blocks=previous_blocks, owner_block_id=owner_block_id,
            repeat_counts=tuple(repeat_counts)+( (variables['count'].get(),) if active[0]=='REPEAT' else () ),
        )
        editor.space_provider=lambda:creation_space
        sub.command_list=editor

        def cancel():
            if (
                staged != working.get(key, []) or blocks != before_blocks
            ) and not messagebox.askyesno(
                "変更の破棄", "この階層の変更を破棄しますか？", parent=sub
            ):
                return
            replace_collection(blocks, before_blocks)
            sub.destroy()

        def commit():
            working[key] = copy.deepcopy(editor.commands)
            sub.destroy()

        bar = ttk.Frame(sub, padding=10)
        bar.pack(side="bottom", fill="x", before=editor.frame)
        ttk.Button(bar, text="キャンセル", command=cancel).pack(side="left")
        ttk.Button(
            bar, text="この階層を確定", style="Primary.TButton", command=commit
        ).pack(side="right")
        sub.protocol("WM_DELETE_WINDOW", cancel)
        sub.bind("<Escape>", lambda e: cancel())
        win.wait_window(sub)
        win.grab_set()
        redraw(False)

    def selection_source_identity(item):
        bi=item.get('block_index');ci=item.get('command_index')
        descriptor=next((d for d in source_defs if d['block_index']==bi and d['command_index']==ci),None)
        if descriptor is None:return None
        cmd=descriptor['command']
        if descriptor['local']:
            identity=cmd.get('point_id') or pending_point_ids.setdefault(ci,new_id())
            point_labels[identity]=descriptor['label']
            return identity
        identity=cmd.get('point_id') or external_point_ids.setdefault((bi,ci),new_id())
        key=descriptor['block_id']+'/'+identity
        point_labels[key]=descriptor['label']
        return key

    def apply_select_data(data):
        working.clear();working.update(data);redraw(False);record_edit();refresh_preview()

    def create_select():
        data=edit_command(win,dict(type='SELECT'),blocks,project,point_sources=point_sources,previous_blocks=previous_blocks,repeat_counts=repeat_counts)
        if data is not None:
            if isinstance(data,list):data=data[-1]
            if data.get('type')!='SELECT':
                messagebox.showinfo('SELECTを追加','選択用のSELECTコマンドを追加してください。',parent=win);return
            prepended.append(data);point_sources.append(data)
            current_data=gather();current_data['selection_ref']=data['point_id'];working.clear();working.update(current_data);redraw(False);record_edit()
    win.create_select=create_select

    def redraw(changed=True):
        if live[0] is not None:live[0].canvas.cancel_range()
        redrawing[0]=True
        if changed:
            drafts[active[0]] = gather()
            typ = next(k for k, v in TYPE_LABELS.items() if v == choice.get())
            from selection_sets import can_create
            if creating and not can_create(typ,point_sources):
                choice.set(TYPE_LABELS[active[0]])
                redrawing[0]=False
                messagebox.showinfo('SELECTが必要です','先にSELECTコマンドを作成し、その直後に追加してください。',parent=win)
                return
            reason=creation_reason(typ,creation_space)
            if reason:
                choice.set(TYPE_LABELS[active[0]]);redrawing[0]=False
                messagebox.showinfo('作図先の確認',reason,parent=win);return
            active[0] = typ
            working.clear()
            working.update(copy.deepcopy(drafts.get(typ, {"type": typ})))
        for widget in mode_host.winfo_children():widget.destroy()
        for tools in coordinate_tools.values():tools.destroy()
        coordinate_tools.clear();target_keys.clear()
        win.coordinate_formula_buttons={};win.previous_point_buttons={}
        for coordinate in coordinate_values.values():coordinate.close()
        coordinate_values.clear();movement_entries.clear()
        point_titles.clear();field_results.clear();coordinate_axis_frames.clear();coordinate_cards.clear();point_buttons.clear();reference_summaries.clear()
        for widget in form.winfo_children():
            widget.destroy()
        entries.clear()
        variables.clear()
        argument_vars.clear()
        focused[0] = None
        typ = active[0]
        if typ=='SELECT':working.setdefault('point_id',new_id());working.setdefault('selections',[])
        if typ in SELECTION_OPERATORS:working.setdefault('selection_ref','@previous')
        if typ == "CUSTOM":
            catalog = project.get("custom_commands", {})
            if selected_custom[0] not in catalog:
                selected_custom[0] = next(iter(catalog), "")
            custom_header = ttk.Frame(form, style="PointCard.TFrame", padding=10)
            custom_header.pack(fill="x", pady=(0,8))
            ttk.Label(custom_header,text="使用するコマンド",style="CardTitle.TLabel").pack(anchor="w",pady=(0,8))
            row = ttk.Frame(custom_header)
            row.pack(fill="x", pady=4)
            field_label(row, text="登録したコマンド", width=18).pack(side="left")
            names = {k: d["name"] for k, d in catalog.items()}
            custom_choice = tk.StringVar(value=names.get(selected_custom[0], ""))
            combo = ttk.Combobox(
                row,
                textvariable=custom_choice,
                values=list(names.values()),
                state="readonly",
            )
            combo.pack(side="left", fill="x", expand=True)

            def choose_custom(_=None):
                working["condition"] = variables.get(
                    "condition", tk.StringVar(value="")
                ).get()
                selected_custom[0] = next(
                    (k for k, v in names.items() if v == custom_choice.get()), ""
                )
                working["name"] = selected_custom[0]
                working["arguments"] = {}
                redraw(False)

            combo.bind("<<ComboboxSelected>>", choose_custom)
            if not catalog:
                ttk.Label(
                    custom_header,
                    text="メイン画面のブロック一覧「…」→「登録コマンド」で新規登録できます。",
                    wraplength=400,
                ).pack(anchor="w", pady=12)
            definition = catalog.get(selected_custom[0], {})
            ttk.Label(
                custom_header,
                text=definition.get("description", ""),
                style="Muted.TLabel",
                wraplength=400,
            ).pack(anchor="w", pady=8)
            ttk.Label(
                custom_header,
                text="実行: "
                + (
                    "生成全体で1回"
                    if definition.get("execution") == "once"
                    else "対象の各行"
                )
                + " / 図形プレビュー対象外",
                style="Muted.TLabel",
                wraplength=400,
            ).pack(anchor="w", pady=(0, 7))
            values_card = ttk.Frame(form, style="PointCard.TFrame", padding=10)
            values_card.pack(fill="x", pady=(0,8))
            ttk.Label(values_card,text="設定する値",style="CardTitle.TLabel").pack(anchor="w",pady=(0,8))
            for param in definition.get("parameters", []):
                row = ttk.Frame(values_card)
                row.pack(fill="x", pady=4)
                field_label(row, text=param.get("label", param["name"]), width=18).pack(
                    side="left"
                )
                original = (
                    working.get("arguments", {})
                    if working.get("name") == selected_custom[0]
                    else {}
                )
                value = tk.StringVar(
                    value=rewrite_references(str(original.get(param["name"], param.get("default", ""))), point_labels)
                )
                from parameter_inputs import argument_entry
                entry = argument_entry(row, param, value, project, win)
                add_reference_color(entry,value,project.get("globals",{}),literal=param.get("kind")=="text")
                argument_vars[param["name"]] = value
                entries["arg:" + param["name"]] = entry
                entry.bind("<FocusIn>", focus_sample)
                value.trace_add("write", update_sample)
                value.trace_add("write", record_edit)
                add_reference_menu(row, entry, "arg:" + param["name"])
                if param["kind"] == "number":
                    label=ttk.Label(values_card,text="",style="CardMuted.TLabel")
                    field_results["arg:"+param["name"]]=label
            paint_card(custom_header);paint_card(values_card)
        if typ in ('SPACE','LAYOUT','VIEWPORT'):
            ttk.Label(form,text='レイアウト・ビューポートの結果はAutoCADで確認してください。番号はCADのCVPORTで確認できます。',style='Muted.TLabel',wraplength=550).pack(fill='x',pady=(0,8))
        if typ == 'SYSVARS':
            from system_variables_ui import SystemVariablesEditor
            items=working.setdefault('items',[dict(name='OSMODE',value_kind='number',value='0')])
            win.system_variables_editor=SystemVariablesEditor(form,items,record_edit)
            win.system_variables_editor.pack(fill='x',pady=8)
        vertex_count[0]=0;vertex_ids.clear();win.vertex_rows=[]
        if typ in VERTEX_TYPES:
            chain=read_vertices(({**dict(x1='0',y1='0',x2='0',y2='0'),**working}) if typ=='LINE' else {**dict(FIELDS[typ]),**({'points':'0,0; 0,0'} if typ=='POLYLINE' else {}), **working})
            vertex_count[0]=len(chain);vertex_ids.extend(p['id'] for p in chain)
            fields=[("layer","")]+[(key+str(i+1),point[key]) for i,point in enumerate(chain) for key in ('x','y')]
            if typ not in ('LINE', 'POLYLINE'):
                fields.extend((k,v) for k,v in FIELDS[typ] if k not in ('layer','points'))
            if typ=='POLYLINE':
                if len(chain)<3:working['closed']='0'
                fields.append(('closed',working.get('closed','1')))
        else:
            fields = visible_fields(typ,working) if typ in LAYOUT_FIELDS else list(FIELDS[typ])
        if typ=='TEXT' and str(working.get('text_halign','')) in ('3','5'):
            fields.extend((key,working.get(key,'0')) for key in ('text_align_x','text_align_y'))
        if typ in SELECTION_OPERATORS:
            options=[('@previous','直前のSELECT'),*selection_descriptors(previous_blocks,point_sources)]
            refrow=ttk.Frame(mode_host);refrow.pack(fill='x',pady=(0,6))
            ttk.Label(refrow,text='使用する選択',width=11).pack(side='left')
            select_picker=ttk.Combobox(refrow,state='readonly',values=[label for _,label in options],width=26)
            select_picker.set(next((label for key,label in options if key==working['selection_ref']),'（参照先がありません）'))
            select_picker.pack(side='left',fill='x',expand=True)
            select_picker.bind('<<ComboboxSelected>>',lambda event:switch_input_mode('selection_ref',next(key for key,label in options if label==select_picker.get())))
            win.selection_ref_picker=select_picker
            ttk.Button(refrow,text='SELECTを追加',command=create_select,style='Compact.TButton').pack(side='left',padx=(6,0))
            if not point_sources or point_sources[-1].get('type')!='SELECT':
                guide=ttk.Frame(mode_host);guide.pack(fill='x',pady=(0,8))
                ttk.Label(guide,text='直前にSELECTがありません。「SELECTを追加」で対象を選択してください。\nプレビューで図形を1つずつクリック、または範囲を囲って選び、確定後にこの設定へ戻ります。',wraplength=520,style='Muted.TLabel').pack(anchor='w')
                ttk.Button(guide,text='SELECTの作成手順',command=lambda:messagebox.showinfo('SELECTの作成手順','1.「SELECTを追加」を押します。\n2. 選択方法を「点」または「範囲」にします。\n3.「プレビューで追加」を押し、図形をクリック／ドラッグして追加します。\n4. 範囲は座標のまま保存するか、対象を囲む最小範囲を点参照で作れます。\n5. Escで選択を終了し、コマンドを反映します。',parent=win)).pack(anchor='w')
            fields=[(key,value) for key,value in fields if key not in ('x1','y1','x4','y4','pick_tolerance')]
        if typ in RANGE_TYPES and 'selection_ref' not in working:
            selection_mode=working.get('selection_mode','point')
            mode_row=ttk.Frame(mode_host);mode_row.pack(fill='x',pady=(0,6))
            ttk.Label(mode_row,text='選択方法',width=9).pack(side='left')
            selection_picker=ttk.Combobox(mode_row,state='readonly',values=tuple(SELECTION_MODES.values()),width=23)
            selection_picker.set(SELECTION_MODES.get(selection_mode,SELECTION_MODES['point']))
            selection_picker.pack(side='left',fill='x',expand=True)
            selection_picker.bind('<<ComboboxSelected>>',lambda event: switch_input_mode('selection_mode',next(k for k,v in SELECTION_MODES.items() if v==selection_picker.get())))
            win.selection_mode_picker=selection_picker
            ttk.Button(mode_row,text='プレビューで追加' if typ=='SELECT' else 'プレビューで範囲を指定',command=start_range,
                       state='normal' if typ=='SELECT' or selection_mode!='point' else 'disabled',style='Compact.TButton').pack(side='left',padx=(6,0))
            if selection_mode!='point':fields[3:3]=[('x4',working.get('x4','@X+100')),('y4',working.get('y4','@Y+100'))]
        notes = {
            'PEDIT': '線分・円弧・ポリラインを編集。結合は接続した同じ属性の図形が対象です。',
            'SELECT': '点・矩形を追加して選択を保存。同じ図形は1回だけ扱います。',
            'ROTATE': '対象と回転の基点・角度を指定。元図形を回転します。',
            'ROTATECOPY': '角度間隔と追加個数で回転複写。元図形は残します。',
            'ARRAYRECT': '行列数は元を含む個数。XY間隔で非連想の配列複写を作ります。',
            'EXPLODE': 'ポリラインやCADブロック等を分解。結果を表示できない形状もあります。',
            'CADBLOCK': '選択した図形をCADブロックへ変換。既存名は上書きしません。',
            'SCALE': '基点と正の倍率で尺度変更。負の倍率はミラーを使ってください。',
            'MTEXT': '改行と幅指定に対応。表示の折り返しはCADのフォントと差が出ます。',
            'HATCH': '単一の閉じた境界を頂点で指定。境界線は出力しません。',
            'SPLINE': '通過点を＋で追加。開いたフィットスプライン（プレビューは近似）です。',
            'INSERT': 'CAD内に定義済みのブロックを挿入。プレビューは挿入位置のみです。',
            'LEADER': '始点が矢印先端、終点側に注記。点は＋で追加できます。',
            'OFFSET': '対象上の点と方向を指定。線分・円は結果をプレビューに反映します。',
            'EXTEND': '境界と延長側の端寄りの点を指定。線分は延長後の形状を表示します。',
            'COPY': '対象・基点・移動先を指定。円や楕円は中心でも選択できます。',
            'MIRROR': '対象と対称軸の2点を指定。削除0＝元図形を残す、1＝削除します。',
            'TRIM': '境界上の点と削除側の点を指定。線分は編集後の形状を表示します。',
        }
        if typ in notes and typ!='SELECT':
            ttk.Label(mode_host, text=notes[typ], style='Muted.TLabel', wraplength=520).pack(fill='x', pady=(0, 6))
        if typ == 'CIRCLE':
            size_row=ttk.Frame(mode_host);size_row.pack(fill='x')
            ttk.Label(size_row,text='サイズ指定',width=9).pack(side='left')
            size_picker=ttk.Combobox(size_row,state='readonly',values=('半径','直径'))
            size_picker.set('直径' if working.get('circle_mode')=='diameter' else '半径');size_picker.pack(side='left',fill='x',expand=True)
            def change_circle_mode(event):
                switch_input_mode('circle_mode','diameter' if size_picker.get()=='直径' else 'radius')
            size_picker.bind('<<ComboboxSelected>>',change_circle_mode);win.circle_mode_picker=size_picker
            if working.get('circle_mode')=='diameter':fields=[(k,v) if k!='r' else ('diameter',working.get('diameter','@OD')) for k,v in fields]
        if typ == 'ARC':
            mode=working.get('arc_mode','center_angles')
            modes_row=ttk.Frame(mode_host);modes_row.pack(fill='x')
            ttk.Label(modes_row,text='入力方式',width=9).pack(side='left')
            mode_picker=ttk.Combobox(modes_row,state='readonly',width=27,values=list(ARC_MODES.values()))
            mode_picker.set(ARC_MODES.get(mode,ARC_MODES['center_angles']));mode_picker.pack(side='left',fill='x',expand=True)
            def change_arc_mode(event):
                switch_input_mode('arc_mode',next(k for k,v in ARC_MODES.items() if v==mode_picker.get()))
            mode_picker.bind('<<ComboboxSelected>>',change_arc_mode)
            win.arc_mode_picker=mode_picker
            if mode!='center_angles':
                fields=[('layer',''),('x1','@X+25'),('y1','@Y'),('x2','@X' if mode=='start_center_end' else '@X+25'),('y2','@Y' if mode=='start_center_end' else '@Y+25'),('x3','@X'),('y3','@Y+25')]
        if typ in DRAWING_TYPES:
            fields.insert(1, ("linetype", ""))
            fields.extend([("color", ""), ("linetype_scale", "")])
        if typ in ("TEXT","MTEXT"):
            fields.insert(2, ("text_style", ""))
        if typ in DIMENSION_TYPES:
            fields.insert(2, ("dim_style", ""))
        if typ != "APPEARANCE":
            fields = [(key, default) for key, default in fields if key not in {"layer", "linetype", "color", "linetype_scale", "text_style", "dim_style"}]
        if typ=='PEDIT' and working.get('polyline_action','ポリライン化') not in ('結合','結合して閉じる'):fields=[(k,v) for k,v in fields if k!='join_tolerance']
        if typ=='SELECT':fields=[]
        advanced_keys = {"layer", "linetype", "color", "linetype_scale", "text_style", "dim_style", "condition"}
        if typ == "IF":
            advanced_keys.discard("condition")
        if typ == "LAYEREDIT":advanced_keys={key for key,default in LAYER_FIELDS if key not in ("target_layer","execution")}
        basic_section = ttk.Frame(form)
        basic_section.pack(fill="x")
        advanced_section = ttk.LabelFrame(
            form, text="レイヤーの変更項目" if typ == "LAYEREDIT" else "作図属性" if typ == "APPEARANCE" else "実行条件", padding=(10, 4, 10, 6), style="Group.TLabelframe"
        )
        win.advanced_section = advanced_section
        advanced_rows = {}
        win.advanced_rows = advanced_rows

        coordinate_rows = {}
        field_names = {key for key, _ in fields}
        for key, default in fields:
            optional = key in advanced_keys
            is_coordinate = coordinate_key(key) and "x"+key[1:] in field_names and "y"+key[1:] in field_names
            if is_coordinate:
                suffix = key[1:]
                if suffix not in coordinate_rows:
                    group = ttk.Frame(basic_section,style="PointCard.TFrame",padding=8)
                    group.pack(fill="x", pady=(0,8))
                    if typ=='SELECT':
                        title='入力する点' if working.get('selection_mode','point')=='point' else ('矩形の始点' if suffix=='1' else '矩形の対角点')
                    elif typ in RANGE_TYPES and working.get('selection_mode','point')!='point' and suffix in ('1','4'):
                        title = ('境界範囲' if typ in ('TRIM','EXTEND') else '選択範囲')+('の始点' if suffix=='1' else 'の対角点')
                    elif typ in VERTEX_TYPES:
                        i=int(suffix)
                        title="始点" if i==1 else "終点" if i==vertex_count[0] else f"中間点{i-1}"
                    elif suffix == "":
                        title = "挿入点" if typ in ("TEXT", "MTEXT", "INSERT") else "位置" if typ == "POINT" else "中心"
                    elif typ == "ARC" and working.get("arc_mode","center_angles") != "center_angles":
                        title={"1":"始点","2":"中心" if working["arc_mode"]=="start_center_end" else "通過点","3":"終点"}[suffix]
                    elif typ in ADVANCED_FIELDS:
                        title = '対象の図形上の点' if suffix=='1' else '基点'
                    elif typ == "COPY":
                        title = {"1": "コピーする対象の点", "2": "コピーの基点", "3": "コピーの移動先"}[suffix]
                    elif typ == "MIRROR":
                        title = {"1": "ミラーする対象の点", "2": "対称軸の始点", "3": "対称軸の終点"}[suffix]
                    elif typ == "EXTEND":
                        title = "延長境界の図形上の点" if suffix == "1" else "延長する端寄りの点"
                    elif typ in ('CHAMFER','FILLET'):
                        title='1本目の選択点' if suffix=='1' else '2本目の選択点'
                    elif suffix == "3":
                        title = "寸法位置"
                    elif typ in ("DIMLINEAR", "DIMALIGNED"):
                        title = "測定点" + suffix
                    elif typ == "OFFSET":
                        title = "対象の図形上の点" if suffix == "1" else "オフセットする側の点"
                    elif typ == "TRIM":
                        title = "切断境界の図形上の点" if suffix == "1" else "切り取る図形の削除側の点"
                    elif typ == "RECTANGLE":
                        title = "対角点" + suffix
                    else:
                        title = "始点" if suffix == "1" else "終点"
                    point_titles['x'+suffix]=title
                    coordinate_cards[suffix]=group
                    style = ttk.Style(win)
                    style.configure('PointHeader.TFrame', background='#e8eef7')
                    style.configure('PointHeader.TLabel', background='#e8eef7', foreground='#192c42', font=('TkDefaultFont', 10, 'bold'))
                    head=ttk.Frame(group, style='PointHeader.TFrame', padding=(6, 4))
                    head._preserve_card_style=True
                    head.pack(fill='x',pady=(0,5))
                    foldable=typ in ('LINE','POLYLINE')
                    caption=tk.StringVar(value=('▶ ' if suffix in collapsed_points else '▼ ') + title if foldable else title)
                    heading=ttk.Label(head,textvariable=caption,style='PointHeader.TLabel')
                    heading.pack(side='left')
                    add_point_actions(head,suffix)
                    axes = ttk.Frame(group)
                    axes.pack(fill='x',expand=True)
                    if foldable:
                        def set_expanded(expanded,s=suffix,a=axes,c=caption,t=title):
                            if expanded:
                                collapsed_points.discard(s);a.pack(fill='x',expand=True);c.set('▼ '+t)
                            else:
                                collapsed_points.add(s);a.pack_forget();c.set('▶ '+t)
                            form_changed()
                        def toggle_point(event=None,s=suffix,change=set_expanded):
                            change(s in collapsed_points)
                            return 'break'
                        head.configure(cursor='hand2');heading.configure(cursor='hand2')
                        for target in (head,heading):target.bind('<Button-1>',toggle_point)
                        head.set_expanded=set_expanded
                        if suffix in collapsed_points:axes.pack_forget()
                    group.point_header=head
                    group.point_heading=heading
                    group.point_caption=caption
                    axes.columnconfigure((0, 1), weight=1, uniform='coordinate')
                    coordinate_rows[suffix] = axes
                    summary=ttk.Label(group,text='',style='ReferenceChip.TLabel',cursor='hand2',wraplength=450)
                    group.bind('<Configure>',lambda event,label=summary:label.configure(wraplength=max(80,event.width-16)))
                    summary.bind('<Button-1>',lambda event,s=suffix:open_coordinate_summary(s))
                    reference_summaries[suffix]=summary
                    if typ in VERTEX_TYPES:
                        win.vertex_rows.append(title)
                        delete=ttk.Button(head,text="点を削除",command=lambda index=int(suffix)-1:change_vertex(index),width=2,style="MainIcon.TButton")
                        delete.icon_button_style="MainIcon.TButton"
                        delete.pack(side="right",padx=(3,0));delete.configure(state="normal" if vertex_count[0]>(3 if typ=="HATCH" else 2) else "disabled")
                axes = coordinate_rows[suffix]
                row = ttk.Frame(axes)
                row.grid(row=0, column=0 if key[0] == "x" else 1, sticky="nsew", padx=(0, 8) if key[0] == "x" else (0, 0))
                column=row
                coordinate_axis_frames[key]=column
                row=ttk.Frame(column);row.pack(fill='x')
                label=ttk.Label(column,text='',style='Muted.TLabel')
                label.pack(anchor='w',padx=(16,0),pady=(2,0))
                field_results[key]=label
                ttk.Label(row,text='参照'+key[0].upper(),width=6).pack(side='left')
            elif optional and key != "condition":
                tile = ttk.Frame(advanced_section)
                advanced_rows[key] = tile
                field_label(tile, text="線種尺度" if key == "linetype_scale" else LABELS.get(key, key), width=12).pack(side="left")
                row = tile
            else:
                row = ttk.Frame(advanced_section if optional else basic_section)
                if optional:
                    advanced_rows[key] = row
                else:
                    row.pack(fill="x", pady=4)
                field_label(row, text=LABELS.get(key, key), width=14).pack(side="left")
            value = tk.StringVar(value=rewrite_references(str(default if is_coordinate and typ in VERTEX_TYPES else working.get(key, default)), point_labels))
            display_value=value
            if is_coordinate:
                coordinate=CoordinateValue(win,value)
                coordinate_values[key]=coordinate
                display_value=coordinate.base
            if key == "text" and typ == "MTEXT":
                from multiline_input import MultilineInput
                entry = MultilineInput(row,value)
            elif key in ("color","layer_color"):
                value.set(entity_color_label(value.get()))
                entry = ttk.Combobox(
                    row, textvariable=value,
                    width=1, values=["", *([] if key=="layer_color" else [entity_color_label(256),entity_color_label(0)]), *[entity_color_label(i) for i in range(1, 10)]],
                )
            elif key == 'erase_source':
                entry = ttk.Combobox(row, textvariable=value, values=('0', '1'), state='readonly', width=8)
            elif key == 'pattern':
                entry = ttk.Combobox(row, textvariable=value, values=('ANSI31', 'ANSI32', 'ANSI33', 'ANSI34', 'ANSI35', 'ANSI36', 'ANSI37', 'ANSI38', 'SOLID'), width=18)
            elif key=='target_layer':
                entry=ttk.Combobox(row,textvariable=value,values=resource_names(project,'layers'),width=1)
            elif key=='layer_linetype':
                entry=ttk.Combobox(row,textvariable=value,values=['',*resource_names(project,'linetypes')],width=1)
            elif key=='layer_weight':
                from layer_change import WEIGHTS
                value.set(next((label for label,code in WEIGHTS.items() if code==value.get()),value.get()))
                entry=ttk.Combobox(row,textvariable=value,values=['',*WEIGHTS],width=1)
            elif key in STYLE_FIELDS:
                entry = ttk.Combobox(
                    row,
                    textvariable=value,
                    values=["", *resource_names(project, STYLE_FIELDS[key])], width=1,
                )
            elif key=='polyline_action':
                entry=ttk.Combobox(row,textvariable=value,values=POLYLINE_EDIT_ACTIONS,state='readonly')
                entry.bind('<<ComboboxSelected>>',lambda event,v=value:switch_input_mode('polyline_action',v.get()))
            elif key in LAYOUT_CHOICES:
                entry=ttk.Combobox(row,textvariable=value,values=LAYOUT_CHOICES[key],state='readonly')
                def choose_layout_mode(event=None,k=key,v=value):
                    before=gather();before[k]=v.get();working.clear();working.update(before);redraw(False)
                entry.bind('<<ComboboxSelected>>',choose_layout_mode)
            elif key in ("value_kind", "execution"):
                entry = ttk.Combobox(
                    row,
                    textvariable=value,
                    values=["number", "text"]
                    if key == "value_kind"
                    else ["per_row", "once"],
                    state="readonly",
                )
            else:
                entry = ttk.Entry(row, textvariable=display_value, width=1 if is_coordinate or optional else 20)
            entry.pack(side="left", fill="x", expand=True)
            if is_coordinate:
                add_entry_hint(entry,display_value,'空欄は0')
                movement_row=ttk.Frame(column)
                movement_row.pack(fill='x',before=label,pady=(3,0))
                ttk.Label(movement_row,text='移動'+key[0].upper(),width=6).pack(side='left')
                movement_entry=ttk.Entry(movement_row,textvariable=coordinate.movement,width=1)
                movement_entry.pack(side='left',fill='x',expand=True)
                add_entry_hint(movement_entry,coordinate.movement,'0')
                add_reference_color(movement_entry,coordinate.movement,project.get('globals',{}))
                movement_entry.bind('<FocusIn>',focus_sample)
                movement_entries[key]=movement_entry
                entries['move:'+key]=movement_entry
            if key == 'closed':
                choices={}
                def choose_closed(number,variable=value):
                    variable.set(number)
                for caption,number in (('閉じる','1'),('閉じない','0')):
                    button=ttk.Button(row,text=caption,style='WorkbenchSegment.TButton',
                                      command=lambda n=number,f=choose_closed:f(n))
                    button.pack(side='left',padx=(4,0));choices[number]=button
                if vertex_count[0]<3:
                    choices['1'].configure(state='disabled');entry.configure(state='readonly')
                def sync_closed(*_,variable=value,buttons=choices):
                    for number,button in buttons.items():
                        button.configure(style='WorkbenchSegmentOn.TButton' if variable.get().strip()==number else 'WorkbenchSegment.TButton')
                value.trace_add('write',sync_closed);sync_closed()
                win.closed_buttons=choices
            if key in ("color","layer_color"):
                chip = tk.Label(row, width=2, relief="solid", borderwidth=1)
                chip.pack(side="left", padx=5)

                def update_color_chip(*_, variable=value, label=chip):
                    try:
                        index = int(entity_color_code(variable.get()))
                        label.configure(bg=swatch(index) if 1 <= index <= 255 else "#f3f5f9")
                    except (ValueError, IndexError):
                        label.configure(bg="#f3f5f9")

                value.trace_add("write", update_color_chip)
                update_color_chip()
                palette = ttk.Button(row, text="色見本…", image=icons_for(win).get("colors"), compound="none", width=2,
                                     style="MainIcon.TButton", command=lambda v=value,k=key: ColorPicker(win, v, title="レイヤーの色を選択" if k=="layer_color" else "作図する図形の色を選択"))
                palette.pack(side="left")
                palette.tooltip_text = "色見本から選ぶ"
                palette.bind("<Enter>", lambda e, b=palette: icons_for(win).schedule(b, b.tooltip_text))
                palette.bind("<Leave>", lambda e: icons_for(win).hide())
            if key not in STYLE_FIELDS and key not in ("name","color","value_kind","execution"):
                add_reference_color(entry,display_value,project.get("globals",{}),literal=key in ("text", "block_name", "pattern", "selection_name"))
            variables[key] = value
            entries[key] = entry
            if typ=='SELECT' and key=='selection_name':
                from select_editor import SelectionEditor
                if select_controller[0] is None:select_controller[0]=SelectionEditor(win,gather,apply_select_data,lambda:live[0].canvas if live[0] else None,refresh_preview,selection_source_identity)
                select_controller[0].build(basic_section)
                win.select_editor=select_controller[0]
            if key in (*STYLE_FIELDS, "color", "linetype_scale"):
                hint=add_entry_hint(entry,value,lambda k=key:inherited_hint(k))
                def show_inheritance(event,e=entry,k=key):
                    if not e.get():
                        text=inherited_hint(k)
                        if text.startswith('未取得'):text+='\n先行コマンドから特定できません。作図開始時のCAD値は取得していません。'
                        icons_for(win).schedule(e,text)
                for widget in (entry,hint):
                    widget.bind('<Enter>',show_inheritance,add='+')
                    widget.bind('<Leave>',lambda event:icons_for(win).hide(),add='+')
            elif key == "condition" and typ != "IF":
                add_entry_hint(entry, value, "条件なし（常に実行）")
            if typ=="LAYEREDIT" and key not in ("target_layer","execution"):add_entry_hint(entry,value,"変更しない")
            entry.bind("<FocusIn>", focus_sample)
            if is_coordinate:
                entry.bind("<Enter>", lambda event, e=entry, k=key: icons_for(win).schedule(e, field_caption(k)+": "+e.get()))
                entry.bind("<Leave>", lambda event: icons_for(win).hide())
            value.trace_add("write", update_sample)
            value.trace_add("write", record_edit)
            if (isinstance(entry, ttk.Entry)
                    and not isinstance(entry, ttk.Combobox)
                    and key not in ("name", "block_name", "pattern", "selection_name", "value_kind", "execution")):
                add_reference_menu(row, entry, key)
                if key=='closed' and vertex_count[0]<3:entry.reference_button.configure(state='disabled')
            if typ in VERTEX_TYPES and key==f"y{vertex_count[0]}":
                tools=ttk.Frame(basic_section);tools.pack(fill="x",pady=(2,6))
                ttk.Button(tools,text="点を追加",command=lambda:change_vertex(),width=2,style="MainIcon.TButton").pack(side="left")
                ttk.Label(tools,text=f"{vertex_count[0]}点 · ＋で終点を追加",style="Muted.TLabel").pack(side="left",padx=8)
            if key == "condition":
                ttk.Button(
                    row,
                    text="条件を作る…",
                    command=lambda v=value: show_condition_builder(win, v, project, local_names),
                ).pack(side="left", padx=(6, 0))
        def arrange_details(event=None):
            columns = 2 if advanced_section.winfo_width() >= 540 else 1
            for column in (0, 1):
                advanced_section.columnconfigure(column, weight=1 if column < columns else 0, uniform="details" if column < columns else "")
            order = [key for key in ([k for k,v in LAYER_FIELDS if k not in ("target_layer","execution")] if typ=="LAYEREDIT" else ("layer", "linetype", "color", "linetype_scale", "text_style", "dim_style")) if key in advanced_rows]
            for i, key in enumerate(order):
                advanced_rows[key].grid(row=i//columns, column=i%columns, columnspan=1, sticky="new",
                                        padx=(0, 12) if columns == 2 and i%columns == 0 else (0, 0), pady=(5, 5))
            if "condition" in advanced_rows:
                advanced_rows["condition"].grid(row=(len(order)+columns-1)//columns, column=0, columnspan=columns, sticky="ew", pady=(6, 4))
        advanced_section.bind("<Configure>", arrange_details)
        arrange_details()
        if advanced_keys.intersection(key for key, _ in fields):
            advanced_section.pack(fill="x", pady=(10, 0))
        if typ in ("IF", "REPEAT"):
            for key, label in [
                ("commands", "実行するコマンド" if typ == "IF" else "繰り返すコマンド")
            ] + ([("else", "ELSE のコマンド")] if typ == "IF" else []):
                ttk.Button(
                    form,
                    text=f"{label}を編集（{len(working.get(key, []))}件）",
                    command=lambda k=key: branch(k),
                ).pack(fill="x", pady=(12, 0))
            if typ=='REPEAT':
                ttk.Label(form,text='横・縦・円周配置は、各座標の「計算」から設定できます。',style='Muted.TLabel',wraplength=550).pack(fill='x',pady=(5,0))
        for suffix,buttons in point_buttons.items():connect_point_buttons(suffix,buttons)
        for suffix in coordinate_tools:
            for axis in ('x','y'):
                key=axis+suffix
                if key in entries:
                    target_keys[point_titles.get('x'+suffix,'座標')+' '+axis.upper()]=key
                    target_keys[point_titles.get('x'+suffix,'座標')+' 移動'+axis.upper()]='move:'+key
        target_picker.configure(values=list(target_keys))
        if target_keys:
            coordinate_toolbar.pack(fill='x',before=body)
            key=next(iter(target_keys.values()));focused[0]=entries[key]
            target_choice.set(next(iter(target_keys)))
            coordinate_tools[key[1:]].pack(side='left')
        else:
            coordinate_toolbar.pack_forget();target_choice.set('')
        for card in coordinate_cards.values():paint_card(card)
        paint_card(advanced_section)
        win.update_idletasks();form_changed()
        redrawing[0]=False
        if history_current[0] is None:history_current[0]=capture_state()
        if typ=='SELECT':
            working.setdefault('selection_name',f"選択{1+sum(c.get('type')=='SELECT' for c in point_sources)}");working.setdefault('pick_tolerance','0.01')
            header.pack_forget();coordinate_toolbar.pack_forget();left.grid_remove()
            body.columnconfigure(0,weight=0,minsize=0)
            if live[0] is not None:live[0].grid_configure(column=0,columnspan=2)
            simple_select_host.pack(fill='x',before=body)
            from select_editor import SelectionEditor
            if select_controller[0] is None:select_controller[0]=SelectionEditor(win,gather,apply_select_data,lambda:live[0].canvas if live[0] else None,refresh_preview,selection_source_identity)
            select_controller[0].build_simple(simple_select_host);win.select_editor=select_controller[0]
        elif simple_select_host.winfo_manager():
            simple_select_host.pack_forget();header.pack(fill='x',before=body);left.grid()
            body.columnconfigure(0,weight=5,minsize=390)
            if live[0] is not None:live[0].grid_configure(column=1,columnspan=1)
        schedule_preview()

    redraw(False)
    picker.bind("<<ComboboxSelected>>", lambda e: redraw())
    original_blocks = copy.deepcopy(blocks)
    cancel_baseline=[copy.deepcopy(gather())]

    def cancel():
        if live[0] is not None and (getattr(live[0].canvas,'range_callback',None) or getattr(live[0].canvas,'point_callback',None)):
            if select_controller[0] is not None:select_controller[0].stop()
            else:live[0].canvas.cancel_range()
            if active[0]!='SELECT':return
        if selecting[0] is not None:
            win.close_point_panel();return
        if (
            gather() != cancel_baseline[0] or blocks != original_blocks
        ) and not messagebox.askyesno(
            "変更の破棄", "コマンドの変更を破棄しますか？", parent=win
        ):
            return
        replace_collection(blocks, original_blocks)
        win.destroy()

    def accept(keep_open=False):
        if selecting[0] is not None:
            selecting[0].apply_reference()
            if selecting[0] is not None:return
        from selection_sets import can_create
        if creating and not can_create(active[0],point_sources):
            return messagebox.showinfo('SELECTが必要です','先にSELECTコマンドを作成し、その直後に追加してください。',parent=win)
        d = gather()
        d["type"] = active[0]
        if d['type']=='SELECT' and live[0] is not None and getattr(live[0].canvas,'selection_count',0)==0:
            return messagebox.showinfo('図形の選択','プレビューで図形を選択してください。',parent=win)
        if d['type']=='SELECT' and not d.get('selections'):
            return messagebox.showerror('選択の確認','点または矩形を追加してください。',parent=win)
        if d['type'] in SELECTION_OPERATORS:
            available=selection_descriptors(previous_blocks,point_sources)
            if not available or (d.get('selection_ref')!='@previous' and d.get('selection_ref') not in {key for key,_ in available}):
                return messagebox.showerror('選択の確認','先にSELECTを追加して、使用する選択を指定してください。',parent=win)
        if d["type"] == "SET" and not valid_name(d.get("name")):
            return messagebox.showerror(
                "変数名",
                "英数字と_の名前を指定してください。予約名は使えません",
                parent=win,
            )
        try:
            for k, v in variables.items():
                text = v.get().strip()
                if k in ("color","layer_color"):
                    text = entity_color_code(text)
                if k=="layer_weight":
                    from layer_change import weight_value
                    text=weight_value(text)
                if k in (
                    "name",
                    "block_name",
                    "selection_name", "polyline_action",
                    "pattern",
                    "layer",
                    "text",
                    "value_kind",
                    "execution",
                    "target_layer", "layer_linetype", "layer_plot", "layer_on", "layer_frozen", "layer_locked", "layer_description", "new_layer_name", "regen_scope",
                    "space_mode", "layout_name", "source_layout", "layout_action", "viewport_action",
                    "linetype",
                    "text_style",
                    "dim_style",
                ):
                    continue
                if (
                    k == "value"
                    and d["type"] == "SYSVAR"
                    and d.get("value_kind") == "text"
                ):
                    if text.startswith("="):
                        parse_expression(text[1:])
                    continue
                if k in ("name", "layer", "text"):
                    continue
                if not text:
                    if k in ("color", "linetype_scale", "layer_color", "layer_weight", "layer_transparency") or (k == "condition" and d["type"] != "IF"):
                        continue
                    raise MacroError(field_caption(k) + " を入力してください")
                if k == "points":
                    polyline_expressions(text)
                else:
                    parse_expression(text)
        except MacroError as exc:
            return messagebox.showerror("入力内容の確認", str(exc), parent=win)
        if d["type"] == "CUSTOM":
            catalog = project.get("custom_commands", {})
            if d.get("name") not in catalog:
                return messagebox.showerror(
                    "登録コマンド", "コマンドを登録・選択してください", parent=win
                )
            try:
                for param in catalog[d["name"]].get("parameters", []):
                    value = d["arguments"][param["name"]]
                    if param.get("control") == "layer" and not value.strip():
                        raise MacroError("レイヤー名を選択または入力してください")
                    if param.get("control") in ("color", "entity_color") and not value.startswith("="):
                        try:
                            code=float(entity_color_code(value))
                        except ValueError:
                            if param["kind"] != "number":raise MacroError("色はACI番号0〜256、BYLAYER、BYBLOCKで指定してください")
                        else:
                            low,high=(0,256) if param.get("control")=="entity_color" else (1,255)
                            if not code.is_integer() or not low<=code<=high:raise MacroError(f"色のACI番号は{low}〜{high}で指定してください")
                    if param["kind"] == "number":
                        parse_expression(value)
                    elif value.startswith("="):
                        parse_expression(value[1:])
            except MacroError as exc:
                return messagebox.showerror("引数の確認", str(exc), parent=win)
        if d['type'] in LAYOUT_FIELDS:
            from layout_commands import render,validate_batch
            try:
                if d['type']=='SYSVARS':validate_batch(d.get('items'))
                else:
                    for k, choices in LAYOUT_CHOICES.items():
                        if k in d and d[k] not in choices:raise ValueError('操作を選択してください')
            except ValueError as exc:return messagebox.showerror('設定の確認',str(exc),parent=win)
        if d["type"] == "SYSVAR":
            import re

            if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", d["name"]):
                return messagebox.showerror(
                    "システム変数名", "例: OSMODE / CMDECHO", parent=win
                )
        for index, identity in pending_point_ids.items():
            point_sources[index]["point_id"] = identity
        for (bi,ci),identity in external_point_ids.items():
            previous_blocks[bi]["commands"][ci]["point_id"]=identity
        if keep_open:
            queued.extend(prepended);prepended.clear();queued.append(d);point_sources.append(d)
            source_defs.append(dict(command=d,block_index=len(previous_blocks),command_index=len(point_sources)-1,block_id='',local=True,label=f'コマンド{len(point_sources)}'))
            replace_collection(original_blocks,copy.deepcopy(blocks))
            pending_point_ids.clear();external_point_ids.clear()
            undo_stack.clear();redo_stack.clear();history_current[0]=None
            working.clear();working.update(copy.deepcopy(d));working.pop('point_id',None)
            redraw(False);cancel_baseline[0]=copy.deepcopy(gather())
            return
        result.append(d)
        win.destroy()

    bar = normal_bar = ttk.Frame(win, padding=(12,10))
    bar.pack(side="bottom", fill="x", before=body)
    ttk.Button(bar, text="キャンセル", command=cancel).pack(side="left")
    ttk.Button(
        bar, text="選択を確定" if active[0]=="SELECT" else "追加して閉じる" if allow_continue else "コマンドを反映", style="WorkbenchPrimary.TButton", command=accept
    ).pack(side="right")
    if allow_continue and active[0]!='SELECT':ttk.Button(bar,text='追加して続ける',style='WorkbenchSecondary.TButton',command=lambda:accept(True)).pack(side='right',padx=8)
    redo_button=ttk.Button(header,text='やり直す',image=icons_for(win).get('redo'),compound='none',style='WorkbenchRef.TButton',width=2,command=redo_draft)
    redo_button.icon_button_style='WorkbenchRef.TButton';redo_button.icon_button_width=2;redo_button.pack(side='right')
    undo_button=ttk.Button(header,text='元に戻す',image=icons_for(win).get('undo'),compound='none',style='WorkbenchRef.TButton',width=2,command=undo_draft)
    undo_button.icon_button_style='WorkbenchRef.TButton';undo_button.icon_button_width=2;undo_button.pack(side='right')
    win.protocol("WM_DELETE_WINDOW", cancel)
    win.bind("<Escape>", lambda e: cancel())
    from command_workbench import choose_kind
    def open_kind(event=None):
        if selecting[0] is not None:return 'break'
        choose_kind(win,kind_groups,TYPE_LABELS,lambda kind:(choice.set(TYPE_LABELS[kind]),redraw()),icons_for(win),disabled_kinds={'VIEWPORT'} if creation_reason('VIEWPORT',creation_space) else ())
        return 'break'
    picker.bind('<Button-1>',open_kind);picker.bind('<space>',open_kind)
    live[0]=PointReferencePreview(body,project,point_sources,focus_point,initial_row,sample_locals,preview_blocks=scene_blocks,source_refs=source_defs,compact=True,repeat_counts=repeat_counts)
    live[0].grid(row=0,column=0 if active[0]=='SELECT' else 1,columnspan=2 if active[0]=='SELECT' else 1,sticky='nsew')
    live[0].row.trace_add('write',lambda *_:sample_row.set(live[0].row.get()) if live[0].row.get()!=sample_row.get() else None)
    win.command_preview=live[0];win.refresh_command_preview=refresh_preview
    schedule_preview()
    def shutdown(event):
        if event.widget is win:
            if refresh_job[0]:win.after_cancel(refresh_job[0]);refresh_job[0]=None
            for coordinate in coordinate_values.values():coordinate.close()
    win.bind('<Destroy>',shutdown,add='+')
    parent.wait_window(win)
    try:
        parent.winfo_toplevel().grab_set() if parent.winfo_toplevel() is not parent._root() else None
    except tk.TclError:
        pass
    if not (queued or result):return None
    completed=queued+(prepended+result if result else [])
    return completed if allow_continue or len(completed)>1 else completed[0]


class CommandList:
    def __init__(
        self,
        parent,
        commands,
        blocks,
        on_select=None,
        on_change=None,
        project=None,
        local_names=(),
        folder_id="",
        previous_blocks=(), owner_block_id=None,repeat_counts=(),
    ):
        self.owner_block_id=owner_block_id
        self.repeat_counts=tuple(repeat_counts)
        self._setting_highlight = None
        self.previous_block_ids=[block["id"] for block in previous_blocks]
        self.commands = commands
        self.blocks = blocks
        self.on_select = on_select
        self.on_change = on_change
        self.project = project
        self.local_names = local_names
        self.folder_id = folder_id
        self.undo_stack = []
        self.redo_stack = []
        self.frame = ttk.Frame(parent)
        self.frame.pack(fill="both", expand=True, padx=10, pady=5)
        self.frame.rowconfigure(0, weight=1)
        self.frame.columnconfigure(0, weight=1)
        self.icons = icons_for(parent)
        self.command_images = {kind: command_icon(self.icons,kind) for label, kinds in COMMAND_GROUPS for kind in kinds}
        self.tree = GridTreeview(
            self.frame,
            columns=("detail",),
            show="tree headings",
            selectmode="extended",
            height=7,
            style="Command.Treeview",
        )
        for key, label, width in [
            ("#0", "コマンド", 220),
            ("detail", "設定 / 条件", 480),
        ]:
            self.tree.heading(key, text=label)
            self.tree.column(
                key, width=width, minwidth=190 if key == "#0" else 120,
                stretch=key != "#0",
            )
        self.tree.grid(row=0, column=0, sticky="nsew")
        ys = ttk.Scrollbar(self.frame, command=self.tree.yview)
        ys.grid(row=0, column=1, sticky="ns")
        self.tree.configure(yscrollcommand=ys.set)
        xs = ttk.Scrollbar(self.frame, orient="horizontal", command=self.tree.xview)
        xs.grid(row=1, column=0, sticky="ew")
        self.tree.configure(xscrollcommand=xs.set)
        self.tree.bind("<Double-1>", lambda e: self.edit())
        self.tree.bind("<Return>", lambda e: self.edit())
        self.tree.bind(
            "<<TreeviewSelect>>",
            lambda e: self.on_select(self.indices()) if self.on_select else None,
        )
        self.tree.bind("<Alt-Up>", lambda e: self.move(-1))
        self.tree.bind("<Alt-Down>", lambda e: self.move(1))
        self.tree.bind("<Delete>", lambda e: self.delete())
        self.tree.bind("<Control-d>", lambda e: self.duplicate())
        self.tree.bind("<Control-z>", lambda e: (self.undo(), "break")[-1])
        self.tree.bind("<Control-y>", lambda e: (self.redo(), "break")[-1])
        self.toolbar = bar = ttk.Frame(parent, padding=(0, 4))
        bar.pack(fill="x", padx=10, before=self.frame)
        add_button = ttk.Button(bar, text="＋ コマンド追加", command=self.choose_add, style="Compact.TButton")
        add_button.toolbar_labelled=True
        add_button.toolbar_full_label="＋ コマンド追加";add_button.toolbar_compact_label="＋ 追加"
        add_button.grid(row=0,column=0,padx=(0,4),sticky="nsew")
        actions = [("編集", self.edit), ("複製", self.duplicate), ("ガイド化", self.make_guide), ("削除", self.delete),
                   ("↑", lambda:self.move(-1)), ("↓", lambda:self.move(1)),
                   ("元に戻す", self.undo), ("やり直し", self.redo)]
        for i,(label, action) in enumerate(actions,1):
            button=ttk.Button(bar,text=label,command=action,width=2,style="MainIcon.TButton")
            button.icon_only=True;button.icon_button_width=2;button.icon_button_style="MainIcon.TButton"
            button.grid(row=0,column=i,padx=(0,2),sticky="nsew")
        self.reference_menu = tk.Menu(self.tree, tearoff=False)
        self.reference_menu.add_command(label='参照を追加', command=self.add_setting_reference)
        self.reference_menu.add_command(label='正本を編集', command=self.edit)
        self.reference_menu.add_command(label='この参照を正本化', command=self.materialize_setting_reference)
        self.reference_menu.add_separator()
        self.reference_menu.add_command(label='参照先へ移動', command=self.go_to_setting_master)
        self.reference_menu.add_command(label='この正本の使用箇所を強調', command=self.highlight_setting_uses)
        self.reference_menu.add_command(label='強調を解除', command=self.clear_setting_highlight)
        def reference_context(event):
            row = self.tree.identify_row(event.y)
            if row: self.tree.selection_set(row)
            self.reference_menu.tk_popup(event.x_root,event.y_root)
            return 'break'
        self.tree.bind('<Button-3>', reference_context)
        self.empty_help=ttk.Frame(self.tree,style="Surface.TFrame",padding=10)
        ttk.Label(self.empty_help,text="線や円などのコマンドを追加して作図します。",style="SurfaceMuted.TLabel",wraplength=250).pack(pady=(0,8))
        ttk.Button(self.empty_help,text="＋ コマンドを追加",command=self.choose_add,style="Compact.TButton").pack()
        bar.bind("<Configure>", lambda event: layout_icon_toolbar(bar, event.width, grid=True))
        self.tree.bind("<<TreeviewSelect>>",self.update_guide_actions,add="+")
        self.refresh()

    def snapshot(self):
        self.undo_stack.append(
            (copy.deepcopy(self.commands), copy.deepcopy(self.blocks))
        )
        self.undo_stack = self.undo_stack[-100:]
        self.redo_stack.clear()

    def restore(self, state):
        self.commands[:] = state[0]
        replace_collection(self.blocks, state[1])
        self.refresh()

    def undo(self):
        if self.undo_stack:
            self.redo_stack.append(
                (copy.deepcopy(self.commands), copy.deepcopy(self.blocks))
            )
            self.restore(self.undo_stack.pop())

    def redo(self):
        if self.redo_stack:
            self.undo_stack.append(
                (copy.deepcopy(self.commands), copy.deepcopy(self.blocks))
            )
            self.restore(self.redo_stack.pop())

    def indices(self):
        return sorted(int(i) for i in self.tree.selection())

    def refresh(self, selection=None):
        self.tree.delete(*self.tree.get_children())
        point_names={c["point_id"]:f"コマンド{j+1}" for j,c in enumerate(self.commands) if c.get("point_id")}
        for block in (self.blocks if isinstance(self.blocks,list) else []):
            for j,command in enumerate(block.get("commands",[])):
                if command.get("point_id"):
                    point_names[block["id"]+"/"+command["point_id"]]=f"{block['name']} / コマンド{j+1}"
        warning_indices=set()
        if isinstance(self.blocks,list) and self.owner_block_id:
            context=dict(self.project or {},blocks=copy.deepcopy(self.blocks))
            owner=next((b for b in context["blocks"] if b["id"]==self.owner_block_id),None)
            if owner is not None:
                owner["commands"]=copy.deepcopy(self.commands)
                warning_indices={x["target_index"] for x in forward_links(context) if x["target_block"]==self.owner_block_id}
        self.tree.tag_configure("reference_warning",background="#fff0cf",foreground="#9a4800")
        from setting_references import registry, usage_index, location_label
        setting_sources = registry(self.commands)
        setting_usage = usage_index(self.commands)
        for i, cmd in enumerate(self.commands):
            display = rewrite_references(dict(cmd), point_names)
            if cmd.get("selection_ref") and cmd["selection_ref"]!="@previous":
                names=dict(selection_descriptors(self.blocks or [],self.commands))
                display["selection_ref"]=names.get(cmd["selection_ref"],"参照先がありません")
            if cmd.get('type') == 'SETTINGREF':
                target = setting_sources.get(cmd.get('setting_ref'))
                if target:
                    usage = setting_usage[cmd['setting_ref']]
                    display = dict(type='SETTINGREF', _caption='正本：'+location_label(usage['master'])+f' / 参照{len(usage["references"])}件 / '+TYPE_LABELS.get(target['type'],target['type'])+' / '+command_summary(target))
                else: display = dict(type='SETTINGREF', _caption='正本がありません')
            if cmd.get("setting_id") in setting_usage:
                count = len(setting_usage[cmd["setting_id"]]["references"])
                display["_caption"] = f"参照{count}件 / " + command_summary(display)
            self.tree.insert(
                "",
                "end",
                iid=str(i),
                text=('［正本］' if cmd.get('setting_id') else '')+("⚠ " if i in warning_indices else "")+TYPE_LABELS.get(cmd.get("type"), cmd.get("type", "?")),
                tags=("reference_warning",) if i in warning_indices else (),
                image=self.command_images.get(cmd.get("type"), self.icons.get("commands")),
                values=(
                    (self.project or {})
                    .get("custom_commands", {})
                    .get(cmd.get("name"), {})
                    .get("name", command_summary(cmd))
                    if cmd.get("type") == "CUSTOM"
                    else display.get("_caption", command_summary(display)),
                ),
            )
        if selection is not None and 0 <= selection < len(self.commands):
            self.tree.selection_set(str(selection))
            self.tree.see(str(selection))
        self._paint_setting_uses()
        self.update_guide_actions()
        if self.commands:self.empty_help.place_forget()
        else:self.empty_help.place(relx=.5,rely=.48,anchor="center",relwidth=.94)
        if self.on_change:
            self.on_change()

    def names(self):
        return list(
            dict.fromkeys(
                list(self.local_names)
                + [
                    c["name"]
                    for c in walk_commands(self.commands)
                    if c.get("type", "").upper() == "SET"
                ]
            )
        )

    def prior_blocks(self):
        return [block for block in self.blocks if block.get("id") in self.previous_block_ids or (block.get("guide") and block.get("id") != self.owner_block_id)] if isinstance(self.blocks,list) else []

    def update_guide_actions(self, event=None):
        guide_owner=isinstance(self.blocks,list) and any(b.get("id")==self.owner_block_id and b.get("guide") for b in self.blocks)
        selected=self.indices()
        allowed=bool(self.owner_block_id and selected and not guide_owner and all(self.commands[i].get("type") in GUIDE_TYPES for i in selected))
        for button in self.toolbar.winfo_children():
            if str(button.cget("text")) == "ガイド化":button.configure(state="normal" if allowed else "disabled")
            if str(button.cget("text")) == COMMAND_GROUPS[-1][0]:button.configure(state="disabled" if guide_owner else "normal")

    def make_guide(self):
        indices=self.indices()
        if not indices:return
        if not isinstance(self.blocks,list) or not self.owner_block_id:
            return messagebox.showinfo("ガイド化", "作図ブロックの編集からガイド化してください", parent=self.frame)
        trial=copy.deepcopy(self.project or {})
        trial["blocks"]=copy.deepcopy(self.blocks)
        try:
            added=copy_to_guide(trial,self.owner_block_id,[self.commands[i] for i in indices],local_commands=self.commands)
            errors=validate_project(trial)
            if errors:raise ValueError("\n".join(errors[:8]))
        except ValueError as exc:
            return messagebox.showerror("ガイド化の確認",str(exc),parent=self.frame)
        if added:
            self.snapshot();replace_collection(self.blocks,trial["blocks"]);self.refresh(indices[0])

    def choose_add(self):
        from command_workbench import choose_kind
        groups=COMMAND_GROUPS
        if isinstance(self.blocks,list) and any(b.get('id')==self.owner_block_id and b.get('guide') for b in self.blocks):
            groups=[(label,[k for k in kinds if k in GUIDE_TYPES]) for label,kinds in groups]
            groups=[(label,kinds) for label,kinds in groups if kinds]
        choose_kind(self.frame,groups,TYPE_LABELS,self.add,self.icons,can_select=self.can_add_kind,disabled_kinds={'VIEWPORT'} if self.space_creation_reason('VIEWPORT') else ())

    def current_space(self):
        from space_command_rules import block_space
        return self.space_provider() if hasattr(self,'space_provider') else block_space(self.blocks,self.owner_block_id,self.project)

    def space_creation_reason(self,kind):
        from space_command_rules import creation_reason
        return creation_reason(kind,self.current_space())

    def can_add_kind(self, kind):
        from selection_sets import can_create
        selected = self.indices()
        at = selected[-1]+1 if selected else len(self.commands)
        return can_create(kind, self.commands[:at])

    def add(self, kind="LINE"):
        reason=self.space_creation_reason(kind)
        if reason:return messagebox.showinfo("作図先の確認",reason,parent=self.frame)
        if not self.can_add_kind(kind):
            return messagebox.showinfo('SELECTが必要です','先にSELECTコマンドを作成し、その直後に追加してください。',parent=self.frame)
        before = copy.deepcopy(self.blocks)
        before_commands = copy.deepcopy(self.commands)
        selected = self.indices()
        insert_at = selected[-1] + 1 if selected else len(self.commands)
        d = edit_command(
            self.frame,
            {"type": kind},
            self.blocks,
            self.project,
            self.names(),
            sample_locals=self.local_names
            if isinstance(self.local_names, dict)
            else None,
            folder_id=self.folder_id,
            owner_space=self.current_space(), creating=True, allow_continue=True, point_sources=self.commands[:insert_at],
            previous_blocks=self.prior_blocks(), owner_block_id=self.owner_block_id,
            repeat_counts=self.repeat_counts,
        )
        if d is not None:
            changed = copy.deepcopy(self.blocks)
            replace_collection(self.blocks, before)
            changed_commands = copy.deepcopy(self.commands)
            self.commands[:] = before_commands
            self.snapshot()
            self.commands[:] = changed_commands
            replace_collection(self.blocks, changed)
            ids = self.indices()
            at = ids[-1] + 1 if ids else len(self.commands)
            self.commands[at:at] = d if isinstance(d,list) else [d]
            self.refresh(at)

    def edit(self):
        ids = self.indices()
        if len(ids) != 1:
            return messagebox.showinfo(
                "コマンドの選択",
                "編集するコマンドを1件選択してください",
                parent=self.frame,
            )
        from setting_references import locate
        i = ids[0]
        target_list, target_index = self.commands, i
        if self.commands[i].get('type') == 'SETTINGREF':
            found = locate(self.commands, self.commands[i].get('setting_ref'))
            if not found:
                return messagebox.showerror('設定参照','正本がありません',parent=self.frame)
            target_list, target_index = found
        target = target_list[target_index]
        setting_identity = target.get('setting_id')
        before = copy.deepcopy(self.blocks)
        before_commands = copy.deepcopy(self.commands)
        d = edit_command(
            self.frame,
            target,
            self.blocks,
            self.project,
            self.names(),
            sample_locals=self.local_names
            if isinstance(self.local_names, dict)
            else None,
            folder_id=self.folder_id,
            point_sources=self.commands[:i],
            previous_blocks=self.prior_blocks(), owner_block_id=self.owner_block_id,
            repeat_counts=self.repeat_counts, owner_space=self.current_space(),
        )
        if d is not None:
            if setting_identity:
                from setting_references import REFERABLE
                replacements = d if isinstance(d,list) else [d]
                if len(replacements) != 1 or replacements[0].get('type') not in REFERABLE:
                    replace_collection(self.blocks, before)
                    self.commands[:] = before_commands
                    return messagebox.showerror('設定参照','参照される正本は設定コマンドのまま編集してください',parent=self.frame)
            # Editing an IF/REPEAT can remove a master used elsewhere in this block.
            # Resolve those references before committing the edited container.
            from setting_references import registry, walk, localize, choose_deletion_mode
            proposed = copy.deepcopy(self.commands)
            if not setting_identity:
                proposed[i:i+1] = d if isinstance(d,list) else [d]
                sources = registry(before_commands)
                missing = set(sources)-set(registry(proposed))
                count = sum(c.get('type') == 'SETTINGREF' and c.get('setting_ref') in missing for c in walk(proposed))
                if count:
                    mode = choose_deletion_mode(self.frame, count)
                    if mode is None:
                        replace_collection(self.blocks, before)
                        self.commands[:] = before_commands
                        return
                    proposed = localize(proposed, sources, all_independent=mode=='all')
            changed = copy.deepcopy(self.blocks)
            replace_collection(self.blocks, before)
            changed_commands = copy.deepcopy(self.commands)
            self.commands[:] = before_commands
            self.snapshot()
            self.commands[:] = changed_commands
            replace_collection(self.blocks, changed)
            replacements = d if isinstance(d,list) else [d]
            if setting_identity:
                from setting_references import locate, REFERABLE
                found = locate(self.commands, setting_identity)
                replacements[0]['setting_id'] = setting_identity
                found[0][found[1]:found[1]+1] = replacements
            else:
                self.commands[:] = proposed
            self.refresh(i)

    def duplicate(self):
        ids = self.indices()
        if not ids:
            return
        self.snapshot()
        copies = clone_commands([self.commands[i] for i in ids])
        for i, command in reversed(list(zip(ids, copies))):
            self.commands.insert(i + 1, command)
        self.refresh(ids[0] + 1)

    def _selected_setting_identity(self):
        ids = self.indices()
        if len(ids) == 1:
            command = self.commands[ids[0]]
            identity = command.get('setting_id') or command.get('setting_ref')
            if identity: return identity
        messagebox.showinfo('設定参照','正本または参照を1件選択してください',parent=self.frame)
        return None

    def go_to_setting_master(self):
        from setting_references import usage_index, location_label
        identity = self._selected_setting_identity()
        if identity is None: return
        usage = usage_index(self.commands).get(identity)
        if not usage or usage['master'] is None:
            return messagebox.showinfo('設定参照','この一覧に正本がありません',parent=self.frame)
        path = usage['master']; row = str(path[0])
        self.tree.selection_set(row); self.tree.focus(row); self.tree.see(row); self.tree.focus_set()
        if len(path) > 1:
            messagebox.showinfo('参照先へ移動','正本を含むコマンドへ移動しました。\n'+location_label(path),parent=self.frame)

    def highlight_setting_uses(self):
        identity = self._selected_setting_identity()
        if identity is None: return
        from setting_references import usage_index
        usage = usage_index(self.commands).get(identity)
        if not usage or usage['master'] is None:
            return messagebox.showinfo('設定参照','この一覧に正本がありません',parent=self.frame)
        self._setting_highlight = identity
        self._paint_setting_uses()

    def clear_setting_highlight(self):
        self._setting_highlight = None
        self._paint_setting_uses()

    def _paint_setting_uses(self):
        from setting_references import usage_index
        self.tree.tag_configure('setting_master', background='#dcecff', foreground='#174a7e')
        self.tree.tag_configure('setting_use', background='#fff0c2', foreground='#6b4900')
        usage = usage_index(self.commands).get(self._setting_highlight)
        if not usage or usage['master'] is None:
            self._setting_highlight = None; usage = None
        master = usage['master'][0] if usage else None
        users = {path[0] for path in usage['references']} if usage else set()
        for row in self.tree.get_children():
            tags = [tag for tag in self.tree.item(row,'tags') if tag not in ('setting_master','setting_use')]
            if int(row) == master: tags.append('setting_master')
            elif int(row) in users: tags.append('setting_use')
            self.tree.item(row,tags=tuple(tags))

    def add_setting_reference(self):
        ids = self.indices()
        if len(ids) != 1: return messagebox.showinfo('設定参照','参照元の設定を1件選択してください',parent=self.frame)
        from setting_references import add_reference
        try: changed = add_reference(self.commands, ids[0])
        except ValueError as exc: return messagebox.showinfo('設定参照',str(exc),parent=self.frame)
        self.snapshot(); self.commands[:] = changed; self.refresh(ids[0]+1)

    def materialize_setting_reference(self):
        ids = self.indices()
        if len(ids) != 1 or self.commands[ids[0]].get('type') != 'SETTINGREF':
            return messagebox.showinfo('設定参照','正本化する参照を1件選択してください',parent=self.frame)
        from setting_references import registry, resolve, new_id
        try: command = resolve(self.commands[ids[0]], registry(self.commands))
        except ValueError as exc: return messagebox.showerror('設定参照',str(exc),parent=self.frame)
        command['setting_id'] = new_id()
        self.snapshot(); self.commands[ids[0]] = command; self.refresh(ids[0])

    def delete(self):
        ids = self.indices()
        if not ids: return
        from selection_deletion import plan as select_plan, apply as select_delete
        dependencies, fallback = select_plan(self.commands, ids)
        keep_select_users = False
        if dependencies:
            can_keep = all(key in fallback for key, _ in dependencies.values())
            if can_keep:
                answer = messagebox.askyesnocancel('SELECTの削除', f'この選択を使うコマンドが{len(dependencies)}件あります。\nはい：利用コマンドも削除\nいいえ：利用コマンドを残し、直前のSELECTへ変更\nキャンセル：削除しない', parent=self.frame)
                if answer is None: return
                keep_select_users = not answer
            elif not messagebox.askokcancel('SELECTと利用コマンドの削除', f'選択対象を失うコマンド{len(dependencies)}件も一緒に削除します。\nキャンセルすると削除しません。', parent=self.frame): return
        selected_changes = select_delete(self.commands, ids, keep_select_users)
        from setting_references import registry, walk, delete_commands, choose_deletion_mode
        removed = set(registry([self.commands[i] for i in ids]))
        kept = [c for i,c in enumerate(self.commands) if i not in ids]
        count = sum(c.get('type') == 'SETTINGREF' and c.get('setting_ref') in removed for c in walk(kept))
        mode = choose_deletion_mode(self.frame, count) if count else 'first'
        if mode is None: return
        try:
            from setting_references import localize
            changed = localize(selected_changes, registry(self.commands), all_independent=mode=='all')
        except ValueError as exc: return messagebox.showerror('設定参照',str(exc),parent=self.frame)
        self.snapshot(); self.commands[:] = changed
        self.refresh(min(ids[0], len(self.commands)-1))

    def move(self, delta):
        ids = self.indices()
        if len(ids) == 1 and 0 <= ids[0] + delta < len(self.commands):
            i=ids[0];j=i+delta
            if self.owner_block_id and isinstance(self.blocks,list):
                trial=dict(self.project or {},blocks=copy.deepcopy(self.blocks))
                owner=next(b for b in trial["blocks"] if b["id"]==self.owner_block_id)
                owner["commands"]=copy.deepcopy(self.commands)
                owner["commands"][i],owner["commands"][j]=owner["commands"][j],owner["commands"][i]
                if not confirm_reference_order(self.frame,trial):return
                commands=next(b for b in trial["blocks"] if b["id"]==self.owner_block_id)["commands"]
                self.snapshot();replace_collection(self.blocks,trial["blocks"]);self.commands[:]=commands
            else:
                self.snapshot();self.commands[i],self.commands[j]=self.commands[j],self.commands[i]
            self.refresh(j)



class MacroEditor:
    def __init__(
        self, parent, preset, blocks, on_close, project=None, selected_rows=None
    ):
        self.unified = isinstance(blocks, list)
        self.win = tk.Toplevel(parent)
        self.win.title(
            ("ブロック編集 · " if self.unified else "プリセット編集 · ")
            + preset.get("name", "")
        )
        fit_window(self.win, 1320, 860, 850, 640)
        self.win.transient(parent)
        self.win.grab_set()
        self.preset = preset
        self.blocks = blocks
        self.working_blocks = copy.deepcopy(blocks)
        if self.unified:
            for index,block in enumerate(self.working_blocks):
                if block.get('id')==preset.get('id'):
                    self.working_blocks[index]=copy.deepcopy(preset);break
            from appearance_commands import extract_appearance
            for block in self.working_blocks:
                if not block.get('guide'):
                    from command_conditions import explicit_conditions
                    commands = block.get('commands', [])
                    block['commands'] = explicit_conditions(extract_appearance(commands, deduplicate=False))
        self.on_close = on_close
        self.project = project
        self._preview_job = None
        self._space_selected = False
        self.win.bind("<Destroy>", self.cancel_preview_job, add="+")
        self.selected_rows = list(selected_rows) if selected_rows is not None else (
            [0] if project and get_rows(project) else []
        )
        self.win.protocol("WM_DELETE_WINDOW", self.cancel)
        self.win.bind("<Escape>", lambda e: self.cancel())
        self.command_panes = ttk.Panedwindow(self.win, orient="horizontal")
        self.command_panes.pack(fill="both", expand=True, padx=12, pady=(12, 8))
        self._split_initialized = False
        self.command_panes.bind("<Configure>", self.fit_command_panes)
        command_page = ttk.Frame(self.command_panes)
        self.command_panes.add(command_page, weight=1)
        meta = ttk.Frame(command_page, padding=(10, 0, 10, 8))
        meta.pack(fill="x")
        self.name = tk.StringVar(value=preset.get("name", ""))
        self.cond = tk.StringVar(value=preset.get("condition", ""))
        if not self.unified:
            self.enabled = tk.BooleanVar(value=preset.get("enabled", True))
        name_row = ttk.Frame(meta)
        name_row.pack(fill="x", pady=(2, 7))
        ttk.Label(name_row, text="名前", width=6).pack(side="left")
        ttk.Entry(name_row, textvariable=self.name).pack(side="left", fill="x", expand=True)
        if self.unified:
            from preview_spaces import block_spaces
            destinations=sorted(set().union(*block_spaces(project or {'blocks':[]})))
            destinations=sorted(set(destinations)|{f['space'] for f in (project or {}).get('block_folders',[]) if f.get('space')})
            self.drawing_space=tk.StringVar(value=('モデル' if preset.get('drawing_space')=='Model' else preset.get('drawing_space','コマンドに従う')))
            ttk.Label(name_row,text='作図先').pack(side='left',padx=(8,4))
            self.space_picker=ttk.Combobox(name_row,textvariable=self.drawing_space,values=['コマンドに従う','モデル',*[n for n in destinations if n!='Model']],state='readonly',width=14)
            self.space_picker.pack(side='left')
            self.drawing_space.trace_add('write',lambda *_:self.queue_preview())
        if not self.unified:
            ttk.Checkbutton(meta, text="このプリセットを有効にする", variable=self.enabled).pack(anchor="w")
        self.conditions_panel = ttk.Frame(command_page, padding=(10, 8))
        self.conditions_panel.pack(side="bottom", fill="x")
        conditions = ttk.Frame(self.conditions_panel)
        condition_row = ttk.Frame(conditions)
        condition_row.pack(fill="x", pady=(3, 0))
        ttk.Label(condition_row, text="条件", width=6).pack(side="left")
        ttk.Entry(condition_row, textvariable=self.cond).pack(
            side="left", fill="x", expand=True
        )
        ttk.Button(
            condition_row,
            text="条件を作る…",
            command=lambda: show_condition_builder(
                self.win, self.cond, self.project or {}, preset.get("variables", {})
            ),
        ).pack(side="left", padx=(6, 0))
        condition_hint = ttk.Label(
            conditions,
            text='例: @TYPE == "A"。空欄なら作図対象の行に適用。',
            style="Muted.TLabel", wraplength=350,
        )
        condition_hint.pack(anchor="w", pady=(4, 0))
        conditions.bind("<Configure>", lambda e: condition_hint.configure(wraplength=max(160, e.width)))
        condition_open = [bool(self.cond.get().strip())]

        def toggle_conditions():
            condition_open[0] = not condition_open[0]
            if condition_open[0]:
                conditions.pack(fill="x", pady=(6, 0))
            else:
                conditions.pack_forget()
            condition_button.configure(
                text="▾ 条件" if condition_open[0] else
                ("▸ 条件あり" if self.cond.get().strip() else "▸ 条件を追加")
            )

        self.conditions_actions = ttk.Frame(self.conditions_panel)
        self.conditions_actions.pack(fill="x", pady=(8, 0))
        self.condition_button = condition_button = ttk.Button(self.conditions_actions, command=toggle_conditions, style="Compact.TButton")
        condition_button.pack(side="left", fill="x", expand=True)
        self.preview_through = tk.BooleanVar(
            value=getattr(self.win._root(), "_command_preview_through", False)
        )
        self.preview_through_button = ttk.Checkbutton(
            self.conditions_actions,
            text="選択したコマンドまで表示",
            variable=self.preview_through,
            command=self.change_preview_mode,
        )
        self.preview_through_button.pack(side="right", padx=(8, 0))
        if condition_open[0]:
            conditions.pack(fill="x", pady=(6, 0))
        condition_button.configure(
            text="▾ 条件" if condition_open[0] else "▸ 条件を追加"
        )
        self.cond.trace_add(
            "write",
            lambda *_: condition_button.configure(
                text="▾ 条件" if condition_open[0] else
                ("▸ 条件あり" if self.cond.get().strip() else
                 "▸ 条件を追加")
            ),
        )
        bar = ttk.Frame(self.win, padding=12)
        bar.pack(side="bottom", fill="x", before=self.command_panes)
        ttk.Button(bar, text="キャンセル", command=self.cancel).pack(side="left")
        ttk.Button(
            bar,
            text="ブロックを反映" if self.unified else "プリセットを確定",
            style="Primary.TButton",
            command=self.save,
        ).pack(side="right")
        self.preview_frame = preview_frame = ttk.Frame(self.command_panes)
        self.command_panes.add(preview_frame, weight=1)
        self.preview_label = ttk.Label(
            preview_frame, text="選択したコマンドのプレビュー",
            style="Muted.TLabel", padding=(8, 4), wraplength=400,
        )
        self.preview_label.pack(side="bottom", fill="x")
        self.preview_canvas = DrawingCanvas(preview_frame, width=320, height=320, space_tabs=True)
        self.preview_canvas.pack(fill="both", expand=True, padx=(8, 0))
        self.preview_canvas.on_edit_command=self.edit_preview_command
        self.preview_tools = ttk.Frame(self.preview_canvas, padding=4, style="Preview.TFrame")
        self.preview_tools.place(relx=1, rely=1, x=-12, y=-10, anchor="se")
        self.preview_canvas.set_overlay_controls(self.preview_tools)
        self.actual_color_toggle = self.preview_canvas.make_color_toggle(self.preview_tools)
        self.actual_color_toggle.pack(side="left", padx=3)
        preview_frame.bind(
            "<Configure>",
            lambda event: self.preview_label.configure(wraplength=max(120, event.width - 16)),
        )
        self.list = CommandList(
            command_page,
            copy.deepcopy(next((b["commands"] for b in self.working_blocks if b.get("id") == preset.get("id")), preset.get("commands", []))) if self.unified else copy.deepcopy(preset.get("commands", [])),
            self.working_blocks,
            self.show_preview,
            self.queue_preview,
            project,
            dict(preset.get("variables", {})),
            folder_id=preset.get("folder_id", ""),
            previous_blocks=self.working_blocks[:next((i for i,b in enumerate(self.working_blocks) if b.get("id")==preset.get("id")),0)] if self.unified else (),
            owner_block_id=preset.get("id"),
        )
        self.list.space_provider=lambda:self.drawing_space.get() if hasattr(self,'drawing_space') else 'Model'
        self.list.tree.tag_configure("previewed", background="#edf3ff")
        for var in (self.name, self.cond, *((self.enabled,) if not self.unified else ())):
            var.trace_add("write", lambda *_: self.queue_preview())
        self.queue_preview()

    def edit_preview_command(self, item):
        if not self.unified:return
        from preview_command_edit import edit_rendered_command
        try:
            trial,_=self.trial()
            updated=edit_rendered_command(self.win,trial,item)
            if updated is None:return
            self.list.snapshot()
            replace_collection(self.working_blocks,updated['blocks'])
            owner=next(b for b in self.working_blocks if b['id']==self.preset['id'])
            self.list.commands[:]=copy.deepcopy(owner['commands'])
            self.list.refresh(item.get('command_index',0))
            self.win.lift()
        except (ValueError,KeyError,IndexError) as exc:
            messagebox.showerror('コマンドの編集',str(exc),parent=self.win)

    def block_operation(self, operation):
        """Operate on a copy of pending edits; only a confirmed dialog commits."""
        from block_operations_ui import split_dialog, join_dialog
        trial, index = self.trial()
        errors = validate_sequential_project(trial)
        if errors:
            return messagebox.showerror("構成の確認", "\n".join(errors[:8]), parent=self.win)
        def apply(updated, selected):
            replace_collection(self.blocks, updated["blocks"])
            self.win.destroy()
            self.on_close()
        if operation == "split":
            return split_dialog(self.win, trial, index, apply)
        return join_dialog(self.win, trial, [index], apply)

    def fit_command_panes(self, event):
        if event.width < 650:
            return
        position = self.command_panes.sashpos(0) if self._split_initialized else int(event.width * 0.52)
        self.command_panes.sashpos(0, max(320, min(position, event.width - 320)))
        self._split_initialized = True

    def change_preview_mode(self):
        self.win._root()._command_preview_through = self.preview_through.get()
        self.show_preview(self.list.indices())

    def queue_preview(self):
        if hasattr(self, "preview_canvas") and self._preview_job is None and self.win.winfo_exists():
            self._preview_job = self.win.after_idle(self.run_queued_preview)

    def run_queued_preview(self):
        self._preview_job = None
        if self.win.winfo_exists():
            self.show_preview(self.list.indices())

    def cancel_preview_job(self, event):
        if event.widget is self.win and self._preview_job is not None:
            self.win.after_cancel(self._preview_job)
            self._preview_job = None

    def current(self):
        result = dict(
            self.preset,
            name=self.name.get().strip(),
            condition=self.cond.get().strip(),
            commands=copy.deepcopy(self.list.commands),
        )

        if self.unified:
            destination=self.drawing_space.get()
            if destination=='コマンドに従う':result.pop('drawing_space',None)
            else:result['drawing_space']='Model' if destination=='モデル' else destination
            result.pop("enabled", None)
            result.pop("draw", None)
        else:
            result["enabled"] = self.enabled.get()
        return result

    def trial(self):
        trial = copy.deepcopy(self.project)
        if self.unified:
            trial["blocks"] = copy.deepcopy(self.working_blocks)
            index = index_of(trial, self.preset["id"])
            trial["blocks"][index] = self.current()
        else:
            index = next(
                i for i, p in enumerate(self.project["presets"]) if p is self.preset
            )
            trial["presets"][index] = self.current()
            trial["blocks"] = copy.deepcopy(self.working_blocks)
        return trial, index

    def show_preview(self, indices):
        if not hasattr(self, "preview_canvas") or not self.win.winfo_exists():
            return
        self.preview_canvas.set_color_resources(self.project or {})
        self.preview_canvas.set_items([])
        through = self.preview_through.get()
        end = max(indices) if indices else None
        for node in self.list.tree.get_children():
            active = through and end is not None and int(node) <= end
            tags=[tag for tag in self.list.tree.item(node,"tags") if tag != "previewed"]
            if active:tags.append("previewed")
            self.list.tree.item(node,tags=tuple(tags))
        if through and end is None:
            self.preview_canvas.set_items([], message="確認するコマンドを選択してください")
            self.preview_label.configure(text="先頭から選択したコマンドまでを表示")
            return
        if not self.project or not self.selected_rows:
            self.preview_label.configure(text="入力表の「SCR出力」列にチェックしてください")
            return
        try:
            trial, pi = self.trial()
            preview_indices = list(range(end + 1)) if through else indices
            if through:
                # Later unfinished commands must not prevent checking this stage.
                collection = "blocks" if self.unified else "presets"
                from setting_references import registry, localize
                commands = trial[collection][pi]["commands"]
                trial[collection][pi]["commands"] = localize(commands[:end+1], registry(commands))
            if self.unified:
                for i, block in enumerate(trial["blocks"]):
                    block["draw"] = i <= pi
            events = []
            _, items = compile_project(
                trial, self.selected_rows[:1], diagnostics=events
            )
            events = [
                e
                for e in events
                if e.get("block_index" if self.unified else "preset_index") == pi
                and (not preview_indices or e.get("command_index") in preview_indices)
            ]
            items = [
                a
                for a in items
                if (a.get("guide") and a["block_index" if self.unified else "preset_index"] != pi) or (a["block_index" if self.unified else "preset_index"] == pi
                and (not preview_indices or a["command_index"] in preview_indices))
            ]
            custom_count = sum(e["type"] == "CUSTOM" for e in events)
            self.preview_canvas.set_items(
                items,
                message="登録コマンドの図形はプレビュー対象外です。生成SCRで確認してください。"
                if custom_count
                else None,
            )
            if not self._space_selected and items:
                tabs=self.preview_canvas.space_tabs
                destination=items[-1].get('cad_space','Model')
                if tabs and destination in tabs.pages:
                    tabs.notebook.select(tabs.pages[destination]);tabs.changed()
                self._space_selected=True
            self.preview_label.configure(
                text=(f"ここまで {end + 1}/{len(self.list.commands)}コマンド · " if through else "編集中の値を反映 · ")
                + f"{self.selected_rows[0] + 1}行目 / 標準{sum(not a.get('guide') for a in items)}図形"
                + (f" / ガイド{sum(bool(a.get('guide')) for a in items)}図形" if any(a.get("guide") for a in items) else "")
                + (f" / 登録{custom_count}件はSCRのみ" if custom_count else "")
            )
        except Exception as exc:
            self.preview_label.configure(text="プレビュー: " + str(exc)[:110])

    def cancel(self):
        if (
            self.current() != self.preset or self.working_blocks != self.blocks
        ) and not messagebox.askyesno(
            "変更の破棄",
            "ブロックの変更を破棄しますか？"
            if self.unified
            else "プリセットの変更を破棄しますか？",
            parent=self.win,
        ):
            return
        self.win.destroy()

    def save(self):
        current = self.current()
        if not current["name"]:
            return messagebox.showerror(
                "名前",
                "ブロック名を入力してください"
                if self.unified
                else "プリセット名を入力してください",
                parent=self.win,
            )
        if self.project:
            trial, _ = self.trial()
            errors = validate_sequential_project(trial) if self.unified else validate_project(trial)
            if errors:
                return messagebox.showerror(
                    "構成の確認", "\n".join(errors[:8]), parent=self.win
                )
        if self.unified:
            if self.project:
                replace_collection(self.blocks, trial["blocks"])
            else:
                index = next(
                    i
                    for i, block in enumerate(self.working_blocks)
                    if block["id"] == current["id"]
                )
                self.working_blocks[index] = current
                replace_collection(self.blocks, self.working_blocks)
        else:
            self.preset.clear()
            self.preset.update(current)
            replace_collection(self.blocks, self.working_blocks)
        self.win.destroy()
        self.on_close()

