"""SELECT-based polyline editing with real circular-arc bulges."""
import copy,math
ACTIONS=('ポリライン化','結合','閉じる','結合して閉じる')
FIELDS=[('polyline_action','ポリライン化'),('join_tolerance','0.001')]

def arc_geometry(a,b,bulge):
    dx,dy=b[0]-a[0],b[1]-a[1];chord=math.hypot(dx,dy)
    if chord==0 or abs(bulge)<1e-14:raise ValueError('円弧の端点・曲率が不正です')
    factor=(1-bulge*bulge)/(4*bulge)
    center=((a[0]+b[0])/2-dy*factor,(a[1]+b[1])/2+dx*factor)
    return center,chord*(1+bulge*bulge)/(4*abs(bulge)),math.atan2(a[1]-center[1],a[0]-center[0]),4*math.atan(bulge)

def geometry(source):
    if source.get('entity_parent') is not None or source.get('segments'):
        raise ValueError('連続線の一部分・分割線は未対応です。線分全体を選択してください。')
    kind=source.get('display_type',source['type']);c=source['coords']
    if kind=='ARC':
        sweep=source['sweep']
        if not 0<abs(sweep)<360:raise ValueError('全円は円弧ポリラインへ変換できません。')
        start=math.radians(source['start_angle']);end=start+math.radians(sweep)
        vertices=[(c[0]+c[2]*math.cos(t),c[1]+c[2]*math.sin(t)) for t in (start,end)]
        return vertices,[math.tan(math.radians(sweep)/4),0.],False
    if kind=='RECTANGLE':
        x,y,u,v=c;return [(x,y),(u,y),(u,v),(x,v)],[0.]*4,True
    if kind not in ('LINE','POLYLINE'):raise ValueError('線分・円弧・ポリラインを選択してください。')
    vertices=list(zip(c[::2],c[1::2]));closed=bool(source.get('closed',False))
    bulges=list(source.get('bulges',[0.]*len(vertices)))
    if len(vertices)<2 or len(bulges)!=len(vertices):raise ValueError('ポリラインの頂点データが不正です。')
    if any(not math.isfinite(float(z)) for p in vertices for z in p) or any(not math.isfinite(float(x)) for x in bulges):raise ValueError('座標・円弧の曲率は有限値で指定してください。')
    return vertices,bulges,closed

def reversed_path(path):
    v,b,c=path
    if c:raise ValueError('閉じたポリラインと他の図形は結合できません。')
    return list(reversed(v)),[-x for x in reversed(b[:-1])]+[0.],False

def joined(paths,tolerance):
    if len(paths)==1:return copy.deepcopy(paths[0])
    if any(p[2] for p in paths):raise ValueError('閉じたポリラインと他の図形は結合できません。')
    # Cluster endpoints, then require a connected non-branching graph.
    ends=[p for v,_,_ in paths for p in (v[0],v[-1])];parents=list(range(len(ends)))
    def root(i):
        while parents[i]!=i:parents[i]=parents[parents[i]];i=parents[i]
        return i
    for i,p in enumerate(ends):
        for j in range(i):
            if math.dist(p,ends[j])<=tolerance:parents[root(i)]=root(j)
    edges=[];adj={}
    for i in range(len(paths)):
        a,b=root(2*i),root(2*i+1);edges.append((a,b))
        for n in (a,b):adj.setdefault(n,[]).append(i)
    if any(len(es)>2 for es in adj.values()):raise ValueError('端点に分岐があるため結合できません。対象を分けて選択してください。')
    leaves=[n for n,es in adj.items() if len(es)==1];start=leaves[0] if leaves else edges[0][0]
    vertex=start;used=set();vs=[];bs=[]
    while len(used)<len(paths):
        choices=[i for i in adj[vertex] if i not in used]
        if not choices:raise ValueError('離れた図形があるため1本に結合できません。端点と許容差を確認してください。')
        i=choices[0];used.add(i);a,b=edges[i]
        v,bulges,_=copy.deepcopy(paths[i]) if a==vertex else reversed_path(paths[i])
        if not vs:vs=v;bs=bulges
        else:bs[-1]=bulges[0];vs.extend(v[1:]);bs.extend(bulges[1:])
        vertex=b if vertex==a else a
    closed=not leaves and vertex==start
    if closed:vs.pop();bs.pop()
    return vs,bs,closed

def plan(sources,action,tolerance):
    if action not in ACTIONS:raise ValueError('ポリライン編集の操作を選択してください。')
    if not math.isfinite(tolerance) or not 0<=tolerance<=100:raise ValueError('結合許容差は0〜100の有限値にしてください。')
    if not sources:raise ValueError('先にSELECTで対象を選択してください。')
    paths=[geometry(s) for s in sources];join=action in ('結合','結合して閉じる')
    if join:
        for key in ('effective_layer','layer','color','linetype','linetype_scale','lineweight'):
            if any(s.get(key)!=sources[0].get(key) for s in sources[1:]):raise ValueError('属性が異なる図形は結合できません。レイヤー・色・線種などを揃えてください。')
        result=[joined(paths,tolerance)]
    else:result=copy.deepcopy(paths)
    if action in ('閉じる','結合して閉じる'):
        for i,(vs,bs,closed) in enumerate(result):
            if len(vs)<3 and not any(abs(x)>1e-14 for x in bs):raise ValueError('閉じるには3点以上、または円弧を含む経路が必要です。複数の線分は「結合して閉じる」を使用してください。')
            result[i]=(vs,bs,True)
    return result

def sampled(vs,bulges,closed):
    points=[];midpoints={}
    pairs=list(zip(vs,vs[1:]))+([(vs[-1],vs[0])] if closed else [])
    for i,(a,b) in enumerate(pairs):
        bulge=bulges[i]
        if not points:points.append(a)
        if abs(bulge)<1e-14:
            points.append(b);midpoints[f'区間{i+1}中点']=((a[0]+b[0])/2,(a[1]+b[1])/2);continue
        center,r,start,sweep=arc_geometry(a,b,bulge)
        fractions={j/max(2,math.ceil(abs(sweep)/math.radians(2))) for j in range(1,max(2,math.ceil(abs(sweep)/math.radians(2)))+1)}
        for angle in (0,math.pi/2,math.pi,3*math.pi/2):
            travel=(angle-start)%(2*math.pi) if sweep>0 else -((start-angle)%(2*math.pi))
            if 0<=travel/sweep<=1:fractions.add(travel/sweep)
        points.extend((center[0]+r*math.cos(start+t*sweep),center[1]+r*math.sin(start+t*sweep)) for t in sorted(fractions))
        midpoints[f'区間{i+1}中点']=(center[0]+r*math.cos(start+sweep/2),center[1]+r*math.sin(start+sweep/2))
    return tuple(z for p in points for z in p),midpoints

def native(command,tolerance,expected_count,close,input_count):
    from selection_sets import reference_lisp
    from extended_commands import quoted
    ref=command.get('selection_ref','@previous');key='*acadstadio-last-selection*' if ref=='@previous' else quoted(ref)
    action=command['polyline_action'];joining=action in ('結合','結合して閉じる')
    # Preflight all entities before an undo mark. PEDIT preserves actual arc bulges.
    body=reference_lisp(ref,'picked')+f'(setq key {key} originals nil index 0) '
    body+=f'(if (/= (sslength picked) {input_count}) (error "AcadStadio: CAD selection differs from preview")) '
    body+='(repeat (sslength picked) (setq e (ssname picked index) index (1+ index) data (entget e) kind (cdr (assoc 0 data))) '
    body+='(if (not (member kind (list "LINE" "ARC" "LWPOLYLINE" "POLYLINE"))) (error "AcadStadio: Select lines, arcs and 2D polylines only")) '
    body+='(if (and (= kind "POLYLINE") (/= 0 (logand 88 (cdr (assoc 70 data))))) (error "AcadStadio: 3D polyline is not supported")) '
    body+='(if (and (assoc 210 data) (not (equal (cdr (assoc 210 data)) (list 0.0 0.0 1.0) 1e-10))) (error "AcadStadio: Non-world-plane geometry is not supported")) '
    body+='(setq originals (cons e originals))) '
    body+='(if (or (= 0 (logand 1 (getvar "UNDOCTL"))) (/= 0 (logand 8 (getvar "UNDOCTL")))) (error "AcadStadio: Enable undo and finish the current undo group")) '
    body+='(command-s "_.UNDO" "_Mark") (command-s "_.UNDO" "_Begin") (setq saved (getvar "PEDITACCEPT")) '
    body+='(setq outcome (vl-catch-all-apply \'(lambda () (setvar "PEDITACCEPT" 1) (setq live nil) '
    body+='(foreach e (reverse originals) (setq oldlast (entlast)) (if (member (cdr (assoc 0 (entget e))) (list "LINE" "ARC")) (command-s "_.PEDIT" e "")) '
    body+='(setq made (if (entget e) e (entlast))) (if (or (not made) (not (member (cdr (assoc 0 (entget made))) (list "POLYLINE" "LWPOLYLINE")))) (error "AcadStadio: Polyline conversion failed")) (setq live (cons made live))) '
    if joining:
        body+='(setq picked (ssadd) oldlast (entlast)) (foreach e live (ssadd e picked)) '
        body+=f'(command-s "_.PEDIT" "_Multiple" picked "" "_Join" {tolerance:.12g} "") '
        body+='(setq live (vl-remove-if-not \'entget live)) '
        body+='(if (and (not (equal oldlast (entlast))) (not (member (entlast) live))) (setq live (cons (entlast) live))) '
    body+=f'(if (/= (length live) {expected_count}) (error "AcadStadio: Could not join all selected objects; operation cancelled")) '
    if close:body+='(foreach e live (command-s "_.PEDIT" e "_Close" "")) '
    body+='(foreach e live (if (not (member (cdr (assoc 0 (entget e))) (list "POLYLINE" "LWPOLYLINE"))) (error "AcadStadio: Result is not a polyline"))) '
    if close:body+='(foreach e live (if (= 0 (logand 1 (cdr (assoc 70 (entget e))))) (error "AcadStadio: Could not close polyline"))) '
    body+='live) nil)) (setvar "PEDITACCEPT" saved) (command-s "_.UNDO" "_End") '
    body+='(if (vl-catch-all-error-p outcome) (progn (command-s "_.UNDO" "_Back") (error (vl-catch-all-error-message outcome)))) '
    body+='(setq old (assoc key *acadstadio-selections*) *acadstadio-selections* (subst (cons key live) old *acadstadio-selections*)) '
    return '((lambda (/ picked key originals index e data kind saved outcome live old oldlast made) (vl-load-com) '+body+' (princ)))'

def emit(command,values,number,items):
    from selection_sets import selected_members
    sources=selected_members(command,values)
    action=command.get('polyline_action','ポリライン化');tolerance=float(number(command.get('join_tolerance','0.001'),values))
    plans=plan(sources,action,tolerance)
    rendered=native(dict(command,polyline_action=action),tolerance,len(plans),action in ('閉じる','結合して閉じる') or all(p[2] for p in plans),len(sources))
    masters=[sources[0]] if action in ('結合','結合して閉じる') else sources
    # All checks and native generation succeeded; now apply the preview changes.
    for source in items:source.pop('polyline_edit_result',None)
    for master,(vs,bs,closed) in zip(masters,plans):
        curve,points=sampled(vs,bs,closed)
        for field in ('start_angle','sweep','segments','block_geometry','reference_points'):master.pop(field,None)
        master.update(polyline_edit_result=True,display_type='POLYLINE',coords=tuple(z for p in vs for z in p),closed=closed,bulges=list(bs),curve=curve,reference_points=points)
    for source in sources:
        if not any(source is m for m in masters):source['operation_deleted']=True
    state=values['__selection_state__'];ref=command.get('selection_ref','@previous');key=state['last'] if ref=='@previous' else ref
    state['sets'][key]=list(masters)
    return [rendered],sources


def components(source):
    """EXPLODE preview: produce arcs, never chords, from a bulged polyline."""
    vs,bulges,closed=geometry(source)
    result=[]
    pairs=list(zip(vs,vs[1:]))+([(vs[-1],vs[0])] if closed else [])
    style={k:source[k] for k in ('layer','effective_layer','color','linetype','linetype_scale','lineweight') if k in source}
    for i,(a,b) in enumerate(pairs):
        if abs(bulges[i])<1e-14:result.append(dict(style,type='LINE',display_type='LINE',coords=(*a,*b)))
        else:
            center,r,start,sweep=arc_geometry(a,b,bulges[i])
            if sweep<0:start+=sweep;sweep=-sweep
            result.append(dict(style,type='ARC',display_type='ARC',coords=(*center,r),start_angle=math.degrees(start)%360,sweep=math.degrees(sweep)))
    return result


def point_references(source):
    """Exact arc-length midpoint and exact segment midpoints for references."""
    vs,bs,closed=geometry(source)
    pairs=list(zip(vs,vs[1:]))+([(vs[-1],vs[0])] if closed else [])
    lengths=[];positions=[];result={}
    for i,(a,b) in enumerate(pairs):
        if abs(bs[i])<1e-14:
            length=math.dist(a,b);position=lambda t,a=a,b=b:(a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t)
        else:
            center,r,start,sweep=arc_geometry(a,b,bs[i]);length=r*abs(sweep)
            position=lambda t,c=center,r=r,s=start,w=sweep:(c[0]+r*math.cos(s+w*t),c[1]+r*math.sin(s+w*t))
        lengths.append(length);positions.append(position);result[f'区間{i+1}中点']=position(.5)
    remaining=sum(lengths)/2
    for length,position in zip(lengths,positions):
        if remaining<=length:
            result['中点']=position(remaining/length if length else 0);break
        remaining-=length
    return result
