# 現在版：1.73.0-beta113

追加はPEDIT（ポリライン編集）。polyline_edit.pyが純粋な接続計画、bulge付き経路、真の中点、円弧を維持する分解、PEDITのSCR生成、選択集合の更新を担当。

- SELECTのOPERATORSへ登録。直前SELECTの作成制限・削除保護に含める。
- engine._emitでSELECTの次にPEDITを処理。選択対象のプレビューを検査後、先頭の経路をインプレース更新。他の結合対象は削除扱いにして点参照を更新。
- プレビューはbulgesとcurveを持つ。preview/edit_preview/dash_preview、copy/mirror/affine、EXPLODEに円弧の保持を反映。
- 後続で使用するSELECTの集合を更新。PEDITは条件／繰返しの共通フローにも従う。
- UIは4つの操作を選択。結合許容差は結合操作だけ表示。
- AutoCAD実機は未実施。native PEDITの応答・UNDOの復元は生成コードとして検証している段階。

まずREADME.md、docs/POLYLINE_EDIT.md、docs/VALIDATION.mdを参照。過去のSELECT簡素化・内部バッチ・モデル/レイアウト視点・レイアウトフロー・ドロップ/ビルド対策は維持。
